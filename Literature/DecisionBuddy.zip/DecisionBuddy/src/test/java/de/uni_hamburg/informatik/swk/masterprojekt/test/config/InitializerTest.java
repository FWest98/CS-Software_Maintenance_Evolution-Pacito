package de.uni_hamburg.informatik.swk.masterprojekt.test.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production.MVCInitializer;

/**
 * Tests the initializer.
 * 
 * @author biryuk
 *
 */
public class InitializerTest extends MVCInitializer
{
    /**
     * Tests root config.
     * 
     * @throws Exception exception
     */
    @Test
    public void testGetRootConfig() throws Exception
    {
        Class<?>[] classes = getRootConfigClasses();
        for (Class<?> class1 : classes)
        {
            System.out.println(class1.toString());
        }
    }

    /**
     * Tests config classes.
     * 
     * @throws Exception exception
     */
    @Test
    public void testGetServletConfigClasses() throws Exception
    {
        Class<?>[] classes = getServletConfigClasses();
        for (Class<?> class1 : classes)
        {
            System.out.println(class1.toString());
        }
    }

    /**
     * Tests servlet mappings.
     * 
     * @throws Exception exception
     */
    @Test
    public void testServletMappings() throws Exception
    {
        String[] mappings = getServletMappings();
        for (String string : mappings)
        {
            assertNotEquals("/*", string);
            assertEquals("/", string);
        }
    }
}