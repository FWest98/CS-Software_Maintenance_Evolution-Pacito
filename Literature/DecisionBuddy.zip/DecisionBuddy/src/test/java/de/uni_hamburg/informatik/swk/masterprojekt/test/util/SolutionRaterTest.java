package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.QualityGoalDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RatingDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.SolutionRater;

/**
 * Tests the SolutionScore.
 * 
 * @author Tim
 *
 */

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class SolutionRaterTest
{
    @Autowired
    private RatingDAO ratingDAO;

    @Autowired
    private QualityGoalDAO qualityGoalDAO;

    @Autowired
    private FrameworkDAO frameworkDAO;

    private QualityGoal qualityGoal1;
    private QualityGoal qualityGoal2;

    private Framework testSolution1;
    private Framework testSolution2;

    @Autowired
    private SolutionRater solutionScore;

    /**
     * Creates test projects and issues.
     */
    @Before
    public void setUp()
    {
        qualityGoal1 = qualityGoalDAO.findOne(1L);
        assertNotNull(qualityGoal1);

        qualityGoal2 = qualityGoalDAO.findOne(2L);
        assertNotNull(qualityGoal2);

        testSolution1 = new Framework();
        testSolution1.setName("Test");
        testSolution1.setShortDescription("test");
        testSolution1.setCreator("Tim");
        testSolution1.setCreationDate(new Date());
        testSolution1 = frameworkDAO.saveAndFlush(testSolution1);
        assertNotNull(testSolution1);

        testSolution2 = new Framework();
        testSolution2.setName("Test2");
        testSolution2.setShortDescription("test");
        testSolution2.setCreator("Tim");
        testSolution2.setCreationDate(new Date());
        testSolution2 = frameworkDAO.saveAndFlush(testSolution2);
        assertNotNull(testSolution2);
    }

    /**
     * Create a new rating for a solution.
     * 
     * @param solution that is rated.
     * @param ratingValue for the rating.
     * @return new rating
     */
    public Rating getTestRating(Solution solution, String ratingValue)
    {
        Rating rating = new Rating();
        rating.setSolution(solution);
        rating.setCreator("Tim");
        rating.setCreationDate(new Date());
        rating.setReasoning("Reasons.");
        rating.setRating(ratingValue);
        return rating;
    }

    /**
     * Test if the right Ratings for a Solution can be found.
     */
    @Test
    public void testComputeUserScoreForSolutionWithNoRatings()
    {
        final Float assertValue1 = 0.0f;

        List<WeightedQualityGoal> weightedQualityGoals = new ArrayList<WeightedQualityGoal>();
        WeightedQualityGoal weightedQualityGoal = new WeightedQualityGoal();
        weightedQualityGoal.setQualityGoal(qualityGoal1);
        weightedQualityGoal.setWeight(1);
        weightedQualityGoals.add(weightedQualityGoal);
        assertTrue(assertValue1.equals(solutionScore.getSolutionUserScore(testSolution1, weightedQualityGoals)));
    }

    /**
     * Test if the right Ratings for a Solution can be found.
     */
    @Test
    public void testComputeUserScoreForSolutionSingleQG()
    {
        // final Float assertValue1 = 0.5f;
        // final Float assertValue2 = 0.25f;
        // Create and save a new Ratings.
        Rating rating1 = getTestRating(testSolution1, "good");
        rating1.setQualityGoal(qualityGoal1);
        assertNull(rating1.getId());
        rating1 = ratingDAO.saveAndFlush(rating1);
        assertNotNull(rating1.getQualityGoal());
        assertNotNull(rating1.getId());
        assertTrue(rating1.getId() > 0);

        // Create and save a new Ratings.
        Rating rating2 = getTestRating(testSolution1, "average");
        rating2.setQualityGoal(qualityGoal1);
        assertNull(rating2.getId());
        rating2 = ratingDAO.saveAndFlush(rating2);
        assertNotNull(rating2.getId());
        assertNotNull(rating2.getQualityGoal());
        assertTrue(rating2.getId() > 0);

        // Create and save a new Ratings.
        Rating rating3 = getTestRating(testSolution1, "weak");
        rating3.setQualityGoal(qualityGoal1);
        assertNull(rating3.getId());
        rating3 = ratingDAO.saveAndFlush(rating3);
        assertNotNull(rating3.getId());
        assertNotNull(rating3.getQualityGoal());
        assertTrue(rating3.getId() > 0);

        // Create and save a new Ratings.
        Rating rating4 = getTestRating(testSolution1, "weak");
        rating4.setQualityGoal(qualityGoal2);
        assertNull(rating4.getId());
        rating4 = ratingDAO.saveAndFlush(rating4);
        assertNotNull(rating4.getId());
        assertNotNull(rating4.getQualityGoal());
        assertTrue(rating4.getId() > 0);

        List<WeightedQualityGoal> weightedQualityGoals = new ArrayList<WeightedQualityGoal>();
        WeightedQualityGoal weightedQualityGoal = new WeightedQualityGoal();
        weightedQualityGoal.setQualityGoal(qualityGoal1);
        weightedQualityGoal.setWeight(1);
        weightedQualityGoals.add(weightedQualityGoal);
        // assertTrue(assertValue1.equals(solutionScore.getSolutionUserScore(testSolution1,
        // weightedQualityGoals)));
        weightedQualityGoals.remove(weightedQualityGoal);
        weightedQualityGoal.setQualityGoal(qualityGoal2);
        weightedQualityGoals.add(weightedQualityGoal);
        // assertTrue(assertValue2.equals(solutionScore.getSolutionUserScore(testSolution1,
        // weightedQualityGoals)));
    }

    /**
     * Test if the right Ratings for a Solution can be found.
     */
    @Test
    public void testComputeUserScoreForSolutionMultipleQualityGoals()
    {
        final int nine = 9;
        // Create and save a new Ratings.
        Rating rating1 = getTestRating(testSolution1, "superb");
        rating1.setQualityGoal(qualityGoal1);
        assertNull(rating1.getId());
        rating1 = ratingDAO.saveAndFlush(rating1);
        assertNotNull(rating1.getQualityGoal());
        assertNotNull(rating1.getId());
        assertTrue(rating1.getId() > 0);

        // Create and save a new Ratings.
        Rating rating2 = getTestRating(testSolution1, "unusable");
        rating2.setQualityGoal(qualityGoal2);
        assertNull(rating2.getId());
        rating2 = ratingDAO.saveAndFlush(rating2);
        assertNotNull(rating2.getId());
        assertNotNull(rating2.getQualityGoal());
        assertTrue(rating2.getId() > 0);

        List<WeightedQualityGoal> weightedQualityGoals = new ArrayList<WeightedQualityGoal>();
        WeightedQualityGoal weightedQualityGoal1 = new WeightedQualityGoal();
        weightedQualityGoal1.setQualityGoal(qualityGoal1);
        weightedQualityGoal1.setWeight(nine);
        weightedQualityGoals.add(weightedQualityGoal1);
        // Assert that score for first QualityGoal is correct
        assertTrue(solutionScore.getSolutionUserScore(testSolution1, weightedQualityGoals).equals(1F));
        weightedQualityGoals.remove(weightedQualityGoal1);
        WeightedQualityGoal weightedQualityGoal2 = new WeightedQualityGoal();
        weightedQualityGoal2.setQualityGoal(qualityGoal2);
        weightedQualityGoal2.setWeight(1);
        weightedQualityGoals.add(weightedQualityGoal2);
        // Assert that score for second QualityGoal is correct
        // assertTrue(solutionScore.getSolutionUserScore(testSolution1,
        // weightedQualityGoals).equals(0F));
        weightedQualityGoals.add(weightedQualityGoal1);
        // Assert that score for both QualityGoals is correct
        // assertTrue(solutionScore.getSolutionUserScore(testSolution1,
        // weightedQualityGoals).equals(assertValue));
    }

    /**
     * Test if the right Ratings for a Solution can be found.
     */
    @Test
    public void testComputeUserScoreMultipleQualityGoalsOneWithoutRating()
    {
        final int nine = 9;
        // final Float assertValue = 0.5f;
        // Create and save a new Ratings.
        Rating rating1 = getTestRating(testSolution1, "superb");
        rating1.setQualityGoal(qualityGoal1);
        assertNull(rating1.getId());
        rating1 = ratingDAO.saveAndFlush(rating1);
        assertNotNull(rating1.getQualityGoal());
        assertNotNull(rating1.getId());
        assertTrue(rating1.getId() > 0);

        // Create and save a new Ratings.
        Rating rating2 = getTestRating(testSolution1, "unusable");
        rating2.setQualityGoal(qualityGoal1);
        assertNull(rating2.getId());
        rating2 = ratingDAO.saveAndFlush(rating2);
        assertNotNull(rating2.getId());
        assertNotNull(rating2.getQualityGoal());
        assertTrue(rating2.getId() > 0);

        List<WeightedQualityGoal> weightedQualityGoals = new ArrayList<WeightedQualityGoal>();
        WeightedQualityGoal weightedQualityGoal1 = new WeightedQualityGoal();
        weightedQualityGoal1.setQualityGoal(qualityGoal1);
        weightedQualityGoal1.setWeight(nine);
        weightedQualityGoals.add(weightedQualityGoal1);
        // Assert that score for first QualityGoal is correct
        // assertTrue(solutionScore.getSolutionUserScore(testSolution1,
        // weightedQualityGoals).equals(assertValue));
        weightedQualityGoals.remove(weightedQualityGoal1);
        WeightedQualityGoal weightedQualityGoal2 = new WeightedQualityGoal();
        weightedQualityGoal2.setQualityGoal(qualityGoal2);
        weightedQualityGoal2.setWeight(1);
        weightedQualityGoals.add(weightedQualityGoal2);
        // Assert that score for second QualityGoal is correct
        assertTrue(solutionScore.getSolutionUserScore(testSolution1, weightedQualityGoals).equals(0F));
        weightedQualityGoals.add(weightedQualityGoal1);
        // Assert that score for both QualityGoals is correct
        // assertTrue(solutionScore.getSolutionUserScore(testSolution1,
        // weightedQualityGoals).equals(assertValue));
    }
}