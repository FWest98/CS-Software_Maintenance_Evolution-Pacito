package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue}
 * class. This class contains no business logic and only toString(), hashCode()
 * and equals() methods are tested.
 * 
 * @author Burak
 *
 */
public class MetricValueTest
{
    private MetricValue metricValue1;
    private MetricValue metricValue2;
    private MetricValue metricValue3;

    /**
     * Creates three MetricValues. MetricValue 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        metricValue1 = new MetricValue();
        metricValue2 = new MetricValue();
        metricValue3 = new MetricValue();

        metricValue1.setId(1L);
        metricValue2.setId(1L);
        metricValue3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testMetricValueToString()
    {
        System.out.println(metricValue1.toString());
    }

    /**
     * Tests the hashCode functionality of a MetricValue, should only be
     * affected by Id.
     */
    @Test
    public void testMetricValueHashcode()
    {
        metricValue1.setValue(1F);
        metricValue2.setValue(1F);
        metricValue3.setValue(2F);
        assertTrue(metricValue1.hashCode() == metricValue1.hashCode());
        assertTrue(metricValue1.hashCode() == metricValue2.hashCode());
        assertFalse(metricValue2.hashCode() == metricValue3.hashCode());
        System.out.println(metricValue1.toString());
        System.out.println(metricValue2.toString());
        System.out.println(metricValue3.toString());
    }

    /**
     * Tests the equals functionality of a MetricValue, should only be affected
     * by Id.
     */
    @Test
    public void testMetricValueEquals()
    {
        assertTrue(metricValue1.equals(metricValue1));
        assertFalse(metricValue1.equals(null));
        assertFalse(metricValue1.equals(new String()));
        assertTrue(metricValue1.equals(metricValue2));
        assertFalse(metricValue1.equals(metricValue3));
    }
}