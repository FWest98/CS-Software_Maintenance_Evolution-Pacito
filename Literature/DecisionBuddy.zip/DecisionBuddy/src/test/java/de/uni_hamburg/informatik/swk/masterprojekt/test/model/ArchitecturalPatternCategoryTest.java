package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Vlad, Tim
 *
 */
public class ArchitecturalPatternCategoryTest
{
    private ArchitecturalPatternCategory architecturalPatternCategory1;
    private ArchitecturalPatternCategory architecturalPatternCategory2;
    private ArchitecturalPatternCategory architecturalPatternCategory3;

    /**
     * Creates three ArchitecturalPatternCategories. 1 and 2 should be equal and
     * 3 different.
     */
    @Before
    public void setUp()
    {
        architecturalPatternCategory1 = new ArchitecturalPatternCategory();
        architecturalPatternCategory2 = new ArchitecturalPatternCategory();
        architecturalPatternCategory3 = new ArchitecturalPatternCategory();

        architecturalPatternCategory1.setId(1L);
        architecturalPatternCategory2.setId(1L);
        architecturalPatternCategory3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testArchitecturalPatternCategoryToString()
    {
        System.out.println(architecturalPatternCategory1.toString());
    }

    /**
     * Tests the hashCode functionality of a ArchitecturalPatternCategory,
     * should only be affected by Id.
     */
    @Test
    public void testArchitecturalPatternCategoryHashcode()
    {
        architecturalPatternCategory1.setDescription("1");
        architecturalPatternCategory2.setDescription("2");
        assertTrue(architecturalPatternCategory1.hashCode() == architecturalPatternCategory1.hashCode());
        assertTrue(architecturalPatternCategory1.hashCode() == architecturalPatternCategory2.hashCode());
        assertFalse(architecturalPatternCategory2.hashCode() == architecturalPatternCategory3.hashCode());
    }

    /**
     * Tests the equals functionality of a ArchitecturalPatternCategory, should
     * only be affected by Id.
     */
    @Test
    public void testArchitecturalPatternCategoryEquals()
    {
        architecturalPatternCategory1.setDescription("1");
        architecturalPatternCategory2.setDescription("2");
        assertTrue(architecturalPatternCategory1.equals(architecturalPatternCategory1));
        assertFalse(architecturalPatternCategory1.equals(null));
        assertFalse(architecturalPatternCategory1.equals(new String()));
        assertTrue(architecturalPatternCategory1.equals(architecturalPatternCategory2));
        assertFalse(architecturalPatternCategory1.equals(architecturalPatternCategory3));
    }
}