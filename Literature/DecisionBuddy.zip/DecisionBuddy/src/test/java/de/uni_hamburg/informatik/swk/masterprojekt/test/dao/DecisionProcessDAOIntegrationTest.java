package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.CommentDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DecisionDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionCandidateDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate;

/**
 * Tests the IssueDAO and the real database.
 * 
 * @author Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class DecisionProcessDAOIntegrationTest
{
    @Autowired
    private IssueDAO issueDAO;

    @Autowired
    private ProjectDAO projectDao;

    // @Autowired
    // private SolutionDAO solutionDao;

    @Autowired
    private SolutionCandidateDAO solutionCandidateDAO;

    @Autowired
    private DecisionDAO decisionDAO;

    @Autowired
    private CommentDAO commentDAO;

    @Autowired
    private FrameworkDAO frameworkDAO;

    private Project testProject = new Project();
    private Issue testIssue1 = new Issue();
    private Issue testIssue2 = new Issue();
    private Framework testSolution = new Framework();

    /**
     * Creates test projects and issues.
     */
    @Before
    public void setUp()
    {
        testProject.setName("Masterprojekt");
        testProject.setDescription("Our Master project");
        testProject.setCreator("Lucas");
        testProject.setCreationDate(new Date());
        testProject.setLastModifier("Lucas");
        testProject.setModificationDate(new Date());
        testProject = projectDao.save(testProject);

        testIssue1.setName("Issue1");
        testIssue1.setDescription("Testissue 1");
        testIssue1.setCreator("Tim");
        testIssue1.setCreationDate(new Date());
        testIssue1.setProject(testProject);
        testIssue1 = issueDAO.save(testIssue1);

        testIssue2.setName("Issue2");
        testIssue2.setDescription("Testissue 2");
        testIssue2.setCreator("Tim");
        testIssue2.setCreationDate(new Date());
        testIssue2.setProject(testProject);
        testIssue2 = issueDAO.save(testIssue2);

        testSolution.setName("Test");
        testSolution.setShortDescription("test");
        testSolution.setCreationDate(new Date());
        testSolution.setCreator("Tim");
        testSolution = frameworkDAO.save(testSolution);
    }

    /**
     * Test if issue can be saved.
     */
    @Test
    public void testSaveIssueInDB()
    {
        // Create and save Decision
        Issue issue = saveNewIssueInDB();
        assertNotNull(issue.getId());
        assertTrue(issue.getId() > 0);
        assertNotNull(issue.getDecision());
        assertTrue(issue.getDecision().getId() > 0);
    }

    /**
     * Test if issue can be saved.
     */
    @Test
    public void testEditIssueInDB()
    {
        // Create and save Decision
        Issue issue = saveNewIssueInDB();
        assertNotNull(issue.getId());
        assertTrue(issue.getId() > 0);
        assertNotNull(issue.getDecision());
        assertTrue(issue.getDecision().getId() > 0);
        for (int i = 0; i < 5; i++)
        {
            issue = issueDAO.findOne(issue.getId());
            issue.setName(String.valueOf(Math.random()));
            issue = issueDAO.saveAndFlush(issue);
            assertNotNull(issue.getDecision());
            assertTrue(issue.getDecision().getId() > 0);
        }
    }

    /**
     * Helper to save a new Decision in DB.
     * 
     * @return A newly saved Decision from the DB.
     */
    public Issue saveNewIssueInDB()
    {
        Issue issue = new Issue();
        issue.setName("Issue1");
        issue.setDescription("Testissue 1");
        issue.setCreator("Tim");
        issue.setCreationDate(new Date());
        issue.setProject(testProject);
        issue = issueDAO.save(issue);
        return issue;
    }

    /**
     * Test if Comment for Decision can be saved.
     */
    @Test
    public void testSaveCommentInDB()
    {
        // Create and save Decision
        Issue issue = saveNewIssueInDB();
        Decision decision = issue.getDecision();
        assertNotNull(decision.getId());
        assertTrue(decision.getId() > 0);

        Comment comment = saveNewCommentInDB(decision);
        assertNotNull(comment.getId());
        assertTrue(comment.getId() > 0);
    }

    /**
     * Helper to create and save a new comment in the DB.
     * 
     * @param decision The Decision is commented on.
     * @return A newly saved Comment from the DB.
     */
    public Comment saveNewCommentInDB(Decision decision)
    {
        Comment comment = new Comment();
        comment.setCommentator("Tim");
        comment.setDate(new Date());
        comment.setComment("Test.");
        decision.addComment(comment);
        return commentDAO.save(comment);
    }

    /**
     * Test if only the right comments for a Decision are found.
     */
    @Test
    public void testFindCommentsForDecision()
    {
        Issue issue1 = saveNewIssueInDB();
        issue1 = issueDAO.findOne(issue1.getId());
        Decision decision1 = issue1.getDecision();
        Decision decision2 = saveNewIssueInDB().getDecision();

        // Create the comments for the decisions
        Comment comment1 = saveNewCommentInDB(decision1);
        assertNotNull(comment1.getId());
        assertTrue(comment1.getId() > 0);
        Comment comment2 = saveNewCommentInDB(decision1);
        assertNotNull(comment1.getId());
        assertTrue(comment1.getId() > 0);
        Comment comment3 = saveNewCommentInDB(decision2);
        assertNotNull(comment1.getId());
        assertTrue(comment1.getId() > 0);

        // Assert that only the right comments for the decisions are found
        decision1 = decisionDAO.findOne(decision1.getId());
        assertNotNull(decision1);
        List<Comment> comments = decision1.getComments();
        assertTrue(comments.contains(comment1));
        assertTrue(comments.contains(comment2));
        assertFalse(comments.contains(comment3));

        decision2 = decisionDAO.findOne(decision2.getId());
        assertNotNull(decision1);
        comments = decision2.getComments();
        assertFalse(comments.contains(comment1));
        assertFalse(comments.contains(comment2));
        assertTrue(comments.contains(comment3));
    }

    /**
     * Test if issue can be created.
     */
    @Test
    public void testSaveSolutionCandidateInDB()
    {
        Decision decision = saveNewIssueInDB().getDecision();

        SolutionCandidate solutionCandidate = saveNewSolutionCandidateInDB(decision, testSolution);
        assertNotNull(solutionCandidate.getId());
        assertTrue(solutionCandidate.getId() > 0);
    }

    /**
     * Helper to save a new SolutionCandidate in DB.
     * 
     * @param decision The Decision the SolutionCandidate belongs to.
     * @param solution The Solution which the SolutionCandidate represents.
     * @return A newly saved Decision from the DB.
     */
    public SolutionCandidate saveNewSolutionCandidateInDB(Decision decision, Solution solution)
    {
        SolutionCandidate solutionCandidate = new SolutionCandidate();
        solutionCandidate.setCreationDate(new Date());
        solutionCandidate.setCreator("Tim");
        decision.addSolutionCandidate(solutionCandidate);
        solutionCandidate.setSolution(solution);
        return solutionCandidateDAO.save(solutionCandidate);
    }

    /**
     * Test if only the right SolutionCandidates for a Decision are found.
     */
    @Test
    public void testFindSolutionCandidatesForDecision()
    {
        Decision decision1 = saveNewIssueInDB().getDecision();
        Decision decision2 = saveNewIssueInDB().getDecision();

        // Create the solutions for the decisions
        SolutionCandidate solutionCandidate1 = saveNewSolutionCandidateInDB(decision1, testSolution);
        assertNotNull(solutionCandidate1.getId());
        assertTrue(solutionCandidate1.getId() > 0);
        SolutionCandidate solutionCandidate2 = saveNewSolutionCandidateInDB(decision1, testSolution);
        assertNotNull(solutionCandidate2.getId());
        assertTrue(solutionCandidate2.getId() > 0);
        SolutionCandidate solutionCandidate3 = saveNewSolutionCandidateInDB(decision2, testSolution);
        assertNotNull(solutionCandidate3.getId());
        assertTrue(solutionCandidate3.getId() > 0);

        // Assert that only the right candidates for the solutions are found
        decision1 = decisionDAO.findOne(decision1.getId());
        assertNotNull(decision1);
        List<SolutionCandidate> solutionCandidates1 = decision1.getSolutionCandidates();
        assertTrue(solutionCandidates1.contains(solutionCandidate1));
        assertTrue(solutionCandidates1.contains(solutionCandidate2));
        assertFalse(solutionCandidates1.contains(solutionCandidate3));

        decision2 = decisionDAO.findOne(decision2.getId());
        assertNotNull(decision2);
        List<SolutionCandidate> solutionCandidates2 = decision2.getSolutionCandidates();
        assertFalse(solutionCandidates2.contains(solutionCandidate1));
        assertFalse(solutionCandidates2.contains(solutionCandidate2));
        assertTrue(solutionCandidates2.contains(solutionCandidate3));
    }

    /**
     * Test if only the right SolutionCandidates/Comments for a Decision with
     * both.
     */
    @Test
    public void testDecisionWithCommentsAndSolutionCandidates()
    {
        Decision decision1 = saveNewIssueInDB().getDecision();
        Decision decision2 = saveNewIssueInDB().getDecision();

        // Create the solutions for the decisions
        SolutionCandidate solutionCandidate1 = saveNewSolutionCandidateInDB(decision1, testSolution);
        assertNotNull(solutionCandidate1.getId());
        assertTrue(solutionCandidate1.getId() > 0);
        SolutionCandidate solutionCandidate2 = saveNewSolutionCandidateInDB(decision1, testSolution);
        assertNotNull(solutionCandidate2.getId());
        assertTrue(solutionCandidate2.getId() > 0);
        SolutionCandidate solutionCandidate3 = saveNewSolutionCandidateInDB(decision2, testSolution);
        assertNotNull(solutionCandidate3.getId());
        assertTrue(solutionCandidate3.getId() > 0);

        // Create the comments for the decisions
        Comment comment1 = saveNewCommentInDB(decision1);
        assertNotNull(comment1.getId());
        assertTrue(comment1.getId() > 0);
        Comment comment2 = saveNewCommentInDB(decision1);
        assertNotNull(comment1.getId());
        assertTrue(comment1.getId() > 0);
        Comment comment3 = saveNewCommentInDB(decision2);
        assertNotNull(comment1.getId());
        assertTrue(comment1.getId() > 0);

        // Assert that only the right comments for the decisions are found
        decision1 = decisionDAO.findOne(decision1.getId());
        assertNotNull(decision1);
        List<Comment> comments = decision1.getComments();
        assertTrue(comments.contains(comment1));
        assertTrue(comments.contains(comment2));
        assertFalse(comments.contains(comment3));

        decision2 = decisionDAO.findOne(decision2.getId());
        assertNotNull(decision1);
        comments = decision2.getComments();
        assertFalse(comments.contains(comment1));
        assertFalse(comments.contains(comment2));
        assertTrue(comments.contains(comment3));

        // Assert that only the right candidates for the solutions are found
        decision1 = decisionDAO.findOne(decision1.getId());
        assertNotNull(decision1);
        List<SolutionCandidate> solutionCandidates1 = decision1.getSolutionCandidates();
        assertTrue(solutionCandidates1.contains(solutionCandidate1));
        assertTrue(solutionCandidates1.contains(solutionCandidate2));
        assertFalse(solutionCandidates1.contains(solutionCandidate3));

        decision2 = decisionDAO.findOne(decision2.getId());
        assertNotNull(decision2);
        List<SolutionCandidate> solutionCandidates2 = decision2.getSolutionCandidates();
        assertFalse(solutionCandidates2.contains(solutionCandidate1));
        assertFalse(solutionCandidates2.contains(solutionCandidate2));
        assertTrue(solutionCandidates2.contains(solutionCandidate3));

    }
}