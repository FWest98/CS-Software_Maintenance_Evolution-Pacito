package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class CommentTest
{
    private Comment comment1;
    private Comment comment2;
    private Comment comment3;

    /**
     * Creates three Comments. Comment 1 and 2 should be equal and 3 different.
     */
    @Before
    public void setUp()
    {
        comment1 = new Comment();
        comment2 = new Comment();
        comment3 = new Comment();

        comment1.setId(1L);
        comment2.setId(1L);
        comment3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testCommentToString()
    {
        System.out.println(comment1.toString());
    }

    /**
     * Tests the hashCode functionality of a Comment, should only be affected by
     * Id.
     */
    @Test
    public void testCommentHashcode()
    {
        comment1.setComment("a");
        comment2.setComment("b");
        assertTrue(comment1.hashCode() == comment1.hashCode());
        assertTrue(comment1.hashCode() == comment2.hashCode());
        assertFalse(comment2.hashCode() == comment3.hashCode());
    }

    /**
     * Tests the equals functionality of a Comment, should only be affected by
     * Id.
     */
    @Test
    public void testCommentEquals()
    {
        comment1.setComment("a");
        comment2.setComment("b");
        assertTrue(comment1.equals(comment1));
        assertFalse(comment1.equals(null));
        assertFalse(comment1.equals(new String()));
        assertTrue(comment1.equals(comment2));
        assertFalse(comment1.equals(comment3));
    }
}