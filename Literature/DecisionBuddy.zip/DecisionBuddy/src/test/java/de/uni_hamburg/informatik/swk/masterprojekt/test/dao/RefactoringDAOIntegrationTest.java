package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RefactoringCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RefactoringDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;

/**
 * Tests the RefactoringDAO and the real database.
 * 
 * @author Tim
 *
 */

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class RefactoringDAOIntegrationTest
{

    @Autowired
    private RefactoringDAO refactoringDAO;

    @Autowired
    private RefactoringCategoryDAO refactoringCategoryDAO;

    /**
     * Test if RefactoringCategory can be saved to database.
     */
    @Test
    public void testSaveRefactoringCategoryInDB()
    {
        RefactoringCategory refactoringCategory = saveRefactoringCategoryInDB();
        assertNotNull(refactoringCategory.getId());
        assertTrue(refactoringCategory.getId() > 0);
    }

    /**
     * Create a new RefactoringCategory and save it in the DB.
     * 
     * @return a saved RefactoringCategory
     */
    public RefactoringCategory saveRefactoringCategoryInDB()
    {
        RefactoringCategory refactoringCategory = new RefactoringCategory();
        // Name of category must be unique.
        refactoringCategory.setName(String.valueOf(Math.random()));
        refactoringCategory.setDescription("test.");
        refactoringCategory = refactoringCategoryDAO.save(refactoringCategory);
        return refactoringCategory;
    }

    /**
     * Test if Refactoring can be saved to database.
     */
    @Test
    public void testSaveRefactoringInDB()
    {
        Refactoring refactoring = saveRefactoringInDB();
        assertNotNull(refactoring.getId());
        assertTrue(refactoring.getId() > 0);
    }

    /**
     * Create a new Refactoring and save it in the DB.
     * 
     * @return a saved Refactoring
     */
    public Refactoring saveRefactoringInDB()
    {
        Refactoring refactoring = new Refactoring();
        refactoring.setRefactoringCategory(saveRefactoringCategoryInDB());
        refactoring.setName("Refactoring");
        refactoring.setShortDescription("Short.");
        refactoring.setExamples("Many.");
        refactoring.setMechanics("Many.");
        refactoring.setSummary("This.");
        refactoring.setCreator("Tim");
        refactoring.setCreationDate(new Date());
        refactoring.setLastModifier("Tim");
        refactoring.setModificationDate(new Date());
        refactoring = refactoringDAO.save(refactoring);
        return refactoring;
    }

    /**
     * Tests the deletion of a refactoring.
     */
    @Test
    public void testDeleteRefactoring()
    {
        Refactoring refactoring = saveRefactoringInDB();
        refactoringDAO.delete(refactoring);
        assertFalse(refactoringDAO.exists(refactoring.getId()));
    }

    /**
     * Tests the query for finding all refactorings in the DB.
     */
    @Test
    public void testFindAllRefactorings()
    {
        List<Refactoring> allRefactorings = refactoringDAO.findAll();
        Refactoring refactoring1 = saveRefactoringInDB();
        Refactoring refactoring2 = saveRefactoringInDB();
        Refactoring refactoring3 = saveRefactoringInDB();
        Refactoring refactoring4 = saveRefactoringInDB();

        assertFalse(allRefactorings.contains(refactoring1));
        assertFalse(allRefactorings.contains(refactoring2));
        assertFalse(allRefactorings.contains(refactoring3));
        assertFalse(allRefactorings.contains(refactoring4));

        allRefactorings = refactoringDAO.findAll();
        assertTrue(allRefactorings.contains(refactoring1));
        assertTrue(allRefactorings.contains(refactoring2));
        assertTrue(allRefactorings.contains(refactoring3));
        assertTrue(allRefactorings.contains(refactoring4));
    }

}
