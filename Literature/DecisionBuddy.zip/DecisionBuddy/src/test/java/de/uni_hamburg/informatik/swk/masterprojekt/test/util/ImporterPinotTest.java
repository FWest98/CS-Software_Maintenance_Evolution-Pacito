package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ImporterPinot;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class ImporterPinotTest
{
    private static final String TMP_PREFIX = "analyzeresult_";
    private static final String TMP_EXTENSION = ".tmp";

    private File invalidFile;
    private File faultyFile;
    private File correctFile;

    @Autowired
    private ImporterPinot importerPinot;

    @Before
    public void setup()
    {
        BufferedWriter writer;
        String text;

        try
        {
            // Write syntactical invalid File
            invalidFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(invalidFile));
            text = "this is not a pinot export";
            writer.write(text);
            writer.close();

            // Write faulty file: Facade Patern instead of Pattern
            faultyFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(faultyFile));
            text = "\n--------- Original GoF Patterns ----------\n\nFacade Patern.\nVormerkMedienFormatierer is"
                    + " a facade class.\nHidden types: Medium Kunde\nFacade access types: VormerkMedienFormatierer"
                    + "\nFile Location: /home/markus/workspaces/eclipse/Mediathek_Vorlage_Blatt06/src/de/uni_hamburg"
                    + "/informatik/swt/se2/mediathek/werkzeuge/subwerkzeuge/vormerkmedienauflister/VormerkMedien"
                    + "Formatierer.java\n";
            writer.write(text);
            writer.close();

            // Write correct File
            correctFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(correctFile));
            text = "\n--------- Original GoF Patterns ----------\n\nFacade Pattern.\nVormerkMedienFormatierer is"
                    + " a facade class.\nHidden types: Medium Kunde\nFacade access types: VormerkMedienFormatierer"
                    + "\nFile Location: /home/markus/workspaces/eclipse/Mediathek_Vorlage_Blatt06/src/de/uni_hamburg"
                    + "/informatik/swt/se2/mediathek/werkzeuge/subwerkzeuge/vormerkmedienauflister/VormerkMedien"
                    + "Formatierer.java\n";
            writer.write(text);
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    @Test(expected = AnalysisResultException.class)
    public void testValidateInvalidData() throws AnalysisResultException
    {
        importerPinot.validateFile(invalidFile.getAbsolutePath());
    }

    @Test
    public void testValidateFaultyData()
    {
        try
        {
            Assert.assertTrue(importerPinot.validateFile(faultyFile.getAbsolutePath()));
        }
        catch (AnalysisResultException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
    }

    @Test
    public void testValidateCorrectData()
    {
        try
        {
            Assert.assertTrue(importerPinot.validateFile(correctFile.getAbsolutePath()));
        }
        catch (AnalysisResultException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
    }

    // @Test(expected = AnalysisResultException.class)
    // public void testImportFaultyData() throws AnalysisResultException
    // {
    // importerPinot.importFile(1, faultyFile.getAbsolutePath());
    // }
    //
    // @Test
    // public void testImportCorrectData()
    // {
    // try
    // {
    // importerPinot.importFile(1, correctFile.getAbsolutePath());
    // }
    // catch (AnalysisResultException e)
    // {
    // e.printStackTrace();
    // fail("Exception caught.");
    // }
    // }
}
