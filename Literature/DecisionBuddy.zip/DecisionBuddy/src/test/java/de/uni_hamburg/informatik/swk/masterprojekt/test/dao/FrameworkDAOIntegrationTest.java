package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;

/**
 * Tests the FrameworkDAO and the real database.
 * 
 * @author Vlad, Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class FrameworkDAOIntegrationTest
{
    @Autowired
    private FrameworkDAO frameworkDAO;

    @Autowired
    private FrameworkCategoryDAO fwcDAO;

    /**
     * Tests the creation of a Framework.
     * 
     */
    @Test
    public void testSaveFramework()
    {
        Framework framework = getTestFramework();

        assertNull(framework.getId());

        framework = frameworkDAO.save(framework);

        assertNotNull(framework.getId());
        assertTrue(framework.getId() > 0);
    }

    /**
     * Tests the deletion of a framework.
     */
    @Test
    public void testDeleteFramework()
    {
        Framework framework = getTestFramework();

        assertNull(framework.getId());
        framework = frameworkDAO.save(framework);
        assertEquals(framework, frameworkDAO.getOne(framework.getId()));
        frameworkDAO.delete(framework);
        assertFalse(frameworkDAO.exists(framework.getId()));
    }

    /**
     * Tests the query for finding all frameworks in the DB.
     */
    @Test
    public void testFindAllFrameworks()
    {
        List<Framework> l = frameworkDAO.findAll();
        Framework framework = getTestFramework();

        assertNull(framework.getId());

        for (Framework f : l)
        {
            assertNotNull(f.getId());
            assertNotNull(f.getName());
            assertNotNull(f.getShortDescription());
        }

        assertFalse(l.contains(framework));
        framework = frameworkDAO.save(framework);
        l = frameworkDAO.findAll();
        assertTrue(l.contains(framework));

    }

    /**
     * Helper method to create a new Framework.
     * 
     * @return A valid Framework object
     */
    private Framework getTestFramework()
    {
        FrameworkCategory fwc = fwcDAO.findOne(new Long(1));

        Framework framework = new Framework();
        framework.setName("Spring4");
        framework.setShortDescription("Useful framework to implement MVC architecture");
        framework.setCreator("Vlad");
        framework.setCreationDate(new Date());
        framework.setLastModifier("Abjdsklhdlfj");
        framework.setModificationDate(new Date());
        framework.setFrameworkCategory(fwc);
        framework.setCurrentVersion("4.0.6");
        framework.setDevelopmentStatus("active");
        framework
                .setDescription("The Spring Framework is an open source application framework and inversion of control"
                        + " container for the Java platform. The framework's core features can be used by any Java "
                        + "application, but there are extensions for building web applications on top of the Java EE "
                        + "platform. Although the framework does not impose any specific programming model, it has "
                        + "become popular in the Java community as an alternative to, replacement for, or even "
                        + "addition to the Enterprise JavaBean (EJB) model.");
        framework.setOperatingSystem("cross system");
        framework.setProgrammingLanguage("Java");
        framework.setDependencies("unknown");
        framework.setDeveloper("Pivotal Software");
        framework.setWebsite("spring.com");
        framework.setLicense("Apache Licence 2.0");
        framework.setSupport("blabla");
        framework.setDocumentation("large");
        framework.setCommunity("Spring devs");
        framework.setSize(1);
        return framework;
    }
}