package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Vlad, Tim
 *
 */
public class ArchitecturalPatternTest
{
    private ArchitecturalPattern architecturalPattern1;
    private ArchitecturalPattern architecturalPattern2;
    private ArchitecturalPattern architecturalPattern3;

    /**
     * Creates three ArchitecturalPatterns. ArchitecturalPattern 1 and 2 should
     * be equal and 3 different.
     */
    @Before
    public void setUp()
    {
        architecturalPattern1 = new ArchitecturalPattern();
        architecturalPattern2 = new ArchitecturalPattern();
        architecturalPattern3 = new ArchitecturalPattern();

        architecturalPattern1.setId(1L);
        architecturalPattern2.setId(1L);
        architecturalPattern3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testArchitecturalPatternToString()
    {
        System.out.println(architecturalPattern1.toString());
    }

    /**
     * Tests the hashCode functionality of a ArchitecturalPattern, should only
     * be affected by Id.
     */
    @Test
    public void testArchitecturalPatternHashcode()
    {
        architecturalPattern1.setShortDescription("1");
        architecturalPattern2.setShortDescription("2");
        assertTrue(architecturalPattern1.hashCode() == architecturalPattern1.hashCode());
        assertTrue(architecturalPattern1.hashCode() == architecturalPattern2.hashCode());
        assertFalse(architecturalPattern2.hashCode() == architecturalPattern3.hashCode());
    }

    /**
     * Tests the equals functionality of a ArchitecturalPattern, should only be
     * affected by Id.
     */
    @Test
    public void testArchitecturalPatternEquals()
    {
        architecturalPattern1.setShortDescription("1");
        architecturalPattern2.setShortDescription("2");
        assertTrue(architecturalPattern1.equals(architecturalPattern1));
        assertFalse(architecturalPattern1.equals(null));
        assertFalse(architecturalPattern1.equals(new String()));
        assertTrue(architecturalPattern1.equals(architecturalPattern2));
        assertFalse(architecturalPattern1.equals(architecturalPattern3));
    }
}