package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class DesignPatternCategoryTest
{
    private DesignPatternCategory designPatternCategory1;
    private DesignPatternCategory designPatternCategory2;
    private DesignPatternCategory designPatternCategory3;

    /**
     * Creates three DesignPatternCategories. DesignPatternCategory 1 and 2
     * should be equal and 3 different.
     */
    @Before
    public void setUp()
    {
        designPatternCategory1 = new DesignPatternCategory();
        designPatternCategory2 = new DesignPatternCategory();
        designPatternCategory3 = new DesignPatternCategory();

        designPatternCategory1.setId(1L);
        designPatternCategory2.setId(1L);
        designPatternCategory3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testDesignPatternCategoryToString()
    {
        System.out.println(designPatternCategory1.toString());
    }

    /**
     * Tests the hashCode functionality of a DesignPatternCategory, should only
     * be affected by Id.
     */
    @Test
    public void testDesignPatternCategoryHashcode()
    {
        designPatternCategory1.setDescription("1");
        designPatternCategory2.setDescription("2");
        assertTrue(designPatternCategory1.hashCode() == designPatternCategory1.hashCode());
        assertTrue(designPatternCategory1.hashCode() == designPatternCategory2.hashCode());
        assertFalse(designPatternCategory2.hashCode() == designPatternCategory3.hashCode());
    }

    /**
     * Tests the equals functionality of a DesignPatternCategory, should only be
     * affected by Id.
     */
    @Test
    public void testDesignPatternCategoryEquals()
    {
        designPatternCategory1.setDescription("1");
        designPatternCategory2.setDescription("2");
        assertTrue(designPatternCategory1.equals(designPatternCategory1));
        assertFalse(designPatternCategory1.equals(null));
        assertFalse(designPatternCategory1.equals(new String()));
        assertTrue(designPatternCategory1.equals(designPatternCategory2));
        assertFalse(designPatternCategory1.equals(designPatternCategory3));
    }
}