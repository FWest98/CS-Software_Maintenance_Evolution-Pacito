package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.IssueValidator;

/**
 * Test class for IssueValidator.
 * 
 * @author Tim
 *
 */

public class IssueValidatorTest
{
    private Issue testIssue;
    private IssueValidator testIssueValidator;

    /**
     * Setup method for issue validator. Called before each test method. Creates
     * a valid Issue.
     * 
     * @throws Exception excep
     */
    @Before
    public void setUp() throws Exception
    {
        testIssue = new Issue();
        testIssue.setId(1L);
        testIssue.setProject(new Project());
        testIssue.setName("test");
        testIssue.setCreator("Tim");
        testIssue.setCreationDate(new Date());
        testIssueValidator = new IssueValidator();
    }

    /**
     * Test method for default issue created in setUp(), if this fails the other
     * tests can't work properly.
     */
    @Test
    public void setUpValid()
    {
        Errors errors;
        errors = new BeanPropertyBindingResult(testIssue, "validIssue");
        testIssueValidator.validate(testIssue, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method with missing mandatory field name.
     */
    @Test
    public void testMissingName()
    {
        testIssue.setName("");
        Errors errors;
        errors = new BeanPropertyBindingResult(testIssue, "validIssue");
        testIssueValidator.validate(testIssue, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Create string of lenghts n.
     * 
     * @param n the length of the string
     * @return new string of length n
     */
    public String createStringOfLenghtsN(int n)
    {
        String string = "a";
        for (int i = 1; i < n; i++)
        {
            string = string.concat("a");
        }
        return string;
    }

    /**
     * Test method for an identifier which exceeds the character limit.
     */
    @Test
    public void testNameTooLong()
    {
        Errors errors;
        String string = createStringOfLenghtsN(ColumnLength.SHORT + 1);
        testIssue.setName(string);
        errors = new BeanPropertyBindingResult(testIssue, "testIssue");
        testIssueValidator.validate(testIssue, errors);
        assertTrue(errors.hasErrors());
        string = createStringOfLenghtsN(ColumnLength.SHORT);
        testIssue.setName(string);
        errors = new BeanPropertyBindingResult(testIssue, "testIssue");
        testIssueValidator.validate(testIssue, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for an identifier which exceeds the character limit.
     */
    @Test
    public void testCreatorTooLong()
    {
        Errors errors;
        String string = createStringOfLenghtsN(ColumnLength.SHORT + 1);
        testIssue.setCreator(string);
        errors = new BeanPropertyBindingResult(testIssue, "testIssue");
        testIssueValidator.validate(testIssue, errors);
        assertTrue(errors.hasErrors());
        string = createStringOfLenghtsN(ColumnLength.SHORT);
        testIssue.setCreator(string);
        errors = new BeanPropertyBindingResult(testIssue, "testIssue");
        testIssueValidator.validate(testIssue, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for an identifier which exceeds the character limit.
     */
    @Test
    public void testLastModifierTooLong()
    {
        Errors errors;
        String string = createStringOfLenghtsN(ColumnLength.SHORT + 1);
        testIssue.setLastModifier(string);
        errors = new BeanPropertyBindingResult(testIssue, "testIssue");
        testIssueValidator.validate(testIssue, errors);
        assertTrue(errors.hasErrors());
        string = createStringOfLenghtsN(ColumnLength.SHORT);
        testIssue.setLastModifier(string);
        errors = new BeanPropertyBindingResult(testIssue, "testIssue");
        testIssueValidator.validate(testIssue, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for an identifier which exceeds the character limit.
     */
    @Test
    public void testDescriptionTooLong()
    {
        Errors errors;
        String string = createStringOfLenghtsN(ColumnLength.LONG + 1);
        testIssue.setDescription(string);
        errors = new BeanPropertyBindingResult(testIssue, "testIssue");
        testIssueValidator.validate(testIssue, errors);
        assertTrue(errors.hasErrors());
        string = createStringOfLenghtsN(ColumnLength.LONG);
        testIssue.setDescription(string);
        errors = new BeanPropertyBindingResult(testIssue, "testIssue");
        testIssueValidator.validate(testIssue, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a name which exceeds the character limit.
     */
    @Test
    public void missingStringInConstraint()
    {
        TechnicalTerm technicalTerm = new TechnicalTerm();
        technicalTerm.setType("string");
        Constraint constraint = new Constraint();
        constraint.setTechnicalTerm(technicalTerm);
        ConstraintElement constraintElement = new ConstraintElement();
        constraintElement.setIntValue(1);
        constraint.addElement(constraintElement);

        testIssue.addConstraint(constraint);
        Errors errors = new BeanPropertyBindingResult(testIssue, "validIssue");
        testIssueValidator.validate(testIssue, errors);
        assertTrue(errors.hasErrors());

        technicalTerm.setType("stringint");
        errors = new BeanPropertyBindingResult(testIssue, "validIssue");
        testIssueValidator.validate(testIssue, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a name which exceeds the character limit.
     */
    @Test
    public void missingIntInConstraint()
    {
        TechnicalTerm technicalTerm = new TechnicalTerm();
        technicalTerm.setType("int");
        Constraint constraint = new Constraint();
        constraint.setTechnicalTerm(technicalTerm);
        ConstraintElement constraintElement = new ConstraintElement();
        constraintElement.setStringValue(new StringValue());
        constraint.addElement(constraintElement);

        testIssue.addConstraint(constraint);
        Errors errors = new BeanPropertyBindingResult(testIssue, "validIssue");
        testIssueValidator.validate(testIssue, errors);
        assertTrue(errors.hasErrors());
    }

}
