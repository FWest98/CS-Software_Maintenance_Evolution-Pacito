package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.SolutionUsageStatistics;

/**
 * Test case for Solution usage statistics. Real data is tested here, it might
 * change so the test cases coul fil in future.
 * 
 * @author Vlad
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class SolutionUsageStatisticsTest
{
    // @Autowired
    // private SolutionDAO             solutionDAO;

    @Autowired
    private SolutionUsageStatistics solutionUsageStatistics;

    // private Solution solution;
    //
    // private List<SolutionCandidate> solutionCandidates;

    @Before
    public void setUp() throws Exception
    {
        // solution = solutionDAO.findByName("Spring");
    }

    //
    // @Test
    // public void test()
    // {
    // assertNotNull(solution);
    // solutionCandidates = solution.getSolutionCandidates();
    // assertFalse(solutionCandidates.isEmpty());
    // for (SolutionCandidate solutionCandidate : solutionCandidates)
    // {
    // solutionCandidate.getDecided();
    // System.out.println(solutionCandidate.getDecided());
    // }
    // }
    //
    @Test
    public void testGetOverallFrequencies() throws Exception
    {
        Long frequency = solutionUsageStatistics.getOverallFrequency(new Long(2));
        assertEquals(new Long(1), frequency);
    }

    //
    // @Test
    // public void testGetUndecidedFrequency() throws Exception
    // {
    //
    // int frequency = solutionUsageStatistics.getUndecided(solution);
    // assertEquals(1, frequency);
    // assertNotEquals(2, frequency);
    // assertNotEquals(0, frequency);
    //
    // }
    //
    @Test
    public void testGetApprovedFrequency() throws Exception
    {
        System.out.println(solutionUsageStatistics.getApproved(2L));
    }
    //
    // @Test
    // public void testGetRejectedFrequency() throws Exception
    // {
    //
    // int frequency = solutionUsageStatistics.getRejected(solution);
    // assertEquals(1, frequency);
    // assertNotEquals(0, frequency);
    // assertNotEquals(2, frequency);
    //
    // }
}
