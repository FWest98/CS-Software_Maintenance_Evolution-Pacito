package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Property;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Property}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class PropertyTest
{
    private Property property1;
    private Property property2;
    private Property property3;

    /**
     * Creates three Properties. Property 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        property1 = new Property();
        property2 = new Property();
        property3 = new Property();

        property1.setId(1L);
        property2.setId(1L);
        property3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testPropertyToString()
    {
        System.out.println(property1.toString());
    }

    /**
     * Tests the hashCode functionality of a Property, should only be affected
     * by Id.
     */
    @Test
    public void testPropertyHashcode()
    {
        property1.setDescription("1");
        property2.setDescription("2");
        assertTrue(property1.hashCode() == property1.hashCode());
        assertTrue(property1.hashCode() == property2.hashCode());
        assertFalse(property2.hashCode() == property3.hashCode());
    }

    /**
     * Tests the equals functionality of a Property, should only be affected by
     * Id.
     */
    @Test
    public void testPropertyEquals()
    {
        property1.setDescription("1");
        property2.setDescription("2");
        assertTrue(property1.equals(property1));
        assertFalse(property1.equals(null));
        assertFalse(property1.equals(new String()));
        assertTrue(property1.equals(property2));
        assertFalse(property1.equals(property3));
    }
}