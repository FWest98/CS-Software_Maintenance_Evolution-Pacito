package de.uni_hamburg.informatik.swk.masterprojekt.test.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production.WebAppConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller.PaginationHelper;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * Tests the pagination helper.
 * 
 * @author schaak
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = WebAppConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class PaginationHelperTest
{
    private PaginationHelper<Solution> paginationHelper;
    private List<Solution> solutionList;

    private static final int PAGE_SIZE_DEFAULT = 10;
    private static final int PAGE_NR_DEFAULT = 0;

    /**
     * Setup method to create a paginationHelper.
     */
    @Before
    public void initializePaginationHelper()
    {
        paginationHelper = new PaginationHelper<Solution>();
        solutionList = null;
    }

    /**
     * Tests configure method in normal case.
     */
    @Test
    public void testConfigureNormal()
    {
        solutionList = createDummySolutions(3);

        String pageSize = "20";
        String page = "1";

        paginationHelper.configure(solutionList, pageSize, page);

        PagedListHolder<Solution> pagedListHolder = paginationHelper.getPagedListHolder();
        List<Solution> solutions = paginationHelper.getPageList();

        assertEquals(Long.valueOf(0), Long.valueOf(pagedListHolder.getPage()));
        assertEquals(Long.valueOf(20), Long.valueOf(pagedListHolder.getPageSize()));
        assertEquals(Long.valueOf(3), Long.valueOf(solutions.size()));
    }

    /**
     * Tests configure method in case of null values.
     */
    @Test
    public void testConfigureNullValues()
    {
        solutionList = createDummySolutions(4);

        String pageSize = null;
        String page = null;

        paginationHelper.configure(solutionList, pageSize, page);

        PagedListHolder<Solution> pagedListHolder = paginationHelper.getPagedListHolder();
        List<Solution> solutions = paginationHelper.getPageList();

        assertEquals(Long.valueOf(PAGE_NR_DEFAULT), Long.valueOf(pagedListHolder.getPage()));
        assertEquals(Long.valueOf(PAGE_SIZE_DEFAULT), Long.valueOf(pagedListHolder.getPageSize()));
        assertEquals(Long.valueOf(4), Long.valueOf(solutions.size()));
    }

    /**
     * Tests configure method in case of illegal values.
     */
    @Test
    public void testConfigureIllegalValues()
    {
        solutionList = createDummySolutions(2);

        String pageSize = "asdhfa";
        String page = "##xd";

        paginationHelper.configure(solutionList, pageSize, page);

        PagedListHolder<Solution> pagedListHolder = paginationHelper.getPagedListHolder();
        List<Solution> solutions = paginationHelper.getPageList();

        assertEquals(Long.valueOf(PAGE_NR_DEFAULT), Long.valueOf(pagedListHolder.getPage()));
        assertEquals(Long.valueOf(PAGE_SIZE_DEFAULT), Long.valueOf(pagedListHolder.getPageSize()));
        assertEquals(Long.valueOf(2), Long.valueOf(solutions.size()));
    }

    /**
     * Tests setting an external pagedListHolder.
     */
    @Test
    public void testConfigureExternal()
    {
        solutionList = createDummySolutions(4);

        PagedListHolder<Solution> externalHolder = new PagedListHolder<Solution>();

        externalHolder.setPage(2);
        externalHolder.setPageSize(4);
        externalHolder.setSource(solutionList);

        paginationHelper.setPagedListHolder(externalHolder);

        PagedListHolder<Solution> pagedListHolder = paginationHelper.getPagedListHolder();
        List<Solution> solutions = paginationHelper.getPageList();

        assertEquals(Long.valueOf(0), Long.valueOf(pagedListHolder.getPage()));
        assertEquals(Long.valueOf(4), Long.valueOf(pagedListHolder.getPageSize()));
        assertEquals(Long.valueOf(4), Long.valueOf(solutions.size()));
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param numberOfSolutions number of dummy solutions to be created.
     * @return a list of solutions
     */
    private List<Solution> createDummySolutions(int numberOfSolutions)
    {
        List<Solution> solutionList = new ArrayList<Solution>();

        for (int i = 0; i < numberOfSolutions; i++)
        {
            Framework framework = new Framework();
            framework.setId(Long.valueOf(i));
            framework.setName("Framework " + i);
            framework.setShortDescription("Description of framework " + i);
            solutionList.add(framework);
        }

        return solutionList;
    }
}