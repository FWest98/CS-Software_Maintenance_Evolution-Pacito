package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;

/**
 * Tests the IssueDAO and the real database.
 * 
 * @author Vlad, Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class IssueDAOIntegrationTest
{
    @Autowired
    private IssueDAO issueDAO;

    @Autowired
    private ProjectDAO projectDao;

    private Project testProject1 = new Project();
    private Project testProject2 = new Project();
    private Issue testIssue1 = new Issue();
    private Issue testIssue2 = new Issue();
    private Issue testIssue3 = new Issue();

    /**
     * Creates test projects and issues.
     */
    @Before
    public void setUp()
    {
        testProject1.setName("Masterprojekt");
        testProject1.setDescription("Our Master project");
        testProject1.setCreator("Lucas");
        testProject1.setCreationDate(new Date());
        testProject1.setLastModifier("Lucas");
        testProject1.setModificationDate(new Date());

        testProject2.setName("Masterprojekt2");
        testProject2.setDescription("Not our Master project");
        testProject2.setCreator("Tim");
        testProject2.setCreationDate(new Date());
        testProject2.setLastModifier("Tim");
        testProject2.setModificationDate(new Date());

        testIssue1.setName("Issue1");
        testIssue1.setDescription("Testissue 1");
        testIssue1.setCreator("Lucas");
        testIssue1.setCreationDate(new Date());
        testIssue1.setLastModifier("Lucas");
        testIssue1.setModificationDate(new Date());

        testIssue2.setName("Issue2");
        testIssue2.setDescription("Testissue 2");
        testIssue2.setCreator("Lucas");
        testIssue2.setCreationDate(new Date());
        testIssue2.setLastModifier("Lucas");
        testIssue2.setModificationDate(new Date());

        testIssue3.setName("Issue3");
        testIssue3.setDescription("Testissue 3");
        testIssue3.setCreator("Lucas");
        testIssue3.setCreationDate(new Date());
        testIssue3.setLastModifier("Lucas");
        testIssue3.setModificationDate(new Date());
    }

    /**
     * Test if issue can be created.
     */
    @Test
    public void testCreateIssue()
    {
        Issue issue = getTestIssue();

        assertNull(issue.getId());

        issue = issueDAO.save(issue);

        assertNotNull(issue.getId());
        assertTrue(issue.getId() > 0);
    }

    /**
     * Tests the deletion of an issue.
     */
    @Test
    public void testDeleteIssue()
    {
        Issue issue = getTestIssue();

        assertNull(issue.getId());
        issue = issueDAO.save(issue);
        assertEquals(issue, issueDAO.getOne(issue.getId()));
        issueDAO.delete(issue);
        assertFalse(issueDAO.exists(issue.getId()));
    }

    /**
     * Tests the query for finding all frameworks in the DB.
     */
    @Test
    public void testFindAllIssues()
    {
        List<Issue> l = issueDAO.findAll();
        Issue issue = getTestIssue();

        assertNull(issue.getId());

        for (Issue i : l)
        {
            assertNotNull(i.getId());
            assertNotNull(i.getName());
        }
        issue = issueDAO.save(issue);
        assertFalse(l.contains(issue));
        issue = issueDAO.save(issue);
        l = issueDAO.findAll();
        assertTrue(l.contains(issue));

    }

    /**
     * Test for finding all issues from a project.
     */
    @Test
    public void testFindIssuesfindByProject()
    {
        assertNull(testProject1.getId());
        testProject1 = (Project) projectDao.save(testProject1);
        assertNotNull(testProject1.getId());

        assertNull(testProject2.getId());
        testProject2 = (Project) projectDao.save(testProject2);
        assertNotNull(testProject2.getId());
        projectDao.flush();

        testIssue1.setProject(testProject1);
        testIssue2.setProject(testProject1);
        testIssue3.setProject(testProject2);

        assertNull(testIssue1.getId());
        testIssue1 = (Issue) issueDAO.save(testIssue1);
        assertNotNull(testIssue1.getId());

        assertNull(testIssue2.getId());
        testIssue2 = (Issue) issueDAO.save(testIssue2);
        assertNotNull(testIssue2.getId());

        assertNull(testIssue3.getId());
        testIssue3 = (Issue) issueDAO.save(testIssue3);
        assertNotNull(testIssue3.getId());
        issueDAO.flush();

        List<Issue> result = issueDAO.findByProjectId(testProject1.getId());
        if (result != null)
        {
            assertTrue(result.contains(testIssue1));
            assertTrue(result.contains(testIssue2));
            assertFalse(result.contains(testIssue3));
        }
    }

    /**
     * Helper method to create a new Issue.
     * 
     * @return A valid Issue object
     */
    private Issue getTestIssue()
    {
        Project projekt = new Project();
        projekt.setName("Projekt1");
        projekt.setCreator("Lukas");
        projekt.setCreationDate(new Date());

        projectDao.save(projekt);

        Issue issue = new Issue();
        issue.setProject(projekt);
        issue.setName("Issue1");
        issue.setDescription("This is a description");
        issue.setCreator("Vlad");
        issue.setCreationDate(new Date());
        issue.setLastModifier("ASdkiqaow");
        issue.setModificationDate(new Date());

        return issue;
    }

}