package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.ArchitecturalPatternValidator;

/**
 * Test class for ArchitecturalPatternValidator.
 * 
 * @author Tim
 *
 */

public class ArchitecturalPatternValidatorTest
{
    private ArchitecturalPattern testArchitecturalPattern;
    private ArchitecturalPatternValidator testArchitecturalPatternValidator;

    /**
     * Setup method for architectural pattern validator. Called before each test
     * method. Creates a valid ArchitecturalPattern.
     * 
     * @throws Exception excep
     */
    @Before
    public void setUp() throws Exception
    {
        testArchitecturalPattern = new ArchitecturalPattern();
        testArchitecturalPattern.setId(1L);
        testArchitecturalPattern.setName("test");
        testArchitecturalPattern.setArchitecturalPatternCategory(new ArchitecturalPatternCategory());
        testArchitecturalPattern.setShortDescription("test");
        testArchitecturalPatternValidator = new ArchitecturalPatternValidator();
    }

    /**
     * Test method for default architectural pattern created in setUp(), if this
     * fails the other tests can't work properly.
     */
    @Test
    public void setUpValid()
    {
        Errors errors;
        errors = new BeanPropertyBindingResult(testArchitecturalPattern, "validAddress");
        testArchitecturalPatternValidator.validate(testArchitecturalPattern, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for missing name.
     */
    @Test
    public void nameMissing()
    {
        Errors errors;
        testArchitecturalPattern = new ArchitecturalPattern();
        testArchitecturalPattern.setId(1L);
        testArchitecturalPattern.setArchitecturalPatternCategory(new ArchitecturalPatternCategory());
        testArchitecturalPatternValidator = new ArchitecturalPatternValidator();
        errors = new BeanPropertyBindingResult(testArchitecturalPattern, "validAddress");
        testArchitecturalPatternValidator.validate(testArchitecturalPattern, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a wrong type.
     */
    @Test
    public void wrongType()
    {
        Errors errors;
        testArchitecturalPattern.setType("Framework");
        errors = new BeanPropertyBindingResult(testArchitecturalPattern, "validAddress");
        testArchitecturalPatternValidator.validate(testArchitecturalPattern, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for an altName1 which exceeds the character limit.
     */
    @Test
    public void nameTooLong()
    {
        Errors errors;
        testArchitecturalPattern.setName("fdsafsdafsadfsdafdsafsadfsadfsdafsdafsdafsdafsdafskdjhasfdkj"
                + "hsadjkfhjadskfhjskadhflskajdfhsdjklahfkjsdahfjldksafhjdsklfhdsjkfhsdkjlfhsdakjflhsdfakjl"
                + "fasdjhfsdalkjfasdkfasdjfsdfdjasjksdfahjasdfkjfsdajasdfkljfdsalkjfsdafsadkjsfadhfdasjkasdfdfsajlkt");
        errors = new BeanPropertyBindingResult(testArchitecturalPattern, "validAddress");
        testArchitecturalPatternValidator.validate(testArchitecturalPattern, errors);
        assertTrue(errors.hasErrors());
    }

}
