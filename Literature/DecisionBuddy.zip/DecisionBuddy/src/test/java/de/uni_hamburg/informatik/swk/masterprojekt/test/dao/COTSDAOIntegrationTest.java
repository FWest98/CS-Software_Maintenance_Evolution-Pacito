package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.COTSCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.COTSDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;

/**
 * Tests the COTSDAO and the real database.
 * 
 * @author Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class COTSDAOIntegrationTest
{
    @Autowired
    private COTSDAO cotsDAO;

    @Autowired
    private COTSCategoryDAO cotsCategoryDAO;

    /**
     * Tests the creation of a COTS.
     * 
     */
    @Test
    public void testSaveCOTS()
    {
        COTS cots = getTestCOTS();

        assertNull(cots.getId());

        cots = cotsDAO.save(cots);

        assertNotNull(cots.getId());
        assertTrue(cots.getId() > 0);
    }

    /**
     * Tests the deletion of a COTS.
     */
    @Test
    public void testDeleteCOTS()
    {
        COTS cots = getTestCOTS();

        assertNull(cots.getId());
        cots = cotsDAO.save(cots);
        assertEquals(cots, cotsDAO.getOne(cots.getId()));
        cotsDAO.delete(cots);
        assertFalse(cotsDAO.exists(cots.getId()));
    }

    /**
     * Tests the query for finding all COTSs in the DB.
     */
    @Test
    public void testFindAllCOTSs()
    {
        List<COTS> l = cotsDAO.findAll();
        COTS cots = getTestCOTS();

        assertNull(cots.getId());

        for (COTS f : l)
        {
            assertNotNull(f.getId());
            assertNotNull(f.getName());
            assertNotNull(f.getShortDescription());
        }

        assertFalse(l.contains(cots));
        cots = cotsDAO.save(cots);
        l = cotsDAO.findAll();
        assertTrue(l.contains(cots));

    }

    /**
     * Helper method to create a new COTS.
     * 
     * @return A valid COTS object
     */
    private COTS getTestCOTS()
    {
        COTSCategory cotsCategory = cotsCategoryDAO.findOne(new Long(1));

        COTS cots = new COTS();
        cots.setName("Spring4");
        cots.setShortDescription("Useful cots to implement MVC architecture");
        cots.setCreator("Vlad");
        cots.setCreationDate(new Date());
        cots.setLastModifier("Abjdsklhdlfj");
        cots.setModificationDate(new Date());
        cots.setCotsCategory(cotsCategory);
        cots.setCurrentVersion("4.0.6");
        cots.setDevelopmentStatus("active");
        cots.setDescription("The Spring COTS is an open source application cots and inversion of control"
                + " container for the Java platform. The cots's core features can be used by any Java "
                + "application, but there are extensions for building web applications on top of the Java EE "
                + "platform. Although the cots does not impose any specific programming model, it has "
                + "become popular in the Java community as an alternative to, replacement for, or even "
                + "addition to the Enterprise JavaBean (EJB) model.");
        cots.setOperatingSystem("cross system");
        cots.setProgrammingLanguage("Java");
        cots.setDeveloper("Pivotal Software");
        cots.setWebsite("spring.com");
        cots.setLicense("Apache Licence 2.0");
        cots.setSupport("blabla");
        cots.setDocumentation("large");
        cots.setCommunity("Spring devs");
        cots.setTesting("Rly?");
        cots.setSize(1);
        return cots;
    }
}