package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ConstraintDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.GeneralException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ConstraintService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Test class for ConstraintService.
 * 
 * @author Lucas
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class ConstraintServiceTest
{

    @Autowired
    private ConstraintService constraintService;

    @Autowired
    private ConstraintDAO constraintDAO;

    @Autowired
    private ProjectDAO projectDAO;

    @Autowired
    private IssueDAO issueDAO;

    @Autowired
    private SolutionDAO solutionDAO;

    private Constraint requiredConstraint;
    private Constraint deliveredConstraint;

    private Project project1;
    private Project project2;

    private Issue issue1;
    private Issue issue2;

    private Solution solution1;
    private Solution solution2;

    /**
     * Generate test data.
     */
    @Before
    public void setUp()
    {
        resetTestData();
        Mockito.when(constraintDAO.saveAndFlush(requiredConstraint)).thenReturn(requiredConstraint);
        Mockito.when(constraintDAO.saveAndFlush(deliveredConstraint)).thenReturn(deliveredConstraint);
        Mockito.when(issueDAO.saveAndFlush(issue1)).thenReturn(issue1);
        Mockito.when(issueDAO.saveAndFlush(issue2)).thenReturn(issue2);
        Mockito.when(solutionDAO.saveAndFlush(solution1)).thenReturn(solution1);
        Mockito.when(solutionDAO.saveAndFlush(solution2)).thenReturn(solution2);

        Mockito.when(issueDAO.findOne(1L)).thenReturn(issue1);
        Mockito.when(issueDAO.findOne(2L)).thenReturn(issue2);
        Mockito.when(solutionDAO.findOne(1L)).thenReturn(solution1);
        Mockito.when(solutionDAO.findOne(2L)).thenReturn(solution2);
    }

    /**
     * Reset DAO-objects.
     */
    @After
    public void reset()
    {
        Mockito.reset(constraintDAO);
        Mockito.reset(projectDAO);
        Mockito.reset(issueDAO);
        Mockito.reset(solutionDAO);
    }

    /**
     * Tests the method getConstraintById().
     */
    @Test
    public void testGetConstraintById()
    {
        Mockito.when(constraintDAO.findOne(1L)).thenReturn(requiredConstraint);
        Mockito.when(constraintDAO.findOne(2L)).thenReturn(deliveredConstraint);

        try
        {
            assertEquals(constraintService.getConstraintById(requiredConstraint.getId()), requiredConstraint);
            assertNotEquals(constraintService.getConstraintById(deliveredConstraint.getId()), requiredConstraint);
        }
        catch (GeneralException e)
        {
            e.printStackTrace();
        }

        Mockito.verify(constraintDAO).findOne(1L);
        Mockito.verify(constraintDAO).findOne(2L);
        Mockito.verifyNoMoreInteractions(constraintDAO);
    }

    /**
     * Tests the method deleteConstraint().
     */
    @Test
    public void testDeleteConstraint()
    {
        try
        {
            constraintService.deleteConstraint(1L);
        }
        catch (GeneralException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }

        Mockito.verify(constraintDAO).delete(1L);
        Mockito.verifyNoMoreInteractions(constraintDAO);
    }

    /**
     * Tests method assignToIssue().
     */
    @Test
    public void testAssignToIssue()
    {
        List<Constraint> constraintList = new ArrayList<Constraint>();
        constraintList.add(deliveredConstraint);

        try
        {
            constraintService.assignToIssueAndSave(constraintList, issue1);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            fail("Exception caught but not expected.");
        }

        assertTrue(issue1.getConstraints().contains(deliveredConstraint));
        Mockito.verify(issueDAO).saveAndFlush(issue1);
        Mockito.verifyNoMoreInteractions(issueDAO);
        Mockito.verifyNoMoreInteractions(constraintDAO);
    }

    /**
     * Tests method assignToSolution().
     */
    @Test
    public void testAssignToSolution()
    {
        List<Constraint> constraintList = new ArrayList<Constraint>();
        constraintList.add(deliveredConstraint);

        try
        {
            constraintService.assignToSolutionAndSave(constraintList, solution1);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            fail("Exception caught but not expected.");
        }

        assertTrue(solution1.getConstraints().contains(deliveredConstraint));
        Mockito.verify(solutionDAO).saveAndFlush(solution1);
        Mockito.verifyNoMoreInteractions(solutionDAO);
        Mockito.verifyNoMoreInteractions(constraintDAO);
    }

    /**
     * Tests method getConstraintsForIssue().
     */
    @Test
    public void testGetConstraintsForIssue()
    {
        issue1.addConstraint(requiredConstraint);

        try
        {
            assertTrue(constraintService.getConstraintsForIssue(issue1.getId()).contains(requiredConstraint));
            assertFalse(constraintService.getConstraintsForIssue(issue1.getId()).contains(deliveredConstraint));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            fail("Exception caught but not expected.");
        }
    }

    /**
     * Tests method getConstraintsForSolution().
     */
    @Test
    public void testGetConstraintsForSolution()
    {
        solution1.addConstraint(requiredConstraint);

        try
        {
            assertTrue(constraintService.getConstraintsForSolution(solution1.getId()).contains(requiredConstraint));
            assertFalse(constraintService.getConstraintsForSolution(solution1.getId()).contains(deliveredConstraint));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            fail("Exception caught but not expected.");
        }
    }

    /**
     * Tests the method getConstraintsByCriteria().
     */
    @Test
    public void testGetConstraintsByCriteria()
    {
        Constraint constraint3 = new Constraint();
        constraint3.setId(3L);

        List<Constraint> l1 = new ArrayList<Constraint>();
        l1.add(deliveredConstraint);
        l1.add(requiredConstraint);
        l1.add(constraint3);
        Mockito.when(constraintDAO.findAll()).thenReturn(l1);

        Filter<Constraint> filter = new Filter<Constraint>()
        {

            /*
             * Filter id < 3.
             */
            @Override
            public boolean isInResult(Constraint item)
            {
                return item.getId() < 3L;
            }
        };

        Comparator<Constraint> sorter = new Comparator<Constraint>()
        {

            /*
             * Sort by id.
             */
            @Override
            public int compare(Constraint arg0, Constraint arg1)
            {
                return arg0.getId() > arg1.getId() ? 1 : -1;
            }
        };

        List<Constraint> l2 = constraintService.getConstraintsByCriteria(filter, sorter);
        assertTrue(l2.size() == 2);
        assertTrue(l2.get(0).equals(requiredConstraint));
        assertTrue(l2.get(1).equals(deliveredConstraint));
        assertFalse(l2.contains(constraint3));
    }

    /**
     * Sets test data to a pre-defined state.
     */
    private void resetTestData()
    {
        project1 = new Project();
        project1.setId(1L);
        project1.setName("Masterprojekt");
        project1.setDescription("Our Master project");
        project1.setCreator("Lucas");
        project1.setCreationDate(new Date());
        project1.setLastModifier("Lucas");
        project1.setModificationDate(new Date());

        project2 = new Project();
        project2.setId(2L);
        project2.setName("OtherProject");
        project2.setDescription("Another project");
        project2.setCreator("Lucas");
        project2.setCreationDate(new Date());
        project2.setLastModifier("Lucas");
        project2.setModificationDate(new Date());

        issue1 = new Issue();
        issue1.setId(1L);
        issue1.setProject(project1);
        issue1.setName("Issue1");
        issue1.setDescription("Testissue 1");
        issue1.setCreator("Lucas");
        issue1.setCreationDate(new Date());
        issue1.setLastModifier("Lucas");
        issue1.setModificationDate(new Date());

        issue2 = new Issue();
        issue2.setId(2L);
        issue2.setProject(project1);
        issue2.setName("Issue2");
        issue2.setDescription("Testissue 2");
        issue2.setCreator("Lucas");
        issue2.setCreationDate(new Date());
        issue2.setLastModifier("Lucas");
        issue2.setModificationDate(new Date());

        FrameworkCategory fc = new FrameworkCategory();
        fc.setId(42L);
        fc.setName("Test category");

        Framework framework1 = new Framework();
        framework1.setId(1L);
        framework1.setName("Test framework 1");
        framework1.setCreator("Tester1");
        framework1.setCreationDate(new Date());
        framework1.setFrameworkCategory(fc);
        solution1 = framework1;

        Framework framework2 = new Framework();
        framework2.setId(2L);
        framework2.setName("Test framework 2");
        framework2.setCreator("Tester2");
        framework2.setCreationDate(new Date());
        framework2.setFrameworkCategory(fc);
        solution2 = framework2;

        requiredConstraint = new Constraint();
        requiredConstraint.setId(1L);
        deliveredConstraint = new Constraint();
        deliveredConstraint.setId(2L);
    }
}
