package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;

/**
 * Tests the ProjectDAO and the real database.
 * 
 * @author Vlad
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class ProjectDAOIntegrationTest
{
    @Autowired
    private ProjectDAO projectDAO;

    /**
     * Test if a project can be created in the database.
     */
    @Test
    public void testCreateProject()
    {
        Project project = getTestProject();

        assertNull(project.getId());

        project = projectDAO.save(project);

        // Ein flush wird durchgef�hrt um sichr zu gehen das die Daten auf die
        // DB
        // geschrieben werden. Nach der Methode erfolgt automtisch ein Rollback.
        projectDAO.flush();

        assertNotNull(project.getId());
        assertTrue(project.getId() > 0);
    }

    /**
     * Tests the deletion of a project.
     */
    @Test
    public void testDeleteProject()
    {
        Project project = getTestProject();

        assertNull(project.getId());
        project = projectDAO.save(project);
        assertEquals(project, projectDAO.getOne(project.getId()));
        projectDAO.delete(project);
        assertFalse(projectDAO.exists(project.getId()));
    }

    /**
     * Tests the query for finding all projects in the DB.
     */
    @Test
    public void testFindAllProjects()
    {
        List<Project> l = projectDAO.findAll();
        Project project = getTestProject();

        assertNull(project.getId());

        for (Project p : l)
        {
            assertNotNull(p.getId());
            assertNotNull(p.getName());
        }

        assertFalse(l.contains(project));
        project = projectDAO.save(project);
        l = projectDAO.findAll();
        assertTrue(l.contains(project));
    }

    /**
     * Helper method to create a new Project.
     * 
     * @return A valid Project object
     */
    private Project getTestProject()
    {
        Project project = new Project();
        project.setName("Project1");
        project.setDescription("A test project");
        project.setCreator("Vlad");
        project.setCreationDate(new Date());
        project.setLastModifier("Asdkjgas");
        project.setModificationDate(new Date());

        return project;
    }
}