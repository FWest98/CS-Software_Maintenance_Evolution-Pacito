package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern}
 * class. This class contains no business logic and only toString(), hashCode()
 * and equals() methods are tested.
 * 
 * @author Burak
 *
 */
public class ElementDesignPatternTest
{
    private ElementDesignPattern elementDesignPattern1;
    private ElementDesignPattern elementDesignPattern2;
    private ElementDesignPattern elementDesignPattern3;

    /**
     * Creates three ElementDesignPatterns. ElementDesignPattern 1 and 2 should
     * be equal and 3 different.
     */
    @Before
    public void setUp()
    {
        elementDesignPattern1 = new ElementDesignPattern();
        elementDesignPattern2 = new ElementDesignPattern();
        elementDesignPattern3 = new ElementDesignPattern();

        elementDesignPattern1.setId(1L);
        elementDesignPattern2.setId(1L);
        elementDesignPattern3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testElementDesignPatternToString()
    {
        System.out.println(elementDesignPattern1.toString());
    }

    /**
     * Tests the hashCode functionality of a ElementDesignPattern, should only
     * be affected by Id.
     */
    @Test
    public void testElementDesignPatternHashcode()
    {
        elementDesignPattern1.setRole("Rolle Eins");
        elementDesignPattern2.setRole("Rolle Eins");
        elementDesignPattern3.setRole("Rolle Zwei");
        assertTrue(elementDesignPattern1.hashCode() == elementDesignPattern1.hashCode());
        assertTrue(elementDesignPattern1.hashCode() == elementDesignPattern2.hashCode());
        assertFalse(elementDesignPattern2.hashCode() == elementDesignPattern3.hashCode());
        System.out.println(elementDesignPattern1.toString());
        System.out.println(elementDesignPattern2.toString());
        System.out.println(elementDesignPattern3.toString());
    }

    /**
     * Tests the equals functionality of a ElementDesignPattern, should only be
     * affected by Id.
     */
    @Test
    public void testElementDesignPatternEquals()
    {
        assertTrue(elementDesignPattern1.equals(elementDesignPattern1));
        assertFalse(elementDesignPattern1.equals(null));
        assertFalse(elementDesignPattern1.equals(new String()));
        assertTrue(elementDesignPattern1.equals(elementDesignPattern2));
        assertFalse(elementDesignPattern1.equals(elementDesignPattern3));
    }
}