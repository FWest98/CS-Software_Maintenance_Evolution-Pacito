package de.uni_hamburg.informatik.swk.masterprojekt.test.beans;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.MenuItem;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production.WebAppConfig;

/**
 * Simple tests for MenuItem class. For more complicated tests see
 * MenuItemManagerTest.
 * 
 * @author schaak
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = WebAppConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MenuItemTest
{

    private MenuItem menuItem;

    /**
     * Setup method to create an empty menuItem.
     */
    @Before
    public void initializemenuItem()
    {
        menuItem = new MenuItem("addlink", "wrongurl", "wrongpic");
    }

    /**
     * Tests getter and setters.
     */
    @Test
    public void testGettersAndSetters()
    {
        String oldName = menuItem.getName();
        String newName = oldName + " Version II";
        menuItem.setName(newName);
        assertTrue("getName/setName do not work properly.", menuItem.getName().equals("addlink Version II"));

        String oldUrl = menuItem.getUrl();
        String newUrl = oldUrl + ".new";
        menuItem.setUrl(newUrl);
        assertTrue("getUrl/setUrl do not work properly.", menuItem.getUrl().equals("wrongurl.new"));

        String oldPic = menuItem.getPicture();
        String newPic = oldPic + ".new";
        menuItem.setPicture(newPic);
        assertTrue("getPic/setPic do not work properly.", menuItem.getPicture().equals("wrongpic.new"));

        List<String> params = new ArrayList<String>();
        params.add("param1");
        params.add("param2");
        params.add("param3");
        menuItem.setParams(params);
        assertTrue("getParams/setParams do not work properly.", menuItem.getParams().size() == 3);

        menuItem.addParam("param4");
        assertTrue("addParam does not work properly.", menuItem.getParams().size() == 4);
    }
}