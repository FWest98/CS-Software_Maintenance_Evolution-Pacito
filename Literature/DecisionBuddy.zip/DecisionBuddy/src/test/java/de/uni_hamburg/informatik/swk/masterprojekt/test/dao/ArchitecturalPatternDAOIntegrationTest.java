package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ArchitecturalPatternCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ArchitecturalPatternDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;

/**
 * Tests the ArchitecturalPatternDAO and the real database.
 * 
 * @author Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class ArchitecturalPatternDAOIntegrationTest
{
    @Autowired
    private ArchitecturalPatternDAO architecturalPatternDAO;

    @Autowired
    private ArchitecturalPatternCategoryDAO apcDAO;

    /**
     * Tests the creation of a architectural pattern.
     * 
     * @throws SQLException ecxp
     * 
     */
    @Test
    public void testSaveArchitecturalPattern() throws SQLException
    {
        ArchitecturalPattern architecturalPattern = getTestArchitecturalPattern();

        assertNull(architecturalPattern.getId());

        architecturalPattern = architecturalPatternDAO.save(architecturalPattern);

        assertNotNull(architecturalPattern.getId());
        assertTrue(architecturalPattern.getId() > 0);
    }

    /**
     * Used for testing the blob makes string a string of hex code to a byte
     * array.
     * 
     * @param s the string which will be converted to the byte array
     * @return returns the byte array
     */
    public static byte[] hexStringToByteArray(String s)
    {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2)
        {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    /**
     * Tests the hashCode functionality of a architectural pattern.
     */
    @Test
    public void testArchitecturalPatternHashcode()
    {
        ArchitecturalPattern ap1 = new ArchitecturalPattern();
        ap1.setId(1L);
        ArchitecturalPattern ap2 = new ArchitecturalPattern();
        ap2.setId(1L);
        ArchitecturalPattern ap3 = new ArchitecturalPattern();
        ap3.setId(2L);
        assertTrue(ap1.hashCode() == ap2.hashCode());
        assertFalse(ap2.hashCode() == ap3.hashCode());
    }

    /**
     * Tests the deletion of a architectural patterns.
     * 
     * @throws SQLException
     */
    @Test
    public void testDeleteArchitecturalPattern() throws SQLException
    {
        ArchitecturalPattern architecturalPattern = getTestArchitecturalPattern();

        assertNull(architecturalPattern.getId());
        architecturalPattern = architecturalPatternDAO.save(architecturalPattern);
        assertEquals(architecturalPattern, architecturalPatternDAO.getOne(architecturalPattern.getId()));
        architecturalPatternDAO.delete(architecturalPattern);
        assertFalse(architecturalPatternDAO.exists(architecturalPattern.getId()));
    }

    /**
     * Tests the query for finding all architectural patterns in the DB.
     * 
     * @throws SQLException
     */
    @Test
    public void testFindAllArchitecturalPatterns() throws SQLException
    {
        List<ArchitecturalPattern> l = architecturalPatternDAO.findAll();
        ArchitecturalPattern architecturalPattern = getTestArchitecturalPattern();

        assertNull(architecturalPattern.getId());

        for (ArchitecturalPattern ap : l)
        {
            assertNotNull(ap.getId());
            assertNotNull(ap.getName());
            assertNotNull(ap.getShortDescription());
        }

        assertFalse(l.contains(architecturalPattern));
        architecturalPattern = architecturalPatternDAO.save(architecturalPattern);
        l = architecturalPatternDAO.findAll();
        assertTrue(l.contains(architecturalPattern));
    }

    /**
     * Helper method to create a new ArchitecturalPattern.
     * 
     * @return A valid ArchitecturalPattern object
     * @throws SQLException
     * @throws
     */
    private ArchitecturalPattern getTestArchitecturalPattern() throws SQLException
    {
        ArchitecturalPatternCategory apc = apcDAO.findOne(new Long(1));
        ArchitecturalPattern architecturalPattern = new ArchitecturalPattern();
        architecturalPattern.setArchitecturalPatternCategory(apc);
        architecturalPattern.setName("Spring4");
        architecturalPattern.setShortDescription("Useful framework to implement MVC architecture");
        architecturalPattern.setCreator("Vlad");
        architecturalPattern.setCreationDate(new Date());
        architecturalPattern.setLastModifier("Abjdsklhdlfj");
        architecturalPattern.setModificationDate(new Date());
        architecturalPattern.setArchitecturalPatternCategory(apc);
        architecturalPattern.setAltName1("a");
        architecturalPattern.setAltName2("a");
        architecturalPattern.setApplicability("all");
        architecturalPattern.setCollaboration("much");
        architecturalPattern.setConsequences("many");
        architecturalPattern.setKnownUses("many");
        architecturalPattern.setMotivation("fun");
        architecturalPattern.setParticipants("many");
        architecturalPattern.setRelatedPatterns("all");
        architecturalPattern.setStructure(new SerialBlob(hexStringToByteArray("e04fd020ea3a6910a2d808002b30309d")));
        architecturalPattern.setUsance("all");

        return architecturalPattern;
    }

}