package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.QualityGoalDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal;

/**
 * Tests the QualityGoal, WeightedQualityGoal DAOs and the real database.
 * 
 * @author Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class QualityGoalDAOIntegrationTest
{
    @Autowired
    private IssueDAO issueDAO;

    @Autowired
    private ProjectDAO projectDao;

    @Autowired
    private QualityGoalDAO qualityGoalDAO;

    private Project testProject = new Project();
    private Issue testIssue = new Issue();

    /**
     * Creates test projects and issues.
     */
    @Before
    public void setUp()
    {
        testProject.setName("Masterprojekt");
        testProject.setDescription("Our Master project");
        testProject.setCreator("Tim");
        testProject.setCreationDate(new Date());
        testProject.setLastModifier("Tim");
        testProject.setModificationDate(new Date());

        testIssue.setName("Issue1");
        testIssue.setDescription("Testissue 1");
        testIssue.setCreator("Tim");
        testIssue.setCreationDate(new Date());
        testIssue.setLastModifier("Tim");
        testIssue.setModificationDate(new Date());
    }

    /**
     * Test if a QualityGoal can be created and saved in the database.
     */
    @Test
    public void testSaveQualityGoalInDB()
    {
        QualityGoal qualityGoal = new QualityGoal();
        qualityGoal.setName("Test");
        assertNull(qualityGoal.getId());

        qualityGoal = qualityGoalDAO.saveAndFlush(qualityGoal);

        assertNotNull(qualityGoal.getId());
        assertTrue(qualityGoal.getId() > 0);
    }

    /**
     * Test if a QualityGoal can be assigned and removed from an Issue.
     */
    @Test
    public void testAssignAndRemoveQualityGoalFromIssue()
    {
        // Get a QualityGoal from DB
        QualityGoal qualityGoal = qualityGoalDAO.findOne(1L);
        assertNotNull(qualityGoal);

        // Create and save a new Issue
        Project project = projectDao.save(testProject);
        Issue issue = testIssue;
        issue.setProject(project);
        issue = issueDAO.save(issue);
        assertNotNull(issue);

        // Create weightedQualityGoal and save it in issue
        WeightedQualityGoal weightedQualityGoal = new WeightedQualityGoal();
        weightedQualityGoal.setQualityGoal(qualityGoal);
        weightedQualityGoal.setWeight(2);
        issue.addWeightedQualityGoal(weightedQualityGoal);
        issue = issueDAO.saveAndFlush(issue);

        // Make sure it can be found again
        assertTrue(issue.getWeightedQualityGoals().contains(weightedQualityGoal));

        // Remove the QualityGoal again.
        issue.removeWeightedQualityGoal(weightedQualityGoal);
        issue = issueDAO.saveAndFlush(issue);

        // Make sure it can't be found anymore
        assertFalse(issue.getWeightedQualityGoals().contains(weightedQualityGoal));
    }
}