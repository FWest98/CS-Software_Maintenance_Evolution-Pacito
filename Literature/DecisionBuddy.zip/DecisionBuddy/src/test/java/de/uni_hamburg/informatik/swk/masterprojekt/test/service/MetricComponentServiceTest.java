package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javassist.NotFoundException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementMetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementMetric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementMetricService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.metric.MetricComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class MetricComponentServiceTest
{
    private Project testProject1;
    private Project testProject2;
    private Element rootElement;
    private List<MetricValue> testMetricValues;
    private List<MetricValue> testMetricValuesGlobal;
    private ElementMetric elementMetric;

    @Autowired
    private MetricComponentService metricComponentService;

    @Autowired
    private ElementMetricService elementMetricService;

    @Before
    public void setUp()
    {
        // Project without root element
        testProject1 = new Project();
        testProject1.setId(0L);
        testProject1.setName("Masterprojekt");
        testProject1.setDescription("Our Master project");
        testProject1.setCreator("Lucas");
        testProject1.setCreationDate(new Date());
        testProject1.setLastModifier("Lucas");
        testProject1.setModificationDate(new Date());

        // Project with root element and 1 child element
        testProject2 = new Project();
        testProject2.setId(1L);
        testProject2.setName("OtherProject");
        testProject2.setDescription("Another project");
        testProject2.setCreator("Lucas");
        testProject2.setCreationDate(new Date());
        testProject2.setLastModifier("Lucas");
        testProject2.setModificationDate(new Date());

        rootElement = new Element();
        rootElement.setId(0L);
        rootElement.setName("org.uni-hamburg.test");
        rootElement.setParent(null);
        rootElement.setProject(testProject2);
        rootElement.setType(ElementType.Package);

        elementMetric = new ElementMetric();
        elementMetric.setId(0L);
        elementMetric.setProject(testProject2);
        elementMetric.setElement(rootElement);

        Element elementChild = new Element();
        elementChild.setId(1L);
        elementChild.setName("org.uni-hamburg.test.child");
        elementChild.setParent(rootElement);
        elementChild.setProject(testProject2);
        elementChild.setType(ElementType.File);

        // create MetricValues
        testMetricValues = new ArrayList<MetricValue>();

        Metric metric1 = new Metric();
        metric1.setId(0L);
        metric1.setType(MetricType.Structural);

        MetricValue metricValue1 = new MetricValue();
        metricValue1.setId(0L);
        metricValue1.setElement(elementChild);
        metricValue1.setMetric(metric1);
        metricValue1.setValue(42f);

        MetricValue metricValue2 = new MetricValue();
        metricValue2.setId(1L);
        metricValue2.setElement(elementChild);
        metricValue2.setMetric(metric1);
        metricValue2.setValue(21f);

        testMetricValues.add(metricValue1);
        testMetricValues.add(metricValue2);

        // create more MetricValues (global)
        testMetricValuesGlobal = new ArrayList<MetricValue>();

        Metric metricGlobal1 = new Metric();
        metricGlobal1.setId(2L);
        metricGlobal1.setType(MetricType.Global);
        metricGlobal1.setSubType(MetricSubType.Cyclicity);

        MetricValue metricValue3 = new MetricValue();
        metricValue3.setId(3L);
        metricValue3.setElement(elementChild);
        metricValue3.setMetric(metricGlobal1);
        metricValue3.setValue(1337f);

        testMetricValuesGlobal.add(metricValue3);
    }

    @Test(expected = NotFoundException.class)
    public void testGetRootElementProjectNotExists() throws NotFoundException
    {
        // Project for this ID does not exist
        metricComponentService.getRootElementForProjectid(999);
    }

    @Test(expected = NotFoundException.class)
    public void testGetRootElementProjectExsistsRootNotExists() throws NotFoundException
    {
        // The project exists, but there is not root element for it
        metricComponentService.getRootElementForProjectid(0);
    }

    @Test
    public void testGetRootElementProjectExistsRootExists() throws NotFoundException
    {
        try
        {
            Mockito.stub(elementMetricService.getElementMetricByProjectId(1L)).toReturn(elementMetric);
        }
        catch (ElementMetricNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }

        Element root = metricComponentService.getRootElementForProjectid(1);

        assertNotNull(root);
        assertNull(root.getParent());
    }

    @Test
    public void testGetMetricsByTypeProjectNotExistsTypeExists() throws NotFoundException
    {
        assertTrue(metricComponentService.getMetricsByType(999, MetricType.Global).isEmpty());
        assertEquals(new ArrayList<Metric>(), metricComponentService.getMetricsByType(999, MetricType.Global));
    }

    public void testGetMetricsByTypeNoMetricsInType() throws NotFoundException
    {
        List<Metric> metrics = metricComponentService.getMetricsByType(1, MetricType.Additional);

        // Should return an empty list.
        // This is no error, it just indicated that there are no elements in
        // this category, as long as it exists
        assertTrue(metrics.isEmpty());
    }

    public void testGetMetricsByType() throws NotFoundException
    {
        MetricType type = MetricType.Global;

        List<Metric> metrics = metricComponentService.getMetricsByType(1, type);

        assertFalse(metrics.isEmpty());

        for (Metric m : metrics)
        {
            assertEquals(type, m.getType());
        }
    }

    @Test
    public void testGetMetricsByTypeAndCategoryProjectNotExists() throws NotFoundException
    {
        assertTrue(metricComponentService.getMetricsByTypeAndSubtype(999, MetricType.Global, MetricSubType.Cyclicity)
                .isEmpty());
        assertEquals(new ArrayList<MetricValue>(),
                metricComponentService.getMetricsByTypeAndSubtype(999, MetricType.Global, MetricSubType.Cyclicity));
    }

    @Test
    public void testGetMetricsByTypeAndCategoryNoMetricsInType() throws NotFoundException
    {
        // Expect that there are no metrics for this type, therefore, nothing
        // should be found even if further filtered by the subtype
        List<MetricValue> values = metricComponentService.getMetricsByTypeAndSubtype(1, MetricType.Additional,
                MetricSubType.Structure);

        assertTrue(values.isEmpty());
    }

    @Test
    public void testGetMetricsByTypeAndCategoryNoMetricsInSubtype() throws NotFoundException
    {
        // This time, there are metrics for the given type but not the subtype
        // yet this one exists
        List<MetricValue> values = metricComponentService.getMetricsByTypeAndSubtype(1, MetricType.Global,
                MetricSubType.Other);

        assertTrue(values.isEmpty());
    }

    @Test
    public void testGetMetricsByTypeAndCategory() throws NotFoundException
    {
        MetricType type = MetricType.Global;
        MetricSubType subtype = MetricSubType.Cyclicity;

        Mockito.when(metricComponentService.getMetricsByTypeAndSubtype(1, type, subtype)).thenReturn(
                testMetricValuesGlobal);

        List<MetricValue> values = metricComponentService.getMetricsByTypeAndSubtype(1, type, subtype);

        assertFalse(values.isEmpty());

        for (MetricValue v : values)
        {
            assertEquals(type, v.getMetric().getType());
            assertEquals(subtype, v.getMetric().getSubType());
        }
    }

    @Test
    public void testGetValuesForElementProjectNotExists() throws NotFoundException
    {
        List<MetricValue> values = metricComponentService.getMetricValuesForElement(999, MetricType.Global);

        assertTrue(values.isEmpty());
    }

    @Test
    public void testGetValuesForElementNoValuesInType() throws NotFoundException
    {
        List<MetricValue> values = metricComponentService.getMetricValuesForElement(1, MetricType.Global);

        assertTrue(values.isEmpty());
    }

    @Test
    public void testGetValuesForElement() throws NotFoundException
    {
        Mockito.when(metricComponentService.getMetricValuesForElement(1, MetricType.Structural)).thenReturn(
                testMetricValues);

        List<MetricValue> values = metricComponentService.getMetricValuesForElement(1, MetricType.Structural);

        assertFalse(values.isEmpty());

        MetricType b = MetricType.Structural;

        for (MetricValue v : values)
        {
            assertEquals(b, v.getMetric().getType());
        }
    }
}
