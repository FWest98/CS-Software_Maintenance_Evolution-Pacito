package de.uni_hamburg.informatik.swk.masterprojekt.test.config;

import java.util.Enumeration;
import java.util.Properties;

import org.junit.Test;

/**
 * Test of the system.
 * 
 * @author biryuk
 *
 */
public class SystemTest
{
    /**
     * Not a real Unit test. Prints out the properties of the system on which
     * the app is executed.
     */
    @Test
    public void test()
    {
        Properties p = System.getProperties();
        Enumeration<?> keys = p.keys();
        while (keys.hasMoreElements())
        {
            String key = (String) keys.nextElement();
            String value = (String) p.get(key);
            System.out.println(key + ": " + value);
        }
    }
}