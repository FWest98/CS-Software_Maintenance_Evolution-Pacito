package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.TechnicalTermValidator;

/**
 * Test class for TechnicalTermValidator.
 * 
 * @author Tim
 *
 */

public class TechnicalTermValidatorTest
{
    private TechnicalTerm testTechnicalTerm;
    private TechnicalTermValidator testTechnicalTermValidator;

    /**
     * Setup method for technicalTerm validator. Called before each test method.
     * Creates a valid TechnicalTerm.
     * 
     * @throws Exception excep
     */
    @Before
    public void setUp() throws Exception
    {
        testTechnicalTerm = new TechnicalTerm();
        testTechnicalTerm.setId(1L);
        testTechnicalTerm.setDeliveredBy("Solution");
        testTechnicalTerm.setIdentifier("Reaction Timne");
        testTechnicalTerm.setType("int");
        testTechnicalTerm.setUnit("Milliseconds");
        testTechnicalTermValidator = new TechnicalTermValidator();
    }

    /**
     * Test method for default design pattern created in setUp(), if this fails
     * the other tests can't work properly.
     */
    @Test
    public void testSetUpValid()
    {
        Errors errors;
        errors = new BeanPropertyBindingResult(testTechnicalTerm, "validAddress");
        testTechnicalTermValidator.validate(testTechnicalTerm, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for missing name.
     */
    @Test
    public void testIdentifierMissing()
    {
        Errors errors;
        testTechnicalTerm.setIdentifier("");
        testTechnicalTermValidator = new TechnicalTermValidator();
        errors = new BeanPropertyBindingResult(testTechnicalTerm, "validAddress");
        testTechnicalTermValidator.validate(testTechnicalTerm, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Create string of lenghts n.
     * 
     * @param n the length of the string
     * @return new string of length n
     */
    public String createStringOfLenghtsN(int n)
    {
        String string = "a";
        for (int i = 1; i < n; i++)
        {
            string = string.concat("a");
        }
        return string;
    }

    /**
     * Test method for an identifier which exceeds the character limit.
     */
    @Test
    public void testIdentifierTooLong()
    {
        Errors errors;
        String string = createStringOfLenghtsN(ColumnLength.SHORT + 1);
        testTechnicalTerm.setIdentifier(string);
        errors = new BeanPropertyBindingResult(testTechnicalTerm, "validAddress");
        testTechnicalTermValidator.validate(testTechnicalTerm, errors);
        assertTrue(errors.hasErrors());
        string = createStringOfLenghtsN(ColumnLength.SHORT);
        testTechnicalTerm.setIdentifier(string);
        errors = new BeanPropertyBindingResult(testTechnicalTerm, "validAddress");
        testTechnicalTermValidator.validate(testTechnicalTerm, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for an unit which exceeds the character limit.
     */
    @Test
    public void testUnitTooLong()
    {
        Errors errors;
        String string = createStringOfLenghtsN(ColumnLength.SHORT + 1);
        testTechnicalTerm.setUnit(string);
        errors = new BeanPropertyBindingResult(testTechnicalTerm, "validAddress");
        testTechnicalTermValidator.validate(testTechnicalTerm, errors);
        assertTrue(errors.hasErrors());
        string = createStringOfLenghtsN(ColumnLength.SHORT);
        testTechnicalTerm.setUnit(string);
        errors = new BeanPropertyBindingResult(testTechnicalTerm, "validAddress");
        testTechnicalTermValidator.validate(testTechnicalTerm, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test if an empty StringValue for string type is found.
     */
    @Test
    public void testNoStringValues()
    {
        Errors errors;
        testTechnicalTerm.setType("string");
        errors = new BeanPropertyBindingResult(testTechnicalTerm, "technicalTerm");
        testTechnicalTermValidator.validate(testTechnicalTerm, errors);
        assertTrue(errors.hasErrors());
        List<StringValue> stringValues = new ArrayList<StringValue>();
        stringValues.add(new StringValue());
        testTechnicalTerm.setStringValues(stringValues);
        errors = new BeanPropertyBindingResult(testTechnicalTerm, "technicalTerm");
        testTechnicalTermValidator.validate(testTechnicalTerm, errors);
        assertFalse(errors.hasErrors());
    }

}