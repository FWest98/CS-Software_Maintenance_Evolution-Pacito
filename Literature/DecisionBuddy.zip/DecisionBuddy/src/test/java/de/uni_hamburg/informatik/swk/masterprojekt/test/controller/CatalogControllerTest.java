package de.uni_hamburg.informatik.swk.masterprojekt.test.controller;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ControllerTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.SolutionService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Unit test for class CatalogController.
 * 
 * @author schaak
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
// use test config file instead of app config
@ContextConfiguration(classes = { ControllerTestConfig.class })
@WebAppConfiguration
// Activating the test profile is necessary so the beans from TestConfig are
// used
@ActiveProfiles(profiles = "ControllerTesting")
public class CatalogControllerTest
{
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private SolutionService solutionServiceMock;

    private ArgumentCaptor<Solution> argumentCaptor;

    private List<Solution> solutionList;
    private List<FrameworkCategory> frameworkCategoryList;
    private List<ArchitecturalPatternCategory> architecturalPatternCategoryList;
    private List<DesignPatternCategory> designPatternCategoryList;
    private List<COTSCategory> cotsCategoryList;
    private List<RefactoringCategory> refactoringCategoryList;

    // dummy solutions
    private Solution dummyCompleteFramework;
    private Solution dummyCompleteArchitecturalPattern;
    private Solution dummyCompleteDesignPattern;
    private Solution dummyCompleteCOTS;
    private Solution dummyCompleteRefactoring;

    private Solution dummyMinimalFramework;
    private Solution dummyMinimalArchitecturalPattern;
    private Solution dummyMinimalDesignPattern;
    private Solution dummyMinimalCOTS;
    private Solution dummyMinimalRefactoring;

    /**
     * Set-up method. Executes before every test.
     * 
     * @throws SolutionPersistenceException solution cannot be saved
     * @throws SolutionNotFoundException solution cannot be found
     */
    @Before
    public void setUp() throws SolutionPersistenceException, SolutionNotFoundException
    {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

        argumentCaptor = ArgumentCaptor.forClass(Solution.class);

        solutionList = new ArrayList<Solution>();

        // Create dummy framework categories
        // frameworkCategoryList = new ArrayList<FrameworkCategory>();
        frameworkCategoryList = createDummyFrameworkCategories();

        // Create dummy architectural pattern categories
        architecturalPatternCategoryList = new ArrayList<ArchitecturalPatternCategory>();
        architecturalPatternCategoryList = createDummyArchitecturalPatternCategories();

        // Create dummy design pattern categories
        // designPatternCategoryList = new ArrayList<DesignPatternCategory>();
        designPatternCategoryList = createDummyDesignPatternCategories();

        // Create dummy cots categories
        // cotsCategoryList = new ArrayList<COTSCategory>();
        cotsCategoryList = createDummyCOTSCategories();

        // Create dummy refactoring categories
        // refactoringCategoryList = new ArrayList<RefactoringCategory>();
        refactoringCategoryList = createDummyRefactoringCategories();

        // Create dummy solutions
        dummyCompleteFramework = createDummyData(1L, "Framework", "complete");
        solutionList.add(dummyCompleteFramework);

        dummyCompleteArchitecturalPattern = createDummyData(2L, "ArchitecturalPattern", "complete");
        solutionList.add(dummyCompleteArchitecturalPattern);

        dummyCompleteDesignPattern = createDummyData(3L, "DesignPattern", "complete");
        solutionList.add(dummyCompleteDesignPattern);

        dummyCompleteCOTS = createDummyData(4L, "COTS", "complete");
        solutionList.add(dummyCompleteCOTS);

        dummyCompleteRefactoring = createDummyData(5L, "Refactoring", "complete");
        solutionList.add(dummyCompleteRefactoring);

        dummyMinimalFramework = createDummyData(10L, "Framework", "minimal");
        solutionList.add(dummyMinimalFramework);

        dummyMinimalArchitecturalPattern = createDummyData(20L, "ArchitecturalPattern", "minimal");
        solutionList.add(dummyMinimalArchitecturalPattern);

        dummyMinimalDesignPattern = createDummyData(30L, "DesignPattern", "minimal");
        solutionList.add(dummyMinimalDesignPattern);

        dummyMinimalCOTS = createDummyData(40L, "COTS", "minimal");
        solutionList.add(dummyMinimalCOTS);

        dummyMinimalRefactoring = createDummyData(50L, "Refactoring", "minimal");
        solutionList.add(dummyMinimalRefactoring);

        // Service method mocks
        Mockito.when(
                solutionServiceMock.getSolutionsByCriteria(org.mockito.Matchers.<Filter<Solution>> any(),
                        org.mockito.Matchers.<Comparator<Solution>> any())).thenReturn(solutionList);

        Mockito.when(solutionServiceMock.getSolutionById(1)).thenReturn(dummyCompleteFramework);
        Mockito.when(solutionServiceMock.getSolutionById(2)).thenReturn(dummyCompleteArchitecturalPattern);
        Mockito.when(solutionServiceMock.getSolutionById(3)).thenReturn(dummyCompleteDesignPattern);
        Mockito.when(solutionServiceMock.getSolutionById(4)).thenReturn(dummyCompleteCOTS);
        Mockito.when(solutionServiceMock.getSolutionById(5)).thenReturn(dummyCompleteRefactoring);

        Mockito.when(solutionServiceMock.getSolutionById(10)).thenReturn(dummyMinimalFramework);
        Mockito.when(solutionServiceMock.getSolutionById(20)).thenReturn(dummyMinimalArchitecturalPattern);
        Mockito.when(solutionServiceMock.getSolutionById(30)).thenReturn(dummyMinimalDesignPattern);
        Mockito.when(solutionServiceMock.getSolutionById(40)).thenReturn(dummyMinimalCOTS);
        Mockito.when(solutionServiceMock.getSolutionById(50)).thenReturn(dummyMinimalRefactoring);

        Mockito.when(solutionServiceMock.saveSolution(org.mockito.Matchers.<Solution> any())).thenReturn(
                dummyCompleteFramework);

        Mockito.when(solutionServiceMock.getFrameworkCategories()).thenReturn(frameworkCategoryList);
        Mockito.when(solutionServiceMock.getArchitecturalPatternCategories()).thenReturn(
                architecturalPatternCategoryList);
        Mockito.when(solutionServiceMock.getDesignPatternCategories()).thenReturn(designPatternCategoryList);
        Mockito.when(solutionServiceMock.getCOTSCategories()).thenReturn(cotsCategoryList);
        Mockito.when(solutionServiceMock.getRefactoringCategories()).thenReturn(refactoringCategoryList);
    }

    /**
     * Reset mock for SolutionService after every test.
     * 
     */
    @After
    public void resetMock()
    {
        Mockito.reset(solutionServiceMock);
    }

    /**
     * Tests if all pre populated model attributes are available.
     * 
     * @param resultActions the resultActions object
     * 
     * @throws Exception exception on method call
     */
    public void testPrePopulatedValues(ResultActions resultActions) throws Exception
    {
        // check all pre populated model values
        resultActions.andExpect(model().attribute("activeview", "catalog"));
        resultActions.andExpect(model().attribute("controlbar", notNullValue()));
        resultActions.andExpect(model().attribute("filteringParams", notNullValue()));
        resultActions.andExpect(model().attribute("sortingParams", notNullValue()));
        resultActions.andExpect(model().attribute("operatingsystems", notNullValue()));
        resultActions.andExpect(model().attribute("programminglanguages", notNullValue()));
        resultActions.andExpect(model().attribute("licenses", notNullValue()));
        resultActions.andExpect(model().attribute("communitysizes", notNullValue()));
        resultActions.andExpect(model().attribute("developmentstati", notNullValue()));
        resultActions.andExpect(model().attribute("solutiontypes", notNullValue()));
        resultActions.andExpect(model().attribute("frameworkcategories", notNullValue()));
        resultActions.andExpect(model().attribute("architecturalpatterncategories", notNullValue()));
        resultActions.andExpect(model().attribute("designpatterncategories", notNullValue()));
        resultActions.andExpect(model().attribute("cotscategories", notNullValue()));
        resultActions.andExpect(model().attribute("refactoringcategories", notNullValue()));
        resultActions.andExpect(model().attribute("technicalterms", notNullValue()));
        resultActions.andExpect(model().attribute("constraintcomparators", notNullValue()));
    }

    /**
     * Tests the correct controller behavior for listing solutions without
     * arguments for pagination, filtering, sorting etc.
     * 
     * @throws Exception an exception that method has failed
     */
    @Test
    public void testListOfSolutions() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/list"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(1)));
        resultActions.andExpect(model().attribute("menu", hasSize(1)));
        resultActions.andExpect(model().attribute("jsp", is("solutions")));
        resultActions.andExpect(model().attribute("pagedListHolder", notNullValue()));
        resultActions.andExpect(model().attribute("solutionlist", hasSize(10)));
        testPrePopulatedValues(resultActions);

        String solutionlist = "solutionlist";

        // inspect list
        resultActions.andExpect(model().attribute(solutionlist, hasItem(hasProperty("id", is(1L)))));
        resultActions.andExpect(model().attribute(solutionlist, hasItem(hasProperty("name", is("Framework 1")))));
        resultActions.andExpect(model().attribute(solutionlist,
                hasItem(hasProperty("description", is("Full description.")))));
        resultActions.andExpect(model().attribute(solutionlist, hasItem(hasProperty("documentation", is("3")))));
        resultActions.andExpect(model().attribute("solutionlist", hasItem(hasProperty("creator", is("Ilija Ilijic")))));
        resultActions.andExpect(model().attribute("solutionlist",
                hasItem(hasProperty("frameworkCategory", notNullValue()))));

        // guarantee that service method getSolutionsByCriteria has exactly been
        // called once
        Mockito.verify(solutionServiceMock, times(1)).getSolutionsByCriteria(
                org.mockito.Matchers.<Filter<Solution>> any(), org.mockito.Matchers.<Comparator<Solution>> any());

        // guarantee that service method getFrameworkCategories has exactly been
        // called once
        Mockito.verify(solutionServiceMock, times(1)).getFrameworkCategories();

        // guarantee that service method getArchitecturalPatternCategories has
        // exactly been called once
        Mockito.verify(solutionServiceMock, times(1)).getArchitecturalPatternCategories();

        // guarantee that service method getDesignPatternCategories has exactly
        // been called once
        Mockito.verify(solutionServiceMock, times(1)).getDesignPatternCategories();

        // guarantee that service method getCOTSCategories has exactly been
        // called once
        Mockito.verify(solutionServiceMock, times(1)).getCOTSCategories();

        // guarantee that service method getRefactoringCategories has exactly
        // been called once
        Mockito.verify(solutionServiceMock, times(1)).getRefactoringCategories();
    }

    /**
     * Tests the profile view of a solution.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testSolutionProfile() throws Exception
    {

        ResultActions resultActions = mockMvc.perform(get("/catalog/solution/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(4)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("view")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute(
                "solution",
                allOf(hasProperty("name", is("Framework 1")), hasProperty("description", is("Full description.")),
                        hasProperty("documentation", is("3")))));

        // guarantee that service method getSolutionById has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).getSolutionById(1);

        // guarantee that service method getFrameworkCategories has exactly been
        // called once
        Mockito.verify(solutionServiceMock, times(1)).getFrameworkCategories();

        // guarantee that service method getArchitecturalPatternCategories has
        // exactly been called once
        Mockito.verify(solutionServiceMock, times(1)).getArchitecturalPatternCategories();

        // guarantee that service method getDesignPatternCategories has exactly
        // been called once
        Mockito.verify(solutionServiceMock, times(1)).getDesignPatternCategories();

        // guarantee that service method getCOTSCategories has exactly been
        // called once
        Mockito.verify(solutionServiceMock, times(1)).getCOTSCategories();

        // guarantee that service method getRefactoringCategories has exactly
        // been called once
        Mockito.verify(solutionServiceMock, times(1)).getRefactoringCategories();
    }

    /******************************************************************
     * 
     * ADD SOLUTION
     * 
     *****************************************************************/

    /**
     * Tests the view for adding a new framework.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddFrameworkPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/add").param("type", "Framework"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("add")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(Framework.class)));
    }

    /**
     * Tests the view for adding a new architectural pattern.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddArchitecturalPatternPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/add").param("type", "ArchitecturalPattern"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("add")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(ArchitecturalPattern.class)));
    }

    /**
     * Tests the view for adding a new design pattern.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddDesignPatternPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/add").param("type", "DesignPattern"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("add")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(DesignPattern.class)));
    }

    /**
     * Tests the view for adding a new COTS.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddCOTSPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/add").param("type", "COTS"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("add")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(COTS.class)));
    }

    /**
     * Tests the view for adding a new refactoring.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddRefactoringPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/add").param("type", "Refactoring"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("add")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(Refactoring.class)));
    }

    /**
     * Tests adding a valid Framework using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingValidFramework() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "Framework").param("name", "TestFramework").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=Framework"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("Framework", argumentCaptor.getValue().getType());
        assertEquals("TestFramework", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests adding an invalid Framework using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingInvalidFramework() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "Framework"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=Framework"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests adding a valid ArchitecturalPattern using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingValidArchitecturalPattern() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "ArchitecturalPattern").param("name", "TestArchitecturalPattern")
                .param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=ArchitecturalPattern"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("ArchitecturalPattern", argumentCaptor.getValue().getType());
        assertEquals("TestArchitecturalPattern", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests adding an invalid Architectural Pattern using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingInvalidArchitecturalPattern() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "ArchitecturalPattern"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=ArchitecturalPattern"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests adding a valid DesignPattern using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingValidDesignPattern() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "DesignPattern").param("name", "TestDesignPattern").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=DesignPattern"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("DesignPattern", argumentCaptor.getValue().getType());
        assertEquals("TestDesignPattern", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests adding an invalid Design Pattern using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingInvalidDesignPattern() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "DesignPattern"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=DesignPattern"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests adding a valid Refactoring using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingValidRefactoring() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "Refactoring").param("name", "TestRefactoring").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=Refactoring"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("Refactoring", argumentCaptor.getValue().getType());
        assertEquals("TestRefactoring", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests adding an invalid Refactoring using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingInvalidRefactoring() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "Refactoring"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=Refactoring"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests adding a valid COTS using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingValidCOTS() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "COTS").param("name", "TestCOTS").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=COTS"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("COTS", argumentCaptor.getValue().getType());
        assertEquals("TestCOTS", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests adding an invalid COTS using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testAddingInvalidCOTS() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/add").param("id", "3")
                .param("type", "COTS"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/add"));
        resultActions.andExpect(redirectedUrl("/catalog/add?type=COTS"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /******************************************************************
     * 
     * EDIT SOLUTION
     * 
     *****************************************************************/

    /**
     * Tests the view for editing a solution.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditSolutionPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/edit/10"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("edit")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(Framework.class)));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(1)).getSolutionById(10);
    }

    /**
     * Tests editing a Framework in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingFramworkValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "Framework").param("name", "TestFramework").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("Framework", argumentCaptor.getValue().getType());
        assertEquals("TestFramework", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing a Framework in an invalid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingFrameworkInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "Framework"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing an ArchitecturalPattern in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingArchitecturalPatternValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "ArchitecturalPattern").param("name", "TestArchitecturalPattern")
                .param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("ArchitecturalPattern", argumentCaptor.getValue().getType());
        assertEquals("TestArchitecturalPattern", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing an Architectural Pattern in an invalid way using a
     * POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingArchitecturalPatternInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "ArchitecturalPattern"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing an DesignPattern in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingDesignPatternValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "DesignPattern").param("name", "TestDesignPattern").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("DesignPattern", argumentCaptor.getValue().getType());
        assertEquals("TestDesignPattern", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing a DesignPattern in an invalid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingDesignPatternInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "DesignPattern"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing an COTS in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingCOTSValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "COTS").param("name", "TestCOTS").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("COTS", argumentCaptor.getValue().getType());
        assertEquals("TestCOTS", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing a COTS in an invalid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingCOTSInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "COTS"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing an Refactoring in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingRefactoringValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "Refactoring").param("name", "TestRefactoring").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("Refactoring", argumentCaptor.getValue().getType());
        assertEquals("TestRefactoring", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing a Refactoring in an invalid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingRefactoringInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/edit").param("id", "3")
                .param("type", "Refactoring"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/catalog/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("solution", notNullValue()));
        resultActions.andExpect(flash().attributeExists("org.springframework.validation.BindingResult.solution"));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing a Framework inline in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingFramworkInlineValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "Framework").param("name", "TestFramework")
                .param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("Framework", argumentCaptor.getValue().getType());
        assertEquals("TestFramework", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing a Framework inline in an invalid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingFrameworkInlineInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "Framework"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("failure")));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing an ArchitecturalPattern inline in a valid way using a
     * POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingArchitecturalPatternInlineValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "ArchitecturalPattern").param("name", "TestArchitecturalPattern")
                .param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("ArchitecturalPattern", argumentCaptor.getValue().getType());
        assertEquals("TestArchitecturalPattern", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing an Architectural Pattern inline in an invalid way using a
     * POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingArchitecturalPatternInlineInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "ArchitecturalPattern"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("failure")));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing an DesignPattern inline in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingDesignPatternInlineValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "DesignPattern").param("name", "TestDesignPattern")
                .param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("DesignPattern", argumentCaptor.getValue().getType());
        assertEquals("TestDesignPattern", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing an DesignPattern inline in an invalid way using a
     * POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingDesignPatternInlineInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "DesignPattern"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("failure")));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing an COTS inline in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingCOTSInlineValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "COTS").param("name", "TestCOTS").param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("COTS", argumentCaptor.getValue().getType());
        assertEquals("TestCOTS", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing an COTS inline in an invalid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingCOTSInlineInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "COTS"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("failure")));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /**
     * Tests editing an Refactoring inline in a valid way using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingRefactoringInlineValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "Refactoring").param("name", "TestRefactoring")
                .param("shortDescription", "Test"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("success")));

        // guarantee that service method saveSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).saveSolution(argumentCaptor.capture());

        // check properties of saved solution
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("Refactoring", argumentCaptor.getValue().getType());
        assertEquals("TestRefactoring", argumentCaptor.getValue().getName());
        assertEquals("Test", argumentCaptor.getValue().getShortDescription());
    }

    /**
     * Tests editing an Refactoring inline in an invalid way using a
     * POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testEditingRefactoringInlineInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/editinline")
                .param("id", "3").param("type", "Refactoring"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("failure")));

        // guarantee that service method saveSolution has never been called
        Mockito.verify(solutionServiceMock, times(0)).saveSolution(org.mockito.Matchers.<Solution> any());
    }

    /******************************************************************
     * 
     * DELETE SOLUTION
     * 
     *****************************************************************/

    /**
     * Tests the view for deleting a framework.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeleteFrameworkPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/delete/1").param("type", "Framework"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("delete")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(Framework.class)));
    }

    /**
     * Tests the view for deleting an architectural pattern.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeleteArchitecturalPatternPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/delete/2").param("type", "ArchitecturalPattern"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("delete")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(ArchitecturalPattern.class)));
    }

    /**
     * Tests the view for deleting an DesignPattern.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeleteDesignPatternPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/delete/3").param("type", "DesignPattern"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("delete")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(DesignPattern.class)));
    }

    /**
     * Tests the view for deleting an COTS.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeleteCOTSPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/delete/4").param("type", "COTS"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("delete")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(COTS.class)));
    }

    /**
     * Tests the view for deleting an Refactoring.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeleteRefactoringPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/catalog/delete/5").param("type", "Refactoring"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addsolution")));
        resultActions.andExpect(model().attribute("viewmode", is("delete")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("solution", notNullValue()));
        resultActions.andExpect(model().attribute("solution", instanceOf(Refactoring.class)));
    }

    /**
     * Tests deleting a Framework using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeletingFramework() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/delete/3"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/list"));
        resultActions.andExpect(redirectedUrl("/catalog/list"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method deleteSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).deleteSolution(org.mockito.Matchers.anyInt());
    }

    /**
     * Tests deleting an ArchitecturalPattern using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeletingArchitecturalPattern() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/delete/3"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/list"));
        resultActions.andExpect(redirectedUrl("/catalog/list"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method deleteSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).deleteSolution(org.mockito.Matchers.anyInt());
    }

    /**
     * Tests deleting an DesignPattern using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeletingDesignPattern() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/delete/3"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/list"));
        resultActions.andExpect(redirectedUrl("/catalog/list"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method deleteSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).deleteSolution(org.mockito.Matchers.anyInt());
    }

    /**
     * Tests deleting a COTS using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeletingCOTS() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/delete/3"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/list"));
        resultActions.andExpect(redirectedUrl("/catalog/list"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method deleteSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).deleteSolution(org.mockito.Matchers.anyInt());
    }

    /**
     * Tests deleting a Refactoring using a POST-method.
     * 
     * @throws Exception an exception if method fails
     */
    @Test
    public void testDeletingRefactoring() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/catalog/delete/3"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/catalog/list"));
        resultActions.andExpect(redirectedUrl("/catalog/list"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method deleteSolution has exactly been called
        // once
        Mockito.verify(solutionServiceMock, times(1)).deleteSolution(org.mockito.Matchers.anyInt());
    }

    /******************************************************************
     * 
     * METHODS TO CREATE DUMMY DATA
     * 
     *****************************************************************/

    /**
     * Helper method to create dummy data.
     * 
     * @param fakeId the id for the name of the dummy object.
     * @param category type of solution object to create
     * @param completeness 'minimal' or 'complete'
     * 
     * @return a populated Solution object.
     */
    private Solution createDummyData(Long fakeId, String category, String completeness)
    {
        if (category.equalsIgnoreCase("framework"))
        {
            if (completeness.equalsIgnoreCase("complete"))
            {
                // Create complete framework object
                return createDummyDataFrameworkComplete(fakeId);
            }
            else
            {
                // Create minimal framework object
                return createDummyDataFrameworkMinimal(fakeId);
            }
        }
        else if (category.equalsIgnoreCase("architecturalpattern"))
        {
            if (completeness.equalsIgnoreCase("complete"))
            {
                // Create complete architectural pattern object
                return createDummyDataArchitecturalPatternComplete(fakeId);
            }
            else
            {
                // Create minimal architectural pattern object
                return createDummyDataArchitecturalPatternMinimal(fakeId);
            }
        }
        else if (category.equalsIgnoreCase("designpattern"))
        {
            if (completeness.equalsIgnoreCase("complete"))
            {
                // Create complete design pattern object
                return createDummyDataDesignPatternComplete(fakeId);
            }
            else
            {
                // Create minimal design pattern object
                return createDummyDataDesignPatternMinimal(fakeId);
            }
        }
        else if (category.equalsIgnoreCase("cots"))
        {
            if (completeness.equalsIgnoreCase("complete"))
            {
                // Create complete cots object
                return createDummyDataCOTSComplete(fakeId);
            }
            else
            {
                // Create minimal cots object
                return createDummyDataCOTSMinimal(fakeId);
            }
        }
        else
        {
            if (completeness.equalsIgnoreCase("complete"))
            {
                // Create complete refactoring object
                return createDummyDataRefactoringComplete(fakeId);
            }
            else
            {
                // Create minimal refactoring object
                return createDummyDataRefactoringMinimal(fakeId);
            }
        }
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a complete framework object
     */
    private Solution createDummyDataFrameworkComplete(Long fakeId)
    {
        Framework framework = new Framework();
        framework.setId(fakeId);
        framework.setName("Framework " + fakeId);
        framework.setShortDescription("Description of framework 1.");
        framework.setCreator("Ilija Ilijic");
        framework.setCreationDate(new Date());
        framework.setLastModifier("Florian Schaak");
        framework.setModificationDate(new Date());

        FrameworkCategory frameworkCategory = this.frameworkCategoryList.get(1);
        framework.setFrameworkCategory(frameworkCategory);

        framework.setCurrentVersion("4.0.6");
        framework.setDevelopmentStatus("active");
        framework.setDescription("Full description.");
        framework.setOperatingSystem("Windows 8");
        framework.setProgrammingLanguage("Java");
        framework.setDependencies("unknown");
        framework.setDeveloper("Tom Vasel");
        framework.setWebsite("dicetower.com");
        framework.setLicense("Apache Licence 2.0");
        framework.setSupport("1");
        framework.setDocumentation("3");
        framework.setCommunity("huge");
        framework.setSize(12);

        return framework;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a complete architectural pattern object
     */
    private Solution createDummyDataArchitecturalPatternComplete(Long fakeId)
    {
        ArchitecturalPattern architecturalPattern = new ArchitecturalPattern();
        architecturalPattern.setId(fakeId);
        architecturalPattern.setName("AP " + fakeId);
        architecturalPattern.setShortDescription("desc");
        architecturalPattern.setCreator("Ilija Ilijic");
        architecturalPattern.setCreationDate(new Date());
        architecturalPattern.setLastModifier("Florian Schaak");
        architecturalPattern.setModificationDate(new Date());

        ArchitecturalPatternCategory architecturalPatternCategory = this.architecturalPatternCategoryList.get(1);
        architecturalPattern.setArchitecturalPatternCategory(architecturalPatternCategory);

        architecturalPattern.setAltName1("Alternative name 1");
        architecturalPattern.setAltName2("Alternative name 2");
        architecturalPattern.setApplicability("none");
        architecturalPattern.setCollaboration("none");
        architecturalPattern.setConsequences("none");
        architecturalPattern.setKnownUses("none");
        architecturalPattern.setMotivation("none");
        architecturalPattern.setParticipants("none");
        architecturalPattern.setRelatedPatterns("none");
        architecturalPattern.setUsance("none");
        architecturalPattern.setStructure(null);

        return architecturalPattern;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a complete design pattern object
     */
    private Solution createDummyDataDesignPatternComplete(Long fakeId)
    {
        DesignPattern designPattern = new DesignPattern();
        designPattern.setId(fakeId);
        designPattern.setName("AP " + fakeId);
        designPattern.setShortDescription("desc");
        designPattern.setCreator("Ilija Ilijic");
        designPattern.setCreationDate(new Date());
        designPattern.setLastModifier("Florian Schaak");
        designPattern.setModificationDate(new Date());

        DesignPatternCategory designPatternCategory = this.designPatternCategoryList.get(1);
        designPattern.setDesignPatternCategory(designPatternCategory);

        designPattern.setAltName1("Alternative name 1");
        designPattern.setAltName2("Alternative name 2");
        designPattern.setApplicability("none");
        designPattern.setCollaboration("none");
        designPattern.setConsequences("none");
        designPattern.setKnownUses("none");
        designPattern.setMotivation("none");
        designPattern.setParticipants("none");
        designPattern.setRelatedPatterns("none");
        designPattern.setStructure(null);

        return designPattern;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a complete cots object
     */
    private Solution createDummyDataCOTSComplete(Long fakeId)
    {
        COTS cots = new COTS();
        cots.setId(fakeId);
        cots.setName("AP " + fakeId);
        cots.setShortDescription("desc");
        cots.setCreator("Ilija Ilijic");
        cots.setCreationDate(new Date());
        cots.setLastModifier("Florian Schaak");
        cots.setModificationDate(new Date());

        COTSCategory cotsCategory = this.cotsCategoryList.get(1);
        cots.setCotsCategory(cotsCategory);

        cots.setCommunity("high");
        cots.setDocumentation("low");
        cots.setOperatingSystem("windows");

        return cots;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a complete design pattern object
     */
    private Solution createDummyDataRefactoringComplete(Long fakeId)
    {
        Refactoring refactoring = new Refactoring();
        refactoring.setId(fakeId);
        refactoring.setName("Refactoring " + fakeId);
        refactoring.setShortDescription("desc");
        refactoring.setCreator("Ilija Ilijic");
        refactoring.setCreationDate(new Date());
        refactoring.setLastModifier("Florian Schaak");
        refactoring.setModificationDate(new Date());

        RefactoringCategory refactoringCategory = this.refactoringCategoryList.get(1);
        refactoring.setRefactoringCategory(refactoringCategory);

        refactoring.setBadSmell("long method");
        refactoring.setMechanics("none");
        refactoring.setExamples("none");

        return refactoring;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a minimal framework object
     */
    private Solution createDummyDataFrameworkMinimal(Long fakeId)
    {
        Framework framework = new Framework();
        framework.setId(fakeId);
        framework.setName("Framework " + fakeId);
        framework.setShortDescription("Description of framework 1.");

        return framework;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a mnimal architectural pattern object
     */
    private Solution createDummyDataArchitecturalPatternMinimal(Long fakeId)
    {
        ArchitecturalPattern architecturalPattern = new ArchitecturalPattern();
        architecturalPattern.setId(fakeId);
        architecturalPattern.setName("AP " + fakeId);
        architecturalPattern.setShortDescription("desc");

        return architecturalPattern;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a mnimal design pattern object
     */
    private Solution createDummyDataDesignPatternMinimal(Long fakeId)
    {
        DesignPattern designPattern = new DesignPattern();
        designPattern.setId(fakeId);
        designPattern.setName("DP " + fakeId);
        designPattern.setShortDescription("desc");

        return designPattern;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a mnimal cots object
     */
    private Solution createDummyDataCOTSMinimal(Long fakeId)
    {
        COTS cots = new COTS();
        cots.setId(fakeId);
        cots.setName("DP " + fakeId);
        cots.setShortDescription("desc");

        return cots;
    }

    /**
     * Helper method for creating dummy data.
     * 
     * @param fakeId the id for the dummy object
     * @return a mnimal refactoring object
     */
    private Solution createDummyDataRefactoringMinimal(Long fakeId)
    {
        Refactoring refactoring = new Refactoring();
        refactoring.setId(fakeId);
        refactoring.setName("Refactoring " + fakeId);
        refactoring.setShortDescription("desc");

        return refactoring;
    }

    /**
     * Helper method to create dummy framework categories.
     * 
     * @return a list of framework categories
     * 
     */
    public List<FrameworkCategory> createDummyFrameworkCategories()
    {
        List<FrameworkCategory> list = new ArrayList<FrameworkCategory>();

        for (int i = 0; i < 5; i++)
        {
            FrameworkCategory fc = new FrameworkCategory();
            fc.setId(Long.valueOf(i));
            fc.setName("Framework Category " + i);
            fc.setDescription("Test description");
            list.add(fc);
        }

        return list;
    }

    /**
     * Helper method to create dummy architecturalpattern categories.
     * 
     * @return a list of architectural pattern categories
     * 
     */
    public List<ArchitecturalPatternCategory> createDummyArchitecturalPatternCategories()
    {
        List<ArchitecturalPatternCategory> list = new ArrayList<ArchitecturalPatternCategory>();

        for (int i = 0; i < 5; i++)
        {
            ArchitecturalPatternCategory apc = new ArchitecturalPatternCategory();
            apc.setId(Long.valueOf(i));
            apc.setName("ArchitecturalPattern Category " + i);
            apc.setDescription("Test description");
            list.add(apc);
        }

        return list;
    }

    /**
     * Helper method to create dummy designpattern categories.
     * 
     * @return a list of designpattern categories
     * 
     */
    public List<DesignPatternCategory> createDummyDesignPatternCategories()
    {
        List<DesignPatternCategory> list = new ArrayList<DesignPatternCategory>();

        for (int i = 0; i < 5; i++)
        {
            DesignPatternCategory dpc = new DesignPatternCategory();
            dpc.setId(Long.valueOf(i));
            dpc.setName("Framework Category " + i);
            dpc.setDescription("Test description");
            list.add(dpc);
        }

        return list;
    }

    /**
     * Helper method to create dummy cots categories.
     * 
     * @return a list of cots categories
     * 
     */
    public List<COTSCategory> createDummyCOTSCategories()
    {
        List<COTSCategory> list = new ArrayList<COTSCategory>();

        for (int i = 0; i < 5; i++)
        {
            COTSCategory cc = new COTSCategory();
            cc.setId(Long.valueOf(i));
            cc.setName("Cots Category " + i);
            cc.setDescription("Test description");
            list.add(cc);
        }

        return list;
    }

    /**
     * Helper method to create dummy refactoring categories.
     * 
     * @return a list of refactoring categories
     * 
     */
    public List<RefactoringCategory> createDummyRefactoringCategories()
    {
        List<RefactoringCategory> list = new ArrayList<RefactoringCategory>();

        for (int i = 0; i < 5; i++)
        {
            RefactoringCategory rc = new RefactoringCategory();
            rc.setId(Long.valueOf(i));
            rc.setName("Refactoring Category " + i);
            rc.setDescription("Test description");
            list.add(rc);
        }

        return list;
    }
}