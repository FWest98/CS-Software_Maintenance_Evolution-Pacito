package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.SolutionService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Test class for SolutionService.
 * 
 * @author Lucas
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class SolutionServiceTest
{

    private Framework framework1;
    private Framework framework2;

    @Autowired
    private SolutionService solutionService;

    @Autowired
    private SolutionDAO solutionDAO;

    // @Autowired
    // private SolutionDAO architecturalPatternDAO;

    @Before
    public void setUp()
    {
        FrameworkCategory fc = new FrameworkCategory();
        fc.setId(42L);
        fc.setName("Test category");

        framework1 = new Framework();
        framework1.setId(1L);
        framework1.setName("Test framework 1");
        framework1.setCreator("Tester1");
        framework1.setCreationDate(new Date());
        framework1.setFrameworkCategory(fc);

        framework2 = new Framework();
        framework2.setId(2L);
        framework2.setName("Test framework 2");
        framework2.setCreator("Tester2");
        framework2.setCreationDate(new Date());
        framework2.setFrameworkCategory(fc);

        List<Solution> findall = new ArrayList<Solution>();
        findall.add(framework1);

        Mockito.when(solutionDAO.findAll()).thenReturn(findall);
    }

    @After
    public void resetDAO()
    {
        Mockito.reset(solutionDAO);
    }

    /**
     * Test method for addSolution().
     */
    @Test
    public void testAddSolution() throws SolutionPersistenceException
    {
        Mockito.when(solutionDAO.saveAndFlush(framework1)).thenReturn(framework1);

        try
        {
            assertNull(solutionService.getSolutionById(framework1.getId()));
        }
        catch (SolutionNotFoundException e)
        {
            // As expected.
        }

        try
        {
            solutionService.saveSolution(framework1);
        }
        catch (SolutionPersistenceException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }

        // assertEquals(framework1,
        // solutionService.getSolutionById(framework1.getId()));
        Mockito.verify(solutionDAO).saveAndFlush(framework1);
    }

    /**
     * Test method for getSolutionById().
     */
    @Test
    public void testGetSolutionById()
    {
        /*
         * solutionService.addSolution(framework1);
         * solutionService.addSolution(framework2);
         */
        Mockito.when(solutionDAO.findOne(1L)).thenReturn(framework1);
        Mockito.when(solutionDAO.findOne(2L)).thenReturn(framework2);

        try
        {
            assertEquals(solutionService.getSolutionById(framework1.getId()), framework1);
        }
        catch (SolutionNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        try
        {
            assertNotEquals(solutionService.getSolutionById(framework2.getId()), framework1);
        }
        catch (SolutionNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
    }

    /**
     * Test method for getSolutionsByCriteria().
     */
    @Test
    public void testGetSolutionsByCriteria() throws SolutionPersistenceException
    {
        framework1.setCreator("Hans");
        framework2.setCreator("Peter");

        Mockito.when(solutionDAO.saveAndFlush(framework1)).thenReturn(framework1);
        Mockito.when(solutionDAO.saveAndFlush(framework2)).thenReturn(framework2);

        try
        {
            solutionService.saveSolution(framework1);
            solutionService.saveSolution(framework2);
        }
        catch (SolutionPersistenceException se)
        {
            se.printStackTrace();
            fail("Exception caught.");
        }

        Filter<Solution> filter = new Filter<Solution>()
        {

            /*
             * All solutions made by Hans.
             */
            @Override
            public boolean isInResult(Solution item)
            {
                return item.getCreator().equals("Hans");
            }
        };

        Comparator<Solution> sorter = new Comparator<Solution>()
        {

            /*
             * No sorting.
             */
            @Override
            public int compare(Solution arg0, Solution arg1)
            {
                return 0;
            }
        };

        assertTrue(solutionService.getSolutionsByCriteria(filter, sorter).contains(framework1));
        assertFalse(solutionService.getSolutionsByCriteria(filter, sorter).contains(framework2));
    }

    /**
     * Test method for getSolutionCatalog().
     */
    @Test
    public void testGetSolutionCatalog()
    {
        Mockito.when(solutionDAO.findOne(1L)).thenReturn(framework1);
        assertTrue(solutionService.getSolutionCatalog().contains(framework1));
        assertFalse(solutionService.getSolutionCatalog().contains(framework2));
    }

    // /**
    // * Test method for getFrameworkCategoryByFramework().
    // */
    // @Test
    // public void testGetFrameworkCategoryByFramework()
    // {
    // FrameworkCategory tmpFC = framework1.getFrameworkCategory();
    // solutionService.addSolution(framework1);
    //
    // assertEquals(
    // solutionService.getFrameworkCategoryByFramework(framework1),
    // tmpFC);
    // assertNotEquals(
    // solutionService.getFrameworkCategoryByFramework(framework1),
    // new FrameworkCategory());
    // }
    //
    // @Test
    // public void testAddSolutionByType()
    // {
    // assertNull(solutionService.getSolutionById(framework1.getId()));
    // solutionService.addSolutionByType(framework1);
    // assertEquals(solutionService.getSolutionById(framework1.getId()),
    // framework1);
    // }

}
