package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.RatingValidator;

/**
 * Test class for RatingValidator.
 * 
 * @author Tim
 *
 */

public class RatingValidatorTest
{
    private Rating testRating;
    private RatingValidator testRatingValidator;

    /**
     * Setup method for rating validator. Called before each test method.
     * Creates a valid Rating.
     * 
     */
    @Before
    public void setUp()
    {
        testRating = new Rating();
        testRating.setId(1L);
        testRating.setReasoning("test");
        testRating.setRating("great");
        testRating.setCreationDate(new Date());
        testRating.setCreator("tim");

        testRatingValidator = new RatingValidator();
    }

    /**
     * Test method for default design pattern created in setUp(), if this fails
     * the other tests can't work properly.
     */
    @Test
    public void testSetUpValid()
    {
        Errors errors;
        errors = new BeanPropertyBindingResult(testRating, "validAddress");
        testRatingValidator.validate(testRating, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for missing name.
     */
    @Test
    public void testReasoningMissing()
    {
        Errors errors;
        testRating.setReasoning("");
        testRatingValidator = new RatingValidator();
        errors = new BeanPropertyBindingResult(testRating, "validAddress");
        testRatingValidator.validate(testRating, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Create string of lenghts n.
     * 
     * @param n the length of the string
     * @return new string of length n
     */
    public String createStringOfLenghtsN(int n)
    {
        String string = "a";
        for (int i = 1; i < n; i++)
        {
            string = string.concat("a");
        }
        return string;
    }

    /**
     * Test method for an name which exceeds the character limit.
     */
    @Test
    public void testReasoningTooLong()
    {
        Errors errors;
        String string = createStringOfLenghtsN(ColumnLength.MEDIUM + 1);
        testRating.setReasoning(string);
        errors = new BeanPropertyBindingResult(testRating, "validAddress");
        testRatingValidator.validate(testRating, errors);
        assertTrue(errors.hasErrors());
        System.out.print("String: " + testRating.getReasoning());
    }
}