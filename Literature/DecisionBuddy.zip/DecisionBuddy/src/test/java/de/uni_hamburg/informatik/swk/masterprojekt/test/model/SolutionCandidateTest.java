package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class SolutionCandidateTest
{
    private SolutionCandidate solutionCandidate1;
    private SolutionCandidate solutionCandidate2;
    private SolutionCandidate solutionCandidate3;

    /**
     * Creates three SolutionCandidates. SolutionCandidate 1 and 2 should be
     * equal and 3 different.
     */
    @Before
    public void setUp()
    {
        solutionCandidate1 = new SolutionCandidate();
        solutionCandidate2 = new SolutionCandidate();
        solutionCandidate3 = new SolutionCandidate();

        solutionCandidate1.setId(1L);
        solutionCandidate2.setId(1L);
        solutionCandidate3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testSolutionCandidateToString()
    {
        System.out.println(solutionCandidate1.toString());
    }

    /**
     * Tests the hashCode functionality of a SolutionCandidate, should only be
     * affected by Id.
     */
    @Test
    public void testSolutionCandidateHashcode()
    {
        solutionCandidate1.setEvaluation("a");
        solutionCandidate1.setEvaluation("b");
        assertTrue(solutionCandidate1.hashCode() == solutionCandidate1.hashCode());
        assertTrue(solutionCandidate1.hashCode() == solutionCandidate2.hashCode());
        assertFalse(solutionCandidate2.hashCode() == solutionCandidate3.hashCode());
    }

    /**
     * Tests the equals functionality of a SolutionCandidate, should only be
     * affected by Id.
     */
    @Test
    public void testSolutionCandidateEquals()
    {
        solutionCandidate1.setEvaluation("a");
        solutionCandidate1.setEvaluation("b");
        assertTrue(solutionCandidate1.equals(solutionCandidate1));
        assertFalse(solutionCandidate1.equals(null));
        assertFalse(solutionCandidate1.equals(new String()));
        assertTrue(solutionCandidate1.equals(solutionCandidate2));
        assertFalse(solutionCandidate1.equals(solutionCandidate3));
    }
}