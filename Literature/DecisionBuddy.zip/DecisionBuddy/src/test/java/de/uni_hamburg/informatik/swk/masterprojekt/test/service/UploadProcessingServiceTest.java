package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultParsingException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.UploadProcessingService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.AnalysisFileFormat;

/**
 * Class testing results of UploadProcessingService.
 * 
 * @author 1fechner
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class UploadProcessingServiceTest
{
    @Autowired
    private UploadProcessingService uploadProcessingService;

    private static String fileName = "test";

    @Before
    public void setUp() throws IOException
    {
        // TODO use different files, causing different types of exceptions
        String fileName = "test";
        File f = new File(fileName);
        f.createNewFile();
    }

    @After
    public void clean()
    {
        File f = new File(fileName);
        f.delete();
    }

//    @Test
//    public void testProcessingResultAllOK() throws AnalysisResultException
//    {
//        // Insert Correct File -> Expect true, all OK
//        assertTrue(uploadProcessingService.processAnalysisResult(1, AnalysisFileFormat.DBAnalyzer.toString(), fileName));
//    }

//    @Test(expected = AnalysisResultFormatUnknownException.class)
//    public void testProcessingResultFormatUnknown() throws AnalysisResultException
//    {
//        // TODO Use file causing Format Unknown Exception
//        assertTrue(uploadProcessingService.processAnalysisResult(1, AnalysisFileFormat.DBAnalyzer.toString(), fileName));
//    }

    @Test(expected = AnalysisResultParsingException.class)
    public void testProcessingResultParsing() throws AnalysisResultException
    {
        // TODO Use file causing Parsing Exception
        assertTrue(uploadProcessingService.processAnalysisResult(1, AnalysisFileFormat.DBAnalyzer.toString(), fileName));

    }

//    @Test(expected = AnalysisResultPersistenceException.class)
//    public void testProcessingResultPersistence() throws AnalysisResultException
//    {
//        // TODO Use file causing Persistence Exception
//        assertTrue(uploadProcessingService.processAnalysisResult(1, AnalysisFileFormat.DBAnalyzer.toString(), fileName));
//
//    }
}