package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class TechnicalTermTest
{
    private TechnicalTerm technicalTerm1;
    private TechnicalTerm technicalTerm2;
    private TechnicalTerm technicalTerm3;

    /**
     * Creates three TechnicalTerms. TechnicalTerm 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        technicalTerm1 = new TechnicalTerm();
        technicalTerm2 = new TechnicalTerm();
        technicalTerm3 = new TechnicalTerm();

        technicalTerm1.setId(1L);
        technicalTerm2.setId(1L);
        technicalTerm3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testTechnicalTermToString()
    {
        System.out.println(technicalTerm1.toString());
    }

    /**
     * Tests the hashCode functionality of a TechnicalTerm, should only be
     * affected by Id.
     */
    @Test
    public void testTechnicalTermHashcode()
    {
        technicalTerm1.setIdentifier("a");
        technicalTerm2.setIdentifier("b");
        assertTrue(technicalTerm1.hashCode() == technicalTerm1.hashCode());
        assertTrue(technicalTerm1.hashCode() == technicalTerm2.hashCode());
        assertFalse(technicalTerm2.hashCode() == technicalTerm3.hashCode());
    }

    /**
     * Tests the equals functionality of a TechnicalTerm, should only be
     * affected by Id.
     */
    @Test
    public void testTechnicalTermEquals()
    {
        technicalTerm1.setIdentifier("a");
        technicalTerm2.setIdentifier("b");
        assertTrue(technicalTerm1.equals(technicalTerm1));
        assertFalse(technicalTerm1.equals(null));
        assertFalse(technicalTerm1.equals(new String()));
        assertTrue(technicalTerm1.equals(technicalTerm2));
        assertFalse(technicalTerm1.equals(technicalTerm3));
    }
}