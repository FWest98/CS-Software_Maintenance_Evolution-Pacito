package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementMetric;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementMetric}
 * class. This class contains no business logic and only toString(), hashCode() and equals()
 * methods are tested. 
 * 
 * @author Burak
 *
 */
public class ElementMetricTest
{
    private ElementMetric elementMetric1;
    private ElementMetric elementMetric2;
    private ElementMetric elementMetric3;

    /**
     * Creates three ElementMetrics. ElementMetric 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        elementMetric1 = new ElementMetric();
        elementMetric2 = new ElementMetric();
        elementMetric3 = new ElementMetric();

        elementMetric1.setId(1L);
        elementMetric2.setId(1L);
        elementMetric3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testElementMetricToString()
    {
        System.out.println(elementMetric1.toString());
    }

    /**
     * Tests the hashCode functionality of a ElementMetric, should only be affected
     * by Id.
     */
    @Test
    public void testElementMetricHashcode()
    {
        elementMetric1.setLastModifier("Eins");
        elementMetric2.setLastModifier("Eins");
        elementMetric3.setLastModifier("Zwei");
        assertTrue(elementMetric1.hashCode() == elementMetric1.hashCode());
        assertTrue(elementMetric1.hashCode() == elementMetric2.hashCode());
        assertFalse(elementMetric2.hashCode() == elementMetric3.hashCode());
    }

    /**
     * Tests the equals functionality of a ElementMetric, should only be affected by
     * Id.
     */
    @Test
    public void testElementMetricEquals()
    {
        assertTrue(elementMetric1.equals(elementMetric1));
        assertFalse(elementMetric1.equals(null));
        assertFalse(elementMetric1.equals(new String()));
        assertTrue(elementMetric1.equals(elementMetric2));
        assertFalse(elementMetric1.equals(elementMetric3));
    }
}