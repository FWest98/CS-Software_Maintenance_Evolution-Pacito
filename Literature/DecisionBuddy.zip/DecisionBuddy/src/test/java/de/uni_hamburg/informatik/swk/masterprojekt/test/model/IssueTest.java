package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Vlad
 *
 */
public class IssueTest
{
    private Issue issue1;
    private Issue issue2;
    private Issue issue3;
    private Project project1;

    @Before
    public void setUp() throws Exception
    {
        issue1 = new Issue();
        issue2 = new Issue();
        issue3 = new Issue();
        project1 = new Project();

        issue1.setId(1L);
        issue1.setProject(project1);
        issue2.setId(1L);
        issue2.setProject(project1);
        issue3.setId(2L);
        issue3.setProject(project1);
        project1.setId(1L);
    }

    @After
    public void tearDown() throws Exception
    {
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testIssueToString()
    {
        System.out.println(issue1.toString());
    }

    /**
     * Tests the hashCode functionality of a framework.
     */
    @Test
    public void testIssueHashcode()
    {
        assertTrue(issue1.hashCode() == issue1.hashCode());
        assertTrue(issue1.hashCode() == issue2.hashCode());
        assertFalse(issue2.hashCode() == issue3.hashCode());
    }

    @Test
    public void testIssueEquals()
    {
        assertTrue(issue1.equals(issue1));
        assertFalse(issue1.equals(null));
        assertFalse(issue1.equals(new String()));
        assertTrue(issue1.equals(issue2));
        assertFalse(issue1.equals(issue3));
    }
}
