package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class FrameworkCategoryTest
{
    private FrameworkCategory frameworkCategory1;
    private FrameworkCategory frameworkCategory2;
    private FrameworkCategory frameworkCategory3;

    /**
     * Creates three FrameworkCategories. FrameworkCategory 1 and 2 should be
     * equal and 3 different.
     */
    @Before
    public void setUp()
    {
        frameworkCategory1 = new FrameworkCategory();
        frameworkCategory2 = new FrameworkCategory();
        frameworkCategory3 = new FrameworkCategory();

        frameworkCategory1.setId(1L);
        frameworkCategory2.setId(1L);
        frameworkCategory3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testFrameworkCategoryToString()
    {
        System.out.println(frameworkCategory1.toString());
    }

    /**
     * Tests the hashCode functionality of a FrameworkCategory, should only be
     * affected by Id.
     */
    @Test
    public void testFrameworkCategoryHashcode()
    {
        frameworkCategory1.setDescription("1");
        frameworkCategory2.setDescription("2");
        assertTrue(frameworkCategory1.hashCode() == frameworkCategory1.hashCode());
        assertTrue(frameworkCategory1.hashCode() == frameworkCategory2.hashCode());
        assertFalse(frameworkCategory2.hashCode() == frameworkCategory3.hashCode());
    }

    /**
     * Tests the equals functionality of a FrameworkCategory, should only be
     * affected by Id.
     */
    @Test
    public void testFrameworkCategoryEquals()
    {
        frameworkCategory1.setDescription("1");
        frameworkCategory2.setDescription("2");
        assertTrue(frameworkCategory1.equals(frameworkCategory1));
        assertFalse(frameworkCategory1.equals(null));
        assertFalse(frameworkCategory1.equals(new String()));
        assertTrue(frameworkCategory1.equals(frameworkCategory2));
        assertFalse(frameworkCategory1.equals(frameworkCategory3));
    }
}