package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class ConstraintTest
{
    private Constraint constraint1;
    private Constraint constraint2;
    private Constraint constraint3;

    /**
     * Creates three Constraints. Constraint 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        constraint1 = new Constraint();
        constraint2 = new Constraint();
        constraint3 = new Constraint();

        constraint1.setId(1L);
        constraint2.setId(1L);
        constraint3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testConstraintToString()
    {
        System.out.println(constraint1.toString());
    }

    /**
     * Tests the hashCode functionality of a Constraint, should only be affected
     * by Id.
     */
    @Test
    public void testConstraintHashcode()
    {
        constraint1.setTechnicalTerm(new TechnicalTerm());
        assertTrue(constraint1.hashCode() == constraint1.hashCode());
        assertTrue(constraint1.hashCode() == constraint2.hashCode());
        assertFalse(constraint2.hashCode() == constraint3.hashCode());
    }

    /**
     * Tests the equals functionality of a Constraint, should only be affected
     * by Id.
     */
    @Test
    public void testConstraintEquals()
    {
        constraint1.setTechnicalTerm(new TechnicalTerm());
        assertTrue(constraint1.equals(constraint1));
        assertFalse(constraint1.equals(null));
        assertFalse(constraint1.equals(new String()));
        assertTrue(constraint1.equals(constraint2));
        assertFalse(constraint1.equals(constraint3));
    }
}