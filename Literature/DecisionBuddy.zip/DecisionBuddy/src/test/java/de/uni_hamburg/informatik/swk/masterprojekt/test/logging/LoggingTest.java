package de.uni_hamburg.informatik.swk.masterprojekt.test.logging;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.util.StatusPrinter;

/**
 * This testcase prints output of the logger stat on the console.
 * 
 * @author Vlad
 *
 */
public class LoggingTest
{
    private LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();

    /**
     * Setup method.
     * 
     * @throws Exception Exception is thrown if set up fails
     */
    @Before
    public void setUp() throws Exception
    {
    }

    /**
     * Tests if StatusPrinter works.
     * 
     */
    @Test
    public void test()
    {
        StatusPrinter.print(loggerContext);
    }
}