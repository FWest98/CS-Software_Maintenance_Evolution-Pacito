package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class FrameworkTest
{
    private Framework framework1;
    private Framework framework2;
    private Framework framework3;

    /**
     * Creates three Frameworks. Framework 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        framework1 = new Framework();
        framework2 = new Framework();
        framework3 = new Framework();

        framework1.setId(1L);
        framework2.setId(1L);
        framework3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testFrameworkToString()
    {
        System.out.println(framework1.toString());
    }

    /**
     * Tests the hashCode functionality of a Framework, should only be affected
     * by Id.
     */
    @Test
    public void testFrameworkHashcode()
    {
        framework1.setShortDescription("1");
        framework2.setShortDescription("2");
        assertTrue(framework1.hashCode() == framework1.hashCode());
        assertTrue(framework1.hashCode() == framework2.hashCode());
        assertFalse(framework2.hashCode() == framework3.hashCode());
    }

    /**
     * Tests the equals functionality of a Framework, should only be affected by
     * Id.
     */
    @Test
    public void testFrameworkEquals()
    {
        framework1.setShortDescription("1");
        framework2.setShortDescription("2");
        assertTrue(framework1.equals(framework1));
        assertFalse(framework1.equals(null));
        assertFalse(framework1.equals(new String()));
        assertTrue(framework1.equals(framework2));
        assertFalse(framework1.equals(framework3));
    }
}