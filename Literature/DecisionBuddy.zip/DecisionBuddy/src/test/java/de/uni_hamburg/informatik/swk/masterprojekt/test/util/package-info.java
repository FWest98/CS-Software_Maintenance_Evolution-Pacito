/**
 * 
 */
/**
 * @author Lucas
 *
 */
package de.uni_hamburg.informatik.swk.masterprojekt.test.util;