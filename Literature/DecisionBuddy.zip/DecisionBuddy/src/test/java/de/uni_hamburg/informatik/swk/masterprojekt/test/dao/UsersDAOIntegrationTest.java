package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.AuthoritiesDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.UsersDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;

/**
 * 
 * @author 4biryuk
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class UsersDAOIntegrationTest
{
    @Autowired
    private UsersDAO usersDAO;
    @Autowired
    private AuthoritiesDAO authoritiesDAO;

    private static final String ROLENAME1 = "ROLE_VLAD";

    private static final String USERNAME1 = "vlad1";
    private static final String PASSWORD1 = "vlad1";
    private static final boolean ENABLED1 = true;

    // private static final String USERNAME2 = "vlad2";
    // private static final String PASSWORD2 = "vlad2";
    // private static final boolean ENABLED2 = true;

    private static final String USERNAME3 = "vlad3";
    private static final String PASSWORD3 = "vlad3";
    private static final boolean ENABLED3 = true;

    private Authority authority1 = new Authority();

    private User user1 = new User();
    private User user2 = new User();
    private User user3 = new User();

    private ArrayList<Authority> authorities = new ArrayList<Authority>();

    @Before
    public void setUp() throws Exception
    {
        user1.setUsername(USERNAME1);
        user1.setPassword(PASSWORD1);
        user1.setEnabled(ENABLED1);

        user2.setUsername(USERNAME1);
        user2.setPassword(PASSWORD1);
        user2.setEnabled(ENABLED1);

        user3.setUsername(USERNAME3);
        user3.setPassword(USERNAME3);
        user3.setEnabled(ENABLED3);

        authority1.setAuthority(ROLENAME1);
        authorities.add(authority1);
    }

    @Test
    public void testSaveUser()
    {
        usersDAO.saveAndFlush(user1);
        assertEquals(user1, usersDAO.findOne(USERNAME1));
        assertEquals(user2, usersDAO.findOne(USERNAME1));
        assertNotEquals(user3, usersDAO.findOne(USERNAME1));
    }

    @Test
    public void testDeleteUser()
    {
        usersDAO.saveAndFlush(user1);
        assertEquals(user1, usersDAO.findOne(USERNAME1));
        assertEquals(user2, usersDAO.findOne(USERNAME1));
        usersDAO.saveAndFlush(user3);
        assertEquals(user3, usersDAO.findOne(USERNAME3));

        usersDAO.delete(USERNAME1);
        try
        {
            usersDAO.findOne("user1");
        }
        catch (Exception e)
        {
            // Do nothing test succeeded.
        }
        assertEquals(usersDAO.findOne(PASSWORD3), user3);
    }

    /**
     * Comment here!
     */
    @Test
    public void testFindAuthoritiesByUser()
    {
        user1.setAuthorities(authorities);
        usersDAO.saveAndFlush(user1);
        assertNotNull(usersDAO.findOne(USERNAME1));
        assertNotNull(usersDAO.findOne(USERNAME1).getAuthorities());

        assertNotNull(authoritiesDAO.findOne(ROLENAME1));
        assertNotNull(authoritiesDAO.findOne(ROLENAME1).getAuthority());
    }

    @Test
    public void testSaveExistingUser()
    {
        usersDAO.saveAndFlush(user3);
        User newUser = new User();
        newUser.setUsername(USERNAME3);
        newUser.setPassword("asdasdasd");
        newUser.setEnabled(true);
        User foundUser = usersDAO.findOne(USERNAME3);
        System.out.println("");
        System.out.println(foundUser.getPassword());
        System.out.println("");
    }

    @Test
    public void findNonExistingUser() throws Exception
    {
        User user = usersDAO.findOne("asdasdaslkfjhas");
        assertNull(user);
    }
}
