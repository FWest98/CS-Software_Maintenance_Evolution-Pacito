package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.FrameworkValidator;

/**
 * Test class for FrameworkValidator.
 * 
 * @author Tim
 *
 */

public class FrameworkValidatorTest
{
    private Framework          testFramework;
    private FrameworkValidator testFrameworkValidator;
    private Errors             errors;

    /**
     * Setup method for framework validator. Called before each test method.
     * Creates a valid Framework.
     * 
     * @throws Exception
     *             excep
     */
    @Before
    public void setUp() throws Exception
    {
        testFramework = new Framework();
        testFramework.setId(1L);
        testFramework.setName("test");
        testFramework.setShortDescription("test");
        testFramework.setFrameworkCategory(new FrameworkCategory());
        testFrameworkValidator = new FrameworkValidator();

        errors = new BeanPropertyBindingResult(testFramework, "validAddress");
    }

    /**
     * Test method for default framework created in setUp(), if this fails the
     * other tests can't work properly.
     */
    @Test
    public void setUpValid()
    {
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a wrong type.
     */
    @Test
    public void wrongType()
    {

        testFramework.setType("ArchitecturalPattern");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a website with a valid url.
     */
    @Test
    public void websiteValid()
    {

        testFramework.setWebsite("http://www.test.de");

        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a website with a valid url with a /xxx.
     */
    @Test
    public void websiteValidWithSlash()
    {

        testFramework.setWebsite("http://www.test.de/lol.html");

        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a website with a valid url starting without http://.
     */
    @Test
    public void websiteValidNoHTTP()
    {

        testFramework.setWebsite("www.test.de");

        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a website without a top level domain.
     */
    @Test
    public void websiteMissingTLD()
    {

        testFramework.setWebsite("http://test");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a website without an invalid protocol.
     */
    @Test
    public void websiteInvalidProtocol()
    {

        testFramework.setWebsite("ftp://test");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a website with an invalid character.
     */
    @Test
    public void websiteInvalidCharacter()
    {

        testFramework.setWebsite("www.test%,de");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for missing name.
     */
    @Test
    public void nameMissing()
    {
        testFramework = new Framework();

        Errors errorsLocal;
        errorsLocal = new BeanPropertyBindingResult(testFramework, "validAddress");

        testFramework.setId(1L);
        testFramework.setShortDescription("test");
        testFramework.setFrameworkCategory(new FrameworkCategory());
        testFrameworkValidator = new FrameworkValidator();
        testFramework.setWebsite("http://www.test.de");

        testFrameworkValidator.validate(testFramework, errorsLocal);
        assertTrue(errorsLocal.hasErrors());
    }

    /**
     * Test method for a website with an url that is too long.
     */
    @Test
    public void websiteTooLong()
    {

        testFramework.setWebsite("http://www."
                + "tesasdfasdfasdfsdafdsafsdafsadfsdafdsafsadfsadfsdafsdafsdafsdafsdafskdjhasfdkjhs"
                + "adjkfhjadskfhjskadhflskajdfhsdjklahfkjsdahfjldksafhjdsklfhdsjkfhsdkjlfhsdakjflhs"
                + "dfakjlfasdjhfsdalkjfasdkfasdjfsdfdjasjksdfahjasdfkjfsdajasdfkljfdsalkjfsdafsadk"
                + "jsfadhfdasjkasdfdfsajlkt.de");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a valid currentVersion.
     */
    @Test
    public void currentVersionValid()
    {

        testFramework.setCurrentVersion("1.3.2.4.6");

        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a valid currentVersion.
     */
    @Test
    public void currentVersionValidMultiNumber()
    {

        testFramework.setCurrentVersion("1.32.2.4.6");

        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for currentVersion which starts with a point.
     */
    @Test
    public void currentVersionStartsWithPoint()
    {

        testFramework.setCurrentVersion(".1.1");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for currentVersion which starts with a point.
     */
    @Test
    public void currentVersionDoublePoint()
    {

        testFramework.setCurrentVersion("1..1");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for currentVersion ends with a point.
     */
    @Test
    public void currentVersionEndsWithPoint()
    {

        testFramework.setCurrentVersion("1.1.");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for currentVersion which starts with a letter.
     */
    @Test
    public void currentVersionLetter()
    {

        testFramework.setCurrentVersion("1a.1");

        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for an invalid development status.
     */
    @Test
    public void developmentStatusInvalid()
    {

        testFramework.setDevelopmentStatus("inprogress");
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for all valid development stati.
     */
    @Test
    public void developmentStatusValid()
    {

        testFramework.setDevelopmentStatus("unknown");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setDevelopmentStatus("active");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setDevelopmentStatus("outdated");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setDevelopmentStatus("replaced");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setDevelopmentStatus("discontinued");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for an invalid community.
     */
    @Test
    public void communityInvalid()
    {

        testFramework.setDevelopmentStatus("big ass");
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for all valid community values.
     */
    @Test
    public void communityValid()
    {
        testFramework.setCommunity("unknown");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setCommunity("small");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setCommunity("medium");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setCommunity("big");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setCommunity("huge");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a name which exceeds the character limit.
     */
    @Test
    public void missingStringInConstraint()
    {
        TechnicalTerm technicalTerm = new TechnicalTerm();
        technicalTerm.setType("string");
        Constraint constraint = new Constraint();
        constraint.setTechnicalTerm(technicalTerm);
        ConstraintElement constraintElement = new ConstraintElement();
        constraintElement.setIntValue(1);
        constraint.addElement(constraintElement);

        testFramework.addConstraint(constraint);
        Errors errors = new BeanPropertyBindingResult(testFramework, "validIssue");
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());

        technicalTerm.setType("stringint");
        errors = new BeanPropertyBindingResult(testFramework, "validIssue");
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a name which exceeds the character limit.
     */
    @Test
    public void missingIntInConstraint()
    {
        TechnicalTerm technicalTerm = new TechnicalTerm();
        technicalTerm.setType("int");
        Constraint constraint = new Constraint();
        constraint.setTechnicalTerm(technicalTerm);
        ConstraintElement constraintElement = new ConstraintElement();
        constraintElement.setStringValue(new StringValue());
        constraint.addElement(constraintElement);

        testFramework.addConstraint(constraint);
        Errors errors = new BeanPropertyBindingResult(testFramework, "validIssue");
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void nameLengthValidationTest()
    {
        testFramework.setName(fillShortColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setName(fillShortColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    // @Test
    public void typeLengthValidationTest() throws Exception
    {
        testFramework.setType("Framework");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setName("Framework");
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void shortDescriptionNameLengthValidationTest()
    {
        testFramework.setShortDescription(fillDescriptionColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setShortDescription(fillDescriptionColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void creatorLengthValidationTest() throws Exception
    {
        testFramework.setCreator(fillShortColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setCreator(fillShortColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void lastModifierLengthValidationTest() throws Exception
    {
        testFramework.setLastModifier(fillShortColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setLastModifier(fillShortColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void currentVersionLengthValidationTest() throws Exception
    {
        testFramework.setCurrentVersion(fillShortColumnNumeric());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setCurrentVersion(fillShortColumnNumeric().concat("1"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void developmentStatusLengthValidationTest() throws Exception
    {

    }

    @Test
    public void descriptionLengthValidtionTest() throws Exception
    {
        testFramework.setDescription(fillMediumColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setDescription(fillMediumColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void operatingSystemLengthValidationTest() throws Exception
    {
        testFramework.setOperatingSystem(fillMediumColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setOperatingSystem(fillMediumColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void dependenciesLengthValidationTest() throws Exception
    {
        testFramework.setDependencies(fillMediumColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setDependencies(fillMediumColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void developerLengthValidationTest() throws Exception
    {
        testFramework.setDeveloper(fillShortColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setDeveloper(fillShortColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void websiteLengthValidationTest() throws Exception
    {
        testFramework.setWebsite("http://test.com");
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setWebsite("http://" + fillShortColumn() + ".com");
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void licenceLengthValidationTest() throws Exception
    {
        testFramework.setLicense(fillShortColumn());
        testFrameworkValidator.validate(testFramework, errors);
        assertFalse(errors.hasErrors());
        testFramework.setLicense(fillShortColumn().concat("a"));
        testFrameworkValidator.validate(testFramework, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Fills a string with the letter "a" to the length of a SHORT column.
     * 
     * @return
     */
    private String fillShortColumn()
    {
        return StringUtils.repeat("a", ColumnLength.SHORT);
    }

    /**
     * Fills a string with the digit "1" to the length of a SHORT column.
     * 
     * @return
     */
    private String fillShortColumnNumeric()
    {
        return StringUtils.repeat("1", ColumnLength.SHORT);
    }

    /**
     * Fills a string with the letter "a" to the length of a DESCRIPTION column.
     * 
     * @return
     */
    private String fillDescriptionColumn()
    {
        return StringUtils.repeat("a", ColumnLength.DESCRIPTION);
    }

    /**
     * Fills a string with the letter "a" to the length of a MEDIUM column.
     * 
     * @return
     */
    private String fillMediumColumn()
    {
        return StringUtils.repeat("a", ColumnLength.MEDIUM);
    }

//    /**
//     * Fills a string with the letter "a" to the length of a LONG column.
//     * 
//     * @return
//     */
//    private String fillLongColumn()
//    {
//        return StringUtils.repeat("a", ColumnLength.LONG);
//    }
}
