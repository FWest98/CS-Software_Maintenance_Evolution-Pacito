package de.uni_hamburg.informatik.swk.masterprojekt.test.beans;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.Breadcrumb;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.BreadcrumbManager;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production.WebAppConfig;

/**
 * Tests to see if class BreadcrumbManager produces correct breadcrumbs.
 * 
 * @author schaak
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = WebAppConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class BreadcrumbManagerTest
{
    private ArrayList<Breadcrumb> breadcrumbs;

    @Autowired
    private BreadcrumbManager breadcrumbManager;

    // actions
    private static final String ACTION_HOME = "home";

    private static final String ACTION_SHOW_SOLUTIONS = "showsolutions";
    private static final String ACTION_SOLUTION_PROFILE = "solutionprofile";
    private static final String ACTION_ADD_SOLUTION = "addsolution";
    private static final String ACTION_EDIT_SOLUTION = "editsolution";
    private static final String ACTION_DELETE_SOLUTION = "deletesolution";

    private static final String ACTION_SHOW_PROJECTS = "showprojects";
    private static final String ACTION_PROJECT_PROFILE = "projectprofile";
    private static final String ACTION_ADD_PROJECT = "addproject";
    private static final String ACTION_EDIT_PROJECT = "editproject";
    private static final String ACTION_DELETE_PROJECT = "deleteproject";
    private static final String ACTION_ISSUE_PROFILE = "issueprofile";
    private static final String ACTION_ADD_ISSUE = "addissue";
    private static final String ACTION_EDIT_ISSUE = "editissue";
    private static final String ACTION_DELETE_ISSUE = "deleteissue";

    private static final String ACTION_SHOW_TECHNICALTERMS = "showtechnicalterms";
    private static final String ACTION_TECHNICALTERM_PROFILE = "technicaltermprofile";
    private static final String ACTION_ADD_TECHNICALTERM = "addtechnicalterm";
    private static final String ACTION_EDIT_TECHNICALTERM = "edittechnicalterm";
    private static final String ACTION_DELETE_TECHNICALTERM = "deletetechnicalterm";

    /**
     * Setup method to create an empty breadcrumb list.
     */
    @Before
    public void initializeBreadcrumbs()
    {
        breadcrumbs = new ArrayList<Breadcrumb>();
    }

    /**
     * Tests the correct number of created Breadcrumbs.
     */
    @Test
    public void numberOfBreadcrumbs()
    {
        // VIEW: HOME
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_HOME);
        assertEquals("number of created breadcrumbs is not correct.", 1, breadcrumbs.size());

        // VIEW: CATALOG
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SHOW_SOLUTIONS);
        assertEquals("number of created breadcrumbs is not correct.", 1, breadcrumbs.size());

        ArrayList<String> list = new ArrayList<String>();
        list.add("5");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SOLUTION_PROFILE, list);
        assertEquals("number of created breadcrumbs is not correct.", 2, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ADD_SOLUTION);
        assertEquals("number of created breadcrumbs is not correct.", 2, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_EDIT_SOLUTION);
        assertEquals("number of created breadcrumbs is not correct.", 3, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_DELETE_SOLUTION);
        assertEquals("number of created breadcrumbs is not correct.", 3, breadcrumbs.size());

        // VIEW: PROJECT
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SHOW_PROJECTS);
        assertEquals("number of created breadcrumbs is not correct.", 1, breadcrumbs.size());

        ArrayList<String> list2 = new ArrayList<String>();
        list2.add("5");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_PROJECT_PROFILE, list2);
        assertEquals("number of created breadcrumbs is not correct.", 2, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ADD_PROJECT);
        assertEquals("number of created breadcrumbs is not correct.", 2, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_EDIT_PROJECT);
        assertEquals("number of created breadcrumbs is not correct.", 3, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_DELETE_PROJECT);
        assertEquals("number of created breadcrumbs is not correct.", 3, breadcrumbs.size());

        list2.add("3"); // project id
        list2.add("4"); // issue id

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ISSUE_PROFILE, list2);
        assertEquals("number of created breadcrumbs is not correct.", 3, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ADD_ISSUE);
        assertEquals("number of created breadcrumbs is not correct.", 3, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_EDIT_ISSUE, list2);
        assertEquals("number of created breadcrumbs is not correct.", 4, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_DELETE_ISSUE, list2);
        assertEquals("number of created breadcrumbs is not correct.", 4, breadcrumbs.size());

        // VIEW: CONSTRAINT
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SHOW_TECHNICALTERMS);
        assertEquals("number of created breadcrumbs is not correct.", 1, breadcrumbs.size());

        ArrayList<String> list3 = new ArrayList<String>();
        list3.add("5");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_TECHNICALTERM_PROFILE, list3);
        assertEquals("number of created breadcrumbs is not correct.", 2, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ADD_TECHNICALTERM);
        assertEquals("number of created breadcrumbs is not correct.", 2, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_EDIT_TECHNICALTERM);
        assertEquals("number of created breadcrumbs is not correct.", 3, breadcrumbs.size());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_DELETE_TECHNICALTERM);
        assertEquals("number of created breadcrumbs is not correct.", 3, breadcrumbs.size());
    }

    /**
     * Tests the correct names of created Breadcrumbs.
     */
    @Test
    public void namesOfBreadcrumbs()
    {
        // VIEW: HOME
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_HOME);
        assertEquals("name of breadcrumb is incorrect.", "home.welcome", breadcrumbs.get(0).getName());

        // VIEW: CATALOG
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SHOW_SOLUTIONS);
        assertEquals("name of breadcrumb is incorrect.", "catalog.solutionoverview", breadcrumbs.get(0).getName());

        ArrayList<String> list = new ArrayList<String>();
        list.add("17");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SOLUTION_PROFILE, list);
        Breadcrumb bc = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "catalog.solutionoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "catalog.solutionprofile", bc.getName());
        assertEquals("id in solutionprofile is not correct.", "17", bc.getParams().get(0));

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ADD_SOLUTION);
        assertEquals("name of breadcrumb is incorrect.", "catalog.solutionoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "catalog.addsolution", breadcrumbs.get(1).getName());

        ArrayList<String> list2 = new ArrayList<String>();
        list2.add("29");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_EDIT_SOLUTION, list2);
        Breadcrumb bc2 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "catalog.solutionoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "catalog.solutionprofile", bc2.getName());
        assertEquals("id in solutionprofile is not correct.", "29", bc2.getParams().get(0));
        Breadcrumb bc3 = breadcrumbs.get(2);
        assertEquals("name of breadcrumb is incorrect.", "catalog.editsolution", bc3.getName());

        ArrayList<String> list3 = new ArrayList<String>();
        list3.add("111");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_DELETE_SOLUTION, list3);
        Breadcrumb bc4 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "catalog.solutionoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "catalog.solutionprofile", bc4.getName());
        assertEquals("id in solutionprofile is not correct.", "111", bc4.getParams().get(0));
        Breadcrumb bc5 = breadcrumbs.get(2);
        assertEquals("name of breadcrumb is incorrect.", "catalog.deletesolution", bc5.getName());

        // VIEW: PROJECT
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SHOW_PROJECTS);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());

        ArrayList<String> list4 = new ArrayList<String>();
        list4.add("17");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_PROJECT_PROFILE, list4);
        Breadcrumb bc6 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.projectprofile", bc6.getName());
        assertEquals("id in projectprofile is not correct.", "17", bc6.getParams().get(0));

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ADD_PROJECT);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.addproject", breadcrumbs.get(1).getName());

        ArrayList<String> list5 = new ArrayList<String>();
        list5.add("29");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_EDIT_PROJECT, list5);
        Breadcrumb bc7 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.projectprofile", bc7.getName());
        assertEquals("id in projectprofile is not correct.", "29", bc7.getParams().get(0));
        Breadcrumb bc8 = breadcrumbs.get(2);
        assertEquals("name of breadcrumb is incorrect.", "project.editproject", bc8.getName());

        ArrayList<String> list6 = new ArrayList<String>();
        list6.add("111");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_DELETE_PROJECT, list6);
        Breadcrumb bc9 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.projectprofile", bc9.getName());
        assertEquals("id in projectprofile is not correct.", "111", bc9.getParams().get(0));
        Breadcrumb bc10 = breadcrumbs.get(2);
        assertEquals("name of breadcrumb is incorrect.", "project.deleteproject", bc10.getName());

        // project id
        ArrayList<String> list62 = new ArrayList<String>();
        list62.add("3"); // project id
        list62.add("4"); // issue id

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ISSUE_PROFILE, list62);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.projectprofile", breadcrumbs.get(1).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.issueprofile", breadcrumbs.get(2).getName());

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ADD_ISSUE);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.projectprofile", breadcrumbs.get(1).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.addissue", breadcrumbs.get(2).getName());

        ArrayList<String> list7 = new ArrayList<String>();
        list7.add("39"); // issue id
        list7.add("29"); // project id

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_EDIT_ISSUE, list7);
        Breadcrumb bc11 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.projectprofile", bc11.getName());
        assertEquals("id in projectprofile is not correct.", "29", bc11.getParams().get(0));
        Breadcrumb bc12 = breadcrumbs.get(2);
        assertEquals("name of breadcrumb is incorrect.", "project.issueprofile", bc12.getName());
        assertEquals("id in issueprofile is not correct.", "39", bc12.getParams().get(0));
        Breadcrumb bc13 = breadcrumbs.get(3);
        assertEquals("name of breadcrumb is incorrect.", "project.editissue", bc13.getName());

        ArrayList<String> list8 = new ArrayList<String>();
        list8.add("11"); // issue id
        list8.add("111"); // project id

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_DELETE_ISSUE, list8);
        Breadcrumb bc14 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "project.projectoverview", breadcrumbs.get(0).getName());
        assertEquals("name of breadcrumb is incorrect.", "project.projectprofile", bc14.getName());
        assertEquals("id in projectprofile is not correct.", "111", bc14.getParams().get(0));
        Breadcrumb bc15 = breadcrumbs.get(2);
        assertEquals("name of breadcrumb is incorrect.", "project.issueprofile", bc15.getName());
        assertEquals("id in issueprofile is not correct.", "11", bc15.getParams().get(0));
        Breadcrumb bc16 = breadcrumbs.get(3);
        assertEquals("name of breadcrumb is incorrect.", "project.deleteissue", bc16.getName());

        // VIEW: CONSTRAINT
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SHOW_TECHNICALTERMS);
        assertEquals("name of breadcrumb is incorrect.", "constraint.technicaltermoverview", breadcrumbs.get(0)
                .getName());

        ArrayList<String> list9 = new ArrayList<String>();
        list9.add("17");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_TECHNICALTERM_PROFILE, list9);
        Breadcrumb bc17 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "constraint.technicaltermoverview", breadcrumbs.get(0)
                .getName());
        assertEquals("name of breadcrumb is incorrect.", "constraint.technicaltermprofile", bc17.getName());
        assertEquals("id in technicaltermprofile is not correct.", "17", bc17.getParams().get(0));

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_ADD_TECHNICALTERM);
        assertEquals("name of breadcrumb is incorrect.", "constraint.technicaltermoverview", breadcrumbs.get(0)
                .getName());
        assertEquals("name of breadcrumb is incorrect.", "constraint.addtechnicalterm", breadcrumbs.get(1).getName());

        ArrayList<String> list10 = new ArrayList<String>();
        list10.add("29");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_EDIT_TECHNICALTERM, list10);
        Breadcrumb bc18 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "constraint.technicaltermoverview", breadcrumbs.get(0)
                .getName());
        assertEquals("name of breadcrumb is incorrect.", "constraint.technicaltermprofile", bc18.getName());
        assertEquals("id in technicaltermprofile is not correct.", "29", bc18.getParams().get(0));
        Breadcrumb bc19 = breadcrumbs.get(2);
        assertEquals("name of breadcrumb is incorrect.", "constraint.edittechnicalterm", bc19.getName());

        ArrayList<String> list11 = new ArrayList<String>();
        list11.add("111");

        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_DELETE_TECHNICALTERM, list6);
        Breadcrumb bc20 = breadcrumbs.get(1);
        assertEquals("name of breadcrumb is incorrect.", "constraint.technicaltermoverview", breadcrumbs.get(0)
                .getName());
        assertEquals("name of breadcrumb is incorrect.", "constraint.technicaltermprofile", bc20.getName());
        assertEquals("id in technicaltermprofile is not correct.", "111", bc20.getParams().get(0));
        Breadcrumb bc21 = breadcrumbs.get(2);
        assertEquals("name of breadcrumb is incorrect.", "constraint.deletetechnicalterm", bc21.getName());
    }

    /**
     * Tests behavior if second argument is needed but not given.
     */
    @Test
    public void missingSecondArgument()
    {
        // CATALOG
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_SOLUTION_PROFILE);
        Breadcrumb bc = breadcrumbs.get(1);
        assertEquals("cannot handle method call without second argument.", "catalog.solutionprofile", bc.getName());
        assertEquals("id in solutionprofile is not correct.", "0", bc.getParams().get(0));

        // PROJECT
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_PROJECT_PROFILE);
        Breadcrumb bc2 = breadcrumbs.get(1);
        assertEquals("cannot handle method call without second argument.", "project.projectprofile", bc2.getName());
        assertEquals("id in projectprofile is not correct.", "0", bc2.getParams().get(0));

        // CONSTRAINT
        breadcrumbs = breadcrumbManager.getBreadcrumbs(ACTION_TECHNICALTERM_PROFILE);
        Breadcrumb bc3 = breadcrumbs.get(1);
        assertEquals("cannot handle method call without second argument.", "constraint.technicaltermprofile",
                bc3.getName());
        assertEquals("id in technicaltermtprofile is not correct.", "0", bc3.getParams().get(0));
    }
}