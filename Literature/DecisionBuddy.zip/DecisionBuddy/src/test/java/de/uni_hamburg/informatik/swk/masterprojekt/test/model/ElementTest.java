package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element}
 * class. This class contains no business logic and only toString(), hashCode()
 * and equals() methods are tested.
 * 
 * @author Burak
 *
 */
public class ElementTest
{
    private Element element1;
    private Element element2;
    private Element element3;

    /**
     * Creates three ElementMetrics. ElementMetric 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        element1 = new Element();
        element2 = new Element();
        element3 = new Element();

        element1.setId(1L);
        element2.setId(1L);
        element3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testElementToString()
    {
        System.out.println(element1.toString());
    }

    /**
     * Tests the hashCode functionality of a Element, should only be affected by
     * Id.
     */
    @Test
    public void testElementHashcode()
    {
        element1.setName("Eins");
        element2.setName("Eins");
        element3.setName("Zwei");
        assertTrue(element1.hashCode() == element1.hashCode());
        assertTrue(element1.hashCode() == element2.hashCode());
        assertFalse(element2.hashCode() == element3.hashCode());
    }

    /**
     * Tests the equals functionality of a Element, should only be affected by
     * Id.
     */
    @Test
    public void testElementEquals()
    {
        assertTrue(element1.equals(element1));
        assertFalse(element1.equals(null));
        assertFalse(element1.equals(new String()));
        assertTrue(element1.equals(element2));
        assertFalse(element1.equals(element3));
    }
}