package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

/**
 * Unit Test Case for Solution class. As a
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution}
 * class is never instanciated no unit testing is possible.
 * 
 * @author Vlad
 *
 */
public class SolutionTest
{
}
