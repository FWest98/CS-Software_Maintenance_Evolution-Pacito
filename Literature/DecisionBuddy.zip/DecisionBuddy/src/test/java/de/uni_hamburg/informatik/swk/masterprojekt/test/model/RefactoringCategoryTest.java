package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class RefactoringCategoryTest
{
    private RefactoringCategory refactoringCategory1;
    private RefactoringCategory refactoringCategory2;
    private RefactoringCategory refactoringCategory3;

    /**
     * Creates three RefactoringCategories. RefactoringCategory 1 and 2 should
     * be equal and 3 different.
     */
    @Before
    public void setUp()
    {
        refactoringCategory1 = new RefactoringCategory();
        refactoringCategory2 = new RefactoringCategory();
        refactoringCategory3 = new RefactoringCategory();

        refactoringCategory1.setId(1L);
        refactoringCategory2.setId(1L);
        refactoringCategory3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testRefactoringCategoryToString()
    {
        System.out.println(refactoringCategory1.toString());
    }

    /**
     * Tests the hashCode functionality of a RefactoringCategory, should only be
     * affected by Id.
     */
    @Test
    public void testRefactoringCategoryHashcode()
    {
        refactoringCategory1.setDescription("1");
        refactoringCategory2.setDescription("2");
        assertTrue(refactoringCategory1.hashCode() == refactoringCategory1.hashCode());
        assertTrue(refactoringCategory1.hashCode() == refactoringCategory2.hashCode());
        assertFalse(refactoringCategory2.hashCode() == refactoringCategory3.hashCode());
    }

    /**
     * Tests the equals functionality of a RefactoringCategory, should only be
     * affected by Id.
     */
    @Test
    public void testRefactoringCategoryEquals()
    {
        refactoringCategory1.setDescription("1");
        refactoringCategory2.setDescription("2");
        assertTrue(refactoringCategory1.equals(refactoringCategory1));
        assertFalse(refactoringCategory1.equals(null));
        assertFalse(refactoringCategory1.equals(new String()));
        assertTrue(refactoringCategory1.equals(refactoringCategory2));
        assertFalse(refactoringCategory1.equals(refactoringCategory3));
    }
}