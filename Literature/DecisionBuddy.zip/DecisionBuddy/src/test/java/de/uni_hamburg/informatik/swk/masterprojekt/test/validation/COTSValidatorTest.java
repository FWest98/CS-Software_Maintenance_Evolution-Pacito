package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.COTSValidator;

/**
 * Test class for COTSValidator.
 * 
 * @author Tim
 *
 */

public class COTSValidatorTest
{
    private COTS testCOTS;
    private COTSValidator testCOTSValidator;
    private Errors errors;

    /**
     * Setup method for cots validator. Called before each test method. Creates
     * a valid COTS.
     * 
     * @throws Exception excep
     */
    @Before
    public void setUp() throws Exception
    {
        testCOTS = new COTS();
        testCOTS.setId(1L);
        testCOTS.setName("test");
        testCOTS.setShortDescription("test");
        testCOTS.setCotsCategory(new COTSCategory());
        testCOTSValidator = new COTSValidator();

        errors = new BeanPropertyBindingResult(testCOTS, "validAddress");
    }

    /**
     * Test method for default cots created in setUp(), if this fails the other
     * tests can't work properly.
     */
    @Test
    public void setUpValid()
    {
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a wrong type.
     */
    @Test
    public void wrongType()
    {

        testCOTS.setType("ArchitecturalPattern");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a website with a valid url.
     */
    @Test
    public void websiteValid()
    {

        testCOTS.setWebsite("http://www.test.de");

        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a website with a valid url with a /xxx.
     */
    @Test
    public void websiteValidWithSlash()
    {

        testCOTS.setWebsite("http://www.test.de/lol.html");

        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a website with a valid url starting without http://.
     */
    @Test
    public void websiteValidNoHTTP()
    {

        testCOTS.setWebsite("www.test.de");

        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a website without a top level domain.
     */
    @Test
    public void websiteMissingTLD()
    {

        testCOTS.setWebsite("http://test");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a website without an invalid protocol.
     */
    @Test
    public void websiteInvalidProtocol()
    {

        testCOTS.setWebsite("ftp://test");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a website with an invalid character.
     */
    @Test
    public void websiteInvalidCharacter()
    {

        testCOTS.setWebsite("www.test%,de");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for missing name.
     */
    @Test
    public void nameMissing()
    {
        testCOTS = new COTS();

        Errors errorsLocal;
        errorsLocal = new BeanPropertyBindingResult(testCOTS, "validAddress");

        testCOTS.setId(1L);
        testCOTS.setShortDescription("test");
        testCOTS.setCotsCategory(new COTSCategory());
        testCOTSValidator = new COTSValidator();
        testCOTS.setWebsite("http://www.test.de");

        testCOTSValidator.validate(testCOTS, errorsLocal);
        assertTrue(errorsLocal.hasErrors());
    }

    /**
     * Test method for a website with an url that is too long.
     */
    @Test
    public void websiteTooLong()
    {

        testCOTS.setWebsite("http://www."
                + "tesasdfasdfasdfsdafdsafsdafsadfsdafdsafsadfsadfsdafsdafsdafsdafsdafskdjhasfdkjhs"
                + "adjkfhjadskfhjskadhflskajdfhsdjklahfkjsdahfjldksafhjdsklfhdsjkfhsdkjlfhsdakjflhs"
                + "dfakjlfasdjhfsdalkjfasdkfasdjfsdfdjasjksdfahjasdfkjfsdajasdfkljfdsalkjfsdafsadk"
                + "jsfadhfdasjkasdfdfsajlkt.de");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a valid currentVersion.
     */
    @Test
    public void currentVersionValid()
    {

        testCOTS.setCurrentVersion("1.3.2.4.6");

        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for a valid currentVersion.
     */
    @Test
    public void currentVersionValidMultiNumber()
    {

        testCOTS.setCurrentVersion("1.32.2.4.6");

        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for currentVersion which starts with a point.
     */
    @Test
    public void currentVersionStartsWithPoint()
    {

        testCOTS.setCurrentVersion(".1.1");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for currentVersion which starts with a point.
     */
    @Test
    public void currentVersionDoublePoint()
    {

        testCOTS.setCurrentVersion("1..1");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for currentVersion ends with a point.
     */
    @Test
    public void currentVersionEndsWithPoint()
    {

        testCOTS.setCurrentVersion("1.1.");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for currentVersion which starts with a letter.
     */
    @Test
    public void currentVersionLetter()
    {

        testCOTS.setCurrentVersion("1a.1");

        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for an invalid development status.
     */
    @Test
    public void developmentStatusInvalid()
    {

        testCOTS.setDevelopmentStatus("inprogress");
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for all valid development stati.
     */
    @Test
    public void developmentStatusValid()
    {

        testCOTS.setDevelopmentStatus("unknown");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setDevelopmentStatus("active");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setDevelopmentStatus("outdated");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setDevelopmentStatus("replaced");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setDevelopmentStatus("discontinued");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for an invalid community.
     */
    @Test
    public void communityInvalid()
    {

        testCOTS.setDevelopmentStatus("big ass");
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for all valid community values.
     */
    @Test
    public void communityValid()
    {
        testCOTS.setCommunity("unknown");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setCommunity("small");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setCommunity("medium");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setCommunity("big");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setCommunity("huge");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
    }

    @Test
    public void nameLengthValidationTest()
    {
        testCOTS.setName(fillShortColumn());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setName(fillShortColumn().concat("a"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    // @Test
    public void typeLengthValidationTest() throws Exception
    {
        testCOTS.setType("COTS");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setName("COTS");
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void shortDescriptionNameLengthValidationTest()
    {
        testCOTS.setShortDescription(fillDescriptionColumn());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setShortDescription(fillDescriptionColumn().concat("a"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void creatorLengthValidationTest() throws Exception
    {
        testCOTS.setCreator(fillShortColumn());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setCreator(fillShortColumn().concat("a"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void lastModifierLengthValidationTest() throws Exception
    {
        testCOTS.setLastModifier(fillShortColumn());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setLastModifier(fillShortColumn().concat("a"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void currentVersionLengthValidationTest() throws Exception
    {
        testCOTS.setCurrentVersion(fillShortColumnNumeric());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setCurrentVersion(fillShortColumnNumeric().concat("1"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void developmentStatusLengthValidationTest() throws Exception
    {

    }

    @Test
    public void descriptionLengthValidtionTest() throws Exception
    {
        testCOTS.setDescription(fillMediumColumn());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setDescription(fillMediumColumn().concat("a"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void operatingSystemLengthValidationTest() throws Exception
    {
        testCOTS.setOperatingSystem(fillMediumColumn());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setOperatingSystem(fillMediumColumn().concat("a"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void developerLengthValidationTest() throws Exception
    {
        testCOTS.setDeveloper(fillShortColumn());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setDeveloper(fillShortColumn().concat("a"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void websiteLengthValidationTest() throws Exception
    {
        testCOTS.setWebsite("http://test.com");
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setWebsite("http://" + fillShortColumn() + ".com");
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    @Test
    public void licenceLengthValidationTest() throws Exception
    {
        testCOTS.setLicense(fillShortColumn());
        testCOTSValidator.validate(testCOTS, errors);
        assertFalse(errors.hasErrors());
        testCOTS.setLicense(fillShortColumn().concat("a"));
        testCOTSValidator.validate(testCOTS, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Fills a string with the letter "a" to the length of a SHORT column.
     * 
     * @return
     */
    private String fillShortColumn()
    {
        return StringUtils.repeat("a", ColumnLength.SHORT);
    }

    /**
     * Fills a string with the digit "1" to the length of a SHORT column.
     * 
     * @return
     */
    private String fillShortColumnNumeric()
    {
        return StringUtils.repeat("1", ColumnLength.SHORT);
    }

    /**
     * Fills a string with the letter "a" to the length of a DESCRIPTION column.
     * 
     * @return
     */
    private String fillDescriptionColumn()
    {
        return StringUtils.repeat("a", ColumnLength.DESCRIPTION);
    }

    /**
     * Fills a string with the letter "a" to the length of a MEDIUM column.
     * 
     * @return
     */
    private String fillMediumColumn()
    {
        return StringUtils.repeat("a", ColumnLength.MEDIUM);
    }

//    /**
//     * Fills a string with the letter "a" to the length of a LONG column.
//     * 
//     * @return
//     */
//    private String fillLongColumn()
//    {
//        return StringUtils.repeat("a", ColumnLength.LONG);
//    }
}
