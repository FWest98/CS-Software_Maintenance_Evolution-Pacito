//package de.uni_hamburg.informatik.swk.masterprojekt.test.security;
//
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import javax.servlet.Filter;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.web.WebAppConfiguration;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.ResultActions;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//import org.springframework.web.context.WebApplicationContext;
//
//import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.SecurityTestConfig;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = { SecurityTestConfig.class })
//@WebAppConfiguration
//@ActiveProfiles("SecurityTesting")
//public class AuthenticationTest
//{
//    private MockMvc mockMvc;
//
//    @Autowired
//    private WebApplicationContext webApplicationContext;
//
//    @Autowired
//    private Filter springFilterChain;
//
//    // @Autowired
//    // private ProjectService projectServiceMock;
//    // @Autowired
//    // private IssueService issueServiceMock;
//    // @Autowired
//    // private SolutionService solutionServiceMock;
//    // @Autowired
//    // private ConstraintService constraintServiceMock;
//    // @Autowired
//    // private TechnicalTermService technicalTermServiceMock;
//
//    @Before
//    public void setUp() throws Exception
//    {
//        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).addFilters(springFilterChain).build();
//    }
//
//    @After
//    public void tearDown() throws Exception
//    {
//    }
//
//    @Test
//    public void testLogin() throws Exception
//    {
//      ResultActions resultActions = mockMvc.perform(get("/login"));
//      resultActions.andExpect(status().isOk());
//    }
//
//}
