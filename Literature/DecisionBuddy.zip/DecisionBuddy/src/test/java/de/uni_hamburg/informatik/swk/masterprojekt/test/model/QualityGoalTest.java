package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class QualityGoalTest
{
    private QualityGoal qualityGoal1;
    private QualityGoal qualityGoal2;
    private QualityGoal qualityGoal3;

    /**
     * Creates three QualityGoals. QualityGoal 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        qualityGoal1 = new QualityGoal();
        qualityGoal2 = new QualityGoal();
        qualityGoal3 = new QualityGoal();

        qualityGoal1.setId(1L);
        qualityGoal2.setId(1L);
        qualityGoal3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testQualityGoalToString()
    {
        System.out.println(qualityGoal1.toString());
    }

    /**
     * Tests the hashCode functionality of a QualityGoal, should only be
     * affected by Id.
     */
    @Test
    public void testQualityGoalHashcode()
    {
        qualityGoal1.setName("a");
        qualityGoal2.setName("b");
        assertTrue(qualityGoal1.hashCode() == qualityGoal1.hashCode());
        assertTrue(qualityGoal1.hashCode() == qualityGoal2.hashCode());
        assertFalse(qualityGoal2.hashCode() == qualityGoal3.hashCode());
    }

    /**
     * Tests the equals functionality of a QualityGoal, should only be affected
     * by Id.
     */
    @Test
    public void testQualityGoalEquals()
    {
        qualityGoal1.setName("a");
        qualityGoal2.setName("b");
        assertTrue(qualityGoal1.equals(qualityGoal1));
        assertFalse(qualityGoal1.equals(null));
        assertFalse(qualityGoal1.equals(new String()));
        assertTrue(qualityGoal1.equals(qualityGoal2));
        assertFalse(qualityGoal1.equals(qualityGoal3));
    }
}