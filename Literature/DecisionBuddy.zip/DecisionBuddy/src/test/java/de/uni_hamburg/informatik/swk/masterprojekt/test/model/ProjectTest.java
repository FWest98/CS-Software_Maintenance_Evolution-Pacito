package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Vlad
 *
 */
public class ProjectTest
{
    private Project project1;
    private Project project2;
    private Project project3;

    @Before
    public void setUp() throws Exception
    {
        project1 = new Project();
        project2 = new Project();
        project3 = new Project();

        project1.setId(1L);
        project2.setId(1L);
        project3.setId(2L);
    }

    @After
    public void tearDown() throws Exception
    {
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testProjectToString()
    {
        System.out.println(project1.toString());
    }

    /**
     * Tests the hashCode functionality of a Project.
     */
    @Test
    public void testProjectHashcode()
    {
        assertEquals(project1.hashCode(), project1.hashCode());
        assertEquals(project1.hashCode(), project2.hashCode());
        assertNotEquals(project2.hashCode(), project3.hashCode());
    }

    /**
     * Tests the equals functionality of a Project.
     */
    @Test
    public void testProjectEquals()
    {
        assertTrue(project1.equals(project1));
        assertFalse(project1.equals(null));
        assertFalse(project1.equals(new String()));
        assertTrue(project1.equals(project2));
        assertFalse(project1.equals(project3));
    }
}
