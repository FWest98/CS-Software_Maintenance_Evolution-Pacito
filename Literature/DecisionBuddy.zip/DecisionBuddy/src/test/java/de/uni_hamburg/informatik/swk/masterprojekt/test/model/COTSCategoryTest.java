package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class COTSCategoryTest
{
    private COTSCategory cotsCategory1;
    private COTSCategory cotsCategory2;
    private COTSCategory cotsCategory3;

    /**
     * Creates three COTSCategories. COTSCategory 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        cotsCategory1 = new COTSCategory();
        cotsCategory2 = new COTSCategory();
        cotsCategory3 = new COTSCategory();

        cotsCategory1.setId(1L);
        cotsCategory2.setId(1L);
        cotsCategory3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testCOTSCategoryToString()
    {
        System.out.println(cotsCategory1.toString());
    }

    /**
     * Tests the hashCode functionality of a COTSCategory, should only be
     * affected by Id.
     */
    @Test
    public void testCOTSCategoryHashcode()
    {
        cotsCategory1.setDescription("1");
        cotsCategory2.setDescription("2");
        assertTrue(cotsCategory1.hashCode() == cotsCategory1.hashCode());
        assertTrue(cotsCategory1.hashCode() == cotsCategory2.hashCode());
        assertFalse(cotsCategory2.hashCode() == cotsCategory3.hashCode());
    }

    /**
     * Tests the equals functionality of a COTSCategory, should only be affected
     * by Id.
     */
    @Test
    public void testCOTSCategoryEquals()
    {
        cotsCategory1.setDescription("1");
        cotsCategory2.setDescription("2");
        assertTrue(cotsCategory1.equals(cotsCategory1));
        assertFalse(cotsCategory1.equals(null));
        assertFalse(cotsCategory1.equals(new String()));
        assertTrue(cotsCategory1.equals(cotsCategory2));
        assertFalse(cotsCategory1.equals(cotsCategory3));
    }
}