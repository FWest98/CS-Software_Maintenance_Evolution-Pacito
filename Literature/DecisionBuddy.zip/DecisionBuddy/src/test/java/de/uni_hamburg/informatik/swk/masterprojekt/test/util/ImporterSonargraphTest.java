package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ImporterSonargraph;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class ImporterSonargraphTest
{
    private static final String TMP_PREFIX = "analyzeresult_";
    private static final String TMP_EXTENSION = ".tmp";

    private File invalidFile;
    private File faultyFile;
    private File correctFile;

    @Autowired
    private ImporterSonargraph importerSonargraph;

    @Before
    public void setup()
    {
        BufferedWriter writer;
        String text;

        try
        {
            // Write syntactical invalid File
            invalidFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(invalidFile));
            text = "<?xml veresion=\"1.0\" ?>\n <ns2:report xmlns:ns2=\"http://www.hello4morrow.com/sonargraph/core/report\""
                    + " version=\"8.0.0.315\" systemPath=\"\\MediathekSonar.sonargraph\\system.sonargraph\"><root></root>";
            writer.write(text);
            writer.close();

            // Write faulty file: metric id="_40" instead of "_0"
            faultyFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(faultyFile));
            text = "<?xml version=\"1.0\" ?>\n<ns2:report xmlns:ns2=\"http://www.hello2morrow.com/sonargraph/core/report\" "
                    + "version=\"8.0.25.315\" systemPath=\"E:\\Uni\\08 MProj SE\\Sonargraph\\MediathekSonar\\MediathekSonar."
                    + "sonargraph\\system.sonargraph\" systemId=\"a5f1100f428794ce2b80322f8a69ce64\" timestamp=\"2015-10-15"
                    + "T20:29:17.513+02:00\"><workspace>  <module ref=\"_ad\">    <root ref=\"_119\"></root>    <root ref="
                    + "\"_43c\"></root>  </module></workspace><moduleElements name=\"Mediathek6\" description=\"\" language"
                    + "=\"Java\" id=\"_ad\">   <element id=\"_ae\" kind=\"JavaLogicalModuleNamespace\" fqName=\"Logical module"
                    + " namespaces:Mediathek6:de:uni_hamburg:informatik:swt:se2:mediathek:fachwerte\" presentationName=\""
                    + "de.uni_hamburg.informatik.swt.se2.mediathek.fachwerte\"></element></moduleElements><metrics>  "
                    + "<metric id=\"_40\" presentationName=\"ACD\" description=\"Average component dependency\"></metric> "
                    + " <metric id=\"_41\" presentationName=\"Abstractness (Module)\" description=\"Abstractness according "
                    + "to Robert C. Martin.\"></metric></metrics><moduleMetrics module=\"Mediathek6\" description=\"\" "
                    + "language=\"Java\">  <level name=\"Module\" presentationName=\"Module\">    <metric ref=\"_1\">      "
                    + "<float ref=\"_ae\">0.6</float>    </metric>  </level></moduleMetrics><systemMetrics>  <level name="
                    + "\"System\" presentationName=\"System\">    <metric ref=\"_0\">      <float ref=\"_ae\">8.92</float>"
                    + "    </metric>  </level></systemMetrics></ns2:report>";
            writer.write(text);
            writer.close();

            // Write correct File
            correctFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(correctFile));
            text = "<?xml version=\"1.0\" ?>\n<ns2:report xmlns:ns2=\"http://www.hello2morrow.com/sonargraph/core/report\" "
                    + "version=\"8.0.25.315\" systemPath=\"E:\\Uni\\08 MProj SE\\Sonargraph\\MediathekSonar\\MediathekSonar."
                    + "sonargraph\\system.sonargraph\" systemId=\"a5f1100f428794ce2b80322f8a69ce64\" timestamp=\"2015-10-15"
                    + "T20:29:17.513+02:00\"><workspace>  <module ref=\"_ad\">    <root ref=\"_119\"></root>    <root ref="
                    + "\"_43c\"></root>  </module></workspace><moduleElements name=\"Mediathek6\" description=\"\" language"
                    + "=\"Java\" id=\"_ad\">   <element id=\"_ae\" kind=\"JavaLogicalModuleNamespace\" fqName=\"Logical module"
                    + " namespaces:Mediathek6:de:uni_hamburg:informatik:swt:se2:mediathek:fachwerte\" presentationName=\""
                    + "de.uni_hamburg.informatik.swt.se2.mediathek.fachwerte\"></element></moduleElements><metrics>  "
                    + "<metric id=\"_0\" presentationName=\"ACD\" description=\"Average component dependency\"></metric> "
                    + " <metric id=\"_1\" presentationName=\"Abstractness (Module)\" description=\"Abstractness according "
                    + "to Robert C. Martin.\"></metric></metrics><moduleMetrics module=\"Mediathek6\" description=\"\" "
                    + "language=\"Java\">  <level name=\"Module\" presentationName=\"Module\">    <metric ref=\"_1\">      "
                    + "<float ref=\"_ae\">0.6</float>    </metric>  </level></moduleMetrics><systemMetrics>  <level name="
                    + "\"System\" presentationName=\"System\">    <metric ref=\"_0\">      <float ref=\"_ae\">8.92</float>"
                    + "    </metric>  </level></systemMetrics></ns2:report>";
            writer.write(text);
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    @Test(expected = AnalysisResultException.class)
    public void testValidateInvalidData() throws AnalysisResultException
    {
        importerSonargraph.validateFile(invalidFile.getAbsolutePath());
    }
    
    @Test
    public void testValidateFaultyData()
    {
        try
        {
            Assert.assertTrue(importerSonargraph.validateFile(faultyFile.getAbsolutePath()));
        }
        catch (AnalysisResultException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
    }

    @Test
    public void testValidateCorrectData()
    {
        try
        {
            Assert.assertTrue(importerSonargraph.validateFile(correctFile.getAbsolutePath()));
        }
        catch (AnalysisResultException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
    }

    // @Test(expected = AnalysisResultException.class)
    // public void testImportFaultyData() throws AnalysisResultException
    // {
    // importerSonargraph.importFile(1, faultyFile.getAbsolutePath());
    // }
    //
    // @Test
    // public void testImportCorrectData()
    // {
    // try
    // {
    // importerSonargraph.importFile(1, correctFile.getAbsolutePath());
    // }
    // catch (AnalysisResultException e)
    // {
    // e.printStackTrace();
    // fail("Exception caught.");
    // }
    // }
}
