package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class RatingTest
{
    private Rating rating1;
    private Rating rating2;
    private Rating rating3;

    /**
     * Creates three Ratings. Rating 1 and 2 should be equal and 3 different.
     */
    @Before
    public void setUp()
    {
        rating1 = new Rating();
        rating2 = new Rating();
        rating3 = new Rating();

        rating1.setId(1L);
        rating2.setId(1L);
        rating3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testRatingToString()
    {
        System.out.println(rating1.toString());
    }

    /**
     * Tests the hashCode functionality of a Rating, should only be affected by
     * Id.
     */
    @Test
    public void testRatingHashcode()
    {
        rating1.setReasoning("a");
        rating2.setReasoning("b");
        assertTrue(rating1.hashCode() == rating1.hashCode());
        assertTrue(rating1.hashCode() == rating2.hashCode());
        assertFalse(rating2.hashCode() == rating3.hashCode());
    }

    /**
     * Tests the equals functionality of a Rating, should only be affected by
     * Id.
     */
    @Test
    public void testRatingEquals()
    {
        rating1.setReasoning("a");
        rating2.setReasoning("b");
        assertTrue(rating1.equals(rating1));
        assertFalse(rating1.equals(null));
        assertFalse(rating1.equals(new String()));
        assertTrue(rating1.equals(rating2));
        assertFalse(rating1.equals(rating3));
    }
}