package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.RefactoringValidator;

/**
 * Test class for RefactoringValidator.
 * 
 * @author Tim
 *
 */

public class RefactoringValidatorTest
{
    private Refactoring testRefactoring;
    private RefactoringValidator testRefactoringValidator;

    /**
     * Setup method for refactoring validator. Called before each test method.
     * Creates a valid Refactoring.
     * 
     * @throws Exception excep
     */
    @Before
    public void setUp() throws Exception
    {
        testRefactoring = new Refactoring();
        testRefactoring.setId(1L);
        testRefactoring.setName("test");
        testRefactoring.setRefactoringCategory(new RefactoringCategory());
        testRefactoring.setShortDescription("test");
        testRefactoring.setExamples("test");
        testRefactoring.setMechanics("test");
        testRefactoring.setSummary("test");
        testRefactoringValidator = new RefactoringValidator();
    }

    /**
     * Test method for default design pattern created in setUp(), if this fails
     * the other tests can't work properly.
     */
    @Test
    public void testSetUpValid()
    {
        Errors errors;
        errors = new BeanPropertyBindingResult(testRefactoring, "validAddress");
        testRefactoringValidator.validate(testRefactoring, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for missing name.
     */
    @Test
    public void testNameMissing()
    {
        Errors errors;
        testRefactoring.setName("");
        testRefactoringValidator = new RefactoringValidator();
        errors = new BeanPropertyBindingResult(testRefactoring, "validAddress");
        testRefactoringValidator.validate(testRefactoring, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a wrong type.
     */
    @Test
    public void testWrongType()
    {
        Errors errors;
        testRefactoring.setType("Framework");
        errors = new BeanPropertyBindingResult(testRefactoring, "validAddress");
        testRefactoringValidator.validate(testRefactoring, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Create string of lenghts n.
     * 
     * @param n the length of the string
     * @return new string of length n
     */
    public String createStringOfLenghtsN(int n)
    {
        String string = "a";
        for (int i = 1; i < n; i++)
        {
            string = string.concat("a");
        }
        return string;
    }

    /**
     * Test method for an name which exceeds the character limit.
     */
    @Test
    public void testNameTooLong()
    {
        Errors errors;
        String string = createStringOfLenghtsN(ColumnLength.SHORT + 1);
        testRefactoring.setName(string);
        errors = new BeanPropertyBindingResult(testRefactoring, "validAddress");
        testRefactoringValidator.validate(testRefactoring, errors);
        assertTrue(errors.hasErrors());
        System.out.print("String: " + testRefactoring.getSummary());
    }

    /**
     * Test method for an Summary which exceeds the character limit.
     */
    @Test
    public void testSummaryTooLong()
    {
        Errors errors;
        testRefactoring.setSummary(createStringOfLenghtsN(ColumnLength.MEDIUM + 1));
        errors = new BeanPropertyBindingResult(testRefactoring, "validAddress");
        testRefactoringValidator.validate(testRefactoring, errors);
        System.out.print("String: " + testRefactoring.getSummary());
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for an name which exceeds the character limit.
     */
    @Test
    public void testMechanicsTooLong()
    {
        Errors errors;
        testRefactoring.setMechanics(createStringOfLenghtsN(ColumnLength.MEDIUM + 1));
        errors = new BeanPropertyBindingResult(testRefactoring, "validAddress");
        testRefactoringValidator.validate(testRefactoring, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for an name which exceeds the character limit.
     */
    @Test
    public void testExamplesTooLong()
    {
        Errors errors;
        testRefactoring.setExamples(createStringOfLenghtsN(ColumnLength.MEDIUM + 1));
        errors = new BeanPropertyBindingResult(testRefactoring, "validAddress");
        testRefactoringValidator.validate(testRefactoring, errors);
        assertTrue(errors.hasErrors());
    }
}