package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class StringValueTest
{
    private StringValue stringValue1;
    private StringValue stringValue2;
    private StringValue stringValue3;

    /**
     * Creates three StringValues. StringValue 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        stringValue1 = new StringValue();
        stringValue2 = new StringValue();
        stringValue3 = new StringValue();

        stringValue1.setId(1L);
        stringValue2.setId(1L);
        stringValue3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testStringValueToString()
    {
        System.out.println(stringValue1.toString());
    }

    /**
     * Tests the hashCode functionality of a StringValue, should only be
     * affected by Id.
     */
    @Test
    public void testStringValueHashcode()
    {
        stringValue1.setStringValue("a");
        stringValue2.setStringValue("n");
        assertTrue(stringValue1.hashCode() == stringValue1.hashCode());
        assertTrue(stringValue1.hashCode() == stringValue2.hashCode());
        assertFalse(stringValue2.hashCode() == stringValue3.hashCode());
    }

    /**
     * Tests the equals functionality of a StringValue, should only be affected
     * by Id.
     */
    @Test
    public void testStringValueEquals()
    {
        stringValue1.setStringValue("a");
        stringValue2.setStringValue("n");
        assertTrue(stringValue1.equals(stringValue1));
        assertFalse(stringValue1.equals(null));
        assertFalse(stringValue1.equals(new String()));
        assertTrue(stringValue1.equals(stringValue2));
        assertFalse(stringValue1.equals(stringValue3));
    }
}