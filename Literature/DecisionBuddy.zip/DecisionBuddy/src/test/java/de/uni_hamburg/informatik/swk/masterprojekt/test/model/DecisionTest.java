package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class DecisionTest
{
    private Decision decision1;
    private Decision decision2;
    private Decision decision3;

    /**
     * Creates three Decisions. Decision 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        decision1 = new Decision();
        decision2 = new Decision();
        decision3 = new Decision();

        decision1.setId(1L);
        decision2.setId(1L);
        decision3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testDecisionToString()
    {
        System.out.println(decision1.toString());
    }

    /**
     * Tests the hashCode functionality of a Decision, should only be affected
     * by Id.
     */
    @Test
    public void testDecisionHashcode()
    {
        decision1.setDecided(true);
        decision2.setDecided(false);
        assertTrue(decision1.hashCode() == decision1.hashCode());
        assertTrue(decision1.hashCode() == decision2.hashCode());
        assertFalse(decision2.hashCode() == decision3.hashCode());
    }

    /**
     * Tests the equals functionality of a Decision, should only be affected by
     * Id.
     */
    @Test
    public void testDecisionEquals()
    {
        decision1.setDecided(true);
        decision2.setDecided(false);
        assertTrue(decision1.equals(decision1));
        assertFalse(decision1.equals(null));
        assertFalse(decision1.equals(new String()));
        assertTrue(decision1.equals(decision2));
        assertFalse(decision1.equals(decision3));
    }
}