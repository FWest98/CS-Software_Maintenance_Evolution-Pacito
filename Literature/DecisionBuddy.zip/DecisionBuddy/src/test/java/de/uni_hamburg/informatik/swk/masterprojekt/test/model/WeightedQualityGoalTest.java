package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class WeightedQualityGoalTest
{
    private WeightedQualityGoal weightedQualityGoal1;
    private WeightedQualityGoal weightedQualityGoal2;
    private WeightedQualityGoal weightedQualityGoal3;

    /**
     * Creates three WeightedQualityGoals. WeightedQualityGoal 1 and 2 should be
     * equal and 3 different.
     */
    @Before
    public void setUp()
    {
        weightedQualityGoal1 = new WeightedQualityGoal();
        weightedQualityGoal2 = new WeightedQualityGoal();
        weightedQualityGoal3 = new WeightedQualityGoal();

        Issue issue1 = new Issue();
        issue1.setId(1L);
        Issue issue2 = new Issue();
        issue2.setId(2L);

        weightedQualityGoal1.setIssue(issue1);
        weightedQualityGoal2.setIssue(issue1);
        weightedQualityGoal3.setIssue(issue2);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testWeightedQualityGoalToString()
    {
        System.out.println(weightedQualityGoal1.toString());
    }

    /**
     * Tests the hashCode functionality of a WeightedQualityGoal, should only be
     * affected by Issue.
     */
    @Test
    public void testWeightedQualityGoalHashcode()
    {
        weightedQualityGoal1.setWeight(1);
        weightedQualityGoal1.setWeight(2);
        assertTrue(weightedQualityGoal1.hashCode() == weightedQualityGoal1.hashCode());
        assertTrue(weightedQualityGoal1.hashCode() == weightedQualityGoal2.hashCode());
        assertFalse(weightedQualityGoal2.hashCode() == weightedQualityGoal3.hashCode());
    }

    /**
     * Tests the equals functionality of a WeightedQualityGoal, should only be
     * affected by Issue.
     */
    @Test
    public void testWeightedQualityGoalEquals()
    {
        weightedQualityGoal1.setWeight(1);
        weightedQualityGoal1.setWeight(2);
        assertTrue(weightedQualityGoal1.equals(weightedQualityGoal1));
        assertFalse(weightedQualityGoal1.equals(null));
        assertFalse(weightedQualityGoal1.equals(new String()));
        assertTrue(weightedQualityGoal1.equals(weightedQualityGoal2));
        assertFalse(weightedQualityGoal1.equals(weightedQualityGoal3));
    }
}