package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ArchitecturalPatternDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.COTSDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RefactoringDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ConstraintProposer;

/**
 * Tests the ConstraintProposer.
 * 
 * @author Tim
 *
 */

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class ConstraintProposerTest {
	@Autowired
	private ConstraintProposer constraintProposer;

	@Autowired
	private FrameworkDAO frameworkDAO;

	@Autowired
	private COTSDAO cotsDAO;

	@Autowired
	private RefactoringDAO refactoringDAO;

	@Autowired
	private ArchitecturalPatternDAO architecturalPatternDAO;

	/**
	 * Creates test projects and issues.
	 */
	@Before
	public void setUp() {
	}

	/**
	 * Test if the right TechnicalTerms are found.
	 */
	@Test
	public void testProposeCorrectTechnicalTerm() {
		assertTrue("Programming Language".equals(constraintProposer
				.findTechnicalTerm("Programmsdf2ingLanguage").getIdentifier()));
		assertTrue("Year of release".equals(constraintProposer
				.findTechnicalTerm("Yer of release").getIdentifier()));
		assertTrue("Camel".equals(constraintProposer.findStringValue("Camelll",
				5L).getStringValue()));
		assertNull(constraintProposer.findStringValue("jhgh", 5L));
	}

	/**
	 * Test if the right Constraints for a specific Solution are be found. Needs
	 * manual inspection.
	 */
	@Test
	public void testProposeCorrectConstraintsForFramework() {
		Framework framework = frameworkDAO.findOne(2L);
		List<Constraint> constraints = constraintProposer
				.proposeConstraintsFromModel(framework);
		for (Constraint constraint : constraints) {
			System.out.print("Found: "
					+ constraint.getTechnicalTerm().getIdentifier());
			System.out.print("|Int: ");
			System.out.print(constraint.getElements().get(0).getIntValue());
			if (constraint.getElements().get(0).getStringValue() != null) {
				System.out.print("|Str: ");
				System.out.print(constraint.getElements().get(0)
						.getStringValue().getStringValue());
			}
			System.out.println();
		}
	}

	/**
	 * Test if the right Constraints for a specific Solution are be found. Needs
	 * manual inspection.
	 */
	@Test
	public void testProposeCorrectForCOTS() {
		COTS cots = cotsDAO.findOne(2L);
		if (cots != null) {
			List<Constraint> constraints = constraintProposer
					.proposeConstraintsFromModel(cots);
			for (Constraint constraint : constraints) {
				System.out.print("Found: "
						+ constraint.getTechnicalTerm().getIdentifier());
				System.out.print("|Int: ");
				System.out.print(constraint.getElements().get(0).getIntValue());
				if (constraint.getElements().get(0).getStringValue() != null) {
					System.out.print("|Str: ");
					System.out.print(constraint.getElements().get(0)
							.getStringValue().getStringValue());
				}
				System.out.println();
			}
		}
	}

	/**
	 * Test if the right Constraints for a specific Solution are be found. Needs
	 * manual inspection.
	 */
	@Test
	public void testProposeCorrectForRefactoring() {
		Refactoring refactoring = refactoringDAO.findOne(2348L);
		List<Constraint> constraints = constraintProposer
				.proposeConstraintsFromModel(refactoring);
		for (Constraint constraint : constraints) {
			System.out.print("Found: "
					+ constraint.getTechnicalTerm().getIdentifier());
			System.out.print("|Int: ");
			System.out.print(constraint.getElements().get(0).getIntValue());
			if (constraint.getElements().get(0).getStringValue() != null) {
				System.out.print("|Str: ");
				System.out.print(constraint.getElements().get(0)
						.getStringValue().getStringValue());
			}
			System.out.println();
		}
	}

	/**
	 * Test if the right Constraints for a specific Solution are be found. Needs
	 * manual inspection.
	 */
	@Test
	public void testProposeCorrectForArchitecturalPattern() {
		ArchitecturalPattern architecturalPattern = architecturalPatternDAO
				.findOne(382L);
		List<Constraint> constraints = constraintProposer
				.proposeConstraintsFromModel(architecturalPattern);
		for (Constraint constraint : constraints) {
			System.out.print("Found: "
					+ constraint.getTechnicalTerm().getIdentifier());
			System.out.print("|Int: ");
			System.out.print(constraint.getElements().get(0).getIntValue());
			if (constraint.getElements().get(0).getStringValue() != null) {
				System.out.print("|Str: ");
				System.out.print(constraint.getElements().get(0)
						.getStringValue().getStringValue());
			}
			System.out.println();
		}
	}
}