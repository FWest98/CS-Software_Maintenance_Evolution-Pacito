//package de.uni_hamburg.informatik.swk.masterprojekt.test.util;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;
//import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorityEditor;
//
//public class AuthorityEditorTest
//{
//    @Autowired
//    private AuthorityEditor authorityEditor;
//
//    private Authority authority;
//
//    @Before
//    public void setUp() throws Exception
//    {
//        authority = new Authority();
//        authority.setAuthority("ROLE_VLAD");
//        // authorityEditor.setValue(authority);
//    }
//
//    @Test
//    public void testGetAsText()
//    {
//        assertNotNull(authorityEditor);
//        String s = authorityEditor.getAsText();
//        assertEquals(s, "ROLE_VLAD");
//    }
//
//}
