package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ComparatorFactory;

public class ComperatorFactoryTest
{
    @Before
    public void setUp() throws Exception
    {

    }

    /**
     * Test if the right exception is thrown for unknown field.
     * 
     * @throws SorterFieldNotFoundException
     * @throws SorterInvalidTypeException
     */
    @Test(expected = SorterFieldNotFoundException.class)
    public void testInvalidField() throws SorterFieldNotFoundException, SorterInvalidTypeException
    {
        new ComparatorFactory<Solution>(Solution.class).generateComparator("fail");
    }

    /**
     * Test if the right exception is thrown for a field with invalid type.
     * 
     * @throws SorterFieldNotFoundException
     * @throws SorterInvalidTypeException
     */
    @Test(expected = SorterInvalidTypeException.class)
    public void testInvalidType() throws SorterFieldNotFoundException, SorterInvalidTypeException
    {
        new ComparatorFactory<Solution>(Solution.class).generateComparator("creationDate");
    }

    /**
     * Test if the no exception is thrown for known field.
     * 
     * @throws SorterFieldNotFoundException
     * @throws SorterInvalidTypeException
     */
    @Test
    public void testValidStringField() throws SorterFieldNotFoundException, SorterInvalidTypeException
    {
        new ComparatorFactory<Solution>(Solution.class).generateComparator("type");
    }

    /**
     * Test if the no exception is thrown for known field.
     * 
     * @throws SorterFieldNotFoundException
     * @throws SorterInvalidTypeException
     */
    @Test
    public void testValidLongField() throws SorterFieldNotFoundException, SorterInvalidTypeException
    {
        new ComparatorFactory<Solution>(Solution.class).generateComparator("id");
    }
}
