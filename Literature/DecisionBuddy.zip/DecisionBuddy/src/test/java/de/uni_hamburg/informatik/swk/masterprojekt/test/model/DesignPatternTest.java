package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPattern;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPattern}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class DesignPatternTest
{
    private DesignPattern designPattern1;
    private DesignPattern designPattern2;
    private DesignPattern designPattern3;

    /**
     * Creates three DesignPatterns. DesignPattern 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        designPattern1 = new DesignPattern();
        designPattern2 = new DesignPattern();
        designPattern3 = new DesignPattern();

        designPattern1.setId(1L);
        designPattern2.setId(1L);
        designPattern3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testDesignPatternToString()
    {
        System.out.println(designPattern1.toString());
    }

    /**
     * Tests the hashCode functionality of a DesignPattern, should only be
     * affected by Id.
     */
    @Test
    public void testDesignPatternHashcode()
    {
        designPattern1.setShortDescription("1");
        designPattern2.setShortDescription("2");
        assertTrue(designPattern1.hashCode() == designPattern1.hashCode());
        assertTrue(designPattern1.hashCode() == designPattern2.hashCode());
        assertFalse(designPattern2.hashCode() == designPattern3.hashCode());
    }

    /**
     * Tests the equals functionality of a DesignPattern, should only be
     * affected by Id.
     */
    @Test
    public void testDesignPatternEquals()
    {
        designPattern1.setShortDescription("1");
        designPattern2.setShortDescription("2");
        assertTrue(designPattern1.equals(designPattern1));
        assertFalse(designPattern1.equals(null));
        assertFalse(designPattern1.equals(new String()));
        assertTrue(designPattern1.equals(designPattern2));
        assertFalse(designPattern1.equals(designPattern3));
    }
}