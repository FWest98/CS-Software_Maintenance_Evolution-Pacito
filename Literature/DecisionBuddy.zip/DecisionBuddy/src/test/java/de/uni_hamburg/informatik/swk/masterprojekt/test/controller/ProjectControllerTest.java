package de.uni_hamburg.informatik.swk.masterprojekt.test.controller;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ControllerTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.IssueService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Unit test for Project controller.
 * 
 * @author Vlad, schaak
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ControllerTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ControllerTesting")
public class ProjectControllerTest
{
    private MockMvc                 mockMvc;

    @Autowired
    private WebApplicationContext   webApplicationContext;

    @Autowired
    private ProjectService          projectServiceMock;

    @Autowired
    private IssueService            issueServiceMock;

    private ArgumentCaptor<Project> projectArgumentCaptor;
    private ArgumentCaptor<Issue>   issueArgumentCaptor;

    private List<Project>           projectList;
    private List<Issue>             issueList;

    // dummy projects
    private Project                 dummyProject1;
    private Project                 dummyProject2;

    // dummy issues
    private Issue                   dummyIssue1;

    /**
     * Set-up method. Executes before every test.
     * 
     * @throws ProjectPersistenceException
     *             project can ot be saved
     * @throws ProjectNotFoundException
     *             project cannot be found
     * @throws IssuePersistenceException
     *             issue cannot be saved
     * @throws IssueNotFoundException
     *             issue cannot be found
     */
    @Before
    public void setUp() throws ProjectPersistenceException, ProjectNotFoundException,
            IssuePersistenceException, IssueNotFoundException, CommentPersistenceException
    {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

        projectArgumentCaptor = ArgumentCaptor.forClass(Project.class);
        issueArgumentCaptor = ArgumentCaptor.forClass(Issue.class);

        projectList = new ArrayList<Project>();
        issueList = new ArrayList<Issue>();

        // Create dummy projects and issues
        dummyProject1 = createDummyProject(1L);
        projectList.add(dummyProject1);
        dummyProject2 = createDummyProject(2L);
        projectList.add(dummyProject2);
        dummyIssue1 = createDummyIssue(1L, dummyProject1);
        issueList.add(dummyIssue1);

        // Return dummy projects when service is called
        Mockito.when(projectServiceMock.getProjectsByCriteria(
                org.mockito.Matchers.<Filter<Project>> any(),
                org.mockito.Matchers.<Comparator<Project>> any())).thenReturn(projectList);

        Mockito.when(projectServiceMock.getProjectById(1)).thenReturn(dummyProject1);
        Mockito.when(projectServiceMock.getProjectById(2)).thenReturn(dummyProject2);
        Mockito.when(issueServiceMock.getIssueById(1)).thenReturn(dummyIssue1);
        Mockito.when(issueServiceMock.getIssuesByProjectID(Long.valueOf("1")))
                .thenReturn(issueList);

        Mockito.when(projectServiceMock.saveProject(org.mockito.Matchers.<Project> any()))
                .thenReturn(dummyProject1);

        Mockito.when(issueServiceMock.saveIssue(org.mockito.Matchers.<Issue> any()))
                .thenReturn(dummyIssue1);
    }

    /**
     * Reset mock for ProjectService & IssueService after every test.
     * 
     */
    @After
    public void resetMock()
    {
        Mockito.reset(projectServiceMock);
        Mockito.reset(issueServiceMock);
    }

    /**
     * Tests if all pre populated model attributes are available.
     * 
     * @param resultActions
     *            the resultActions object
     * 
     * @throws Exception
     *             exception on method call
     */
    public void testPrePopulatedValues(ResultActions resultActions) throws Exception
    {
        // check all pre populated model values
        resultActions.andExpect(model().attribute("activeview", "project"));
        resultActions.andExpect(model().attribute("controlbar", notNullValue()));
        resultActions.andExpect(model().attribute("technicalterms", notNullValue()));
        resultActions.andExpect(model().attribute("constraintcomparators", notNullValue()));
    }

    /**
     * Tests the correct controller behavior for listing projects without
     * arguments for pagination, sorting etc.
     * 
     * @throws Exception
     *             an exception that method has failed
     */
    @Test
    public void testListOfProjects() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/list"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(1)));
        resultActions.andExpect(model().attribute("menu", hasSize(1)));
        resultActions.andExpect(model().attribute("jsp", is("projects")));
        resultActions.andExpect(model().attribute("pagedListHolder", notNullValue()));
        resultActions.andExpect(model().attribute("projectlist", hasSize(2)));
        testPrePopulatedValues(resultActions);

        String projectlist = "projectlist";

        // inspect list
        resultActions.andExpect(model().attribute(projectlist, hasItem(hasProperty("id", is(1L)))));
        resultActions.andExpect(model().attribute(projectlist,
                hasItem(hasProperty("name", is("ControllerTestProject")))));
        resultActions.andExpect(model().attribute(projectlist,
                hasItem(hasProperty("description", is("A project!")))));

        // guarantee that service method getProjectsByCriteria has exactly been
        // called once
        Mockito.verify(projectServiceMock, times(1)).getProjectsByCriteria(
                org.mockito.Matchers.<Filter<Project>> any(),
                org.mockito.Matchers.<Comparator<Project>> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests the profile view of a project.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testProjectProfile() throws Exception
    {

        ResultActions resultActions = mockMvc.perform(get("/project/project/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(5)));
        resultActions.andExpect(model().attribute("jsp", is("addproject")));
        resultActions.andExpect(model().attribute("viewmode", is("view")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(
                model().attribute("project", allOf(hasProperty("name", is("ControllerTestProject")),
                        hasProperty("description", is("A project!")))));

        String issuelist = "issuelist";

        // inspect list
        resultActions.andExpect(model().attribute(issuelist, hasItem(hasProperty("id", is(1L)))));
        resultActions.andExpect(
                model().attribute(issuelist, hasItem(hasProperty("name", is("issue!")))));
        resultActions.andExpect(model().attribute(issuelist,
                hasItem(hasProperty("description", is("need a solution")))));

        // guarantee that service method getProjectById has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that service method getIssuesByProjectID has exactly been
        // called once
        Mockito.verify(issueServiceMock, times(1)).getIssuesByProjectID(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /******************************************************************
     * 
     * ADD PROJECT
     * 
     *****************************************************************/

    /**
     * Tests the view for adding a new project..
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddProjectPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/add"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addproject")));
        resultActions.andExpect(model().attribute("viewmode", is("add")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("project", notNullValue()));
        resultActions.andExpect(model().attribute("project", instanceOf(Project.class)));

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests adding a valid Project using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddingValidProject() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/project/add")
                .param("id", "3").param("name", "MinProject").param("description", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/project/add"));
        resultActions.andExpect(redirectedUrl("/project/add"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveProject has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).saveProject(projectArgumentCaptor.capture());

        // check properties of saved project
        assertEquals(Long.valueOf("3"), projectArgumentCaptor.getValue().getId());
        assertEquals("MinProject", projectArgumentCaptor.getValue().getName());
        assertEquals("Test", projectArgumentCaptor.getValue().getDescription());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests adding an invalid Project using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddingInvalidProject() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/project/add")
                .param("id", "3").param("description", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/project/add"));
        resultActions.andExpect(redirectedUrl("/project/add"));

        // Check binding result
        resultActions.andExpect(flash().attribute("project", notNullValue()));
        resultActions.andExpect(
                flash().attributeExists("org.springframework.validation.BindingResult.project"));

        // guarantee that service method saveProject has never been called
        Mockito.verify(projectServiceMock, times(0))
                .saveProject(org.mockito.Matchers.<Project> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /******************************************************************
     * 
     * EDIT PROJECT
     * 
     *****************************************************************/

    /**
     * Tests the view for editing a project..
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditProjectPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/edit/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addproject")));
        resultActions.andExpect(model().attribute("viewmode", is("edit")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("project", notNullValue()));
        resultActions.andExpect(model().attribute("project", instanceOf(Project.class)));

        // guarantee that service method saveProject has never been called
        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests editing a Project in a valid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingProjectValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/project/edit")
                .param("id", "3").param("name", "MinProject").param("description", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/project/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/project/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));
        resultActions.andExpect(flash().attribute("issuelist", notNullValue()));

        // guarantee that service method saveProject has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).saveProject(projectArgumentCaptor.capture());

        // check properties of saved project
        assertEquals(Long.valueOf("3"), projectArgumentCaptor.getValue().getId());

        assertEquals("MinProject", projectArgumentCaptor.getValue().getName());
        assertEquals("Test", projectArgumentCaptor.getValue().getDescription());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests editing an invalid Project using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingInvalidProject() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/project/edit")
                .param("id", "3").param("description", "Test"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/project/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/project/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("project", notNullValue()));
        resultActions.andExpect(
                flash().attributeExists("org.springframework.validation.BindingResult.project"));

        // guarantee that service method saveProject has never been called
        Mockito.verify(projectServiceMock, times(0))
                .saveProject(org.mockito.Matchers.<Project> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests editing a Project inline in a valid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingProjectInlineValid() throws Exception
    {
        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/project/editinline").param("id", "3")
                        .param("name", "MinProject").param("description", "Test"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("success")));

        // guarantee that service method saveProject has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).saveProject(projectArgumentCaptor.capture());

        // check properties of saved project
        assertEquals(Long.valueOf("3"), projectArgumentCaptor.getValue().getId());
        assertEquals("MinProject", projectArgumentCaptor.getValue().getName());
        assertEquals("Test", projectArgumentCaptor.getValue().getDescription());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests editing a Project inline in an invalid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingProjectInlineInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders
                .post("/project/editinline").param("id", "3").param("description", "Test"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("failure")));

        // guarantee that service method saveProject has never been called
        Mockito.verify(projectServiceMock, times(0))
                .saveProject(org.mockito.Matchers.<Project> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /******************************************************************
     * 
     * DELETE PROJECT
     * 
     *****************************************************************/

    /**
     * Tests the view for deleting a project.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testDeleteProjectPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/delete/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addproject")));
        resultActions.andExpect(model().attribute("viewmode", is("delete")));
        resultActions.andExpect(model().attributeExists("issuelist"));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("project", notNullValue()));
        resultActions.andExpect(model().attribute("project", instanceOf(Project.class)));
    }

    /**
     * Tests deleting a Project using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testDeletingProject() throws Exception
    {
        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/project/delete/3"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/project/list"));
        resultActions.andExpect(redirectedUrl("/project/list"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method deleteProject has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).deleteProject(org.mockito.Matchers.anyInt());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests the profile view of an issue.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testIssueProfile() throws Exception
    {

        ResultActions resultActions = mockMvc.perform(get("/project/project/1/issue/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(4)));
        resultActions.andExpect(model().attribute("jsp", is("addissue")));
        resultActions.andExpect(model().attribute("viewmode", is("view")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("issue", allOf(hasProperty("name", is("issue!")),
                hasProperty("description", is("need a solution")))));

        // String solutionlist = "solutionlist";

        // guarantee that service method getProjectById has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that service method getIssueById has exactly been called
        // once
        Mockito.verify(issueServiceMock, times(1)).getIssueById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);

    }

    /**
     * Tests the profile view for an issue if type mismatch occurs.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testIssueProfileTypeMismatch() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/project/2/issue/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("jsp", is("error")));
        resultActions.andExpect(model().attribute("exceptionType", is("issueprojectmismatch")));

        // guarantee that service method getProjectById has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).getProjectById(2);

        // guarantee that service method getIssueById has exactly been called
        // once
        Mockito.verify(issueServiceMock, times(1)).getIssueById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /******************************************************************
     * 
     * ADD ISSUE
     * 
     *****************************************************************/

    /**
     * Tests the view for adding a new issue.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddIssuePage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/project/1/issue/add"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addissue")));
        resultActions.andExpect(model().attribute("viewmode", is("add")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("issue", notNullValue()));
        resultActions.andExpect(model().attribute("issue", instanceOf(Issue.class)));

        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
    }

    /**
     * Tests adding a valid Issue using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddingValidIssue() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(
                MockMvcRequestBuilders.post("/project/project/1/issue/add").param("id", "3")
                        .param("name", "IssueOne").param("description", "An issue."));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/project/project/{projectId}/issue/add"));
        resultActions.andExpect(redirectedUrl("/project/project/1/issue/add"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveIssue has exactly been called once
        Mockito.verify(issueServiceMock, times(1)).saveIssue(issueArgumentCaptor.capture());

        // check properties of saved issue
        assertEquals(Long.valueOf("3"), issueArgumentCaptor.getValue().getId());
        assertEquals("IssueOne", issueArgumentCaptor.getValue().getName());
        assertEquals("An issue.", issueArgumentCaptor.getValue().getDescription());

        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /**
     * Tests adding an invalid Issue using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddingInvalidIssue() throws Exception
    {
        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/project/project/1/issue/add")
                        .param("id", "3").param("description", "An issue."));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/project/project/{projectId}/issue/add"));
        resultActions.andExpect(redirectedUrl("/project/project/1/issue/add"));

        // Check binding result
        resultActions.andExpect(flash().attribute("issue", notNullValue()));
        resultActions.andExpect(
                flash().attributeExists("org.springframework.validation.BindingResult.issue"));

        // guarantee that service method saveIssue has never been called
        Mockito.verify(issueServiceMock, times(0)).saveIssue(org.mockito.Matchers.<Issue> any());

        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /******************************************************************
     * 
     * EDIT ISSUE
     * 
     *****************************************************************/

    /**
     * Tests the view for editing an issue..
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditIssuePage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/project/1/issue/edit/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(4)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addissue")));
        resultActions.andExpect(model().attribute("viewmode", is("edit")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("issue", notNullValue()));
        resultActions.andExpect(model().attribute("issue", instanceOf(Issue.class)));

        // guarantee that service method saveIssue has never been called
        Mockito.verify(issueServiceMock, times(1)).getIssueById(1);

        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /**
     * Tests editing an Issue in a valid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingIssueValid() throws Exception
    {

        ResultActions resultActions = mockMvc.perform(
                MockMvcRequestBuilders.post("/project/project/1/issue/edit").param("id", "3")
                        .param("name", "IssueOne").param("description", "An issue."));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions
                .andExpect(view().name("redirect:/project/project/{projectId}/issue/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/project/project/1/issue/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveIssue has exactly been called once
        Mockito.verify(issueServiceMock, times(1)).saveIssue(issueArgumentCaptor.capture());

        // check properties of saved issue
        assertEquals(Long.valueOf("3"), issueArgumentCaptor.getValue().getId());
        assertEquals("IssueOne", issueArgumentCaptor.getValue().getName());
        assertEquals("An issue.", issueArgumentCaptor.getValue().getDescription());

        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /**
     * Tests editing an Issue in an invalid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingIssueInvalid() throws Exception
    {

        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/project/project/1/issue/edit")
                        .param("id", "3").param("description", "An issue."));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions
                .andExpect(view().name("redirect:/project/project/{projectId}/issue/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/project/project/1/issue/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("issue", notNullValue()));
        resultActions.andExpect(
                flash().attributeExists("org.springframework.validation.BindingResult.issue"));

        // guarantee that service method saveIssue has never been called
        Mockito.verify(issueServiceMock, times(0)).saveIssue((org.mockito.Matchers.<Issue> any()));

        Mockito.verify(projectServiceMock, times(1)).getProjectById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /**
     * Tests editing an Issue inline in a valid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingIssueInlineValid() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(
                MockMvcRequestBuilders.post("/project/project/1/issue/editinline").param("id", "3")
                        .param("name", "IssueOne").param("description", "An issue."));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("success")));

        // guarantee that service method saveIssue has exactly been called once
        Mockito.verify(issueServiceMock, times(1)).saveIssue(issueArgumentCaptor.capture());

        // check properties of saved issue
        assertEquals(Long.valueOf("3"), issueArgumentCaptor.getValue().getId());
        assertEquals("IssueOne", issueArgumentCaptor.getValue().getName());
        assertEquals("An issue.", issueArgumentCaptor.getValue().getDescription());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /**
     * Tests editing an Issue inline in an invalid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingIssueInlineInvalid() throws Exception
    {
        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/project/project/1/issue/editinline")
                        .param("id", "3").param("description", "An issue."));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("failure")));

        // guarantee that service method saveIssue has never been called
        Mockito.verify(issueServiceMock, times(0)).saveIssue(org.mockito.Matchers.<Issue> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /******************************************************************
     * 
     * DELETE ISSUE
     * 
     *****************************************************************/

    /**
     * Tests the view for deleting an Issue.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testDeleteIssuePage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/project/1/issue/delete/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(4)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addissue")));
        resultActions.andExpect(model().attribute("viewmode", is("delete")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("issue", notNullValue()));
        resultActions.andExpect(model().attribute("issue", instanceOf(Issue.class)));
    }

    /**
     * Tests the view for deleting an issue if type mismatch occurs.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testDeleteIssuePageTypeMismatch() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/project/project/2/issue/delete/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("jsp", is("error")));
        resultActions.andExpect(model().attribute("exceptionType", is("issueprojectmismatch")));

        // guarantee that service method getProjectById has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).getProjectById(2);

        // guarantee that service method getIssueById has exactly been called
        // once
        Mockito.verify(issueServiceMock, times(1)).getIssueById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /**
     * Tests deleting an Issue using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testDeletingIssue() throws Exception
    {
        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/project/project/1/issue/delete/1"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/project/project/{projectId}"));
        resultActions.andExpect(redirectedUrl("/project/project/1"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method deleteIssue has exactly been called
        // once
        Mockito.verify(issueServiceMock, times(1)).deleteIssue(org.mockito.Matchers.anyInt());

        Mockito.verify(issueServiceMock, times(1)).getIssueById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /**
     * Tests deleting an Issue using a POST-method if type mismatch occurs.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testDeletingIssueTypeMismatch() throws Exception
    {
        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/project/project/2/issue/delete/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("jsp", is("error")));
        resultActions.andExpect(model().attribute("exceptionType", is("issueprojectmismatch")));

        // guarantee that service method getProjectById has exactly been called
        // once
        Mockito.verify(projectServiceMock, times(1)).getProjectById(2);

        // guarantee that service method getIssueById has exactly been called
        // once
        Mockito.verify(issueServiceMock, times(1)).getIssueById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(projectServiceMock);
        Mockito.verifyNoMoreInteractions(issueServiceMock);
    }

    /******************************************************************
     * 
     * METHODS TO CREATE DUMMY DATA
     * 
     *****************************************************************/

    /**
     * Helper method to create dummy project.
     * 
     * @param fakeId
     *            the id for the dummy object.
     * @return a populated Project object.
     */
    private Project createDummyProject(Long fakeId)
    {
        Project project = new Project();
        project.setId(fakeId);
        project.setDescription("A project!");
        project.setCreationDate(new Date());
        project.setCreator("Vlad");
        project.setLastModifier("Vlad");
        project.setModificationDate(new Date());
        project.setName("ControllerTestProject");
        return project;
    }

    /**
     * Helper method to create dummy issue.
     * 
     * @param fakeId
     *            the id for the dummy object
     * @param project
     *            project, the issue belongs to
     * @return a populated issue object
     */
    private Issue createDummyIssue(Long fakeId, Project project)
    {
        Issue issue = new Issue();
        issue.setId(fakeId);
        issue.setProject(project);

        // other random values
        issue.setName("issue!");
        issue.setDescription("need a solution");
        project.setCreationDate(new Date());
        project.setCreator("Vlad");
        project.setLastModifier("Vlad");
        project.setModificationDate(new Date());
        return issue;
    }
}