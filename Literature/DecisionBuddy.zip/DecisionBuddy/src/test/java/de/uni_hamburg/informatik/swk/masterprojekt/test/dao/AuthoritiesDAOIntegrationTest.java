package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.AuthoritiesDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.UsersDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;

/**
 * 
 * @author 4biryuk
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class AuthoritiesDAOIntegrationTest
{
    @Autowired
    private AuthoritiesDAO      authoritiesDAO;

    @Autowired
    private UsersDAO            usersDAO;

    private static final String USERNAME1  = "vlad";

    private static final String ROLENAME1  = "ROLE_VLAD1";
    // private static final String ROLENAME2 = "ROLE_VLAD2";
    private static final String ROLENAME3  = "ROLE_VLAD3";

    private User                user       = new User();

    private Authority           authority1 = new Authority();
    private Authority           authority2 = new Authority();
    private Authority           authority3 = new Authority();

    private ArrayList<User>     users      = new ArrayList<User>();

    @Before
    public void setUp() throws Exception
    {
        user.setUsername(USERNAME1);
        user.setPassword("vlad");
        user.setEnabled(true);

        users.add(user);

        authority1.setAuthority(ROLENAME1);
        authority2.setAuthority(ROLENAME1);
        authority3.setAuthority(ROLENAME3);

    }

    @Test
    public void testSaveAuthority()
    {
        authoritiesDAO.saveAndFlush(authority1);
        assertEquals(authority1, authoritiesDAO.findOne(ROLENAME1));
        assertEquals(authority2, authoritiesDAO.findOne(ROLENAME1));
        assertNotEquals(authority3, ROLENAME1);
    }

    @Test
    public void testGetUsersByRole() throws Exception
    {
        authority1.setUsers(users);
        authoritiesDAO.saveAndFlush(authority1);
        assertNotNull(authoritiesDAO.findOne(ROLENAME1));
        assertNotNull(authoritiesDAO.findOne(ROLENAME1).getUsers());

        assertNotNull(usersDAO.findOne(USERNAME1));
        assertNotNull(usersDAO.findOne(USERNAME1).getAuthorities());
    }

    // Test for something that might be useful in future
    // @Test
    // public void testCountAuthoritiesByUsers() throws Exception
    // {
    // List<Object[]> listOfObjectArrays =
    // authoritiesDAO.findAuthoritiesByUsers();
    // for (Object[] objects : listOfObjectArrays)
    // {
    // String rolename = (String) objects[0];
    // BigInteger usage = (BigInteger) objects[1];
    // System.out.println(rolename);
    // System.out.println(usage);
    // }
    // }
}
