package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.ProjectValidator;

/**
 * Test class for ProjectValidator.
 * 
 * @author Tim
 *
 */

public class ProjectValidatorTest
{
    private Project testProject;
    private ProjectValidator testProjectValidator;

    /**
     * Setup method for project validator. Called before each test method.
     * Creates a valid Project.
     * 
     * @throws Exception excep
     */
    @Before
    public void setUp() throws Exception
    {
        testProject = new Project();
        testProject.setId(1L);
        testProject.setName("test");
        testProject.setCreator("Tim");
        testProject.setCreationDate(new Date());
        testProjectValidator = new ProjectValidator();
    }

    /**
     * Test method for default project created in setUp(), if this fails the
     * other tests can't work properly.
     */
    @Test
    public void setUpValid()
    {
        Errors errors;
        errors = new BeanPropertyBindingResult(testProject, "validProject");
        testProjectValidator.validate(testProject, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method with missing mandatory field name.
     */
    @Test
    public void missingMandatoryField()
    {
        testProject = new Project();
        testProject.setId(1L);
        testProject.setCreator("Tim");
        testProject.setCreationDate(new Date());
        Errors errors;
        errors = new BeanPropertyBindingResult(testProject, "validProject");
        testProjectValidator.validate(testProject, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a name which exceeds the character limit.
     */
    @Test
    public void nameTooLong()
    {
        Errors errors;
        testProject.setName("fdsafsdafsadfsdafdsafsadfsadfsdafsdafsdafsdafsdafskdjhasfdkj"
                + "hsadjkfhjadskfhjskadhflskajdfhsdjklahfkjsdahfjldksafhjdsklfhdsjkfhsdkjlfhsdakjflhsdfakjl"
                + "fasdjhfsdalkjfasdkfasdjfsdfdjasjksdfahjasdfkjfsdajasdfkljfdsalkjfsdafsadkjsfadhfdasjkasdfdfsajlkt");
        errors = new BeanPropertyBindingResult(testProject, "validProject");
        testProjectValidator.validate(testProject, errors);
        assertTrue(errors.hasErrors());
    }

}
