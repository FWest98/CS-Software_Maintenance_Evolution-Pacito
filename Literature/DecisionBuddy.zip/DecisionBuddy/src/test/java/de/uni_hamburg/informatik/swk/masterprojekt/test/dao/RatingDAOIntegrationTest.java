package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.PropertyDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.QualityGoalDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RatingDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Property;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * Tests the RatingDAO and the real database.
 * 
 * @author Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class RatingDAOIntegrationTest
{
    @Autowired
    private RatingDAO ratingDAO;

    @Autowired
    private QualityGoalDAO qualityGoalDAO;

    @Autowired
    private PropertyDAO propertyDAO;

    @Autowired
    private FrameworkDAO frameworkDAO;

    private Property testProperty;
    private QualityGoal testQualityGoal1;
    private QualityGoal testQualityGoal2;

    private Framework testSolution1;
    private Framework testSolution2;

    /**
     * Creates test projects and issues.
     */
    @Before
    public void setUp()
    {
        testProperty = propertyDAO.findOne(1L);
        assertNotNull(testProperty);

        testQualityGoal1 = qualityGoalDAO.findOne(1L);
        assertNotNull(testQualityGoal1);

        testQualityGoal2 = qualityGoalDAO.findOne(2L);
        assertNotNull(testQualityGoal2);

        testSolution1 = new Framework();
        testSolution1.setName("Test");
        testSolution1.setShortDescription("test");
        testSolution1.setCreator("Tim");
        testSolution1.setCreationDate(new Date());
        testSolution1 = frameworkDAO.saveAndFlush(testSolution1);
        assertNotNull(testSolution1);

        testSolution2 = new Framework();
        testSolution2.setName("Test2");
        testSolution2.setShortDescription("test");
        testSolution2.setCreator("Tim");
        testSolution2.setCreationDate(new Date());
        testSolution2 = frameworkDAO.saveAndFlush(testSolution2);
        assertNotNull(testSolution2);
    }

    /**
     * Create a new rating for a solution.
     * 
     * @param solution that is rated
     * @return new rating
     */
    public Rating getTestRating(Solution solution)
    {
        Rating rating = new Rating();
        rating.setSolution(solution);
        rating.setCreator("Tim");
        rating.setCreationDate(new Date());
        rating.setReasoning("Reasons.");
        rating.setRating("great");
        return rating;
    }

    /**
     * Test if a Rating for a QualityGoal can be created and saved in the
     * database.
     */
    @Test
    public void testSaveQualityGoalRatingInDB()
    {
        Rating rating = getTestRating(testSolution1);
        rating.setQualityGoal(testQualityGoal1);
        assertNull(rating.getId());
        rating = ratingDAO.saveAndFlush(rating);
        assertNotNull(rating.getId());
        assertTrue(rating.getId() > 0);
    }

    /**
     * Test if a Rating for a QualityGoal can be created and saved in the
     * database.
     */
    @Test
    public void testSavePropertyRatingInDB()
    {
        Rating rating = getTestRating(testSolution1);
        rating.setProperty(testProperty);
        assertNull(rating.getId());
        rating = ratingDAO.saveAndFlush(rating);
        assertNotNull(rating.getId());
        assertTrue(rating.getId() > 0);
    }

    /**
     * Test if a Rating can be deleted from the database.
     */
    @Test
    public void testDeleteRatingFromDB()
    {
        // Create and save a new Rating.
        Rating rating = getTestRating(testSolution1);
        rating.setQualityGoal(testQualityGoal1);
        assertNull(rating.getId());
        rating = ratingDAO.saveAndFlush(rating);
        assertNotNull(rating.getId());
        assertTrue(rating.getId() > 0);

        // Delete Rating from DB.
        ratingDAO.delete(rating);
        ratingDAO.flush();

        // Make sure it is deleted.
        rating = ratingDAO.findOne(rating.getId());
        assertNull(rating);
    }

    /**
     * Test if the right Ratings for a Solution can be found.
     */
    @Test
    public void testFindAllRatingsForSolution()
    {
        // Create and save a new Ratings.
        Rating rating1 = getTestRating(testSolution1);
        rating1.setQualityGoal(testQualityGoal1);
        assertNull(rating1.getId());
        rating1 = ratingDAO.saveAndFlush(rating1);
        assertNotNull(rating1.getId());
        assertTrue(rating1.getId() > 0);

        Rating rating2 = getTestRating(testSolution1);
        rating2.setQualityGoal(testQualityGoal1);
        assertNull(rating2.getId());
        rating2 = ratingDAO.saveAndFlush(rating2);
        assertNotNull(rating2.getId());
        assertTrue(rating2.getId() > 0);

        Rating rating3 = getTestRating(testSolution2);
        rating3.setQualityGoal(testQualityGoal1);
        assertNull(rating3.getId());
        rating3 = ratingDAO.saveAndFlush(rating3);
        assertNotNull(rating3.getId());
        assertTrue(rating3.getId() > 0);

        // Load the Ratings for the two Solutions by ID.
        List<Rating> solution1Rating = ratingDAO.findBySolution(testSolution1);
        List<Rating> solution2Rating = ratingDAO.findBySolution(testSolution2);

        // Make sure the right Ratings are found.
        assertTrue(solution1Rating.contains(rating1));
        assertTrue(solution1Rating.contains(rating2));
        assertFalse(solution1Rating.contains(rating3));

        assertFalse(solution2Rating.contains(rating1));
        assertFalse(solution2Rating.contains(rating2));
        assertTrue(solution2Rating.contains(rating3));
    }

    /**
     * Test if the right Ratings for a Solution can be found by it's ID.
     */
    @Test
    public void testFindAllRatingsForSolutionById()
    {
        // Create and save a new Ratings.
        Rating rating1 = getTestRating(testSolution1);
        rating1.setQualityGoal(testQualityGoal1);
        assertNull(rating1.getId());
        rating1 = ratingDAO.saveAndFlush(rating1);
        assertNotNull(rating1.getId());
        assertTrue(rating1.getId() > 0);

        Rating rating2 = getTestRating(testSolution1);
        rating2.setQualityGoal(testQualityGoal1);
        assertNull(rating2.getId());
        rating2 = ratingDAO.saveAndFlush(rating2);
        assertNotNull(rating2.getId());
        assertTrue(rating2.getId() > 0);

        Rating rating3 = getTestRating(testSolution2);
        rating3.setQualityGoal(testQualityGoal1);
        assertNull(rating3.getId());
        rating3 = ratingDAO.saveAndFlush(rating3);
        assertNotNull(rating3.getId());
        assertTrue(rating3.getId() > 0);

        // Load the Ratings for the two Solutions by ID.
        List<Rating> solution1Rating = ratingDAO.findBySolutionId(testSolution1.getId());
        List<Rating> solution2Rating = ratingDAO.findBySolutionId(testSolution2.getId());

        // Make sure the right Ratings are found.
        assertTrue(solution1Rating.contains(rating1));
        assertTrue(solution1Rating.contains(rating2));
        assertFalse(solution1Rating.contains(rating3));

        assertFalse(solution2Rating.contains(rating1));
        assertFalse(solution2Rating.contains(rating2));
        assertTrue(solution2Rating.contains(rating3));
    }

    /**
     * Test if the right Ratings for a Solution can be found.
     */
    @Test
    public void testFindAllRatingsForSolutionAndQualityGoal()
    {
        // Create and save a new Ratings.
        Rating rating1 = getTestRating(testSolution1);
        rating1.setQualityGoal(testQualityGoal1);
        assertNull(rating1.getId());
        rating1 = ratingDAO.saveAndFlush(rating1);
        assertNotNull(rating1.getId());
        assertTrue(rating1.getId() > 0);

        Rating rating2 = getTestRating(testSolution1);
        rating2.setQualityGoal(testQualityGoal2);
        assertNull(rating2.getId());
        rating2 = ratingDAO.saveAndFlush(rating2);
        assertNotNull(rating2.getId());
        assertTrue(rating2.getId() > 0);

        Rating rating3 = getTestRating(testSolution2);
        rating3.setQualityGoal(testQualityGoal1);
        assertNull(rating3.getId());
        rating3 = ratingDAO.saveAndFlush(rating3);
        assertNotNull(rating3.getId());
        assertTrue(rating3.getId() > 0);

        // Load the Ratings for the two Solutions by ID.
        List<Rating> solution1Rating = ratingDAO.findBySolution(testSolution1);
        List<Rating> solution2Rating = ratingDAO.findBySolution(testSolution2);

        // Make sure the right Ratings are found.
        assertTrue(solution1Rating.contains(rating1));
        assertTrue(solution1Rating.contains(rating2));
        assertFalse(solution1Rating.contains(rating3));

        assertFalse(solution2Rating.contains(rating1));
        assertFalse(solution2Rating.contains(rating2));
        assertTrue(solution2Rating.contains(rating3));

        List<Rating> solutionRatingGoal1 = ratingDAO.findBySolutionAndQualityGoal(testSolution1, testQualityGoal1);
        List<Rating> solutionRatingGoal2 = ratingDAO.findBySolutionAndQualityGoal(testSolution1, testQualityGoal2);
        assertTrue(solutionRatingGoal1.contains(rating1));
        assertFalse(solutionRatingGoal1.contains(rating2));
        assertFalse(solutionRatingGoal1.contains(rating3));

        assertFalse(solutionRatingGoal2.contains(rating1));
        assertTrue(solutionRatingGoal2.contains(rating2));
        assertFalse(solutionRatingGoal1.contains(rating3));
    }
}