package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.fail;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectServiceImpl;

/**
 * Test class for ProjectService.
 * 
 * @author Lucas
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class ProjectServiceTest
{
    @Configuration
    static class ProjectServiceTestContextConfiguration
    {
        @Bean
        public ProjectService projectService()
        {
            return new ProjectServiceImpl();
        }

        @Bean
        public ProjectDAO projectDAO()
        {
            return Mockito.mock(ProjectDAO.class);
        }
    }

    @Autowired
    private ProjectService projectService;

    @Autowired
    private ProjectDAO projectDAO;

    @Before
    public void resetDAO()
    {
        Mockito.reset(projectDAO);
    }

    /**
     * Test method for addProject().
     */
    @Test
    public void testAddProject()
    {

        Project p = getTestProject();

        Mockito.when(projectDAO.saveAndFlush(p)).thenReturn(p);

        try
        {
            projectService.saveProject(p);
        }
        catch (ProjectPersistenceException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        Mockito.verify(projectDAO).saveAndFlush(p);
        Mockito.verifyNoMoreInteractions(projectDAO);
    }

    /**
     * Test method for deleteProject().
     */
    @Test
    public void testDeleteProject()
    {
        Project p = getTestProject();
        try
        {
            projectService.deleteProject(p.getId());
        }
        catch (ProjectNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        Mockito.verify(projectDAO).delete(p.getId());
        Mockito.verifyNoMoreInteractions(projectDAO);
    }

    /**
     * Test method for getProjectById().
     */
    @Test
    public void testGetProjectById()
    {
        Mockito.when(projectDAO.findOne(1L)).thenReturn(getTestProject());

        try
        {
            projectService.getProjectById(1L);
        }
        catch (ProjectNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        Mockito.verify(projectDAO).findOne(1L);
        Mockito.verifyNoMoreInteractions(projectDAO);
    }

    /**
     * Test method for getAllProjects().
     */
    @Test
    public void testGetAllProjects()
    {
        projectService.getAllProjects();
        Mockito.verify(projectDAO).findAll();
        Mockito.verifyNoMoreInteractions(projectDAO);
    }

    /**
     * Helper method to create a new Project.
     * 
     * @return a valid Project
     */
    private Project getTestProject()
    {
        Project p = new Project();
        p.setId(1L);
        p.setName("TestProject");
        p.setCreator("Lucas");
        p.setCreationDate(new Date());
        return p;
    }
}
