package de.uni_hamburg.informatik.swk.masterprojekt.test.controller;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ControllerTestConfig;

/**
 * Unit test for class HomeController.
 * 
 * @author schaak
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
// use test config file instead of app config
@ContextConfiguration(classes = { ControllerTestConfig.class })
@WebAppConfiguration
// Activating the test profile is necessary so the beans from TestConfig are
// used
@ActiveProfiles(profiles = "ControllerTesting")
public class HomeControllerTest
{
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    /**
     * Set-up method. Executes before every test.
     */
    @Before
    public void setUp()
    {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    /**
     * Tests the correct controller behavior showing the root page.
     * 
     * @throws Exception an exception that method has failed
     */
    @Test
    public void testRootPage() throws Exception
    {
        mockMvc.perform(get("/")).andExpect(status().isOk()).andExpect(view().name("index"))
                .andExpect(forwardedUrl("index")).andExpect(model().attribute("breadcrumbs", hasSize(1)))
                .andExpect(model().attribute("menu", hasSize(0)));

        mockMvc.perform(get("/home")).andExpect(status().isOk()).andExpect(view().name("index"))
                .andExpect(forwardedUrl("index")).andExpect(model().attribute("breadcrumbs", hasSize(1)))
                .andExpect(model().attribute("menu", hasSize(0)));
    }

}