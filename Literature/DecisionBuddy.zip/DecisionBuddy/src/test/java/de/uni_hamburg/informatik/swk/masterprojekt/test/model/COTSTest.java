package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class COTSTest
{
    private COTS cots1;
    private COTS cots2;
    private COTS cots3;

    /**
     * Creates three COTSs. COTS 1 and 2 should be equal and 3 different.
     */
    @Before
    public void setUp()
    {
        cots1 = new COTS();
        cots2 = new COTS();
        cots3 = new COTS();

        cots1.setId(1L);
        cots2.setId(1L);
        cots3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testCOTSToString()
    {
        System.out.println(cots1.toString());
    }

    /**
     * Tests the hashCode functionality of a COTS, should only be affected by
     * Id.
     */
    @Test
    public void testCOTSHashcode()
    {
        cots1.setShortDescription("1");
        cots2.setShortDescription("2");
        assertTrue(cots1.hashCode() == cots1.hashCode());
        assertTrue(cots1.hashCode() == cots2.hashCode());
        assertFalse(cots2.hashCode() == cots3.hashCode());
    }

    /**
     * Tests the equals functionality of a COTS, should only be affected by Id.
     */
    @Test
    public void testCOTSEquals()
    {
        cots1.setShortDescription("1");
        cots2.setShortDescription("2");
        assertTrue(cots1.equals(cots1));
        assertFalse(cots1.equals(null));
        assertFalse(cots1.equals(new String()));
        assertTrue(cots1.equals(cots2));
        assertFalse(cots1.equals(cots3));
    }
}