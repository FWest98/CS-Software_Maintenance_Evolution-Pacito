package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.PropertyDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Property;

/**
 * Tests the PropertyDAO and the real database.
 * 
 * @author Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class PropertyDAOIntegrationTest
{
    @Autowired
    private PropertyDAO propertyDAO;

    /**
     * Test if a Property can be created and saved in the database.
     */
    @Test
    public void testSavePropetylInDB()
    {
        Property property = new Property();
        property.setName("Test");
        assertNull(property.getId());

        property = propertyDAO.saveAndFlush(property);

        assertNotNull(property.getId());
        assertTrue(property.getId() > 0);
    }

    /**
     * Test if a Property can be deleted from the database.
     */
    @Test
    public void testDeletePropertyInDB()
    {
        // Load Property with ID 1 from DB and delete it
        Property property = propertyDAO.findOne(1L);
        assertNotNull(property);
        propertyDAO.delete(property);
        //propertyDAO.flush();

        // Make sure it is deleted.
        property = propertyDAO.findOne(1L);
        assertNull(property);
    }
}