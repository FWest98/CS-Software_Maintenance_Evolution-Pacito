package de.uni_hamburg.informatik.swk.masterprojekt.test.beans;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.MenuItem;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.MenuManager;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production.WebAppConfig;

/**
 * Tests to see if class MenuManager produces correct items.
 * 
 * @author schaak
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = WebAppConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MenuManagerTest
{
    private ArrayList<MenuItem> menu;

    @Autowired
    private MenuManager menuManager;

    // actions
    private static final String ACTION_HOME = "home";

    private static final String ACTION_SHOW_SOLUTIONS = "showsolutions";
    private static final String ACTION_SOLUTION_PROFILE = "solutionprofile";
    private static final String ACTION_ADD_SOLUTION = "addsolution";
    private static final String ACTION_EDIT_SOLUTION = "editsolution";
    private static final String ACTION_DELETE_SOLUTION = "deletesolution";

    private static final String ACTION_SHOW_PROJECTS = "showprojects";
    private static final String ACTION_PROJECT_PROFILE = "projectprofile";
    private static final String ACTION_ADD_PROJECT = "addproject";
    private static final String ACTION_EDIT_PROJECT = "editproject";
    private static final String ACTION_DELETE_PROJECT = "deleteproject";
    private static final String ACTION_ISSUE_PROFILE = "issueprofile";
    private static final String ACTION_ADD_ISSUE = "addissue";
    private static final String ACTION_EDIT_ISSUE = "editissue";
    private static final String ACTION_DELETE_ISSUE = "deleteissue";

    private static final String ACTION_SHOW_TECHNICALTERMS = "showtechnicalterms";
    private static final String ACTION_TECHNICALTERM_PROFILE = "technicaltermprofile";
    private static final String ACTION_ADD_TECHNICALTERM = "addtechnicalterm";
    private static final String ACTION_EDIT_TECHNICALTERM = "edittechnicalterm";
    private static final String ACTION_DELETE_TECHNICALTERM = "deletetechnicalterm";

    /**
     * Setup method to create an empty menu.
     */
    @Before
    public void initializeMenu()
    {
        menu = new ArrayList<MenuItem>();
    }

    /**
     * Tests the correct number of created Menu items.
     */
    @Test
    public void numberOfMenuItems()
    {

        ArrayList<String> list = new ArrayList<String>();
        list.add("5");
        list.add("15");

        // HOME
        menu = menuManager.getMenu(ACTION_HOME);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        // CATALOG
        menu = menuManager.getMenu(ACTION_SHOW_SOLUTIONS);
        assertEquals("number of created menu items is not correct.", 1, menu.size());

        menu = menuManager.getMenu(ACTION_SOLUTION_PROFILE, list);
        assertEquals("number of created menu items is not correct.", 4, menu.size());

        menu = menuManager.getMenu(ACTION_ADD_SOLUTION);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_EDIT_SOLUTION);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_DELETE_SOLUTION);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        // PROJECT
        menu = menuManager.getMenu(ACTION_SHOW_PROJECTS);
        assertEquals("number of created menu items is not correct.", 1, menu.size());

        menu = menuManager.getMenu(ACTION_PROJECT_PROFILE, list);
        assertEquals("number of created menu items is not correct.", 5, menu.size());

        menu = menuManager.getMenu(ACTION_ADD_PROJECT);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_EDIT_PROJECT);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_DELETE_PROJECT);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_ISSUE_PROFILE, list);
        assertEquals("number of created menu items is not correct.", 4, menu.size());

        menu = menuManager.getMenu(ACTION_ADD_ISSUE);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_EDIT_ISSUE);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_DELETE_ISSUE);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        // CONSTRAINT
        menu = menuManager.getMenu(ACTION_SHOW_TECHNICALTERMS);
        assertEquals("number of created menu items is not correct.", 1, menu.size());

        menu = menuManager.getMenu(ACTION_TECHNICALTERM_PROFILE, list);
        assertEquals("number of created menu items is not correct.", 3, menu.size());

        menu = menuManager.getMenu(ACTION_ADD_TECHNICALTERM);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_EDIT_TECHNICALTERM);
        assertEquals("number of created menu items is not correct.", 0, menu.size());

        menu = menuManager.getMenu(ACTION_DELETE_TECHNICALTERM);
        assertEquals("number of created menu items is not correct.", 0, menu.size());
    }

    /**
     * Tests the correct names of created Menu items.
     */
    @Test
    public void namesOfMenuItems()
    {
        ArrayList<String> list = new ArrayList<String>();
        list.add("5");
        list.add("15");

        // HOME
        menu = menuManager.getMenu(ACTION_HOME);
        assertTrue("menu has to be empty.", menu.isEmpty());

        // CATALOG
        menu = menuManager.getMenu(ACTION_SHOW_SOLUTIONS);
        assertEquals("name of menu item is incorrect.", "catalog.addsolution", menu.get(0).getName());

        menu = menuManager.getMenu(ACTION_SOLUTION_PROFILE, list);
        assertEquals("name of menu item is incorrect.", "catalog.addsolution", menu.get(0).getName());
        assertEquals("name of menu item is incorrect.", "catalog.editsolution", menu.get(1).getName());
        assertEquals("name of menu item is incorrect.", "catalog.deletesolution", menu.get(2).getName());

        menu = menuManager.getMenu(ACTION_ADD_SOLUTION);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_EDIT_SOLUTION);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_DELETE_SOLUTION);
        assertTrue("menu has to be empty.", menu.isEmpty());

        // PROJECT
        menu = menuManager.getMenu(ACTION_SHOW_PROJECTS);
        assertEquals("name of menu item is incorrect.", "project.addproject", menu.get(0).getName());

        menu = menuManager.getMenu(ACTION_PROJECT_PROFILE, list);
        assertEquals("name of menu item is incorrect.", "project.addproject", menu.get(0).getName());
        assertEquals("name of menu item is incorrect.", "project.addissue", menu.get(1).getName());
        assertEquals("name of menu item is incorrect.", "project.uploadad", menu.get(2).getName());
        assertEquals("name of menu item is incorrect.", "project.editproject", menu.get(3).getName());
        assertEquals("name of menu item is incorrect.", "project.deleteproject", menu.get(4).getName());

        menu = menuManager.getMenu(ACTION_ADD_PROJECT);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_EDIT_PROJECT);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_DELETE_PROJECT);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_ISSUE_PROFILE, list);
        assertEquals("name of menu item is incorrect.", "project.addissue", menu.get(0).getName());
        assertEquals("name of menu item is incorrect.", "project.editissue", menu.get(1).getName());
        assertEquals("name of menu item is incorrect.", "project.deleteissue", menu.get(2).getName());

        menu = menuManager.getMenu(ACTION_ADD_ISSUE);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_EDIT_ISSUE);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_DELETE_ISSUE);
        assertTrue("menu has to be empty.", menu.isEmpty());

        // CONSTRAINT
        menu = menuManager.getMenu(ACTION_SHOW_TECHNICALTERMS);
        assertEquals("name of menu item is incorrect.", "constraint.addtechnicalterm", menu.get(0).getName());

        menu = menuManager.getMenu(ACTION_TECHNICALTERM_PROFILE, list);
        assertEquals("name of menu item is incorrect.", "constraint.addtechnicalterm", menu.get(0).getName());
        assertEquals("name of menu item is incorrect.", "constraint.edittechnicalterm", menu.get(1).getName());
        assertEquals("name of menu item is incorrect.", "constraint.deletetechnicalterm", menu.get(2).getName());

        menu = menuManager.getMenu(ACTION_ADD_TECHNICALTERM);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_EDIT_TECHNICALTERM);
        assertTrue("menu has to be empty.", menu.isEmpty());

        menu = menuManager.getMenu(ACTION_DELETE_TECHNICALTERM);
        assertTrue("menu has to be empty.", menu.isEmpty());
    }
}