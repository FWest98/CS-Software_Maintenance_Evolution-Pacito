package de.uni_hamburg.informatik.swk.masterprojekt.test.validation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.DesignPatternValidator;

/**
 * Test class for DesignPatternValidator.
 * 
 * @author Tim
 *
 */

public class DesignPatternValidatorTest
{
    private DesignPattern testDesignPattern;
    private DesignPatternValidator testDesignPatternValidator;

    /**
     * Setup method for design pattern validator. Called before each test
     * method. Creates a valid DesignPattern.
     * 
     * @throws Exception excep
     */
    @Before
    public void setUp() throws Exception
    {
        testDesignPattern = new DesignPattern();
        testDesignPattern.setId(1L);
        testDesignPattern.setName("test");
        testDesignPattern.setDesignPatternCategory(new DesignPatternCategory());
        testDesignPattern.setShortDescription("test");
        testDesignPatternValidator = new DesignPatternValidator();
    }

    /**
     * Test method for default design pattern created in setUp(), if this fails
     * the other tests can't work properly.
     */
    @Test
    public void setUpValid()
    {
        Errors errors;
        errors = new BeanPropertyBindingResult(testDesignPattern, "validAddress");
        testDesignPatternValidator.validate(testDesignPattern, errors);
        assertFalse(errors.hasErrors());
    }

    /**
     * Test method for missing name.
     */
    @Test
    public void nameMissing()
    {
        Errors errors;
        testDesignPattern = new DesignPattern();
        testDesignPattern.setId(1L);
        testDesignPattern.setDesignPatternCategory(new DesignPatternCategory());
        testDesignPatternValidator = new DesignPatternValidator();
        errors = new BeanPropertyBindingResult(testDesignPattern, "validAddress");
        testDesignPatternValidator.validate(testDesignPattern, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for a wrong type.
     */
    @Test
    public void wrongType()
    {
        Errors errors;
        testDesignPattern.setType("Framework");
        errors = new BeanPropertyBindingResult(testDesignPattern, "validAddress");
        testDesignPatternValidator.validate(testDesignPattern, errors);
        assertTrue(errors.hasErrors());
    }

    /**
     * Test method for an altName1 which exceeds the character limit.
     */
    @Test
    public void nameTooLong()
    {
        Errors errors;
        testDesignPattern.setName("fdsafsdafsadfsdafdsafsadfsadfsdafsdafsdafsdafsdafskdjhasfdkj"
                + "hsadjkfhjadskfhjskadhflskajdfhsdjklahfkjsdahfjldksafhjdsklfhdsjkfhsdkjlfhsdakjflhsdfakjl"
                + "fasdjhfsdalkjfasdkfasdjfsdfdjasjksdfahjasdfkjfsdajasdfkljfdsalkjfsdafsadkjsfadhfdasjkasdfdfsajlkt");
        errors = new BeanPropertyBindingResult(testDesignPattern, "validAddress");
        testDesignPatternValidator.validate(testDesignPattern, errors);
        assertTrue(errors.hasErrors());
    }

}