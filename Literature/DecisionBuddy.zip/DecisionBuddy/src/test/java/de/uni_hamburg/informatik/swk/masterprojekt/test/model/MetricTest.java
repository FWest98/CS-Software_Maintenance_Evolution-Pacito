package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric}
 * class. This class contains no business logic and only toString(), hashCode() and equals()
 * methods are tested.
 * 
 * @author Burak
 *
 */
public class MetricTest
{
    private Metric metric1;
    private Metric metric2;
    private Metric metric3;

    /**
     * Creates three Metrics. Metric 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        metric1 = new Metric();
        metric2 = new Metric();
        metric3 = new Metric();

        metric1.setId(1L);
        metric2.setId(1L);
        metric3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testMetricToString()
    {
        System.out.println(metric1.toString());
    }

    /**
     * Tests the hashCode functionality of a Metric, should only be affected
     * by Id.
     */
    @Test
    public void testMetricHashcode()
    {
        metric1.setNameLangFile("Metric1 Lang File");
        metric2.setNameLangFile("Metric1 Lang File");
        assertTrue(metric1.hashCode() == metric1.hashCode());
        assertTrue(metric1.hashCode() == metric2.hashCode());
        assertFalse(metric2.hashCode() == metric3.hashCode());
        System.out.println(metric1.toString());
        System.out.println(metric2.toString());
        System.out.println(metric3.toString());
    }

    /**
     * Tests the equals functionality of a Metric, should only be affected by
     * Id.
     */
    @Test
    public void testMetricEquals()
    {
        assertTrue(metric1.equals(metric1));
        assertFalse(metric1.equals(null));
        assertFalse(metric1.equals(new String()));
        assertTrue(metric1.equals(metric2));
        assertFalse(metric1.equals(metric3));
    }
}