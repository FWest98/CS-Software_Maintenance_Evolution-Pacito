package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring}
 * class. This class contains no business logic and only toStrign(), hashCode()
 * methods are tested. equals()
 * 
 * @author Tim
 *
 */
public class RefactoringTest
{
    private Refactoring refactoring1;
    private Refactoring refactoring2;
    private Refactoring refactoring3;

    /**
     * Creates three Refactorings. Refactoring 1 and 2 should be equal and 3
     * different.
     */
    @Before
    public void setUp()
    {
        refactoring1 = new Refactoring();
        refactoring2 = new Refactoring();
        refactoring3 = new Refactoring();

        refactoring1.setId(1L);
        refactoring2.setId(1L);
        refactoring3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testRefactoringToString()
    {
        System.out.println(refactoring1.toString());
    }

    /**
     * Tests the hashCode functionality of a Refactoring, should only be
     * affected by Id.
     */
    @Test
    public void testRefactoringHashcode()
    {
        refactoring1.setShortDescription("1");
        refactoring2.setShortDescription("2");
        assertTrue(refactoring1.hashCode() == refactoring1.hashCode());
        assertTrue(refactoring1.hashCode() == refactoring2.hashCode());
        assertFalse(refactoring2.hashCode() == refactoring3.hashCode());
    }

    /**
     * Tests the equals functionality of a Refactoring, should only be affected
     * by Id.
     */
    @Test
    public void testRefactoringEquals()
    {
        refactoring1.setShortDescription("1");
        refactoring2.setShortDescription("2");
        assertTrue(refactoring1.equals(refactoring1));
        assertFalse(refactoring1.equals(null));
        assertFalse(refactoring1.equals(new String()));
        assertTrue(refactoring1.equals(refactoring2));
        assertFalse(refactoring1.equals(refactoring3));
    }
}