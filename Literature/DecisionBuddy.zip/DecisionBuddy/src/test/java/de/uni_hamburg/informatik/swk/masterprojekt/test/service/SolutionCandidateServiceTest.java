package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionCandidateDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate;

/**
 * Test class for SolutionCandidateService.
 * 
 * @author Lucas
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class SolutionCandidateServiceTest
{

    @Autowired
    private SolutionCandidateDAO solutionCandidateDAO;

    // @Autowired
    // private SolutionCandidateService solutionCandidateService;

    @Autowired
    private IssueDAO issueDAO;

    @Autowired
    private SolutionDAO solutionDAO;

    private SolutionCandidate candidate1;
    private Issue issue;
    private Solution solution;
    private List<Solution> allSolutions;

    /**
     * Creates test data.
     */
    @Before
    public void setUp()
    {
        Mockito.reset(issueDAO);
        Mockito.reset(solutionDAO);
        Mockito.reset(solutionCandidateDAO);

        Decision decision = new Decision();
        decision.setId(1L);
        decision.setDecided(false);

        Project testProject1 = new Project();
        testProject1.setId(1L);
        testProject1.setName("Masterprojekt");
        testProject1.setDescription("Our master project");
        testProject1.setCreator("Lucas");
        testProject1.setCreationDate(new Date());
        testProject1.setLastModifier("Lucas");
        testProject1.setModificationDate(new Date());

        issue = new Issue();
        issue.setId(1L);
        issue.setProject(testProject1);
        issue.setName("Issue1");
        issue.setDescription("Testissue 1");
        issue.setCreator("Lucas");
        issue.setCreationDate(new Date());
        issue.setLastModifier("Lucas");
        issue.setModificationDate(new Date());

        issue.setDecision(decision);
        decision.setIssue(issue);

        solution = new Framework();
        solution.setId(1L);
        solution.setName("Solution 1");
        solution.setCreationDate(new Date());
        solution.setModificationDate(new Date());
        solution.setShortDescription("A solution for tests");
        solution.setCreator("Lucas");
        solution.setLastModifier("Lucas");
        solution.setType("Framework");

        allSolutions = new ArrayList<Solution>();

        for (int i = 2; i <= 10; i++)
        {
            Solution tempSolution = new Framework();
            tempSolution.setId((long) i);
            tempSolution.setName("Solution " + i);
            tempSolution.setCreationDate(new Date());
            tempSolution.setModificationDate(new Date());
            tempSolution.setShortDescription("A solution for tests");
            tempSolution.setCreator("Lucas");
            tempSolution.setLastModifier("Lucas");
            tempSolution.setType("Framework");

            allSolutions.add(tempSolution);
        }

        candidate1 = new SolutionCandidate();
        candidate1.setId(1L);
        candidate1.setSolution(solution);
        candidate1.setDecision(issue.getDecision());
        candidate1.setCreationDate(new Date());
        candidate1.setModificationDate(new Date());
        candidate1.setCreator("Lucas");
        candidate1.setLastModifier(candidate1.getCreator());
        candidate1.setEvaluation("Ok.");

        decision.addSolutionCandidate(candidate1);
    }

    // dummy test method to fix error while running tests for now.........
    @Test
    public void testDummy()
    {
        assertEquals(true, true);
    }
}
