package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.IssueService;

/**
 * Test class for IssueService.
 * 
 * @author Lucas
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class IssueServiceTest
{

    private Issue testIssue1;
    private Issue testIssue2;
    private Issue testIssue3;
    private Project testProject1;
    private Project testProject2;

    @Autowired
    private IssueService issueService;

    @Autowired
    private IssueDAO issueDAO;

    @Autowired
    private ProjectDAO projectDAO;

    /**
     * Setup method for issue service. Called before each test method. Creates 3
     * test issues, 2 test projects and adds testIssue1 to issueService. Also
     * creates a new IssueService.
     * 
     * @throws Exception
     */
    @Before
    public void setUp() throws Exception
    {
        testProject1 = new Project();
        testProject1.setId(1L);
        testProject1.setName("Masterprojekt");
        testProject1.setDescription("Our Master project");
        testProject1.setCreator("Lucas");
        testProject1.setCreationDate(new Date());
        testProject1.setLastModifier("Lucas");
        testProject1.setModificationDate(new Date());

        testProject2 = new Project();
        testProject2.setId(2L);
        testProject2.setName("OtherProject");
        testProject2.setDescription("Another project");
        testProject2.setCreator("Lucas");
        testProject2.setCreationDate(new Date());
        testProject2.setLastModifier("Lucas");
        testProject2.setModificationDate(new Date());

        testIssue1 = new Issue();
        testIssue1.setId(1L);
        testIssue1.setProject(testProject1);
        testIssue1.setName("Issue1");
        testIssue1.setDescription("Testissue 1");
        testIssue1.setCreator("Lucas");
        testIssue1.setCreationDate(new Date());
        testIssue1.setLastModifier("Lucas");
        testIssue1.setModificationDate(new Date());

        testIssue2 = new Issue();
        testIssue2.setId(2L);
        testIssue2.setProject(testProject1);
        testIssue2.setName("Issue2");
        testIssue2.setDescription("Testissue 2");
        testIssue2.setCreator("Lucas");
        testIssue2.setCreationDate(new Date());
        testIssue2.setLastModifier("Lucas");
        testIssue2.setModificationDate(new Date());

        testIssue3 = new Issue();
        testIssue3.setId(3L);
        testIssue3.setProject(testProject2);
        testIssue3.setName("Issue3");
        testIssue3.setDescription("Testissue 3");
        testIssue3.setCreator("Lucas");
        testIssue3.setCreationDate(new Date());
        testIssue3.setLastModifier("Lucas");
        testIssue3.setModificationDate(new Date());

        Mockito.when(projectDAO.findOne(1L)).thenReturn(testProject1);
        Mockito.when(projectDAO.findOne(2L)).thenReturn(testProject2);

        Mockito.when(issueDAO.findOne(1L)).thenReturn(testIssue1);
        Mockito.when(issueDAO.findOne(2L)).thenReturn(testIssue2);
        Mockito.when(issueDAO.findOne(3L)).thenReturn(testIssue3);

    }

    /**
     * Test method for addIssue().
     */
    @Test
    public void testAddIssue() throws CommentPersistenceException
    {
        Mockito.when(issueDAO.saveAndFlush(testIssue2)).thenReturn(testIssue2);

        try
        {
            issueService.saveIssue(testIssue2);
        }
        catch (IssuePersistenceException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        Mockito.verify(issueDAO).saveAndFlush(testIssue2);
    }

    /**
     * Test method for getIssueByID().
     */
    @Test
    public void testGetIssueByID()
    {
        Mockito.when(issueDAO.findOne(testIssue1.getId())).thenReturn(testIssue1);
        try
        {
            assertEquals(testIssue1, issueService.getIssueById(testIssue1.getId()));
        }
        catch (IssueNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        Mockito.verify(issueDAO).findOne(testIssue1.getId());
    }

    /**
     * Test method for deleteIssue().
     */
    @Test
    public void testDeleteIssue()
    {
        try
        {
            issueService.deleteIssue((Long) testIssue1.getId());
        }
        catch (IssueNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        Mockito.verify(issueDAO).delete(testIssue1.getId());
    }

    /**
     * Test method for getIssuesByProjectID().
     */
    @Test
    public void testGetIssuesByProjectID()
    {
        List<Issue> issueList1 = new ArrayList<Issue>();
        List<Issue> issueList2 = new ArrayList<Issue>();
        issueList1.add(testIssue1);
        issueList1.add(testIssue2);
        System.out.println(issueList1.toString());
        issueList2.add(testIssue3);
        System.out.println(issueList2.toString());
        Mockito.when(issueDAO.findByProjectId(testProject1.getId())).thenReturn(issueList1);
        Mockito.when(issueDAO.findByProjectId(testProject2.getId())).thenReturn(issueList2);

        List<Issue> result1 = null;
        try
        {
            result1 = issueService.getIssuesByProjectID(testProject1.getId());
        }
        catch (ProjectNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        List<Issue> result2 = null;
        try
        {
            result2 = issueService.getIssuesByProjectID(testProject2.getId());
        }
        catch (ProjectNotFoundException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
        Mockito.verify(issueDAO).findByProjectId(testProject1.getId());

        if (result1 != null && result2 != null)
        {
            assertTrue(result1.contains(testIssue1));
            assertTrue(result2.contains(testIssue3));
            assertFalse(result2.contains(testIssue2));
            assertFalse(result1.contains(testIssue3));
        }
        else
        {
            fail("No issues found for that ProjectID");
        }
    }

    /*
     * TODO: Decisions and Comments not yet implemented
     * 
     * @Test public void testCommentOnDecision() { fail("Not yet implemented");
     * }
     */
}