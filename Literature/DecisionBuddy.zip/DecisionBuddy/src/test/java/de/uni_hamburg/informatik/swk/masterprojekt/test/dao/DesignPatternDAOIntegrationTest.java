package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DesignPatternCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DesignPatternDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;

/**
 * Tests the DesignPatternDAO and the real database.
 * 
 * @author Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class DesignPatternDAOIntegrationTest
{
    @Autowired
    private DesignPatternDAO designPatternDAO;

    @Autowired
    private DesignPatternCategoryDAO designPatternCategoryDAO;

    /**
     * Tests the creation of a design pattern.
     * 
     * @throws SQLException if blob conversion goes wrong
     * 
     */
    @Test
    public void testSaveDesignPattern() throws SQLException
    {
        DesignPattern designPattern = getTestDesignPattern();

        assertNull(designPattern.getId());

        designPattern = designPatternDAO.save(designPattern);

        assertNotNull(designPattern.getId());
        assertTrue(designPattern.getId() > 0);
    }

    /**
     * Used for testing the blob makes string a string of hex code to a byte
     * array.
     * 
     * @param s the string which will be converted to the byte array
     * @return returns the byte array
     */
    public static byte[] hexStringToByteArray(String s)
    {
        final int sixteen = 16;
        final int four = 4;
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2)
        {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), sixteen) << four) + Character.digit(s.charAt(i + 1),
                    sixteen));
        }
        return data;
    }

    /**
     * Tests the deletion of a design patterns.
     * 
     * @throws SQLException if blob conversion goes wrong
     */
    @Test
    public void testDeleteDesignPattern() throws SQLException
    {
        DesignPattern designPattern = getTestDesignPattern();

        assertNull(designPattern.getId());
        designPattern = designPatternDAO.save(designPattern);
        assertEquals(designPattern, designPatternDAO.getOne(designPattern.getId()));
        designPatternDAO.delete(designPattern);
        assertFalse(designPatternDAO.exists(designPattern.getId()));
    }

    /**
     * Tests the query for finding all design patterns in the DB.
     * 
     * @throws SQLException if blob conversion goes wrong
     */
    @Test
    public void testFindAllDesignPatterns() throws SQLException
    {
        // Get all DesignPatterns from the DB and create a new DesignPattern.
        List<DesignPattern> designPatternsDB = designPatternDAO.findAll();
        DesignPattern newDesignPattern = getTestDesignPattern();

        // Assert that the new Design Pattern has no ID and is not yet in the
        // DB.
        assertNull(newDesignPattern.getId());
        assertFalse(designPatternsDB.contains(newDesignPattern));

        // Save the new Design Pattern in the DB and assert it can be loaded.
        newDesignPattern = designPatternDAO.save(newDesignPattern);
        designPatternsDB = designPatternDAO.findAll();
        assertTrue(designPatternsDB.contains(newDesignPattern));
    }

    /**
     * Helper method to create a new DesignPattern.
     * 
     * @return A valid DesignPattern object
     * @throws SQLException if blob conversion goes wrong
     * @throws
     */
    private DesignPattern getTestDesignPattern() throws SQLException
    {
        DesignPatternCategory designPatternCategory = new DesignPatternCategory();
        designPatternCategory.setDescription("Test.");
        designPatternCategory.setName("Test");
        designPatternCategoryDAO.save(designPatternCategory);
        DesignPattern designPattern = new DesignPattern();
        designPattern.setDesignPatternCategory(designPatternCategory);
        designPattern.setName("Spring4");
        designPattern.setShortDescription("Useful framework to implement MVC architecture");
        designPattern.setCreator("Vlad");
        designPattern.setCreationDate(new Date());
        designPattern.setLastModifier("Abjdsklhdlfj");
        designPattern.setModificationDate(new Date());
        designPattern.setDesignPatternCategory(designPatternCategory);
        designPattern.setAltName1("a");
        designPattern.setAltName2("a");
        designPattern.setApplicability("all");
        designPattern.setCollaboration("much");
        designPattern.setConsequences("many");
        designPattern.setKnownUses("many");
        designPattern.setMotivation("fun");
        designPattern.setParticipants("many");
        designPattern.setRelatedPatterns("all");
        designPattern.setSampleCode("sample");
        designPattern.setStructure(new SerialBlob(hexStringToByteArray("e04fd020ea3a6910a2d808002b30309d")));
        designPattern.setImplementation("easy");
        return designPattern;
    }

}