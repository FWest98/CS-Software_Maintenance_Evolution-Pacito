package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.UsersDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.UserService;

/**
 * 
 * @author Vlad
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class UserServiceTest
{
    private static final String USERNAME1 = "user1";
    private static final String USERNAME2 = "user2";
    private static final String USERNAME3 = "user3";

    private static final String PASSWORD1 = "password1";
    private static final String PASSWORD2 = "password2";
    private static final String PASSWORD3 = "password3";

    private User                user1;
    private User                user2;
    private User                user3;

    private List<User>          userList;

    @Autowired
    private UserService         userService;

    @Autowired
    private UsersDAO            userDAO;

    @Before
    public void setUp() throws Exception
    {
        user1 = new User();
        user2 = new User();
        user3 = new User();

        user1.setUsername(USERNAME1);
        user1.setPassword(PASSWORD1);
        user1.setEnabled(true);

        user2.setUsername(USERNAME2);
        user2.setPassword(PASSWORD2);
        user2.setEnabled(true);

        user3.setUsername(USERNAME3);
        user3.setPassword(PASSWORD3);
        user3.setEnabled(true);

        userList = new ArrayList<User>();
        userList.add(user1);
        userList.add(user2);
        userList.add(user3);

        Mockito.when(userDAO.findOne(USERNAME1)).thenReturn(user1);
        Mockito.when(userDAO.findOne(USERNAME2)).thenReturn(user2);
        Mockito.when(userDAO.findOne(USERNAME3)).thenReturn(user3);

        Mockito.when(userDAO.saveAndFlush(user1)).thenReturn(user1);
        Mockito.when(userDAO.saveAndFlush(user2)).thenReturn(user2);
        Mockito.when(userDAO.saveAndFlush(user3)).thenReturn(user3);
    }

    @Test
    public void testAddUser()
    {
        // Mockito.when(userDAO.saveAndFlush(user1)).thenReturn(user1);
        try
        {
            userService.saveUser(user1);
        }
        catch (UserPersistenceException e)
        {
            System.out.println(e);
        }
        // Mockito.verify(userDAO).saveAndFlush(user1);
    }

    @Test
    public void testGetUserByUsername() throws UserNotFoundException
    {
        try
        {
            assertEquals(user1, userService.getUser(USERNAME1));
        }
        catch (UserNotFoundException e)
        {
            fail(e.toString());
        }
        // Mockito.verify(userDAO).findOne(user1.getUsername());
    }

    @Test
    public void testDeleteUser() throws Exception
    {
        try
        {
            userService.deleteUser(user1.getUsername());
        }
        catch (Exception e)
        {
            fail(e.toString());
        }
        // Mockito.verify(userDAO).delete(user1.getUsername());
    }

    @Test
    public void getAllUsers() throws Exception
    {
        try
        {
            List<User> userList = userService.getUsers();
            assertEquals(userList.size(), 0L);
            assertNotEquals(userList.size(), 1L);
        }
        catch (Exception e)
        {
            fail(e.toString());
        }
    }

    /**
     * Test if persisting a user with username that already exists fails. For
     * saving user with existing username call update method as it should still
     * be possible to edit existing users somehow.
     * 
     * @throws UserPersistenceException
     *             the exception
     */
    @Test(expected = UserPersistenceException.class)
    public void testPersistSameUserTwice() throws UserPersistenceException
    {
        userService.saveUser(user2);
        User newUser = new User();
        newUser.setUsername(USERNAME2);
        newUser.setPassword("alksdasgdlkh");
        newUser.setEnabled(true);
        userService.saveUser(newUser);
    }

    /**
     * Test if existing can be updated with update methot (not to be confused
     * with save method).
     * 
     * @throws Exception
     */
    @Test
    public void testEditExistingUser() throws Exception
    {
        user2.setPassword("asd");
        userService.editUser(user2);
        user2.setPassword("qwert");
        userService.editUser(user2);
        User foundUser = userService.getUser(USERNAME2);
        assertEquals("qwert", foundUser.getPassword());
    }

}
