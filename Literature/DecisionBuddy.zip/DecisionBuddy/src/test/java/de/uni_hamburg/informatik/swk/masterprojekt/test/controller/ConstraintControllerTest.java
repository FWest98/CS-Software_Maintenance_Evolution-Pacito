package de.uni_hamburg.informatik.swk.masterprojekt.test.controller;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.flash;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ControllerTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.StringValueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.StringValuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.TechnicalTermService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Unit test for Constraint controller.
 * 
 * @author schaak
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ControllerTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ControllerTesting")
public class ConstraintControllerTest
{
    private MockMvc                       mockMvc;

    @Autowired
    private WebApplicationContext         webApplicationContext;

    @Autowired
    private TechnicalTermService          technicalTermServiceMock;

    private ArgumentCaptor<TechnicalTerm> argumentCaptor;

    private List<TechnicalTerm>           technicalTermList;
    private List<StringValue>             stringValueList;

    // dummy technical terms
    private TechnicalTerm                 dummyTechnicalTerm1;
    private TechnicalTerm                 dummyTechnicalTerm2;

    // dummy string values
    private StringValue                   dummyStringValue1;

    /**
     * Set-up method. Executes before every test.
     * 
     * @throws TechnicalTermPersistenceException
     *             technicalTerm can ot be saved
     * @throws TechnicalTermNotFoundException
     *             technicalTerm cannot be found
     * @throws StringValuePersistenceException
     *             stringValue cannot be saved
     * @throws StringValueNotFoundException
     *             stringValue cannot be found
     * @throws SorterFieldNotFoundException
     *             exception if sorting field could not be found
     * @throws SorterInvalidTypeException
     *             exception if sorter has invalid type
     */
    @Before
    public void setUp() throws TechnicalTermPersistenceException, TechnicalTermNotFoundException,
            StringValuePersistenceException, StringValueNotFoundException,
            SorterInvalidTypeException, SorterFieldNotFoundException
    {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

        argumentCaptor = ArgumentCaptor.forClass(TechnicalTerm.class);

        technicalTermList = new ArrayList<TechnicalTerm>();
        stringValueList = new ArrayList<StringValue>();

        // Create dummy technicalTerms and stringValues
        dummyTechnicalTerm1 = createDummyTechnicalTerm(1L);
        dummyTechnicalTerm1.setRequiredBy("issue");
        dummyTechnicalTerm1.setDeliveredBy("solution");
        technicalTermList.add(dummyTechnicalTerm1);

        dummyTechnicalTerm2 = createDummyTechnicalTerm(2L);
        dummyTechnicalTerm2.setRequiredBy("solution");
        dummyTechnicalTerm2.setDeliveredBy("issue");
        technicalTermList.add(dummyTechnicalTerm2);

        dummyStringValue1 = createDummyStringValue(1L, dummyTechnicalTerm1);
        stringValueList.add(dummyStringValue1);

        // Return dummy technicalTerms when service is called
        Mockito.when(technicalTermServiceMock.getTechnicalTermsByCriteria(
                org.mockito.Matchers.<Filter<TechnicalTerm>> any(),
                org.mockito.Matchers.<Comparator<TechnicalTerm>> any()))
                .thenReturn(technicalTermList);

        Mockito.when(technicalTermServiceMock.getTechnicalTermById(1))
                .thenReturn(dummyTechnicalTerm1);
        Mockito.when(technicalTermServiceMock.getTechnicalTermById(2))
                .thenReturn(dummyTechnicalTerm2);

        Mockito.when(technicalTermServiceMock
                .saveTechnicalTerm(org.mockito.Matchers.<TechnicalTerm> any()))
                .thenReturn(dummyTechnicalTerm1);
    }

    /**
     * Reset mock for TechnicalTermService & StringValueService after every
     * test.
     * 
     */
    @After
    public void resetMock()
    {
        Mockito.reset(technicalTermServiceMock);
    }

    /**
     * Tests if all pre populated model attributes are available.
     * 
     * @param resultActions
     *            the resultActions object
     * 
     * @throws Exception
     *             exception on method call
     */
    public void testPrePopulatedValues(ResultActions resultActions) throws Exception
    {
        // check all pre populated model values
        resultActions.andExpect(model().attribute("activeview", "constraint"));
        resultActions.andExpect(model().attribute("controlbar", notNullValue()));
        resultActions.andExpect(model().attribute("technicaltermtypes", notNullValue()));
    }

    /**
     * Tests the correct controller behavior for listing technicalTerms without
     * arguments for pagination, sorting etc.
     * 
     * @throws Exception
     *             an exception that method has failed
     */
    @Test
    public void testListOfTechnicalTerms() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/constraint/list"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(1)));
        resultActions.andExpect(model().attribute("menu", hasSize(1)));
        resultActions.andExpect(model().attribute("jsp", is("technicalterms")));
        resultActions.andExpect(model().attribute("pagedListHolder", notNullValue()));
        resultActions.andExpect(model().attribute("technicaltermlist", hasSize(2)));
        testPrePopulatedValues(resultActions);

        String technicalTermlist = "technicaltermlist";

        // inspect list
        resultActions.andExpect(
                model().attribute(technicalTermlist, hasItem(hasProperty("id", is(1L)))));
        resultActions.andExpect(model().attribute(technicalTermlist,
                hasItem(hasProperty("identifier", is("ControllerTestTechnicalTerm")))));
        resultActions.andExpect(
                model().attribute(technicalTermlist, hasItem(hasProperty("unit", is("cm")))));

        // guarantee that service method getTechnicalTermsByCriteria has exactly
        // been called once
        Mockito.verify(technicalTermServiceMock, times(1)).getTechnicalTermsByCriteria(
                org.mockito.Matchers.<Filter<TechnicalTerm>> any(),
                org.mockito.Matchers.<Comparator<TechnicalTerm>> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /**
     * Tests the profile view of a technicalTerm.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testTechnicalTermProfile() throws Exception
    {

        ResultActions resultActions = mockMvc.perform(get("/constraint/technicalterm/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(3)));
        resultActions.andExpect(model().attribute("jsp", is("addtechnicalterm")));
        resultActions.andExpect(model().attribute("viewmode", is("view")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("technicalterm",
                allOf(hasProperty("identifier", is("ControllerTestTechnicalTerm")),
                        hasProperty("unit", is("cm")))));

        // String stringValuelist = "stringvaluelist";

        // guarantee that service method getTechnicalTermById has exactly been
        // called once
        Mockito.verify(technicalTermServiceMock, times(1)).getTechnicalTermById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /******************************************************************
     * 
     * ADD TECHNICALTERM
     * 
     *****************************************************************/

    /**
     * Tests the view for adding a new technicalTerm..
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddTechnicalTermPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/constraint/add"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(2)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addtechnicalterm")));
        resultActions.andExpect(model().attribute("viewmode", is("add")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("technicalterm", notNullValue()));
        resultActions
                .andExpect(model().attribute("technicalterm", instanceOf(TechnicalTerm.class)));

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /**
     * Tests adding a valid TechnicalTerm using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddingValidTechnicalTerm() throws Exception
    {
        String[] stringValueIds = { "1" };
        String[] stringValues = { "test" };

        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/constraint/add")
                .param("id", "3").param("identifier", "MinTechnicalTerm").param("unit", "cm")
                .param("stringvalue-id", stringValueIds)
                .param("stringvalue-stringvalue", stringValues));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/constraint/add"));
        resultActions.andExpect(redirectedUrl("/constraint/add"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveTechnicalTerm has exactly been
        // called once
        Mockito.verify(technicalTermServiceMock, times(1))
                .saveTechnicalTerm(argumentCaptor.capture());

        // check properties of saved technicalTerm
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("MinTechnicalTerm", argumentCaptor.getValue().getIdentifier());
        assertEquals("cm", argumentCaptor.getValue().getUnit());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /**
     * Tests adding an invalid TechnicalTerm using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testAddingInvalidTechnicalTerm() throws Exception
    {
        String[] stringValueIds = { "1" };
        String[] stringValues = { "test" };

        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/constraint/add")
                .param("id", "3").param("unit", "cm").param("stringvalue-id", stringValueIds)
                .param("stringvalue-stringvalue", stringValues));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/constraint/add"));
        resultActions.andExpect(redirectedUrl("/constraint/add"));

        // Check binding result
        resultActions.andExpect(flash().attribute("technicalterm", notNullValue()));
        resultActions.andExpect(flash()
                .attributeExists("org.springframework.validation.BindingResult.technicalterm"));

        // guarantee that service method saveTechnicalTerm has never been called
        Mockito.verify(technicalTermServiceMock, times(0))
                .saveTechnicalTerm(org.mockito.Matchers.<TechnicalTerm> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /******************************************************************
     * 
     * EDIT TECHNICAL TERM
     * 
     *****************************************************************/

    /**
     * Tests the view for editing a technicalTerm..
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditTechnicalTermPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/constraint/edit/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addtechnicalterm")));
        resultActions.andExpect(model().attribute("viewmode", is("edit")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("technicalterm", notNullValue()));
        resultActions
                .andExpect(model().attribute("technicalterm", instanceOf(TechnicalTerm.class)));

        // guarantee that service method getTechnicalTermById has been called
        // once
        Mockito.verify(technicalTermServiceMock, times(1)).getTechnicalTermById(1);

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /**
     * Tests editing a TechnicalTerm in a valid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingTechnicalTermValid() throws Exception
    {
        String[] stringValueIds = { "1" };
        String[] stringValues = { "test" };

        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders
                .post("/constraint/edit").param("id", "3").param("identifier", "MinTechnicalTerm")
                .param("unit", "cm").param("stringvalue-id", stringValueIds)
                .param("stringvalue-stringvalue", stringValues));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/constraint/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/constraint/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method saveTechnicalTerm has exactly been
        // called once
        Mockito.verify(technicalTermServiceMock, times(1))
                .saveTechnicalTerm(argumentCaptor.capture());

        // check properties of saved technicalTerm
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("MinTechnicalTerm", argumentCaptor.getValue().getIdentifier());
        assertEquals("cm", argumentCaptor.getValue().getUnit());
    }

    /**
     * Tests editing an invalid TechnicalTerm using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingInvalidTechnicalTerm() throws Exception
    {
        String[] stringValueIds = { "1" };
        String[] stringValues = { "test" };

        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/constraint/edit").param("id", "3")
                        .param("unit", "cm").param("stringvalue-id", stringValueIds)
                        .param("stringvalue-stringvalue", stringValues));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/constraint/edit/{id}"));
        resultActions.andExpect(redirectedUrl("/constraint/edit/3"));

        // Check binding result
        resultActions.andExpect(flash().attribute("technicalterm", notNullValue()));
        resultActions.andExpect(flash()
                .attributeExists("org.springframework.validation.BindingResult.technicalterm"));

        // guarantee that service method saveTechnicalTerm has never been called
        Mockito.verify(technicalTermServiceMock, times(0))
                .saveTechnicalTerm(org.mockito.Matchers.<TechnicalTerm> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /**
     * Tests editing a TechnicalTerm inline in a valid way using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingTechnicalTermInlineValid() throws Exception
    {
        String[] stringValueIds = { "1" };
        String[] stringValues = { "test" };

        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/constraint/editinline").param("id", "3")
                        .param("identifier", "MinTechnicalTerm").param("unit", "cm")
                        .param("stringvalue-id", stringValueIds)
                        .param("stringvalue-stringvalue", stringValues));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("success")));

        // guarantee that service method saveTechnicalTerm has exactly been
        // called once
        Mockito.verify(technicalTermServiceMock, times(1))
                .saveTechnicalTerm(argumentCaptor.capture());

        // check properties of saved technicalTerm
        assertEquals(Long.valueOf("3"), argumentCaptor.getValue().getId());
        assertEquals("MinTechnicalTerm", argumentCaptor.getValue().getIdentifier());
        assertEquals("cm", argumentCaptor.getValue().getUnit());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /**
     * Tests editing a TechnicalTerm inline in an invalid way using a
     * POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testEditingTechnicalTermInlineInvalid() throws Exception
    {
        String[] stringValueIds = { "1" };
        String[] stringValues = { "test" };

        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/constraint/editinline").param("id", "3")
                        .param("unit", "cm").param("stringvalue-id", stringValueIds)
                        .param("stringvalue-stringvalue", stringValues));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(content().contentType(MediaType.APPLICATION_JSON));

        // Check binding result
        resultActions.andExpect(jsonPath("$.type", is("failure")));

        // guarantee that service method saveTechnicalTerm has never been called
        Mockito.verify(technicalTermServiceMock, times(0))
                .saveTechnicalTerm(org.mockito.Matchers.<TechnicalTerm> any());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /******************************************************************
     * 
     * DELETE PROJECT
     * 
     *****************************************************************/

    /**
     * Tests the view for deleting a technicalTerm.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testDeleteTechnicalTermPage() throws Exception
    {
        ResultActions resultActions = mockMvc.perform(get("/constraint/delete/1"));

        // checks
        resultActions.andExpect(status().isOk());
        resultActions.andExpect(view().name("index"));
        resultActions.andExpect(forwardedUrl("index"));

        // model attributes
        resultActions.andExpect(model().attribute("breadcrumbs", hasSize(3)));
        resultActions.andExpect(model().attribute("menu", hasSize(0)));
        resultActions.andExpect(model().attribute("jsp", is("addtechnicalterm")));
        resultActions.andExpect(model().attribute("viewmode", is("delete")));
        testPrePopulatedValues(resultActions);

        resultActions.andExpect(model().attribute("technicalterm", notNullValue()));
        resultActions
                .andExpect(model().attribute("technicalterm", instanceOf(TechnicalTerm.class)));
    }

    /**
     * Tests deleting a TechnicalTerm using a POST-method.
     * 
     * @throws Exception
     *             an exception if method fails
     */
    @Test
    public void testDeletingTechnicalTerm() throws Exception
    {
        ResultActions resultActions = mockMvc
                .perform(MockMvcRequestBuilders.post("/constraint/delete/3"));

        // checks
        resultActions.andExpect(status().isFound());
        resultActions.andExpect(view().name("redirect:/constraint/list"));
        resultActions.andExpect(redirectedUrl("/constraint/list"));

        // Check binding result
        resultActions.andExpect(flash().attribute("messagestatus", is("success")));

        // guarantee that service method deleteTechnicalTerm has exactly been
        // called once
        Mockito.verify(technicalTermServiceMock, times(1))
                .deleteTechnicalTerm(org.mockito.Matchers.anyInt());

        // guarantee that no other service method has been called
        Mockito.verifyNoMoreInteractions(technicalTermServiceMock);
    }

    /******************************************************************
     * 
     * METHODS TO CREATE DUMMY DATA
     * 
     *****************************************************************/

    /**
     * Helper method to create dummy technicalTerm.
     * 
     * @param fakeId
     *            the id for the dummy object.
     * @return a populated TechnicalTerm object.
     */
    private TechnicalTerm createDummyTechnicalTerm(Long fakeId)
    {
        TechnicalTerm technicalTerm = new TechnicalTerm();
        technicalTerm.setIdentifier("ControllerTestTechnicalTerm");
        technicalTerm.setId(fakeId);
        technicalTerm.setUnit("cm");
        technicalTerm.setDeliveredBy("solution");
        technicalTerm.setRequiredBy("issue");

        return technicalTerm;
    }

    /**
     * Helper method to create dummy stringValue.
     * 
     * @param fakeId
     *            the id for the dummy object
     * @param technicalTerm
     *            technicalTerm, the stringValue belongs to
     * @return a populated stringValue object
     */
    private StringValue createDummyStringValue(Long fakeId, TechnicalTerm technicalTerm)
    {
        StringValue stringValue = new StringValue();
        stringValue.setId(fakeId);
        stringValue.setTechnicalTerm(technicalTerm);
        stringValue.setStringValue("stringValue!");

        return stringValue;
    }
}