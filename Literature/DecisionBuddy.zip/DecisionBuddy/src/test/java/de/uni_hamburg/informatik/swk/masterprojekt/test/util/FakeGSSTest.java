package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.FakeGSS;

/**
 * Tests FakeGSS.
 * 
 * @author Tim
 *
 */
public class FakeGSSTest
{
    private Framework solution1 = new Framework();
    private Framework solution2 = new Framework();
    private QualityGoal goal1 = new QualityGoal();
    private QualityGoal goal2 = new QualityGoal();

    /**
     * Setup method for architectural pattern validator. Called before each test
     * method. Creates a valid ArchitecturalPattern.
     * 
     * @throws Exception excep
     */
    @Before
    public void setUp() throws Exception
    {
        solution1.setName("a");
        solution2.setName("asdfasdf");

        goal1.setName("Security");
        goal2.setName("Usability");
    }

    /**
     * Test method for default architectural pattern created in setUp(), if this
     * fails the other tests can't work properly.
     */
    @Test
    public void setUpValid()
    {
        WeightedQualityGoal weightedQualityGoal1 = new WeightedQualityGoal();
        weightedQualityGoal1.setQualityGoal(goal1);
        weightedQualityGoal1.setWeight(1);

        WeightedQualityGoal weightedQualityGoal2 = new WeightedQualityGoal();
        weightedQualityGoal2.setQualityGoal(goal2);
        weightedQualityGoal2.setWeight(2);

        WeightedQualityGoal weightedQualityGoal3 = new WeightedQualityGoal();
        weightedQualityGoal3.setQualityGoal(goal1);
        weightedQualityGoal3.setWeight(2);

        List<WeightedQualityGoal> weightedQualityGoals1 = new ArrayList<WeightedQualityGoal>();
        weightedQualityGoals1.add(weightedQualityGoal1);
        List<WeightedQualityGoal> weightedQualityGoals2 = new ArrayList<WeightedQualityGoal>();
        weightedQualityGoals2.add(weightedQualityGoal1);
        weightedQualityGoals2.add(weightedQualityGoal2);
        List<WeightedQualityGoal> weightedQualityGoals3 = new ArrayList<WeightedQualityGoal>();
        weightedQualityGoals3.add(weightedQualityGoal2);
        weightedQualityGoals3.add(weightedQualityGoal3);
        // Different Solution should get different values
        assertTrue(FakeGSS.getSolutionRating(solution1, weightedQualityGoals1) != FakeGSS.getSolutionRating(solution2,
                weightedQualityGoals1));
        // Different Goals should get different values
        assertTrue(FakeGSS.getSolutionRating(solution1, weightedQualityGoals1) != FakeGSS.getSolutionRating(solution1,
                weightedQualityGoals2));
        assertTrue(FakeGSS.getSolutionRating(solution2, weightedQualityGoals1) != FakeGSS.getSolutionRating(solution2,
                weightedQualityGoals2));
        // Different Weights should get different values
        assertTrue(FakeGSS.getSolutionRating(solution1, weightedQualityGoals2) != FakeGSS.getSolutionRating(solution1,
                weightedQualityGoals3));
        assertTrue(FakeGSS.getSolutionRating(solution2, weightedQualityGoals2) != FakeGSS.getSolutionRating(solution2,
                weightedQualityGoals3));

    }
}