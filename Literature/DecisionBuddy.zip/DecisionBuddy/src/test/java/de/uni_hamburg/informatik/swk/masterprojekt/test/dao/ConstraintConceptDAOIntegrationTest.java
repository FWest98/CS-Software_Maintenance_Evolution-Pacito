package de.uni_hamburg.informatik.swk.masterprojekt.test.dao;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.DatabaseTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ConstraintDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ConstraintElementDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.TechnicalTermDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;

/**
 * Tests the the DAOs belonging the constraint concept and the real database.
 * 
 * @author Tim
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = DatabaseTestConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public class ConstraintConceptDAOIntegrationTest
{
    @Autowired
    private ConstraintDAO constraintDAO;

    @Autowired
    private ConstraintElementDAO constraintElementDAO;

    @Autowired
    private TechnicalTermDAO technicalTermDAO;

    @Autowired
    private IssueDAO issueDAO;

    @Autowired
    private ProjectDAO projectDAO;

    @Autowired
    private FrameworkDAO frameworkDAO;

    /**
     * Test if constraint can be saved to database.
     */
    @Test
    public void testSaveTechnicalTermInDB()
    {
        TechnicalTerm technicalTerm = saveTechnicalTermInDB();
        assertNotNull(technicalTerm.getId());
        assertTrue(technicalTerm.getId() > 0);
    }

    /**
     * Create a new TechnicalTerm and save it in the DB.
     * 
     * @return a saved TechnicalTerm
     */
    public TechnicalTerm saveTechnicalTermInDB()
    {
        TechnicalTerm technicalTerm = new TechnicalTerm();
        technicalTerm.setUnit("ms");
        technicalTerm.setIdentifier("Response Time");
        technicalTerm.setRequiredBy("Issue");
        technicalTerm.setDeliveredBy("Solution");
        technicalTerm.setType("int");
        technicalTerm = technicalTermDAO.save(technicalTerm);
        return technicalTerm;
    }

    /**
     * Test if constraint can be saved to database.
     */
    @Test
    public void testSaveConstraintInDB()
    {
        // Create and save TechnicalTerm
        TechnicalTerm technicalTerm = saveTechnicalTermInDB();
        assertNotNull(technicalTerm.getId());
        assertTrue(technicalTerm.getId() > 0);

        // Create and save Constraint
        Constraint contstraint = saveConstraintInDB(technicalTerm);
        assertNotNull(contstraint.getId());
        assertTrue(contstraint.getId() > 0);
    }

    /**
     * Create a new Constraint and save it in the DB.
     * 
     * @param technicalTerm The TechnicalTerm for the Constraint.
     * @return a saved TechnicalTerm
     */
    public Constraint saveConstraintInDB(TechnicalTerm technicalTerm)
    {
        Constraint contstraint = new Constraint();
        contstraint.setTechnicalTerm(technicalTerm);
        assertNull(contstraint.getId());
        contstraint = constraintDAO.save(contstraint);
        return contstraint;
    }

    /**
     * Test if constraint can be saved to database.
     */
    @Test
    public void testSaveConstraintElementInDB()
    {
        // Create and save TechnicalTerm
        TechnicalTerm technicalTerm = saveTechnicalTermInDB();
        assertNotNull(technicalTerm.getId());
        assertTrue(technicalTerm.getId() > 0);

        // Create and save Constraint
        Constraint contstraint = saveConstraintInDB(technicalTerm);
        assertNotNull(contstraint.getId());
        assertTrue(contstraint.getId() > 0);

        // Create and save ConstraintElement
        ConstraintElement contstraintElement = saveConstraintElementInDB(contstraint);
        assertNotNull(contstraintElement.getId());
        assertTrue(contstraintElement.getId() > 0);
    }

    /**
     * Create a new ConstraintElement and save it in the DB.
     * 
     * @param constraint The Constraint for the ConstraintElement.
     * @return a saved ConstraintElement
     */
    public ConstraintElement saveConstraintElementInDB(Constraint constraint)
    {
        ConstraintElement constraintElement = new ConstraintElement();
        constraint.addElement(constraintElement);
        constraintElement.setIntValue(2);
        assertNull(constraintElement.getId());
        constraintElement = constraintElementDAO.save(constraintElement);
        assertNotNull(constraintElement.getId());
        assertTrue(constraintElement.getId() > 0);
        return constraintElement;
    }

    /**
     * Test if correct ConstraintElements for Constraint are found.
     */
    @Test
    public void testFindAllConstraintElementsForConstraint()
    {
        // Create and save TechnicalTerm
        TechnicalTerm technicalTerm = saveTechnicalTermInDB();
        assertNotNull(technicalTerm.getId());
        assertTrue(technicalTerm.getId() > 0);

        // Create and save Constraints
        Constraint constraint1 = saveConstraintInDB(technicalTerm);
        assertNotNull(constraint1.getId());
        assertTrue(constraint1.getId() > 0);

        Constraint constraint2 = saveConstraintInDB(technicalTerm);
        assertNotNull(constraint2.getId());
        assertTrue(constraint2.getId() > 0);

        // Create and save ConstraintElemts
        ConstraintElement constraintElement1 = saveConstraintElementInDB(constraint1);
        assertNotNull(constraintElement1.getId());
        assertTrue(constraintElement1.getId() > 0);
        ConstraintElement constraintElement2 = saveConstraintElementInDB(constraint1);
        assertNotNull(constraintElement2.getId());
        assertTrue(constraintElement2.getId() > 0);
        ConstraintElement constraintElement3 = saveConstraintElementInDB(constraint2);
        assertNotNull(constraintElement3.getId());
        assertTrue(constraintElement3.getId() > 0);

        constraint1 = constraintDAO.findOne(constraint1.getId());
        assertNotNull(constraint1);
        List<ConstraintElement> constraintList = constraint1.getElements();
        assertTrue(constraintList.contains(constraintElement1));
        assertTrue(constraintList.contains(constraintElement2));
        assertFalse(constraintList.contains(constraintElement3));

    }

    /**
     * Test if constraints can be added and found for issues.
     */
    @Test
    public void testAddConstraintToIssue()
    {
        // Create and save TechnicalTerm
        TechnicalTerm technicalTerm = saveTechnicalTermInDB();
        assertNotNull(technicalTerm.getId());
        assertTrue(technicalTerm.getId() > 0);

        // Create and save Constraints
        Constraint constraint1 = saveConstraintInDB(technicalTerm);
        assertNotNull(constraint1.getId());
        assertTrue(constraint1.getId() > 0);

        Constraint constraint2 = saveConstraintInDB(technicalTerm);
        assertNotNull(constraint2.getId());
        assertTrue(constraint2.getId() > 0);

        Constraint constraint3 = saveConstraintInDB(technicalTerm);
        assertNotNull(constraint3.getId());
        assertTrue(constraint3.getId() > 0);

        // Create Project and Issue
        Project project = new Project();
        project.setName("Masterprojekt");
        project.setDescription("Our Master project");
        project.setCreator("Lucas");
        project.setCreationDate(new Date());
        project.setLastModifier("Lucas");
        project.setModificationDate(new Date());
        project = projectDAO.save(project);

        Issue issue1 = new Issue();
        issue1.setName("Issue1");
        issue1.setDescription("Testissue 1");
        issue1.setCreator("Lucas");
        issue1.setCreationDate(new Date());
        issue1.setLastModifier("Lucas");
        issue1.setModificationDate(new Date());
        issue1.setProject(project);
        issue1 = issueDAO.save(issue1);
        issue1.addConstraint(constraint1);
        issue1.addConstraint(constraint2);

        Issue issue2 = new Issue();
        issue2.setName("Issue2");
        issue2.setDescription("Testissue 2");
        issue2.setCreator("Tim");
        issue2.setCreationDate(new Date());
        issue2.addConstraint(constraint3);
        issue2.setProject(project);

        issue1 = issueDAO.save(issue1);
        issue1 = issueDAO.findOne(issue1.getId());

        issue2 = issueDAO.save(issue2);
        issue2 = issueDAO.findOne(issue2.getId());

        assertTrue(issue1.getConstraints().contains(constraint1));
        assertTrue(issue1.getConstraints().contains(constraint2));
        assertFalse(issue1.getConstraints().contains(constraint3));

        assertFalse(issue2.getConstraints().contains(constraint1));
        assertFalse(issue2.getConstraints().contains(constraint2));
        assertTrue(issue2.getConstraints().contains(constraint3));
    }

    /**
     * Test if constraints can be added and found for solutions.
     */
    @Test
    public void testAddConstraintToSolution()
    {
        // Create and save TechnicalTerm
        TechnicalTerm technicalTerm = saveTechnicalTermInDB();
        assertNotNull(technicalTerm.getId());
        assertTrue(technicalTerm.getId() > 0);

        // Create and save Constraints
        Constraint constraint1 = saveConstraintInDB(technicalTerm);
        assertNotNull(constraint1.getId());
        assertTrue(constraint1.getId() > 0);

        Constraint constraint2 = saveConstraintInDB(technicalTerm);
        assertNotNull(constraint2.getId());
        assertTrue(constraint2.getId() > 0);

        // Create Issue
        Framework framework = new Framework();
        framework.setName("TestFramework");
        framework.setShortDescription("Test");
        framework.setCreator("Tim");
        framework.setCreationDate(new Date());
        framework = frameworkDAO.save(framework);
        framework.addConstraint(constraint1);
        framework.addConstraint(constraint2);
        framework = frameworkDAO.save(framework);

        // Assertions
        assertTrue(framework.getConstraints().contains(constraint1));
        assertTrue(framework.getConstraints().contains(constraint2));
    }
}