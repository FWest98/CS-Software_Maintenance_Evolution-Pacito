package de.uni_hamburg.informatik.swk.masterprojekt.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.AuthoritiesDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AuthorityPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.AuthorityService;

/**
 * 
 * @author Vlad
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class AuthorityServiceTest
{
    private static final String AUTHORITY_NAME1 = "ROLE_AUTHORITY1";
    private static final String AUTHORITY_NAME2 = "ROLE_AUTHORITY2";
    private static final String AUTHORITY_NAME3 = "ROLE_AUTHORITY3";

    private Authority           authority1;
    private Authority           authority2;
    private Authority           authority3;

    private List<Authority>     authorityList;

    @Autowired
    private AuthorityService    authorityService;

    @Autowired
    private AuthoritiesDAO      authorityDAO;

    @Before
    public void setUp() throws Exception
    {
        authority1 = new Authority();
        authority2 = new Authority();
        authority3 = new Authority();

        authority1.setAuthority(AUTHORITY_NAME1);
        authority2.setAuthority(AUTHORITY_NAME2);
        authority3.setAuthority(AUTHORITY_NAME3);

        authorityList = new ArrayList<Authority>();
        authorityList.add(authority1);
        authorityList.add(authority2);
        authorityList.add(authority3);

        Mockito.when(authorityDAO.findOne(AUTHORITY_NAME1)).thenReturn(authority1);
        Mockito.when(authorityDAO.findOne(AUTHORITY_NAME2)).thenReturn(authority2);
        Mockito.when(authorityDAO.findOne(AUTHORITY_NAME3)).thenReturn(authority3);

        Mockito.when(authorityDAO.saveAndFlush(authority1)).thenReturn(authority1);
        Mockito.when(authorityDAO.saveAndFlush(authority2)).thenReturn(authority2);
        Mockito.when(authorityDAO.saveAndFlush(authority3)).thenReturn(authority3);
    }

    @Test
    public void testAddAuthority()
    {
        // Mockito.when(authorityDAO.saveAndFlush(authority1)).thenReturn(authority1);
        try
        {
            authorityService.saveAuthority(authority1);
        }
        catch (AuthorityPersistenceException e)
        {
            fail(e.toString());
        }
        Mockito.verify(authorityDAO).saveAndFlush(authority1);
    }

    @Test
    public void testGetAuthority() throws Exception
    {
        try
        {
            assertEquals(authority1, authorityService.getAuthorityByName(AUTHORITY_NAME1));
        }
        catch (Exception e)
        {
            fail(e.toString());
        }
        Mockito.verify(authorityDAO).findOne(authority1.getAuthority());
    }

    @Test
    public void testDeleteAuthority() throws Exception
    {
        try
        {
            authorityService.deleteAuthority(AUTHORITY_NAME1);
        }
        catch (Exception e)
        {
            fail(e.toString());
        }
        Mockito.verify(authorityDAO).delete(authority1.getAuthority());
    }

    @Test
    public void getAllAuthorities() throws Exception
    {
        try
        {
            // List<Authority> authorities = authorityService.getAuthorities();
            assertEquals(authorityList.size(), 3L);
            assertNotEquals(authorityList.size(), 1L);
        }
        catch (Exception e)
        {
            fail(e.toString());
        }

    }

}
