package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ImporterDecisionBuddyAnalyzer;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class ImporterDecisionBuddyAnalyzerTest
{
    private static final String TMP_PREFIX = "analyzeresult_";
    private static final String TMP_EXTENSION = ".tmp";

    private File invalidFile;
    private File faultyFile;
    private File correctFile;

    @Autowired
    private ImporterDecisionBuddyAnalyzer importerDecisionBuddyAnalyzer;

    @Before
    public void setup()
    {
        BufferedWriter writer;
        String text;

        try
        {
            // Write syntactical invalid File
            invalidFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(invalidFile));
            text = "this is not a DBA export";
            writer.write(text);
            writer.close();

            // Write faulty file: Facade Patern instead of Pattern
            faultyFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(faultyFile));
            text = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<root>\n<known/>\n<unknown>\n"
                    + "<framework>\n<description>Spring Context</description>\n<url>https://github.com/SpringSource"
                    + "/spring-framework</url>\n<groupid>org.springframework</groupid>\n<artifactid>spring-context"
                    + "</artifactid>\n<version>4.0.0.RELEASE</version>\n<package name=\"de.uni_hamburg.informatik."
                    + "swk.masterprojekt.decisionbuddy.beans\">\n<class>BreadcrumbManager</class>\n<class>MenuManager"
                    + "</class>\n</package>\n</framework>\n</unknown>\n</root>";
            writer.write(text);
            writer.close();

            // Write correct File
            correctFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
            writer = new BufferedWriter(new FileWriter(correctFile));
            text = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<root>\n<known/>\n<unknown>"
                    + "\n<framework>\n<name>Spring Context</name>\n<description>Spring Context</description>\n"
                    + "<url>https://github.com/SpringSource/spring-framework</url>\n<groupid>org.springframework"
                    + "</groupid>\n<artifactid>spring-context</artifactid>\n<version>4.0.0.RELEASE</version>\n"
                    + "<package name=\"de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans\">\n<class>"
                    + "BreadcrumbManager</class>\n<class>MenuManager</class>\n</package>\n</framework>\n</unknown>\n</root>";
            writer.write(text);
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    @Test(expected = AnalysisResultException.class)
    public void testValidateInvalidData() throws AnalysisResultException
    {
        importerDecisionBuddyAnalyzer.validateFile(invalidFile.getAbsolutePath());
    }

    @Test
    public void testValidateFaultyData()
    {
        try
        {
            Assert.assertTrue(importerDecisionBuddyAnalyzer.validateFile(faultyFile.getAbsolutePath()));
        }
        catch (AnalysisResultException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
    }

    @Test
    public void testValidateCorrectData()
    {
        try
        {
            Assert.assertTrue(importerDecisionBuddyAnalyzer.validateFile(correctFile.getAbsolutePath()));
        }
        catch (AnalysisResultException e)
        {
            e.printStackTrace();
            fail("Exception caught.");
        }
    }

    // @Test(expected = AnalysisResultException.class)
    // public void testImportFaultyData() throws AnalysisResultException
    // {
    // importerDecisionBuddyAnalyzer.importFile(1,
    // faultyFile.getAbsolutePath());
    // }
    //
    // @Test
    // public void testImportCorrectData()
    // {
    // try
    // {
    // importerDecisionBuddyAnalyzer.importFile(1,
    // correctFile.getAbsolutePath());
    // }
    // catch (AnalysisResultException e)
    // {
    // e.printStackTrace();
    // fail("Exception caught.");
    // }
    // }
}
