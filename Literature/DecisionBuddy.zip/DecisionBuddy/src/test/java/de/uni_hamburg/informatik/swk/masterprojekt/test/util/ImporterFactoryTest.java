package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.AnalysisFileFormat;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.Importer;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ImporterFactory;

/**
 * Testet die Funktionen der ImportFactory und der verschiedenen Importer,
 * welche von der ImportFactory zur Verfügung gestellt werden.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class ImporterFactoryTest
{

    @Autowired
    private ImporterFactory importerFactory;

    /**
     * Testet ob die richtigen Importer beim Ausführen der ImporterFactory
     * zurückgegeben werden.
     */
    @Test
    public void testGetImporter()
    {
        // Lässt sich verschiedene Importer von der importFactory zurückgeben
        Importer importerNull = importerFactory.getImporter(AnalysisFileFormat.Sonargraph);

        // Testet ob die erhaltenen Importer den erwarteten Objekten entsprechen
        assertNull("A false String given to the ImporterFactory doesn't lead to a Null object!", importerNull);
    }

}
