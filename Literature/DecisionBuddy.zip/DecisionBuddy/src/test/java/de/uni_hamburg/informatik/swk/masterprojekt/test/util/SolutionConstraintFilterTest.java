package de.uni_hamburg.informatik.swk.masterprojekt.test.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing.ServiceTestConfig;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.SolutionConstraintFilter;

/**
 * Test class for SolutionConstraintFilter.
 * 
 * @author Lucas
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ServiceTestConfig.class })
@WebAppConfiguration
@ActiveProfiles(profiles = "ServiceTesting")
public class SolutionConstraintFilterTest
{

    private Solution solution;
    private Issue issue;

    /**
     * Creates a basic issue and solution without any constraints.
     */
    @Before
    public void setUp()
    {
        FrameworkCategory fc = new FrameworkCategory();
        fc.setId(42L);
        fc.setName("Test category");

        Framework framework = new Framework();
        framework.setId(1L);
        framework.setName("Test framework 1");
        framework.setCreator("Tester1");
        framework.setCreationDate(new Date());
        framework.setFrameworkCategory(fc);
        solution = framework;

        Project testProject1 = new Project();
        testProject1.setId(1L);
        testProject1.setName("Masterprojekt");
        testProject1.setDescription("Our Master project");
        testProject1.setCreator("Lucas");
        testProject1.setCreationDate(new Date());
        testProject1.setLastModifier("Lucas");
        testProject1.setModificationDate(new Date());

        issue = new Issue();
        issue.setId(1L);
        issue.setProject(testProject1);
        issue.setName("Issue1");
        issue.setDescription("Testissue 1");
        issue.setCreator("Lucas");
        issue.setCreationDate(new Date());
        issue.setLastModifier("Lucas");
        issue.setModificationDate(new Date());
    }

    /**
     * Tests comparison of int-constraints.
     */
    @Test
    public void intConstraintDeliveredByIssueTest()
    {
        Constraint issueConstraint = new Constraint();
        Constraint solutionConstraint = new Constraint();
        TechnicalTerm technicalTerm = new TechnicalTerm();
        ConstraintElement issueElement = new ConstraintElement();
        ConstraintElement solutionElement = new ConstraintElement();

        technicalTerm.setDeliveredBy("issue");
        technicalTerm.setRequiredBy("solution");
        technicalTerm.setId(1L);
        technicalTerm.setIdentifier("testTerm");
        technicalTerm.setType("int");
        technicalTerm.setUnit("x");

        issueElement.setId(1L);
        issueElement.setIntValue(10);

        solutionElement.setComparator("smaller");
        solutionElement.setId(2L);
        solutionElement.setIntValue(8);

        issueConstraint.setTechnicalTerm(technicalTerm);
        solutionConstraint.setTechnicalTerm(technicalTerm);

        issueConstraint.addElement(issueElement);
        issueElement.setConstraint(issueConstraint);
        solutionConstraint.addElement(solutionElement);
        solutionElement.setConstraint(solutionConstraint);

        issue.addConstraint(issueConstraint);
        solution.addConstraint(solutionConstraint);

        SolutionConstraintFilter filter = new SolutionConstraintFilter(issue);

        assertFalse(filter.isInResult(solution));

        issueElement.setIntValue(5);
        assertTrue(filter.isInResult(solution));

        issueElement.setIntValue(8);
        assertFalse(filter.isInResult(solution));

        solutionElement.setComparator("smallerequal");
        assertTrue(filter.isInResult(solution));

    }

    /**
     * Tests comparison of int-constraints.
     */
    @Test
    public void intConstraintDeliveredBySolutionTest()
    {
        Constraint issueConstraint = new Constraint();
        Constraint solutionConstraint = new Constraint();
        TechnicalTerm technicalTerm = new TechnicalTerm();
        ConstraintElement issueElement = new ConstraintElement();
        ConstraintElement solutionElement = new ConstraintElement();

        technicalTerm.setDeliveredBy("solution");
        technicalTerm.setRequiredBy("issue");
        technicalTerm.setId(1L);
        technicalTerm.setIdentifier("testTerm");
        technicalTerm.setType("int");
        technicalTerm.setUnit("x");

        issueElement.setComparator("greater");
        issueElement.setId(1L);
        issueElement.setIntValue(10);

        solutionElement.setId(2L);
        solutionElement.setIntValue(8);

        issueConstraint.setTechnicalTerm(technicalTerm);
        solutionConstraint.setTechnicalTerm(technicalTerm);

        issueConstraint.addElement(issueElement);
        issueElement.setConstraint(issueConstraint);
        solutionConstraint.addElement(solutionElement);
        solutionElement.setConstraint(solutionConstraint);

        issue.addConstraint(issueConstraint);
        solution.addConstraint(solutionConstraint);

        SolutionConstraintFilter filter = new SolutionConstraintFilter(issue);

        assertFalse(filter.isInResult(solution));

        issueElement.setIntValue(5);
        assertTrue(filter.isInResult(solution));

        issueElement.setIntValue(8);
        assertFalse(filter.isInResult(solution));

        issueElement.setComparator("greaterequal");
        assertTrue(filter.isInResult(solution));

    }

    /**
     * Tests comparison of string-constraints.
     */
    @Test
    public void stringConstraintTest()
    {
        Constraint issueConstraint = new Constraint();
        Constraint solutionConstraint = new Constraint();
        TechnicalTerm technicalTerm = new TechnicalTerm();
        ConstraintElement issueElement1 = new ConstraintElement();
        ConstraintElement issueElement2 = new ConstraintElement();
        ConstraintElement issueElement3 = new ConstraintElement();
        ConstraintElement solutionElement1 = new ConstraintElement();
        ConstraintElement solutionElement2 = new ConstraintElement();

        technicalTerm.setDeliveredBy("solution");
        technicalTerm.setRequiredBy("issue");
        technicalTerm.setId(1L);
        technicalTerm.setIdentifier("testTerm");
        technicalTerm.setType("string");

        StringValue stringValue1 = new StringValue();
        StringValue stringValue2 = new StringValue();
        StringValue stringValue3 = new StringValue();
        StringValue stringValue4 = new StringValue();
        stringValue1.setStringValue("String 1");
        stringValue2.setStringValue("String 2");
        stringValue3.setStringValue("String 3");
        stringValue4.setStringValue("String 4");

        issueElement1.setId(1L);
        issueElement1.setStringValue(stringValue1);
        issueElement2.setId(2L);
        issueElement2.setStringValue(stringValue2);
        issueElement3.setId(3L);
        issueElement3.setStringValue(stringValue3);

        solutionElement1.setId(4L);
        solutionElement1.setStringValue(stringValue1);
        solutionElement2.setId(5L);
        solutionElement2.setStringValue(stringValue4);

        issueConstraint.setTechnicalTerm(technicalTerm);
        solutionConstraint.setTechnicalTerm(technicalTerm);

        issueElement1.setConstraint(issueConstraint);
        issueElement2.setConstraint(issueConstraint);
        issueElement3.setConstraint(issueConstraint);
        solutionElement1.setConstraint(solutionConstraint);
        solutionElement2.setConstraint(solutionConstraint);

        issue.addConstraint(issueConstraint);
        solution.addConstraint(solutionConstraint);

        SolutionConstraintFilter filter = new SolutionConstraintFilter(issue);

        assertTrue(filter.isInResult(solution));

        solutionConstraint.addElement(solutionElement1);
        issueConstraint.addElement(issueElement1);

        assertTrue(filter.isInResult(solution));

        solutionConstraint.addElement(solutionElement2);
        issueConstraint.addElement(issueElement2);

        assertTrue(filter.isInResult(solution));

        List<ConstraintElement> issueList = new ArrayList<ConstraintElement>();
        List<ConstraintElement> solutionList = new ArrayList<ConstraintElement>();

        issueList.add(issueElement1);
        solutionList.add(solutionElement2);

        issueConstraint.setElements(issueList);
        solutionConstraint.setElements(solutionList);

        assertFalse(filter.isInResult(solution));

        issueList = new ArrayList<ConstraintElement>();
        solutionList = new ArrayList<ConstraintElement>();

        issueList.add(issueElement2);
        solutionList.add(solutionElement1);

        issueConstraint.setElements(issueList);
        solutionConstraint.setElements(solutionList);

        assertFalse(filter.isInResult(solution));
    }

    /**
     * Tests comparison of stringint-constraints.
     */
    @Test
    public void stringintDeliveredBySolutionConstraintTest()
    {
        Constraint issueConstraint = new Constraint();
        Constraint solutionConstraint = new Constraint();
        TechnicalTerm technicalTerm = new TechnicalTerm();
        ConstraintElement issueElement1 = new ConstraintElement();
        ConstraintElement issueElement2 = new ConstraintElement();
        ConstraintElement issueElement3 = new ConstraintElement();
        ConstraintElement solutionElement1 = new ConstraintElement();
        ConstraintElement solutionElement2 = new ConstraintElement();

        technicalTerm.setDeliveredBy("solution");
        technicalTerm.setRequiredBy("issue");
        technicalTerm.setId(1L);
        technicalTerm.setIdentifier("testTerm");
        technicalTerm.setType("stringint");

        StringValue stringValue1 = new StringValue();
        StringValue stringValue2 = new StringValue();
        StringValue stringValue3 = new StringValue();
        StringValue stringValue4 = new StringValue();
        stringValue1.setStringValue("String 1");
        stringValue2.setStringValue("String 2");
        stringValue3.setStringValue("String 3");
        stringValue4.setStringValue("String 4");

        issueElement1.setId(1L);
        issueElement1.setStringValue(stringValue1);
        issueElement1.setIntValue(1);
        issueElement1.setComparator("greater");
        issueElement2.setId(2L);
        issueElement2.setStringValue(stringValue2);
        issueElement2.setIntValue(2);
        issueElement2.setComparator("smallerequal");
        issueElement3.setId(3L);
        issueElement3.setStringValue(stringValue3);
        issueElement3.setIntValue(3);
        issueElement3.setComparator("equals");

        solutionElement1.setId(4L);
        solutionElement1.setStringValue(stringValue1);
        solutionElement1.setIntValue(1);
        solutionElement2.setId(5L);
        solutionElement2.setStringValue(stringValue4);
        solutionElement2.setIntValue(15);

        issueConstraint.setTechnicalTerm(technicalTerm);
        solutionConstraint.setTechnicalTerm(technicalTerm);

        issueElement1.setConstraint(issueConstraint);
        issueElement2.setConstraint(issueConstraint);
        issueElement3.setConstraint(issueConstraint);
        solutionElement1.setConstraint(solutionConstraint);
        solutionElement2.setConstraint(solutionConstraint);

        issue.addConstraint(issueConstraint);
        solution.addConstraint(solutionConstraint);

        SolutionConstraintFilter filter = new SolutionConstraintFilter(issue);

        // Same stringValue, but int-comparison fails
        issueConstraint.addElement(issueElement1);
        solutionConstraint.addElement(solutionElement1);
        assertFalse(filter.isInResult(solution));

        // New element does not change the result
        solutionConstraint.addElement(solutionElement2);
        assertFalse(filter.isInResult(solution));

        // Changed intValue to match the comparator requirements
        solutionElement1.setIntValue(2);
        assertTrue(filter.isInResult(solution));

        // New Requirements do not change the result, because there is a match
        // already
        issueConstraint.addElement(issueElement2);
        issueConstraint.addElement(issueElement3);
        assertTrue(filter.isInResult(solution));

        // Still no change, because the match on stringValue1 is successful
        solutionElement2.setStringValue(stringValue3);
        assertTrue(filter.isInResult(solution));
    }

    /**
     * Tests comparison of stringint-constraints.
     */
    @Test
    public void stringintDeliveredByIssueConstraintTest()
    {
        Constraint issueConstraint = new Constraint();
        Constraint solutionConstraint = new Constraint();
        TechnicalTerm technicalTerm = new TechnicalTerm();
        ConstraintElement issueElement1 = new ConstraintElement();
        ConstraintElement issueElement2 = new ConstraintElement();
        ConstraintElement issueElement3 = new ConstraintElement();
        ConstraintElement solutionElement1 = new ConstraintElement();
        ConstraintElement solutionElement2 = new ConstraintElement();

        technicalTerm.setDeliveredBy("issue");
        technicalTerm.setRequiredBy("solution");
        technicalTerm.setId(1L);
        technicalTerm.setIdentifier("testTerm");
        technicalTerm.setType("stringint");

        StringValue stringValue1 = new StringValue();
        StringValue stringValue2 = new StringValue();
        StringValue stringValue3 = new StringValue();
        StringValue stringValue4 = new StringValue();
        stringValue1.setStringValue("String 1");
        stringValue2.setStringValue("String 2");
        stringValue3.setStringValue("String 3");
        stringValue4.setStringValue("String 4");

        issueElement1.setId(1L);
        issueElement1.setStringValue(stringValue1);
        issueElement1.setIntValue(1);
        issueElement2.setId(2L);
        issueElement2.setStringValue(stringValue2);
        issueElement2.setIntValue(15);
        issueElement3.setId(3L);
        issueElement3.setStringValue(stringValue3);
        issueElement3.setIntValue(3);

        solutionElement1.setId(4L);
        solutionElement1.setStringValue(stringValue1);
        solutionElement1.setIntValue(1);
        solutionElement1.setComparator("smaller");
        solutionElement2.setId(5L);
        solutionElement2.setStringValue(stringValue2);
        solutionElement2.setIntValue(15);
        solutionElement2.setComparator("equals");

        issueConstraint.setTechnicalTerm(technicalTerm);
        solutionConstraint.setTechnicalTerm(technicalTerm);

        issueElement1.setConstraint(issueConstraint);
        issueElement2.setConstraint(issueConstraint);
        issueElement3.setConstraint(issueConstraint);
        solutionElement1.setConstraint(solutionConstraint);
        solutionElement2.setConstraint(solutionConstraint);

        issue.addConstraint(issueConstraint);
        solution.addConstraint(solutionConstraint);

        SolutionConstraintFilter filter = new SolutionConstraintFilter(issue);

        // String values do not match, requirement not fulfilled
        solutionConstraint.addElement(solutionElement2);
        issueConstraint.addElement(issueElement3);
        assertFalse(filter.isInResult(solution));

        // Same stringValue, but int-comparison fails
        issueConstraint.addElement(issueElement1);
        solutionConstraint.addElement(solutionElement1);
        assertFalse(filter.isInResult(solution));

        // New element matches solutionElement2, other mismatch becomes
        // irrelevant
        issueConstraint.addElement(issueElement2);
        assertTrue(filter.isInResult(solution));

    }
}
