package de.uni_hamburg.informatik.swk.masterprojekt.test.beans;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.Breadcrumb;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production.WebAppConfig;

/**
 * Simple tests for Breadcrumb class. For more complicated tests see
 * BreadcrumbManagerTest.
 * 
 * @author schaak
 *
 */
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = WebAppConfig.class)
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class BreadcrumbTest
{

    private Breadcrumb breadcrumb;

    /**
     * Setup method to create an empty breadcrumb.
     */
    @Before
    public void initializeBreadcrumb()
    {
        breadcrumb = new Breadcrumb("home", "wrongurl");
    }

    /**
     * Tests getter and setters.
     */
    @Test
    public void testGettersAndSetters()
    {
        String oldName = breadcrumb.getName();
        String newName = oldName + " Version II";
        breadcrumb.setName(newName);
        assertTrue("getName/setName do not work properly.", breadcrumb.getName().equals("home Version II"));

        String oldUrl = breadcrumb.getUrl();
        String newUrl = oldUrl + ".new";
        breadcrumb.setUrl(newUrl);
        assertTrue("getUrl/setUrl do not work properly.", breadcrumb.getUrl().equals("wrongurl.new"));

        List<String> params = new ArrayList<String>();
        params.add("param1");
        params.add("param2");
        params.add("param3");
        breadcrumb.setParams(params);
        assertTrue("getParams/setParams do not work properly.", breadcrumb.getParams().size() == 3);
    }
}