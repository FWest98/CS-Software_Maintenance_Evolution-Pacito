package de.uni_hamburg.informatik.swk.masterprojekt.test.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;

/**
 * Unit Test Case for
 * {@link de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework}
 * class. This class contains no business logic and only toString(), hashCode()
 * and equals() methods are tested.
 * 
 * @author Burak
 *
 */
public class ElementFrameworkTest
{
    private ElementFramework elementFramework1;
    private ElementFramework elementFramework2;
    private ElementFramework elementFramework3;

    /**
     * Creates three ElementFrameworks. ElementFramework 1 and 2 should be equal
     * and 3 different.
     */
    @Before
    public void setUp()
    {
        elementFramework1 = new ElementFramework();
        elementFramework2 = new ElementFramework();
        elementFramework3 = new ElementFramework();

        elementFramework1.setId(1L);
        elementFramework2.setId(1L);
        elementFramework3.setId(2L);
    }

    /**
     * Test functionality of toString Method.
     */
    @Test
    public void testFrameworkToString()
    {
        System.out.println(elementFramework1.toString());
    }

    /**
     * Tests the hashCode functionality of a ElementFramework, should only be
     * affected by Id.
     */
    @Test
    public void testElementFrameworkHashcode()
    {
        elementFramework1.setAltName("Eins");
        elementFramework2.setAltName("Eins");
        elementFramework3.setAltName("Zwei");
        assertTrue(elementFramework1.hashCode() == elementFramework1.hashCode());
        assertTrue(elementFramework1.hashCode() == elementFramework2.hashCode());
        assertFalse(elementFramework2.hashCode() == elementFramework3.hashCode());
    }

    /**
     * Tests the equals functionality of a ElementFramework, should only be
     * affected by Id.
     */
    @Test
    public void testElementFrameworkEquals()
    {
        assertTrue(elementFramework1.equals(elementFramework1));
        assertFalse(elementFramework1.equals(null));
        assertFalse(elementFramework1.equals(new String()));
        assertTrue(elementFramework1.equals(elementFramework2));
        assertFalse(elementFramework1.equals(elementFramework3));
    }
}