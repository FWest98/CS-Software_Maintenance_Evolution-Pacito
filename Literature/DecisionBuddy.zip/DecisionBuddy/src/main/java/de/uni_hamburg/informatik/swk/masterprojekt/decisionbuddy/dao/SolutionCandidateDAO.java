package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate;

/**
 * A DAO class for SolutionCandidate.
 * 
 * @author Tim
 *
 */
public interface SolutionCandidateDAO extends JpaRepository<SolutionCandidate, Long>
{
    Long countBySolutionId(Long solutionId);

    @Query(value = "select count(SolutionID) from SolutionCandidate where Decided = 1  and SolutionID= :id")
    Long countApprovedBySolutionId(@Param("id") Long id);
}