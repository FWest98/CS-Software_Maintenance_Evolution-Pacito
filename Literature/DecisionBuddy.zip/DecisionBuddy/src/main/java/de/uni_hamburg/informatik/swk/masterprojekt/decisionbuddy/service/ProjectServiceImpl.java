package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Service class for managing projects.
 *
 * @author Lucas
 *
 */
@Service
@Transactional
public class ProjectServiceImpl implements ProjectService
{

    @Autowired
    private ProjectDAO projectDAO;

    /**
     * Adds a new Project to the database.
     * 
     * @param project the project to save
     * 
     * @return the saved project object
     * 
     * @throws ProjectPersistenceException Exception if Project could not be
     *             persisted
     */
    @Override
    public Project saveProject(Project project) throws ProjectPersistenceException
    {
        Project savedProject;
        savedProject = projectDAO.saveAndFlush(project);

        if (savedProject == null)
        {
            throw new ProjectPersistenceException();
        }

        return savedProject;
    }

    /**
     * Deletes a project with the specified ID.
     * 
     * @param id the id of the project to be deleted
     * 
     * @throws ProjectNotFoundException Exception if Project is not found
     */
    @Override
    public void deleteProject(long id) throws ProjectNotFoundException
    {
        try
        {
            projectDAO.delete(id);
        }
        catch (DataAccessException e)
        {
            throw new ProjectNotFoundException();
        }
    }

    /**
     * Finds a project with the specified ID.
     * 
     * @param id ID of the Project
     * 
     * @return Project with the id.
     * 
     * @throws ProjectNotFoundException Exception if Project is not found
     */
    @Override
    public Project getProjectById(long id) throws ProjectNotFoundException
    {
        Project project = projectDAO.findOne(id);

        if (project == null)
        {
            throw new ProjectNotFoundException();
        }

        return project;
    }

    /**
     * Returns all projects.
     * 
     * @return a List of all projects.
     */
    @Override
    public List<Project> getAllProjects()
    {
        return projectDAO.findAll();
    }

    /**
     * Filters the projects using the specified Filter and sorts the result.
     * 
     * See Filter.java for an example on how to use this method.
     * 
     * @param filter Specifies how the projects should be filtered.
     * @param sorter Specifies how the result should be sorted. See
     *            documentation of java.util.Comparator for details.
     * 
     * @return Filtered and sorted list of the projects.
     */
    @Override
    public List<Project> getProjectsByCriteria(Filter<Project> filter, Comparator<Project> sorter)
    {
        List<Project> catalog = getAllProjects();
        List<Project> result = new ArrayList<Project>();

        if (filter != null)
        {
            for (Project element : catalog)
            {
                if (filter.isInResult(element))
                {
                    result.add(element);
                }
            }
        }
        else
        {
            result = catalog;
        }

        if (sorter != null)
        {
            Collections.sort(result, sorter);
        }

        return result;
    }
}