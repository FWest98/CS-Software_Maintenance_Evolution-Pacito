package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.AuthoritiesDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AuthorityNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AuthorityPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;

/**
 * @see AuthorityService
 * @author Vlad
 *
 */
@Service
@Transactional
public class AuthorityServiceImpl implements AuthorityService
{
    @Autowired
    private AuthoritiesDAO authorityDAO;

    /**
     * {@inheritDoc}
     */
    @Override
    public Authority saveAuthority(Authority authority) throws AuthorityPersistenceException

    {
        authorityDAO.saveAndFlush(authority);
        return authority;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Authority getAuthorityByName(String authorityName) throws AuthorityNotFoundException
    {
        return authorityDAO.findOne(authorityName);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Authority> getAuthorities()
    {
        return authorityDAO.findAll();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteAuthority(String authorityName) throws AuthorityNotFoundException
    {
        authorityDAO.delete(authorityName);
    }

}
