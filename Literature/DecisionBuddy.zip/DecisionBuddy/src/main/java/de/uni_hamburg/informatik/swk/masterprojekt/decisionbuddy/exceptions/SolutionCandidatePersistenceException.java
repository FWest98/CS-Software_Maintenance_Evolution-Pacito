package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a SolutionCandidate could not be written
 * to the database.
 * 
 * @author schaak
 *
 */
public class SolutionCandidatePersistenceException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public SolutionCandidatePersistenceException()
    {
        setExceptionType("solutioncandidatepersistence");
    }
}
