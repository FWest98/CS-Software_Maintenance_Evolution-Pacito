package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DynamicEntities;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StaticEntities;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.TechnicalTermService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.HelperFunctions;

/**
 * This controller is responsible for returning markup for dynamically managing
 * objects in lists on frontend.
 * 
 * @author schaak
 *
 */
@Controller
@RequestMapping(value = "/markup")
public class MarkupController
{
    @Autowired
    private TechnicalTermService technicalTermService;

    @Autowired
    private StaticEntities staticEntities;

    @Autowired
    private DynamicEntities dynamicEntities;

    @Autowired
    private HelperFunctions helperFunctions;

    @Autowired
    private MessageSource messageSource;

    /******************************************************************
     * 
     * MARKUP
     * 
     *****************************************************************/

    /**
     * Returns the markup for a NEW STRINGVALUE ROW.
     * 
     * @param stringValue the newly entered stringvalue
     * @param technicalTermId id of technical term
     * @param request needed for context path
     * 
     * @return the markup for the string value row to be added
     */
    @RequestMapping(value = "/stringvalue", method = RequestMethod.GET)
    public @ResponseBody String getMarkupForStringValueRow(@RequestParam(value = "stringvalue") String stringValue,
            @RequestParam(value = "technicalTermId") String technicalTermId, HttpServletRequest request)
    {
        // name of fields has to follow spring scheme
        String collectionNumber = "99";
        String nameBase = "stringValues[" + collectionNumber + "].";

        return "<tr data-collection-id='" + collectionNumber + "'><td>" + "<input name='" + nameBase + "id'"
                + " type='hidden' value='' class='object-id' />" + "<input name='" + nameBase + "technicalTerm.id'"
                + " type='hidden' value='" + technicalTermId + "' class='object-id' />" + "</td><td>" + "<input name='"
                + nameBase + "stringValue'" + " type='text' value='" + stringValue + "' />" + "</td>"
                + "<td class='tempdelete'>" + "<img src='" + request.getContextPath()
                + "/resources/images/deleteicon.png' />" + "</td>" + "</tr>";
    }

    /**
     * Returns the markup for a NEW CONSTRAINT ROW.
     * 
     * @param technicalTermId id of the technical term
     * @param request needed for context path
     * @param model String containing 'issue' or 'solution'
     * 
     * @return the markup for the constraint row to be added
     * 
     * @throws TechnicalTermNotFoundException exception if tt is not found
     */
    @RequestMapping(value = "/constraint", method = RequestMethod.GET)
    public @ResponseBody String getMarkupForConstraintRow(
            @RequestParam(value = "technicaltermid") String technicalTermId,
            @RequestParam(value = "model") String model, HttpServletRequest request)
            throws TechnicalTermNotFoundException
    {
        // name of fields has to follow spring scheme
        String collectionNumber = "99";
        String nameBase = "constraints[" + collectionNumber + "].";

        // get technical term
        TechnicalTerm technicalTerm = technicalTermService.getTechnicalTermById(Integer.valueOf(technicalTermId));

        // get locale
        Locale locale = LocaleContextHolder.getLocale();

        // get localized required / delivered message
        String dependency;
        if (technicalTerm.getRequiredBy().equals(model))
        {
            dependency = messageSource.getMessage("model.constraint.technicalTerm.required", null, locale);
        }
        else
        {
            dependency = messageSource.getMessage("model.constraint.technicalTerm.delivered", null, locale);
        }

        // get more translated messages
        String notAvailable = messageSource.getMessage("showconstraintelements.notAvailable", null, locale);
        String addConstraintElement = messageSource.getMessage("addconstraintelement.submit", null, locale);

        // build and return markup
        return "<tr class='boss-row' data-collection-id='" + collectionNumber + "'><td>"
                + "<input id='constraint-id' type='hidden' name='" + nameBase + "id' class='object-id' /></td>"
                + "<td ><input id='technicaltermid' type='hidden' name='" + nameBase + "technicalTerm.id' value='"
                + technicalTerm.getId() + "' class='object-id' />" + technicalTerm.getIdentifier() + "</td>" + "<td>"
                + dependency + "</td><td class='tempdelete'><img src='" + request.getContextPath()
                + "/resources/images/deleteicon.png' /></td>" + "<td class='td-no-border'>AND</td>"
                + "</tr><tr class='sub-row'><td colspan='4'>" + "<span class='elementsnotavailable'>" + notAvailable
                + "</span>" + "<table class='inner-table'><thead><tr><th width='85%'></th><th width='10%'></th>"
                + "<th class='td-no-border' width='5%'></th></tr></thead>" + "<tfoot></tfoot>"
                + "<tr><td colspan='2' class='td-no-border td-button'>"
                + "<input id='object-submit' class='addelement constraint-element tempadd' type='submit' value='"
                + addConstraintElement + "'></td></tr></table></td></tr>";
    }

    /**
     * Returns the markup for a NEW CONSTRAINTELEMENT ROW.
     * 
     * @param technicalTermId the technical term id
     * @param constraintId the constraint id
     * @param request needed for context path
     * @param model String containing 'issue' or 'solution'
     * @param constraintIndex index of constraint
     * @return the markup for the constraint element row to be added
     * 
     * @throws TechnicalTermNotFoundException exception if tt is not found
     * @throws SorterInvalidTypeException exception if type is invalid
     * @throws SorterFieldNotFoundException exception if field is not found
     */
    @RequestMapping(value = "/constraintelement", method = RequestMethod.GET)
    public @ResponseBody String getMarkupForConstraintElementRow(
            @RequestParam(value = "technicaltermid") String technicalTermId,
            @RequestParam(value = "constraintid") String constraintId, @RequestParam(value = "model") String model,
            @RequestParam(value = "constraintindex") String constraintIndex, HttpServletRequest request)
            throws TechnicalTermNotFoundException, SorterInvalidTypeException, SorterFieldNotFoundException
    {
        // name of fields has to follow spring scheme
        String collectionNumber = "999";
        String nameBase = "constraints[" + constraintIndex + "].elements[" + collectionNumber + "].";

        // get technical term
        TechnicalTerm technicalTerm = technicalTermService.getTechnicalTermById(Integer.valueOf(technicalTermId));

        // get locale
        Locale locale = LocaleContextHolder.getLocale();

        // building string value dropdown
        List<StringValue> stringValues = technicalTerm.getStringValues();

        String optionsStringValues = "";
        for (StringValue stringValue : stringValues)
        {
            optionsStringValues += "<option value='" + stringValue.getId() + "'>" + stringValue.getStringValue()
                    + "</option>";
        }

        // building comparators dropdown
        String optionsComparators = "";
        for (Map.Entry<String, String> comparator : staticEntities.getConstraintComparators().entrySet())
        {
            optionsComparators += "<option value='" + comparator.getKey() + "'>" + comparator.getValue() + "</option>";
        }

        // building unit display
        String unitMarkup = "";

        // version
        if ("version".equalsIgnoreCase(technicalTerm.getUnit()))
        {
            // the unit 'version' has to be displayed BEFORE the int value
            unitMarkup += "<span class='unit version'>"
                    + messageSource.getMessage("model.constraint.technicalTerm.unit.version", null, locale) + "</span>";
        }

        // 'string', 'stringint', 'int'
        String type = technicalTerm.getType();

        // int value
        if (type.equals("stringint"))
        {
            unitMarkup += "<input size='4' name='" + nameBase + "intValue' />";
        }
        else
        {
            unitMarkup += "<input size='4' name='" + nameBase + "intValue' value='0' />";
        }

        // non-version unit
        if (technicalTerm.getUnit() != null && technicalTerm.getUnit() != "none"
                && !("version".equalsIgnoreCase(technicalTerm.getUnit())))
        {
            // every unit besides 'version' has to be displayed AFTER the int
            // value
            unitMarkup += " <span class='unit'>" + technicalTerm.getUnit() + "</span>";
        }

        // comparators
        String comparator;
        if (technicalTerm.getRequiredBy().equals(model))
        {
            comparator = "<select name='" + nameBase + "comparator'>" + optionsComparators + "</select>";
        }
        else
        {
            comparator = "";
        }

        // markup is quite different depending on type
        String typeMarkup = "";

        if (type.equals("string"))
        {
            typeMarkup += "<select name='" + nameBase + "stringValue'>" + optionsStringValues + "</select>";
        }
        else if (type.equals("stringint"))
        {
            // markup for string value dropdown
            typeMarkup += "<select name='" + nameBase + "stringValue'>" + optionsStringValues + "</select>"
                    + "<input type='checkbox' class='constraintelement-useint' value='useint'><span>"
                    + messageSource.getMessage("model.constraint.constraintElement.moreSpecific", null, locale)
                    + "</span><span class='intvalues hidden'>" + comparator + unitMarkup + "</span";
        }
        else if (type.equals("int"))
        {

            typeMarkup += "<span class='intvalues'>" + comparator + unitMarkup + "</span>";
        }
        else
        {
            typeMarkup += "something went wrong";
        }

        return "<tr data-subcollection-id='" + collectionNumber + "'><td class='td-dotted-border'>"
                + "<input type='hidden' name='" + nameBase + "id' class='object-id' />" + "<input type='hidden' name='"
                + nameBase + "constraint' value='" + constraintId + "' class='object-id' />" + typeMarkup
                + "</td><td class='tempdelete constraint-element td-dotted-border'>" + "<img src='"
                + request.getContextPath() + "/resources/images/deleteicon.png' />"
                + "</td><td class='td-no-border'>OR</td></tr>";
    }

    /**
     * Returns the markup for a NEW QUALITY GOAL ROW.
     * 
     * @param qualitygoalid id of qualitygoal
     * @param request needed for context path
     * 
     * @return the markup for the qualitygoal row to be added
     */
    @RequestMapping(value = "/qualitygoal", method = RequestMethod.GET)
    public @ResponseBody String getMarkupForQualityGoalRow(@RequestParam(value = "issueid") String issueId,
            @RequestParam(value = "qualitygoalid") String qualityGoalId, HttpServletRequest request)
    {
        // name of fields has to follow spring scheme
        String collectionNumber = "99";
        String nameBase = "weightedQualityGoals[" + collectionNumber + "].";

        String options = "";

        for (Map.Entry<String, String> qualityGoal : dynamicEntities.getQualityGoals().entrySet())
        {
            if (qualityGoal.getKey().equals(qualityGoalId))
            {
                options += "<option selected='selected' value='" + qualityGoal.getKey() + "'>" + qualityGoal.getValue()
                        + "</option>";
            }
            else
            {
                options += "<option value='" + qualityGoal.getKey() + "'>" + qualityGoal.getValue() + "</option>";
            }
        }

        return "<tr class='single-row' data-collection-id='" + collectionNumber + "'>" + "<td><input name='" + nameBase
                + "issue' class='object-id' type='hidden' value='" + issueId + "'>" + "<select name='" + nameBase
                + "qualityGoal' class='quality-select quality-selected'>" + options
                + "</select></td><td class='slider-td'><div class='int-slider'>"
                + "<div class='weight-slider'></div><input name='" + nameBase
                + "weight' class='weight' type='hidden' value='5'>"
                + "</div></td><td class='tempdelete qualitygoal'><img src='" + request.getContextPath()
                + "/resources/images/deleteicon.png'></td></tr>";
    }

    /**
     * Returns the markup for a NEW SOLUTION CANDIDATE ROW.
     * 
     * @param solutionId the id of the solution
     * @param decisionId the id of the desicion
     * @@param solutionName name of solution
     * @param solutionType type name of solution
     * @param request needed for context path
     * 
     * @return the markup for the candidate row to be added
     * 
     */
    @RequestMapping(value = "/solutioncandidate", method = RequestMethod.GET)
    public @ResponseBody String getMarkupForCandidateRow(@RequestParam(value = "solutionid") String solutionId,
            @RequestParam(value = "decisionid") String decisionId,
            @RequestParam(value = "solutionname") String solutionName,
            @RequestParam(value = "solutiontype") String solutionType, HttpServletRequest request)
    {
        // name of fields has to follow spring scheme
        String collectionNumber = "99";
        String nameBase = "decision.solutionCandidates[" + collectionNumber + "].";

        // get locale
        Locale locale = LocaleContextHolder.getLocale();

        String options = "";

        for (Map.Entry<String, String> status : staticEntities.getCandidateDecisionStati().entrySet())
        {
            if (status.getKey().equals("0"))
            {
                options += "<option selected='selected' value='" + status.getKey() + "'>" + status.getValue()
                        + "</option>";
            }
            else
            {
                options += "<option value='" + status.getKey() + "'>" + status.getValue() + "</option>";
            }
        }

        String current = new SimpleDateFormat("yyyy-MM-dd, HH:mm:ss").format(new Date());
        String userName = helperFunctions.createUsername();

        // build and return markup
        return "<tr class='boss-row' data-collection-id='" + collectionNumber + "'>"
                + "<td class='object-row' data-href='/decisionbuddy/catalog/solution/" + solutionId + "'>"
                + "<input name='" + nameBase + "decision' class='object-id' type='hidden' value='" + decisionId + "'>"
                + "<input name='" + nameBase + "solution.id' class='object-id solution-id' type='hidden' value='"
                + solutionId + "'>" + "<input id='solution-candidate-id' name='" + nameBase
                + "id' class='object-id' type='hidden'>" + "<img src='" + request.getContextPath()
                + "/resources/images/profile.png' title='Profile' width='15px' height='15px'>" + "</td><td>"
                + solutionName + "</td><td>" + solutionType + "</td><td>" + "<input name='" + nameBase
                + "creator' class='object-id' type='hidden' value='" + userName + "'>" + "<input name='" + nameBase
                + "creationDate' class='object-id' type='hidden' value='" + current + "'>" + "<input name='" + nameBase
                + "lastModifier' class='object-id lastModifier' type='hidden' value='" + userName + "'>"
                + "<input name='" + nameBase
                + "modificationDate' class='object-id modificationDate' type='hidden' value='" + current + "'>"
                + userName + "</td><td class='tempdelete candidate'>" + "<img src='" + request.getContextPath()
                + "/resources/images/deleteicon.png'></td></tr>"
                + "<tr class='child-row richtext'><td colspan='2' class='editable-td editable-select'>"
                + "<div class='cand-status cand-status-undecided'><select name='" + nameBase + "decided'"
                + "class='decision-state'>" + options + "</select></div></td>"
                + "<td class='richtext' colspan='3'><textarea name='" + nameBase + "evaluation' rows='8' cols='40'>"
                + messageSource.getMessage("model.solutioncandidate.writeevaluation", null, locale)
                + "</textarea></td></tr>";
    }
}