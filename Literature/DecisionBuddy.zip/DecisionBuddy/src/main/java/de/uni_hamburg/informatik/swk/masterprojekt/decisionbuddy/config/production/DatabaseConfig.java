package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaSessionFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * The Spring database configuration file to configure the database connection
 * and JPA repositories.
 * 
 * @author Vlad
 *
 */
@Configuration
@EnableTransactionManagement
@ComponentScan("de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy")
// Manadatory if using JPA interfaces (repositories) with injection ( package
// where the repositories reside must be specified)
@EnableJpaRepositories("de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao")
// Reference to external database configuration file.
@PropertySource("classpath:database.properties")
public class DatabaseConfig
{
    // Hibernate configuration properties that reference
    // "database.configuration" file
    private static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
    private static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
    private static final String PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";
    private static final String PROPERTY_NAME_ENTITYMANAGER_PACKAGES_TO_SCAN = "entitymanager.packages.to.scan";

    // Environment allows to access an external config file
    // (call env.getProperty("property name"))
    @Autowired
    private Environment environment;

    /**
     * Configuration of the driver manager.
     * 
     * @return a configured data source for the connection
     */
    @Bean
    public DataSource dataSource()
    {
        final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
        dsLookup.setResourceRef(true);
        DataSource dataSource = dsLookup.getDataSource("jdbc/MasterProjekt");
        return dataSource;
    }

    /**
     * Creates a JPA transaction manager for dependency injection.
     * 
     * @return a JPA transaction manager
     */
    @Bean
    public JpaTransactionManager transactionManager()
    {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

    /**
     * Configures a factory bean that creates a JPA EntityManagerFactory
     * according to JPA's standard container bootstrap contract.
     * 
     * @return an entity manager factory
     */
    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory()
    {
        LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactory.setDataSource(dataSource());
        entityManagerFactory.setPackagesToScan(new String[] { environment
                .getRequiredProperty(PROPERTY_NAME_ENTITYMANAGER_PACKAGES_TO_SCAN) });

        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        entityManagerFactory.setJpaVendorAdapter(vendorAdapter);
        entityManagerFactory.setJpaProperties(jpaProperties());

        return entityManagerFactory;
    }

    /**
     * Configures additional (non-mandatory) properties for the
     * entityManagerFactory.
     * 
     * @return configuration properties
     */
    public Properties jpaProperties()
    {
        Properties properties = new Properties();
        properties.setProperty(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO,
                environment.getProperty(PROPERTY_NAME_HIBERNATE_HBM2DDL_AUTO));
        properties.setProperty(PROPERTY_NAME_HIBERNATE_DIALECT,
                environment.getProperty(PROPERTY_NAME_HIBERNATE_DIALECT));
        // Show SQL statements on console
        properties.setProperty(PROPERTY_NAME_HIBERNATE_SHOW_SQL,
                environment.getProperty(PROPERTY_NAME_HIBERNATE_SHOW_SQL));
        return properties;
    }

    /**
     * Creates Session Factory for managing database sessions.
     * 
     * @return a session factory bean
     */
    @Bean
    public HibernateJpaSessionFactoryBean sessionFactory(EntityManagerFactory emf)
    {
        HibernateJpaSessionFactoryBean factory = new HibernateJpaSessionFactoryBean();
        factory.setEntityManagerFactory(emf);
        return factory;
    }
}