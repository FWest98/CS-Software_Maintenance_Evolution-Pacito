package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.hibernate.collection.internal.PersistentBag;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;

/**
 * Converter for converting String input to Authority object.
 * 
 * @author Vlad
 *
 */
@Component
public class AuthorityListEditor extends PropertyEditorSupport
{
    @Override
    public void setAsText(String authorities)
    {
        if (authorities != null)
        {
            if (!authorities.isEmpty())
            {
                setValue(AuthorityUtils.commaSeparatedStringToAuthorityList(authorities));
            }
            else
            {
                setValue(new ArrayList<Authority>());
            }
        }
        else
        {
            setValue(new ArrayList<Authority>());
        }
    }

    @Override
    public String getAsText()
    {
        // String commaSeparatedString = "";
        Object object = getValue();
        PersistentBag pb = (PersistentBag) object;
        // for (Object object2 : pb)
        // {
        // Authority authority = (Authority) object2;
        // commaSeparatedString.concat(authority.toString());
        // }

        return StringUtils.join(pb, ", ");
        // return commaSeparatedString;
    }
}
