package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;

/**
 * A DAO class for RefactoringCategory.
 * 
 * @author Tim
 *
 */
public interface RefactoringCategoryDAO extends JpaRepository<RefactoringCategory, Long>
{

}
