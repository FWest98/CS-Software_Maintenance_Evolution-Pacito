package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the SolutionCandidate table from the database.
 *
 * @author Tim
 *
 */

@Entity
@Table(name = "SolutionCandidate")
public class SolutionCandidate implements UserEditable
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue
    private Long id;

    @ManyToOne(targetEntity = Solution.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "SolutionID", referencedColumnName = "ID", nullable = false)
    private Solution solution;

    @ManyToOne(targetEntity = Decision.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "DecisionID", referencedColumnName = "ID", nullable = false)
    private Decision decision;

    @Column(name = "Evaluation", nullable = true, length = ColumnLength.LONG)
    private String evaluation;

    @Column(name = "Decided", nullable = false, columnDefinition = "TINYINT(1)")
    private Integer decided;

    @Column(name = "Creator", nullable = false, length = ColumnLength.SHORT)
    private String creator;

    @Column(name = "CreationDate", nullable = false)
    private Date creationDate;

    @Column(name = "LastModifier", nullable = true, length = ColumnLength.SHORT)
    private String lastModifier;

    @Column(name = "ModificationDate", nullable = true)
    private Date modificationDate;

    /**
     * Constructor without parameters.
     */
    public SolutionCandidate()
    {
        decided = 0;
        creationDate = new Date();
        modificationDate = new Date();
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Solution getSolution()
    {
        return solution;
    }

    public void setSolution(Solution solution)
    {
        this.solution = solution;
    }

    public Decision getDecision()
    {
        return decision;
    }

    public void setDecision(Decision decision)
    {
        this.decision = decision;
    }

    public String getEvaluation()
    {
        return evaluation;
    }

    public void setEvaluation(String evaluation)
    {
        this.evaluation = evaluation;
    }

    public Integer getDecided()
    {
        return decided;
    }

    public void setDecided(Integer decided)
    {
        this.decided = decided;
    }

    public String getCreator()
    {
        return creator;
    }

    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    public Date getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(Date creationDate)
    {
        this.creationDate = creationDate;
    }

    public String getLastModifier()
    {
        return lastModifier;
    }

    public void setLastModifier(String lastModifier)
    {
        this.lastModifier = lastModifier;
    }

    public Date getModificationDate()
    {
        return modificationDate;
    }

    public void setModificationDate(Date modificationDate)
    {
        this.modificationDate = modificationDate;
    }

    @Override
    public int hashCode()
    {
        int result;
        if (getId() == null)
        {
            result = 0;
        }
        else
        {
            result = getId().hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        SolutionCandidate other = (SolutionCandidate) obj;
        if (other.getId() == null || this.getId() == null)
        {
            return false;
        }
        return other.getId().equals(this.getId());
    }
}
