/**
 * @author Oliver
 *
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;