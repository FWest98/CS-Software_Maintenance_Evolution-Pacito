package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.metric;

import java.util.List;

import javassist.NotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

/**
 * This interface describes a service intended to provide data suitable for
 * display in the UI. <br>
 * Metric- and Element services are wrapped here
 * 
 * @author 1fechner
 */
public interface MetricComponentService
{
    /**
     * Returns all root-elements for the given project.
     * 
     * @param projectid The project the root-element is to be returned
     * 
     * @return A list of root-elements. Empty if there is no data or no
     *         root-element
     * 
     * @throws NotFoundException if there is no root-element to be found
     */
    Element getRootElementForProjectid(int projectId) throws NotFoundException;

    /**
     * Returns all identifiers associated with the given type. <br>
     * These identifiers are to be sorted according to the order defined in the
     * database
     * 
     * @param projectId The Id of the project to be filtered by
     * @param type The type to be filtered by
     * 
     * @return A list of identifiers
     * 
     * @throws NotFoundException If the given type does not exist
     */
    List<Metric> getMetricsByType(int projectId, MetricType type) throws NotFoundException;

    /**
     * Returns a list of <code>MetricValue</code>s associated with the given
     * project, type and subtype. <br>
     * These are to be sorted according to the order defined in the database.
     * 
     * @param projectId The project to be filtered by
     * @param type The type to be filtered by
     * @param subtype The subtype to be filtered by
     * 
     * @return A list of MetricValues filtered by the given criteria
     * 
     * @throws NotFoundException If the given type or subtype doesn't exist
     */
    List<MetricValue> getMetricsByTypeAndSubtype(int projectId, MetricType type, MetricSubType subtype)
            throws NotFoundException;

    /**
     * A list of MetricValues for the Element specified, filtered by the given
     * Type. <br>
     * These are to be sorted according to the order defined in the database.
     * 
     * @param elementid The unique Id of the element
     * 
     * @param type The type of elements to be filtered by
     * 
     * @return A list of MetricValues for the Element specified in
     * 
     * @throws NotFoundException If the given subtype does not exist
     */
    List<MetricValue> getMetricValuesForElement(long elementId, MetricType type) throws NotFoundException;

}
