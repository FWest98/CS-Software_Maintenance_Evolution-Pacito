package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.AnalysisFileFormat;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.Importer;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ImporterFactory;

/**
 * UploadService to connect uploaded file in front end and input processing.
 * 
 * @author 1vietor
 * */
@Service
@Transactional
public class UploadProcessingServiceImpl implements UploadProcessingService
{
    @Autowired
    private ImporterFactory importFactory;

    @Override
    public boolean processAnalysisResult(Integer projectId, String outputFormat, String filePath)
            throws AnalysisResultException
    {
        Importer importer = importFactory.getImporter(AnalysisFileFormat.valueOf(outputFormat));

        if(importer.validateFile(filePath)) {
            importer.importFile(projectId, filePath);
        }
        return true;
    }
}
