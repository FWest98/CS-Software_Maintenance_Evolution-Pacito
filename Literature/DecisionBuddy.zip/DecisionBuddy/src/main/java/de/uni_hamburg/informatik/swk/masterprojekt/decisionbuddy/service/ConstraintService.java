package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.Comparator;
import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ConstraintNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ConstraintPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * 
 * Overview of interface of class ConstraintService.
 * 
 * @see architectural specification
 * 
 * @author Lucas, schaak
 *
 */
public interface ConstraintService
{
    /**
     * Find a Constraint by a given id.
     * 
     * @param id The id of the desired Constraint.
     * 
     * @return The matching Constraint.
     * 
     * @throws ConstraintNotFoundException Exception if Constraint is not found.
     */
    Constraint getConstraintById(long id) throws ConstraintNotFoundException;

    /**
     * Delete a Constraint with the given id.
     * 
     * @param id The id of the constraint to be deleted
     * 
     * @throws ConstraintNotFoundException Exception if Constraint is not found.
     */
    void deleteConstraint(long id) throws ConstraintNotFoundException;

    /**
     * Delete a ConstraintElement with the given id.
     * 
     * @param id The id of the constraint element to be deleted
     * 
     */
    void deleteConstraintElement(long id);

    /**
     * Assigns a List of Constraints to an Issue and adds it to the database.
     * 
     * @param constraintlist the constraints to be added.
     * @param issue The issue to which the Constraints should be added.
     * 
     * @throws ConstraintPersistenceException Exception if Constraint could not
     *             be persisted.
     * @throws IssuePersistenceException Exception if Issue could not be
     *             persisted.
     * @throws IssueNotFoundException Exception if the Issue is not found.
     */
    void assignToIssueAndSave(List<Constraint> constraintlist, Issue issue) throws ConstraintPersistenceException,
            IssuePersistenceException, IssueNotFoundException, CommentPersistenceException;

    /**
     * Assigns a Constraintlist to a Solution and adds it to the database.
     * 
     * @param constraintlist the constraintlist to be added.
     * @param solution The Solution to which the Constraints should be added.
     * 
     * @throws ConstraintPersistenceException Exception if Constraint could not
     *             be persisted.
     * @throws SolutionPersistenceException Exception if Solution could not be
     *             persisted.
     * @throws SolutionNotFoundException Exception if the Solution is not found.
     */
    void assignToSolutionAndSave(List<Constraint> constraintlist, Solution solution)
            throws ConstraintPersistenceException, SolutionPersistenceException, SolutionNotFoundException;

    /**
     * Get a list of constraints that belong to the given Issue.
     * 
     * @param issueId The id for the Issue to get the constraints for.
     * 
     * @return List of all constraints that belong to issue.
     * 
     * @throws IssueNotFoundException Exception if the Issue is not found.
     */
    List<Constraint> getConstraintsForIssue(long issueId) throws IssueNotFoundException;

    /**
     * Get a list of constraints that belong to the given Solution.
     * 
     * @param solutionId The id for the Solution to get the constraints for.
     * 
     * @return List of all constraints that belong to solution.
     * 
     * @throws SolutionNotFoundException Exception if the Solution is not found.
     */
    List<Constraint> getConstraintsForSolution(long solutionId) throws SolutionNotFoundException;

    /**
     * Get a list of constraints, given a Filter and a Sorter.
     * 
     * @see Filter
     * @see Comparator
     * 
     * @param filter a Filter object to reduce the result set
     * @param sorter a Sorter object to arrange the result items by criteria
     * 
     * @return List of constraints
     */
    List<Constraint> getConstraintsByCriteria(Filter<Constraint> filter, Comparator<Constraint> sorter);
}
