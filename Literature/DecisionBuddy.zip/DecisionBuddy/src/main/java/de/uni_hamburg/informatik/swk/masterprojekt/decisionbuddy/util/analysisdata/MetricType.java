package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

public enum MetricType
{
    Global, Structural, Additional, Other
}
