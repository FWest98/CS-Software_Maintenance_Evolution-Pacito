package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans;

import java.io.Serializable;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

/**
 * Builds and returns a collection of menu items for specific action.
 * 
 * @author schaak
 *
 */
@Component
public class MenuManager implements Serializable
{
    private static final long serialVersionUID = 1L;
    private ArrayList<MenuItem> menu;

    /**
     * Constructor to create Manager.
     */
    public MenuManager()
    {
        menu = new ArrayList<MenuItem>();
    }

    /**
     * Returns a collection of MenuItems for specific action.
     * 
     * @param action the action you want to generate a menu for
     * @param idList additional attributes which are sometimes needed
     * @return menu a collection of menu items according to action
     */
    public ArrayList<MenuItem> getMenu(String action, ArrayList<String> idList)
    {
        menu = new ArrayList<MenuItem>();

        if (action.equals("showsolutions")) // View: Catalog
        {
            addSolution();
        }
        else if (action.equals("solutionprofile"))
        {
            addSolution();
            editSolution(idList.get(0));
            deleteSolution(idList.get(0));
            addRating(idList.get(0));

        }
        else if (action.equals("addsolution"))
        {
            clearMenu();
        }
        else if (action.equals("editsolution"))
        {
            clearMenu();
        }
        else if (action.equals("deletesolution"))
        {
            clearMenu();
        }
        else if (action.equals("showprojects")) // View: Project
        {
            addProject();
        }
        else if (action.equals("projectprofile"))
        {
            addProject();
            addIssue(idList.get(0));
            uploadAD(idList.get(0));
            editProject(idList.get(0));
            deleteProject(idList.get(0));
        }
        else if (action.equals("addproject"))
        {
            clearMenu();
        }
        else if (action.equals("uploadad"))
        {
            clearMenu();
        }
        else if (action.equals("editproject"))
        {
            clearMenu();
        }
        else if (action.equals("deleteproject"))
        {
            clearMenu();
        }
        else if (action.equals("issueprofile"))
        {
            addIssue(idList.get(1));
            editIssue(idList.get(1), idList.get(0));
            deleteIssue(idList.get(1), idList.get(0));
            addAddComment(idList.get(1), idList.get(0));
        }
        else if (action.equals("addissue"))
        {
            clearMenu();
        }
        else if (action.equals("editissue"))
        {
            clearMenu();
        }
        else if (action.equals("deleteissue"))
        {
            clearMenu();
        }
        else if (action.equals("showtechnicalterms")) // View: Constraint
        {
            addTechnicalTerm();
        }
        else if (action.equals("technicaltermprofile"))
        {
            addTechnicalTerm();
            editTechnicalTerm(idList.get(0));
            deleteTechnicalTerm(idList.get(0));
        }
        else if (action.equals("addtechnicalterm"))
        {
            clearMenu();
        }
        else if (action.equals("edittechnicalterm"))
        {
            clearMenu();
        }
        else if (action.equals("deletetechnicalterm"))
        {
            clearMenu();
        }
        else if (action.equals("showusers")) // View: User
        {
            addUsers();
        }
        else if (action.equals("userprofile"))
        {
            addUsers();
            editUser(idList.get(0));
            deleteUser(idList.get(0));
        }
        else if (action.equals("adduser"))
        {
            clearMenu();
        }
        else if (action.equals("edituser"))
        {
            clearMenu();
        }
        else if (action.equals("deleteuser"))
        {
            clearMenu();
        }

        return menu;
    }

    /**
     * Catalog view. Helper method for adding MenuItem 'Add Solution' to Menu.
     */
    public void addSolution()
    {
        menu.add(new MenuItem("catalog.addsolution", "/catalog/add", "add.png"));
    }

    /**
     * Catalog view. Helper method for adding MenuItem 'Add Rating' to Menu.
     */
    public void addRating(String id)
    {
        menu.add(new MenuItem("catalog.addrating", "/catalog/solution/" + id + "/rating/add", "add.png"));
    }

    /**
     * Catalog view. Helper method for adding MenuItem 'Edit solution' to Menu.
     * 
     * @param id ID of solution to be edited
     */
    public void editSolution(String id)
    {
        MenuItem menuItem = new MenuItem("catalog.editsolution", "/catalog/edit/" + id, "edit.png");
        menu.add(menuItem);
    }

    /**
     * Catalog view. Helper method for adding MenuItem 'Delete solution' to
     * Menu.
     * 
     * @param id ID of solution to be deleted
     */
    public void deleteSolution(String id)
    {
        MenuItem menuItem = new MenuItem("catalog.deletesolution", "/catalog/delete/" + id, "delete.png");
        menu.add(menuItem);
    }

    /**
     * Project view. Helper method for adding MenuItem 'Add Project' to Menu.
     */
    public void addProject()
    {
        menu.add(new MenuItem("project.addproject", "/project/add", "add.png"));
    }

    /**
     * Project view. Helper method for adding MenuItem 'Uplad data' to Menu.
     * 
     * @param id ID of project to be edited
     */
    public void uploadAD(String id)
    {
        MenuItem menuItem = new MenuItem("project.uploadad", "/project/" + id + "/analysisdata/add", "upload.png");
        menu.add(menuItem);
    }

    /**
     * Project view. Helper method for adding MenuItem 'Edit project' to Menu.
     * 
     * @param id ID of project to be edited
     */
    public void editProject(String id)
    {
        MenuItem menuItem = new MenuItem("project.editproject", "/project/edit/" + id, "edit.png");
        menu.add(menuItem);
    }

    /**
     * Project view. Helper method for adding MenuItem 'Delete project' to Menu.
     * 
     * @param id ID of project to be deleted
     */
    public void deleteProject(String id)
    {
        MenuItem menuItem = new MenuItem("project.deleteproject", "/project/delete/" + id, "delete.png");
        menu.add(menuItem);
    }

    /**
     * Project view. Helper method for adding MenuItem 'Add Issue' to Menu.
     * 
     * @param projectId ID of project of issue
     */
    public void addIssue(String projectId)
    {
        menu.add(new MenuItem("project.addissue", "/project/project/" + projectId + "/issue/add", "add.png"));
    }

    /**
     * Project view. Helper method for adding MenuItem 'Add Comment' to Menu.
     */
    public void addAddComment(String projectId, String id)
    {
        menu.add(new MenuItem("project.addcomment", "/project/project/" + projectId + "/issue/" + id + "/comment/add",
                "add.png"));
    }

    /**
     * Project view. Helper method for adding MenuItem 'Edit issue' to Menu.
     * 
     * @param projectId ID of project of issue
     * @param id ID of issue to be edited
     */
    public void editIssue(String projectId, String id)
    {
        MenuItem menuItem = new MenuItem("project.editissue", "/project/project/" + projectId + "/issue/edit/" + id,
                "edit.png");
        menu.add(menuItem);
    }

    /**
     * Project view. Helper method for adding MenuItem 'Delete issue' to Menu.
     * 
     * @param projectId ID of project of issue
     * @param id ID of issue to be deleted
     */
    public void deleteIssue(String projectId, String id)
    {
        MenuItem menuItem = new MenuItem("project.deleteissue",
                "/project/project/" + projectId + "/issue/delete/" + id, "delete.png");
        menu.add(menuItem);
    }

    /**
     * Constraint view. Helper method for adding MenuItem 'Add TechnicalTerm' to
     * Menu.
     */
    public void addTechnicalTerm()
    {
        menu.add(new MenuItem("constraint.addtechnicalterm", "/constraint/add", "add.png"));
    }

    /**
     * Constraint view. Helper method for adding MenuItem 'Edit TechnicalTerm'
     * to Menu.
     * 
     * @param id ID of technicalterm to be edited
     */
    public void editTechnicalTerm(String id)
    {
        MenuItem menuItem = new MenuItem("constraint.edittechnicalterm", "/constraint/edit/" + id, "edit.png");
        menu.add(menuItem);
    }

    /**
     * Constraint view. Helper method for adding MenuItem 'Delete TechnicalTerm'
     * to Menu.
     * 
     * @param id ID of technicalterm to be deleted
     */
    public void deleteTechnicalTerm(String id)
    {
        MenuItem menuItem = new MenuItem("constraint.deletetechnicalterm", "/constraint/delete/" + id, "delete.png");
        menu.add(menuItem);
    }

    /**
     * User view. Helper method for adding MenuItem 'Add User' to Menu.
     */
    private void addUsers()
    {
        menu.add(new MenuItem("user.adduser", "/user/add", "add.png"));
    }

    /**
     * User view. Helper method for adding MenuItem 'Edit User' to Menu.
     * 
     * @param username username of User to be edited
     */
    private void editUser(String username)
    {
        MenuItem menuItem = new MenuItem("user.edituser", "/user/edit/" + username, "edit.png");
        menu.add(menuItem);
    }

    /**
     * User view. Helper method for deleting MenuItem 'Delete User' to Menu.
     * 
     * @param username
     */
    private void deleteUser(String username)
    {
        MenuItem menuItem = new MenuItem("user.deleteuser", "/user/delete/" + username, "delete.png");
        menu.add(menuItem);
    }

    /**
     * Helper method for removing all MenuItems from Menu.
     */
    public void clearMenu()
    {
        menu.clear();
    }

    /**
     * Convenience method for compability - to be removed later.
     * 
     * @param action action
     * @return menu List of MenuItems
     * @see getMenu(String action, String id)
     */
    public ArrayList<MenuItem> getMenu(String action)
    {
        ArrayList<String> list = new ArrayList<String>();
        list.add("0");
        return getMenu(action, list);
    }
}