package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;

/**
 * UploadService to connect uploaded file in front end and input processing.
 * 
 * @author 1fechner
 */
public interface UploadProcessingService
{
    /**
     * Process an uploaded analysis result.
     * 
     * @param projectId The id of the project the results belong to
     * @param outputFormat The output format the given file is supposed to have,
     *            specified by user. There is NO GUARANTEE the file actually has
     *            the given output type
     * @param filePath Path the file uploaded is to be found at.
     * 
     * @return True if file was uploaded and parsed correctly, false else
     * @throws AnalysisResultException
     */
    boolean processAnalysisResult(Integer projectId, String outputFormat, String filePath)
            throws AnalysisResultException;
}
