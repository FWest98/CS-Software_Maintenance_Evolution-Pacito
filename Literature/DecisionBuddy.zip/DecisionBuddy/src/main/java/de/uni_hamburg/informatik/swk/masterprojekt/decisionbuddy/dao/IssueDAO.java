package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;

/**
 * A DAO class for Issue.
 * 
 * @author Vlad
 *
 */
public interface IssueDAO extends JpaRepository<Issue, Long>
{
    /**
     * Find all issues belonging to a project.
     * 
     * @param projectId the project for which u want to find the Issues
     * @return all issues belonging to that project
     */
    List<Issue> findByProjectId(Long projectId);
}
