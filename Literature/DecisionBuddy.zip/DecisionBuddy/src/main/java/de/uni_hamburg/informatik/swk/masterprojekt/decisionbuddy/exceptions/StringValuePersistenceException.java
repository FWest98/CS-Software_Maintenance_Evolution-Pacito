package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a string value could not be written to
 * the database.
 * 
 * @author schaak
 * 
 */
public class StringValuePersistenceException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public StringValuePersistenceException()
    {
        setExceptionType("stringvaluepersistence");
    }
}
