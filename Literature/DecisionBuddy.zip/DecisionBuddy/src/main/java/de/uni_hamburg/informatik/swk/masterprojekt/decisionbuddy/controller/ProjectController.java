package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxFailure;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxFailureItem;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxResponse;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxSuccess;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueProjectMismatchException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DynamicEntities;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StaticEntities;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.CommentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.IssueService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.SolutionService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.TechnicalTermService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.designpattern.DesignPatternComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.framework.FrameworkComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.metric.MetricComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorizationConstants;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ComparatorFactory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ConstraintEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.DateEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.DecisionEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.HelperFunctions;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.IntegerEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.IssueEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Paginator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ProjectEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.QualityGoalEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.SolutionConstraintFilter;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.SolutionRater;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.StringValueEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.TechnicalTermEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.CommentValidator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.IssueValidator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.ProjectValidator;

/**
 * This controller is responsible for managing the project view.
 * 
 * @author schaak
 *
 */
@Controller
// Read authorities only need to be granted here because all requests that
// concern /project are mapped here. Write request authorities need to be
// specified in the according methods.
@PreAuthorize(AuthorizationConstants.PROJECT_READ)
@RequestMapping(value = "/project")
public class ProjectController
{
    @Autowired
    private Paginator<Project>            paginationHelper;

    @Autowired
    private ProjectService                projectService;

    @Autowired
    private IssueService                  issueService;

    @Autowired
    private SolutionRater                 solutionRater;

    @Autowired
    private SolutionService               solutionService;

    @Autowired
    private TechnicalTermService          technicalTermService;

    @Autowired
    private MetricComponentService        metricComponentService;

    @Autowired
    private DesignPatternComponentService designpatternComponentService;

    @Autowired
    private FrameworkComponentService     frameworkComponentService;

    @Autowired
    private CommentService                commentService;

    @Autowired
    private HelperFunctions               helperFunctions;

    @Autowired
    private StaticEntities                staticEntities;

    @Autowired
    private DynamicEntities               dynamicEntities;

    @Autowired
    private ProjectValidator              projectValidator;

    @Autowired
    private IssueValidator                issueValidator;

    @Autowired
    private CommentValidator              commentValidator;

    @Autowired
    private MessageSource                 messageSource;

    /**
     * Called before binding between input and model fields.
     * 
     * @param binder
     *            the binder instance
     */
    @InitBinder
    private void initBinder(WebDataBinder binder)
    {
        // Integer <-> String
        binder.registerCustomEditor(Integer.class, new IntegerEditor());

        // Project <-> String
        binder.registerCustomEditor(Project.class, new ProjectEditor());

        // Issue <-> String
        binder.registerCustomEditor(Issue.class, new IssueEditor());

        // Constraint <-> String
        binder.registerCustomEditor(Constraint.class, new ConstraintEditor());

        // StringValue <-> String
        binder.registerCustomEditor(StringValue.class, new StringValueEditor());

        // TechnicalTerm <-> String
        binder.registerCustomEditor(TechnicalTerm.class, new TechnicalTermEditor());

        // QualityGoal <-> String
        binder.registerCustomEditor(QualityGoal.class, new QualityGoalEditor());

        // Decision <-> String
        binder.registerCustomEditor(Decision.class, new DecisionEditor());

        // Date <-> String
        binder.registerCustomEditor(Date.class, new DateEditor());
    }

    /******************************************************************
     * 
     * SHOW PROJECTS
     * 
     *****************************************************************/

    /**
     * Shows a list of current projects..
     * 
     * @param page
     *            which page in project list should be returned (optional)
     * @param pageSize
     *            how many projects should be shown (optional)
     * @param filter
     *            specifies if the projects should be filtered (optional)
     * @param sorter
     *            specifies how the projects should be sorted (optional)
     * 
     * @return view for listing projects.
     * @throws SorterFieldNotFoundException
     *             sorting field is not found
     * @throws SorterInvalidTypeException
     *             sorting field type is invalid
     */
    @RequestMapping(value = { "", "/", "/list" })
    public ModelAndView listOfProjects(@RequestParam(value = "page", required = false) String page,
            @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "filter", required = false) String filter,
            @RequestParam(value = "sorter", required = false) String sorter)
                    throws SorterFieldNotFoundException, SorterInvalidTypeException
    {
        ModelAndView catalogView = new ModelAndView("index");

        // show projects.jsp
        catalogView.addObject("jsp", "projects");

        // get projects by sorting and filtering criteria
        Comparator<Project> projectComparator = new ComparatorFactory<Project>(Project.class)
                .generateComparator(sorter);

        List<Project> processedProjects = projectService.getProjectsByCriteria(null,
                projectComparator);

        // Configure pagination
        paginationHelper.configure(processedProjects, pageSize, page);

        // model entries
        catalogView.addObject("projectlist", paginationHelper.getPageList());
        catalogView.addObject("pagedListHolder", paginationHelper.getPagedListHolder());

        // get breadcrumbs and menu for action
        catalogView = helperFunctions.getBreadcrumbs("showprojects", catalogView);
        catalogView = helperFunctions.getMenu("showprojects", catalogView);

        return catalogView;
    }

    /******************************************************************
     * 
     * SHOW PROJECT PROFILE
     * 
     *****************************************************************/

    /**
     * Shows a specific project in profile view.
     * 
     * @param id
     *            ID of project to be displayed.
     * 
     * @return detailview of project
     * 
     * @throws ProjectNotFoundException
     *             exception if project is not found
     */
    @RequestMapping(value = "/project/{id}")
    public ModelAndView projectProfile(@PathVariable Integer id) throws ProjectNotFoundException
    {
        ModelAndView projectView = new ModelAndView("index");

        // get project from service
        Project project = projectService.getProjectById(id);

        // get issues for project
        List<Issue> issueList = issueService.getIssuesByProjectID(project.getId());

        // get root element for structural metrics
        Element rootElement = null;

        try
        {
            rootElement = metricComponentService.getRootElementForProjectid(id);
        }
        catch (Exception e)
        {
            // TODO Log Exceptions
        }
        // project metrics for three categories
        List<MetricValue> globalmetricsstruct;
        List<MetricValue> globalmetricscycl;
        List<MetricValue> globalmetricsother;

        // patterns for project
        List<ElementDesignPattern> globaldesignpattern;

        // frameworks for project
        List<ElementFramework> globalframework;

        // frameworks for project without package link
        List<ElementFramework> globalframeworkPackageless;
        
        List<Metric> relevantMetrics;

        // get the list of metric values for the root element of our project
        List<MetricValue> rootMetricValues;

        try
        {
            // get global metrics for Structure
            globalmetricsstruct = metricComponentService.getMetricsByTypeAndSubtype(id,
                    MetricType.Global, MetricSubType.Structure);

            // get global metrics for Cyclicity
            globalmetricscycl = metricComponentService.getMetricsByTypeAndSubtype(id,
                    MetricType.Global, MetricSubType.Cyclicity);

            // get global metrics for Dependencies
            globalmetricsother = metricComponentService.getMetricsByTypeAndSubtype(id,
                    MetricType.Global, MetricSubType.Other);

            // get the list of metrics to show in structural section
            relevantMetrics = metricComponentService.getMetricsByType(id, MetricType.Structural);

            rootMetricValues = metricComponentService.getMetricValuesForElement(rootElement.getId(),
                    MetricType.Structural);
        }

        catch (Exception e)
        {
            globalmetricsstruct = new ArrayList<>();
            globalmetricscycl = new ArrayList<>();
            globalmetricsother = new ArrayList<>();

            relevantMetrics = new ArrayList<>();

            rootMetricValues = new ArrayList<>();
        }

        // get the list of project patterns to show in patterns tab
        try
        {
            globaldesignpattern = designpatternComponentService
                    .getDesignPatternsForProject((long) id, ElementType.Package);
        }
        catch (Exception e)
        {
            globaldesignpattern = new ArrayList<>();
        }

        // get the list of project frameworks to show in frameworks tab
        try
        {
            globalframework = frameworkComponentService.getFrameworksForProject((long) id,
                    ElementType.Package);
        }
        catch (Exception e)
        {
            globalframework = new ArrayList<>();
        }
        
        // get the list of project frameworks to show in frameworks tab
        try
        {
            globalframeworkPackageless = frameworkComponentService.getFrameworksForProject((long) id,
                    ElementType.Undefined);
        }
        catch (Exception e)
        {
        	globalframeworkPackageless = new ArrayList<>();
        }

        // get metrics for project
        // TODO Use DAO an actual metric object
        // List<MetricValue> metricList =
        // metricCandidateService.getMetricsByProjectID(project.getId());

        // fill model
        projectView.addObject("jsp", "addproject");
        projectView.addObject("viewmode", "view");
        projectView.addObject("project", project);
        projectView.addObject("issuelist", issueList);
        projectView.addObject("rootelement", rootElement);
        projectView.addObject("globalmetricsstruct", globalmetricsstruct);
        projectView.addObject("globalmetricscycl", globalmetricscycl);
        projectView.addObject("globalmetricsother", globalmetricsother);
        projectView.addObject("globaldesignpattern", globaldesignpattern);
        projectView.addObject("globalframework", globalframework);
        projectView.addObject("globalframeworkPackageless", globalframeworkPackageless);
        projectView.addObject("tabindex", "1");
        projectView.addObject("relevantmetrics", relevantMetrics);
        projectView.addObject("rootmetricvalues", rootMetricValues);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        projectView = helperFunctions.getBreadcrumbs("projectprofile", list, projectView);

        // get menu for action
        projectView = helperFunctions.getMenu("projectprofile", list, projectView);

        return projectView;
    }

    /******************************************************************
     * 
     * ADD PROJECT
     * 
     *****************************************************************/

    /**
     * Shows the mask for adding a new project. Generic method.
     * 
     * @param previousModel
     *            needed to conserve bindingResult and validation of former
     *            project
     * 
     * @return view/mask for adding a project
     * 
     * @throws ProjectNotFoundException
     *             exception if project is not found
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public ModelAndView addProjectPage(Model previousModel) throws ProjectNotFoundException
    {
        Project project;

        ModelAndView projectView = new ModelAndView("index");

        // check if project object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("project"))
        {
            project = (Project) previousModel.asMap().get("project");

        }
        else
        {
            // default: no previous project is available
            project = new Project();

            // get issues for project
            List<Issue> issueList;
            issueList = new ArrayList<Issue>();
            projectView.addObject("issuelist", issueList);
        }

        // fill model
        projectView.addObject("jsp", "addproject");
        projectView.addObject("viewmode", "add");
        projectView.addObject("project", project);

        // get breadcrumbs for action
        projectView = helperFunctions.getBreadcrumbs("addproject", projectView);

        // get menu for action
        projectView = helperFunctions.getMenu("addproject", projectView);

        return projectView;
    }

    /**
     * General method for adding a Project.
     * 
     * @param project
     *            the project object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param tabindex
     *            the desired tab
     * @param redirectAttrs
     *            needed to save values during redirects
     * 
     * @return stays on mask to add a project and shows a success/failure
     *         message.
     * 
     * @throws ProjectPersistenceException
     *             exception if project could not be saved
     * 
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addingProject(@ModelAttribute("project") Project project,
            BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws ProjectPersistenceException
    {
        // validate project
        projectValidator.validate(project, bindingResult);

        // finalize
        helperFunctions.finalizeUserEditable(project);

        // determine if the project is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("project", project);
            redirectAttrs.addFlashAttribute("org.springframework.validation.BindingResult.project",
                    bindingResult);
            redirectAttrs.addFlashAttribute("tabindex", tabindex);
        }
        else
        {
            Project savedProject;

            // persist project
            savedProject = projectService.saveProject(project);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "addproject.success");

            List<String> params = new ArrayList<String>();
            params.add(savedProject.getName());
            params.add(String.valueOf(savedProject.getId()));
            redirectAttrs.addFlashAttribute("messageparams", params);
        }

        return "redirect:/project/add";
    }

    /******************************************************************
     * 
     * EDIT PROJECT
     * 
     *****************************************************************/

    /**
     * Shows the mask for editing a project. Generic method.
     * 
     * @param id
     *            the id of the project to be edited
     * @param previousModel
     *            needed to conserve bindingResult and validation of former
     *            project
     * 
     * @return view/mask for editing a project
     * 
     * @throws ProjectNotFoundException
     *             exception if project is not found
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
    public ModelAndView editProjectPage(@PathVariable Integer id, Model previousModel)
            throws ProjectNotFoundException
    {
        ModelAndView projectView = new ModelAndView("index");

        // check if project object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (!previousModel.containsAttribute("project"))
        {
            Project project = projectService.getProjectById(id);
            projectView.addObject("project", project);

            // get issues for project
            List<Issue> issueList = issueService.getIssuesByProjectID(project.getId());
            projectView.addObject("issuelist", issueList);
        }

        // fill model
        projectView.addObject("jsp", "addproject");
        projectView.addObject("viewmode", "edit");

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        projectView = helperFunctions.getBreadcrumbs("editproject", list, projectView);

        // get menu for action
        projectView = helperFunctions.getMenu("editproject", list, projectView);

        return projectView;
    }

    /**
     * General method for editing a Project.
     * 
     * @param project
     *            the project object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param tabindex
     *            the desired tab index
     * @param redirectAttrs
     *            needed to save values during redirects
     * 
     * @return stays on mask to edit a project and shows a success/failure
     *         message.
     * 
     * @throws ProjectPersistenceException
     *             exception if project could not be saved
     * @throws ProjectNotFoundException
     *             exception if project is not found
     * 
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public String editingProject(@ModelAttribute("project") Project project,
            BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs)
                    throws ProjectPersistenceException, ProjectNotFoundException
    {
        // validate project
        projectValidator.validate(project, bindingResult);

        // determine if the edited project is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("org.springframework.validation.BindingResult.project",
                    bindingResult);
        }
        else
        {
            // finalize
            helperFunctions.finalizeUserEditable(project);

            // persist project
            projectService.saveProject(project);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "editproject.success");
        }

        // fill redirect model
        List<String> params = new ArrayList<String>();
        params.add(project.getName());
        params.add(String.valueOf(project.getId()));
        redirectAttrs.addFlashAttribute("messageparams", params);

        redirectAttrs.addFlashAttribute("project", project);
        redirectAttrs.addFlashAttribute("tabindex", tabindex);

        // get issues for project
        List<Issue> issueList = issueService.getIssuesByProjectID(project.getId());
        redirectAttrs.addFlashAttribute("issuelist", issueList);

        redirectAttrs.addAttribute("id", project.getId());
        return "redirect:/project/edit/{id}";
    }

    /**
     * Process of editing a Project inline. Triggers when Project is edited
     * inline.
     * 
     * @param project
     *            the project object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * 
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws ProjectPersistenceException
     *             exception if project could not be saved
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/editinline", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingProjectInline(
            @ModelAttribute("project") Project project, BindingResult bindingResult)
                    throws ProjectPersistenceException
    {
        // validate project
        projectValidator.validate(project, bindingResult);

        // determine if success or failure
        if (bindingResult.hasErrors())
        {
            Locale locale = LocaleContextHolder.getLocale();
            AjaxFailure ajaxFailure = new AjaxFailure();

            // parse every occured error into AjaxFailure object
            for (ObjectError error : bindingResult.getAllErrors())
            {
                AjaxFailureItem ajaxFailureItem = new AjaxFailureItem();

                ajaxFailureItem.setErrorCode(error.getCodes()[0]);
                ajaxFailureItem.setErrorArguments(error.getArguments());

                String message = "";
                try
                {
                    message = messageSource.getMessage(error.getCodes()[0], error.getArguments(),
                            locale);
                }
                catch (NoSuchMessageException e)
                {
                    message = "The data you entered seems to be invalid.";
                }
                ajaxFailureItem.setErrorMessage(message);

                FieldError fieldError = (FieldError) error;

                ajaxFailureItem.setErrorFieldName(fieldError.getField());
                ajaxFailure.addAjaxFailureItem(ajaxFailureItem);
            }

            return ajaxFailure;
        }
        else
        {
            // finalize
            helperFunctions.finalizeUserEditable(project);

            // persist project
            projectService.saveProject(project);

            // return ajax success object
            AjaxSuccess ajaxSuccess = new AjaxSuccess();
            ajaxSuccess.setLastModifier(project.getLastModifier());
            Format format = new SimpleDateFormat("yyyy-MM-dd, HH:mm:ss");
            ajaxSuccess.setModificationDate(format.format((Date) project.getModificationDate()));

            return ajaxSuccess;
        }
    }

    /******************************************************************
     * 
     * DELETE PROJECT
     * 
     *****************************************************************/

    /**
     * Shows a project which is about to be deleted.
     * 
     * @param id
     *            ID of project to be deleted
     * 
     * @return detailview of project to be deleted
     * 
     * @throws ProjectNotFoundException
     *             exception if project is not found
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public ModelAndView deleteProjectPage(@PathVariable Integer id) throws ProjectNotFoundException
    {
        ModelAndView projectView = new ModelAndView("index");

        // get project from service
        Project project = projectService.getProjectById(id);

        // get issues for project
        List<Issue> issueList = issueService.getIssuesByProjectID(project.getId());

        // fill model
        projectView.addObject("jsp", "addproject");
        projectView.addObject("viewmode", "delete");
        projectView.addObject("project", project);
        projectView.addObject("issuelist", issueList);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        projectView = helperFunctions.getBreadcrumbs("deleteproject", list, projectView);

        // get menu for action
        projectView = helperFunctions.getMenu("deleteproject", list, projectView);

        return projectView;
    }

    /**
     * Deletes a project.
     * 
     * @param id
     *            ID of project to be deleted
     * @param redirectAttrs
     *            needed to save values during redirects
     * 
     * @return show projects view
     * 
     * @throws ProjectNotFoundException
     *             exception if project is not found
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    public String deletingProject(@PathVariable Integer id, RedirectAttributes redirectAttrs)
            throws ProjectNotFoundException
    {
        // delete project
        projectService.deleteProject(id);

        // fill redirect model
        redirectAttrs.addFlashAttribute("messagestatus", "success");
        redirectAttrs.addFlashAttribute("messagecode", "deleteproject.success");

        List<String> params = new ArrayList<String>();
        params.add(String.valueOf(id));
        redirectAttrs.addFlashAttribute("messageparams", params);

        return "redirect:/project/list";
    }

    /******************************************************************
     * 
     * SHOW ISSUE PROFILE
     * 
     *****************************************************************/

    /**
     * Shows a specific issue in profile view.
     * 
     * @param id
     *            ID of issue to be displayed.
     * @param projectId
     *            ID of project the issue belongs to
     * 
     * @return detailview of issue
     * 
     * @throws IssueNotFoundException
     *             exception if issue is not found
     * @throws ProjectNotFoundException
     *             exception if project is not found
     * @throws IssueProjectMismatchException
     *             exception if ids dont match
     */
    @RequestMapping(value = "/project/{projectId}/issue/{id}")
    public ModelAndView issueProfile(@PathVariable Integer projectId, @PathVariable Integer id)
            throws IssueNotFoundException, ProjectNotFoundException, IssueProjectMismatchException
    {
        ModelAndView projectView = new ModelAndView("index");

        // get issue from service
        Issue issue = issueService.getIssueById(id);

        // get comments for issue
        List<Comment> comments = commentService.getCommentsByIssueID(issue.getId());
        Collections.sort(comments, Comment.getDateComprator());
        projectView.addObject("commentlist", comments);

        // get project from service
        Project project = projectService.getProjectById(projectId);

        // check if issue belongs to provided project
        if (!project.getId().equals(issue.getProject().getId()))
        {
            throw new IssueProjectMismatchException();
        }

        // fill model
        projectView.addObject("jsp", "addissue");
        projectView.addObject("viewmode", "view");
        projectView.addObject("issue", issue);
        projectView.addObject("tabindex", 1);
        projectView.addObject("recommendations", getRecommendations(issue));

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        list.add(project.getId().toString());

        projectView = helperFunctions.getBreadcrumbs("issueprofile", list, projectView);

        // get menu for action
        projectView = helperFunctions.getMenu("issueprofile", list, projectView);

        return projectView;
    }

    /******************************************************************
     * 
     * ADD ISSUE
     * 
     *****************************************************************/

    /**
     * Shows the mask for adding a new issue. Generic method.
     * 
     * @param previousModel
     *            needed to conserve bindingResult and validation of former
     *            issue
     * @param projectId
     *            id of project that issue should belong to
     * 
     * @return view/mask for adding an issue
     * 
     * @throws IssueNotFoundException
     *             exception if issue is not found
     * @throws ProjectNotFoundException
     *             exception if project is not found
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/project/{projectId}/issue/add", method = RequestMethod.GET)
    public ModelAndView addIssuePage(@PathVariable Integer projectId, Model previousModel)
            throws IssueNotFoundException, ProjectNotFoundException
    {
        Issue issue;

        ModelAndView projectView = new ModelAndView("index");

        // get project from service
        Project project = projectService.getProjectById(projectId);

        // check if issue object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("issue"))
        {
            issue = (Issue) previousModel.asMap().get("issue");
        }
        else
        {
            // default: no previous project is available
            issue = new Issue();
        }

        // assign project to issue
        issue.setProject(project);

        // fill model
        projectView.addObject("jsp", "addissue");
        projectView.addObject("viewmode", "add");
        projectView.addObject("issue", issue);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(project.getId().toString());

        projectView = helperFunctions.getBreadcrumbs("addissue", list, projectView);

        // get menu for action
        projectView = helperFunctions.getMenu("addissue", list, projectView);

        return projectView;
    }

    /**
     * General method for adding an Issue.
     * 
     * @param issue
     *            the issue object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param tabindex
     *            the index of the desired tab
     * @param redirectAttrs
     *            needed to save values during redirects
     * @param projectId
     *            id of project that issue should belong to
     * 
     * @return stays on mask to add an issue and shows a success/failure
     *         message.
     * 
     * @throws IssuePersistenceException
     *             exception if issue could not be saved
     * @throws ProjectNotFoundException
     *             exception if project is not found
     * @throws TechnicalTermNotFoundException
     *             exception if tt is not found
     * 
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/project/{projectId}/issue/add", method = RequestMethod.POST)
    public String addingIssue(@PathVariable Integer projectId, @ModelAttribute("issue") Issue issue,
            BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs)
                    throws IssuePersistenceException, ProjectNotFoundException,
                    TechnicalTermNotFoundException, CommentPersistenceException

    {
        // validate issue
        validateIssue(issue, bindingResult);

        // finalize
        helperFunctions.finalizeUserEditable(issue);

        // get project from service
        projectService.getProjectById(projectId);

        // determine if the issue is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("issue", issue);
            redirectAttrs.addFlashAttribute("org.springframework.validation.BindingResult.issue",
                    bindingResult);
            redirectAttrs.addFlashAttribute("tabindex", tabindex);
        }
        else
        {
            // save issue
            issueService.saveIssue(issue);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "addissue.success");

            List<String> params = new ArrayList<String>();
            params.add(issue.getName());
            params.add(String.valueOf(issue.getId()));
            redirectAttrs.addFlashAttribute("messageparams", params);
        }

        redirectAttrs.addFlashAttribute("projectId", projectId);

        return "redirect:/project/project/{projectId}/issue/add";
    }

    /******************************************************************
     * 
     * EDIT ISSUE
     * 
     *****************************************************************/

    /**
     * Shows the mask for editing an issue. Generic method.
     * 
     * @param id
     *            the id of the issue to be edited
     * @param previousModel
     *            needed to conserve bindingResult and validation of former
     *            issue
     * @param projectId
     *            the id of the project the issue belongs to
     * 
     * @return view/mask for editing an issue
     * 
     * @throws IssueNotFoundException
     *             exception if issue is not found
     * @throws ProjectNotFoundException
     *             exception if project is not found
     * @throws IssueProjectMismatchException
     *             exception if project / issue dont match
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/project/{projectId}/issue/edit/{id}", method = RequestMethod.GET)
    public ModelAndView editIssuePage(@PathVariable Integer projectId, @PathVariable Integer id,
            Model previousModel) throws IssueNotFoundException, ProjectNotFoundException,
                    IssueProjectMismatchException
    {
        ModelAndView projectView = new ModelAndView("index");

        // get project from service
        Project project = projectService.getProjectById(projectId);

        // check if issue object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (!previousModel.containsAttribute("issue"))
        {
            Issue issue = issueService.getIssueById(id);
            issue.setProject(project);
            projectView.addObject("issue", issue);
            projectView.addObject("recommendations", getRecommendations(issue));

            List<Comment> comments = commentService.getCommentsByIssueID(issue.getId());
            projectView.addObject("commentlist", comments);

            // check if issue belongs to provided project
            if (!project.getId().equals(issue.getProject().getId()))
            {
                throw new IssueProjectMismatchException();
            }

        }

        // fill model
        projectView.addObject("jsp", "addissue");
        projectView.addObject("viewmode", "edit");

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        list.add(project.getId().toString());

        projectView = helperFunctions.getBreadcrumbs("editissue", list, projectView);

        // get menu for action
        projectView = helperFunctions.getMenu("editissue", list, projectView);

        return projectView;
    }

    /**
     * General method for editing an Issue.
     * 
     * @param issue
     *            the issue object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param tabindex
     *            the index of the desired tab
     * @param redirectAttrs
     *            needed to save values during redirects
     * @param projectId
     *            the id of project the issue belongs to
     * 
     * @return stays on mask to edit an issue and shows a success/failure
     *         message.
     * 
     * @throws IssuePersistenceException
     *             exception if issue could not be saved
     * @throws IssueNotFoundException
     *             exception if issue is not found
     * @throws ProjectNotFoundException
     *             exception if project is not found
     * @throws TechnicalTermNotFoundException
     *             exception if tt is not found
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/project/{projectId}/issue/edit", method = RequestMethod.POST)
    public String editingIssue(@PathVariable Integer projectId,
            @ModelAttribute("issue") Issue issue, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws IssuePersistenceException,
                    IssueNotFoundException, ProjectNotFoundException,
                    TechnicalTermNotFoundException, CommentPersistenceException
    {
        // validate issue
        validateIssue(issue, bindingResult);

        // get project from service
        Project project = projectService.getProjectById(projectId);

        // determine if the edited issue is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("issue", issue);
            redirectAttrs.addFlashAttribute("org.springframework.validation.BindingResult.issue",
                    bindingResult);

        }
        else
        {
            // finalize
            helperFunctions.finalizeUserEditable(issue);

            // save issue
            issueService.saveIssue(issue);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "editissue.success");
        }

        // fill redirect model
        List<String> params = new ArrayList<String>();
        params.add(issue.getName());
        params.add(String.valueOf(issue.getId()));
        redirectAttrs.addFlashAttribute("messageparams", params);

        redirectAttrs.addFlashAttribute("project", issue);
        redirectAttrs.addFlashAttribute("tabindex", tabindex);

        redirectAttrs.addAttribute("id", issue.getId());
        redirectAttrs.addAttribute("projectId", project.getId());

        return "redirect:/project/project/{projectId}/issue/edit/{id}";
    }

    /**
     * Process of editing an Issue inline. Triggers when Issue is edited inline.
     * 
     * @param issue
     *            the issue object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param projectId
     *            the id of project the issue belongs to
     * 
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws IssuePersistenceException
     *             exception if issue could not be saved
     * @throws IssueNotFoundException
     *             exception if issue is not found.
     * @throws ProjectNotFoundException
     *             exception if project could not be saved
     * @throws TechnicalTermNotFoundException
     *             exception if tt is not found.
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/project/{projectId}/issue/editinline", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingIssueInline(@PathVariable Integer projectId,
            @ModelAttribute("issue") Issue issue, BindingResult bindingResult)
                    throws IssuePersistenceException, IssueNotFoundException,
                    ProjectNotFoundException, TechnicalTermNotFoundException,
                    CommentPersistenceException
    {
        // validate issue
        validateIssue(issue, bindingResult);

        // get project from service to check if Project exists
        // Project project = projectService.getProjectById(projectId);

        // determine if success or failure
        if (bindingResult.hasErrors())
        {
            Locale locale = LocaleContextHolder.getLocale();
            AjaxFailure ajaxFailure = new AjaxFailure();

            // parse every occured error into AjaxFailure object
            for (ObjectError error : bindingResult.getAllErrors())
            {
                AjaxFailureItem ajaxFailureItem = new AjaxFailureItem();

                ajaxFailureItem.setErrorCode(helperFunctions.skipIndexedCodes(error.getCodes()));
                ajaxFailureItem.setErrorArguments(error.getArguments());

                String message = "";
                try
                {
                    message = messageSource.getMessage(
                            helperFunctions.skipIndexedCodes(error.getCodes()),
                            error.getArguments(), locale);
                }
                catch (NoSuchMessageException e)
                {
                }
                ajaxFailureItem.setErrorMessage(message);

                FieldError fieldError = (FieldError) error;

                ajaxFailureItem.setErrorFieldName(fieldError.getField());
                ajaxFailure.addAjaxFailureItem(ajaxFailureItem);
            }

            return ajaxFailure;
        }
        else
        {
            // finalize
            helperFunctions.finalizeUserEditable(issue);

            // save issue
            issueService.saveIssue(issue);

            // return ajax success object
            AjaxSuccess ajaxSuccess = new AjaxSuccess();
            ajaxSuccess.setLastModifier(issue.getLastModifier());
            Format format = new SimpleDateFormat("yyyy-MM-dd, HH:mm:ss");
            ajaxSuccess.setModificationDate(format.format((Date) issue.getModificationDate()));

            return ajaxSuccess;
        }
    }

    /******************************************************************
     * 
     * DELETE ISSUE
     * 
     *****************************************************************/

    /**
     * Shows an issue which is about to be deleted.
     * 
     * @param id
     *            ID of issue to be deleted
     * @param projectId
     *            ID of project the issue belongs to
     * @return detailview of issue to be deleted
     * 
     * @throws IssueNotFoundException
     *             exception if issue is not found
     * @throws ProjectNotFoundException
     *             exception if project is not found
     * @throws IssueProjectMismatchException
     *             exception if issue and project dont match
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/project/{projectId}/issue/delete/{id}", method = RequestMethod.GET)
    public ModelAndView deleteIssuePage(@PathVariable Integer projectId, @PathVariable Integer id)
            throws IssueNotFoundException, ProjectNotFoundException, IssueProjectMismatchException
    {
        ModelAndView projectView = new ModelAndView("index");

        // get issue from service
        Issue issue = issueService.getIssueById(id);

        // get project from service
        Project project = projectService.getProjectById(projectId);

        // check if issue belongs to provided project
        if (!project.getId().equals(issue.getProject().getId()))
        {
            throw new IssueProjectMismatchException();
        }

        // fill model
        projectView.addObject("jsp", "addissue");
        projectView.addObject("viewmode", "delete");
        projectView.addObject("issue", issue);
        projectView.addObject("project", project);
        projectView.addObject("recommendations", getRecommendations(issue));

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        list.add(project.getId().toString());
        projectView = helperFunctions.getBreadcrumbs("deleteissue", list, projectView);

        // get menu for action
        projectView = helperFunctions.getMenu("deleteissue", list, projectView);

        return projectView;
    }

    /**
     * Deletes an issue.
     * 
     * @param id
     *            ID of issue to be deleted
     * @param projectId
     *            ID of project
     * @param redirectAttrs
     *            needed to save values during redirects
     * 
     * @return show projects profile
     * 
     * @throws IssueNotFoundException
     *             exception if issue is not found
     * @throws ProjectNotFoundException
     *             exception if project is not found
     * @throws IssueProjectMismatchException
     *             exception if issue and project dont match
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/project/{projectId}/issue/delete/{id}", method = RequestMethod.POST)
    public String deletingIssue(@PathVariable Integer projectId, @PathVariable Integer id,
            RedirectAttributes redirectAttrs) throws IssueNotFoundException,
                    ProjectNotFoundException, IssueProjectMismatchException
    {
        // get issue from service
        Issue issue = issueService.getIssueById(id);

        // get project from service
        Project project = projectService.getProjectById(projectId);

        // check if issue belongs to provided project
        if (!project.getId().equals(issue.getProject().getId()))
        {
            throw new IssueProjectMismatchException();
        }

        // delete issue
        issueService.deleteIssue(issue.getId());

        // fill redirect model
        redirectAttrs.addFlashAttribute("messagestatus", "success");
        redirectAttrs.addFlashAttribute("messagecode", "deleteissue.success");

        List<String> params = new ArrayList<String>();
        params.add(String.valueOf(id));
        redirectAttrs.addFlashAttribute("messageparams", params);

        redirectAttrs.addFlashAttribute("projectId", project.getId());

        return "redirect:/project/project/{projectId}";
    }

    /**
     * General method for adding an Issue.
     * 
     * @param issue
     *            the issue object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param tabindex
     *            the index of the desired tab
     * @param redirectAttrs
     *            needed to save values during redirects
     * @param projectId
     *            id of project that issue should belong to
     * 
     * @return stays on mask to add an issue and shows a success/failure
     *         message.
     * 
     * @throws IssuePersistenceException
     *             exception if issue could not be saved
     * @throws ProjectNotFoundException
     *             exception if project is not found
     * @throws TechnicalTermNotFoundException
     *             exception if tt is not found
     * 
     */

    /**
     * Validating of issue. If required, set connection to technicalterm.
     * 
     * @param issue
     *            the issue to be validated
     * @param bindingResult
     *            the bindingresult object
     * 
     * @throws TechnicalTermNotFoundException
     *             exception if tt is not found
     */
    public void validateIssue(Issue issue, BindingResult bindingResult)
            throws TechnicalTermNotFoundException
    {
        // set connections if not available
        for (Constraint constraint : issue.getConstraints())
        {
            if (constraint.getTechnicalTerm() == null
                    || constraint.getTechnicalTerm().getType() == null)
            {
                TechnicalTerm technicalTerm = technicalTermService
                        .getTechnicalTermById(constraint.getTechnicalTerm().getId());
                constraint.setTechnicalTerm(technicalTerm);
            }
        }

        // validate issue
        issueValidator.validate(issue, bindingResult);
    }

    /**
     * Returns the recommendations for an issue.
     * 
     * @param issue
     *            the issue to get recommendations for
     * @return a list of recommendations
     */
    public List<Solution> getRecommendations(Issue issue)
    {
        // use solution constraint filter
        Filter<Solution> solutionFilter = new SolutionConstraintFilter(issue);
        List<Solution> recommendations = solutionService.getSolutionsByCriteria(solutionFilter,
                null);

        List<WeightedQualityGoal> weightedQualityGoals = issue.getWeightedQualityGoals();

        // calculate solution rating scores for issue and save in transient
        // state
        for (Solution solution : recommendations)
        {
            solutionRater.assignSolutionScore(solution, weightedQualityGoals);
        }

        // sort after overall score
        Comparator<Solution> scoreComparator = Collections.reverseOrder(
                new ComparatorFactory<Solution>(Solution.class).generateScoreComparatator());
        Collections.sort(recommendations, scoreComparator);

        return recommendations;
    }

    /******************************************************************
     * 
     * ADD COMMENT
     * 
     *****************************************************************
     * 
     * /** Shows the mask for adding a new comment.
     * 
     * @param previousModel
     *            needed to conserve bindingResult and validation of former
     *            comment
     * 
     * @return view/mask for adding a comment.
     * @throws IssueNotFoundException
     *             exception if solution is not found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "project/{projectId}/issue/{issueId}/comment/add", method = RequestMethod.GET)
    public ModelAndView addCommentPage(@PathVariable Integer projectId,
            @PathVariable Integer issueId, Model previousModel) throws IssueNotFoundException
    {
        Comment comment;

        ModelAndView catalogView = new ModelAndView("index");

        // check if comment object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("comment"))
        {
            comment = (Comment) previousModel.asMap().get("comment");
        }
        else
        {
            Issue issue = issueService.getIssueById(Long.valueOf(issueId));

            // default: no previous comment is available
            comment = new Comment();
            comment.setDecision(issue.getDecision());
        }

        // fill model
        catalogView.addObject("jsp", "addcomment");
        catalogView.addObject("viewmode", "add");
        catalogView.addObject("comment", comment);

        ArrayList<String> list = new ArrayList<String>();
        list.add(projectId.toString());
        list.add(issueId.toString());

        // get breadcrumbs for action
        catalogView = helperFunctions.getBreadcrumbs("addcomment", list, catalogView);

        // get menu for action
        catalogView = helperFunctions.getMenu("addcomment", catalogView);

        return catalogView;
    }

    /**
     * Process of adding a Comment.
     * 
     * @param comment
     *            the comment object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param tabindex
     *            index of desired tab
     * @param redirectAttrs
     *            needed to save values during redirects
     * 
     * @return stays on mask to add a comment and shows a success/failure
     *         message.
     * 
     * @throws CommentPersistenceException
     *             exception if comment could not be saved
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "project/{projectId}/issue/{issueId}/comment/add", method = RequestMethod.POST)
    public String addingComment(@PathVariable Integer projectId, @PathVariable Integer issueId,
            @ModelAttribute("comment") Comment comment, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws CommentPersistenceException
    {
        // validate comment
        commentValidator.validate(comment, bindingResult);

        // finalize
        comment.setDate(new Date());
        comment.setCommentator(helperFunctions.createUsername());

        // determine if the comment is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("comment", comment);
            redirectAttrs.addFlashAttribute("org.springframework.validation.BindingResult.comment",
                    bindingResult);

            redirectAttrs.addFlashAttribute("tabindex", tabindex);
        }
        else
        {
            // persist comment
            commentService.saveComment(comment);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "addcomment.success");

            List<String> params = new ArrayList<String>();
            redirectAttrs.addFlashAttribute("messageparams", params);
            redirectAttrs.addFlashAttribute("issueId", issueId);
            redirectAttrs.addFlashAttribute("projectId", projectId);
        }

        return "redirect:/project/project/{projectId}/issue/{issueId}/comment/add";
    }

    /**
     * Assigns technical terms to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'technicalTerms' containing List of technical
     *         terms
     * 
     * @throws SorterInvalidTypeException
     *             exception if type is invalid
     * @throws SorterFieldNotFoundException
     *             exception if field is not found
     */
    @ModelAttribute("technicalterms")
    public Map<String, String> dropdownTechnicalTerms()
            throws SorterInvalidTypeException, SorterFieldNotFoundException
    {
        return dynamicEntities.getTechnicalTerms();
    }

    /**
     * Assigns quality goals to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'qualitygoals' containing List of quality goals
     */
    @ModelAttribute("qualitygoals")
    public Map<String, String> dropdownQualityGoals()
    {
        return dynamicEntities.getQualityGoals();
    }

    /**
     * Assigns constraint comparators to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'constraintcomparators' containing List of
     *         comparators
     */
    @ModelAttribute("constraintcomparators")
    public Map<String, String> dropdownConstraintComparators()
    {
        return staticEntities.getConstraintComparators();
    }

    /**
     * Assigns decision stati to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'candidatedecisionstati' containing List of
     *         candidate decided stati
     */
    @ModelAttribute("candidatedecisionstati")
    public Map<String, String> dropdownCandidateDecisionStati()
    {
        return staticEntities.getCandidateDecisionStati();
    }

    /******************************************************************
     * 
     * CONTROLBAR
     * 
     *****************************************************************/

    /**
     * Returns the sorting params to the view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'sortingParams' containing sorting keys & values
     */
    @ModelAttribute("sortingParams")
    public Map<String, String> sortingParams()
    {
        Map<String, String> sortingParams = new LinkedHashMap<String, String>();

        sortingParams.put("id", "id");
        sortingParams.put("name", "name");
        sortingParams.put("creator", "creator");
        sortingParams.put("description", "description");

        return sortingParams;
    }

    /**
     * Configures the controlbar.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'controlbar' containing config
     */
    @ModelAttribute("controlbar")
    public Map<String, String> controlbarConfig()
    {
        Map<String, String> controlbar = new LinkedHashMap<String, String>();

        controlbar.put("filteringAllowed", "false");
        controlbar.put("sortingAllowed", "true");
        controlbar.put("pageSizeAllowed", "true");
        controlbar.put("paginationAllowed", "true");
        controlbar.put("modelName", "project");

        return controlbar;
    }

    /******************************************************************
     * 
     * OTHER
     * 
     *****************************************************************/

    /**
     * CSS-Styling: set project view as active view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return String 'activeview' containing 'project'
     */
    @ModelAttribute("activeview")
    public String cssActiveView()
    {
        return "project";
    }
}