package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a element could not be written to the
 * database.
 * 
 * @author Burak
 *
 */
public class ElementPersistenceException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public ElementPersistenceException()
    {
        setExceptionType("elementpersistence");
    }
}
