package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate;

/**
 * Service class for managing issues.
 * 
 * @author schaak
 * 
 */
@Service
@Transactional
public class IssueServiceImpl implements IssueService
{
    @Autowired
    private IssueDAO issueDAO;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private CommentService commentService;

    /**
     * Adds a new Issue to the database.
     * 
     * @param issue the issue to save
     * 
     * @return the saved issue object
     * 
     * @throws IssuePersistenceException Exception if Issue could not be
     *             persisted
     */
    @Override
    public Issue saveIssue(Issue issue) throws IssuePersistenceException, CommentPersistenceException
    {
        // restore constraint connections
        for (Constraint constraint : issue.getConstraints())
        {
            for (ConstraintElement constraintElement : constraint.getElements())
            {
                constraintElement.setConstraint(constraint);
            }
        }

        setDecisionState(issue);

        Issue savedIssue;
        savedIssue = issueDAO.saveAndFlush(issue);

        if (savedIssue == null)
        {
            throw new IssuePersistenceException();
        }

        return savedIssue;
    }

    /**
     * This helper function determines the decision state of an issue.
     * 
     * @param issue the issue to calculate the decision state for.
     */
    private void setDecisionState(Issue issue) throws CommentPersistenceException
    {
        // update decision state
        // to solve a decision, no candidate is allowed to stay undecided
        // and at least one has to be approved

        boolean isAnyApproved = false;
        boolean isAnyUndecided = false;

        Decision decision = issue.getDecision();
        for (SolutionCandidate solutionCandidate : decision.getSolutionCandidates())
        {
            if (Integer.valueOf("0").equals(solutionCandidate.getDecided()))
            {
                isAnyUndecided = true;
                break;
            }
            else if (Integer.valueOf("1").equals(solutionCandidate.getDecided()))
            {
                isAnyApproved = true;
            }
        }

        if (isAnyApproved && !isAnyUndecided)
        {
            boolean wasDecided = decision.isDecided();
            decision.setDecided(true);

            // if decision was undecided until now, set decision date
            if (!wasDecided)
            {
                decision.setDecisionDate(new Date());

                // save decision comment
                Comment comment = new Comment();
                comment.setComment("The issue has been solved. (" + new Date() + ")");
                comment.setCommentator("System");
                comment.setDate(new Date());
                comment.setDecision(decision);

                commentService.saveComment(comment);
            }
        }
        else
        {
            decision.setDecided(false);
        }
    }

    /**
     * Finds issues of the specified project id.
     * 
     * @param id ID of the Project
     * 
     * @return list of issues for that project
     * 
     * @throws ProjectNotFoundException Exception if Project is not found
     */
    @Override
    public List<Issue> getIssuesByProjectID(long id) throws ProjectNotFoundException
    {
        Project project = projectService.getProjectById(id);

        return issueDAO.findByProjectId(project.getId());
    }

    /**
     * Finds an issue with the specified ID.
     * 
     * @param id ID of the Issue
     * 
     * @return Issue with the id.
     * 
     * @throws IssueNotFoundException Exception if Issue is not found
     */
    @Override
    public Issue getIssueById(long id) throws IssueNotFoundException
    {
        Issue issue = issueDAO.findOne(id);

        if (issue == null)
        {
            throw new IssueNotFoundException();
        }

        return issue;
    }

    /**
     * Deletes an issue with the specified ID.
     * 
     * @param id the id of the issue to be deleted
     * 
     * @throws IssueNotFoundException Exception if Issue is not found
     */
    @Override
    public void deleteIssue(long id) throws IssueNotFoundException
    {
        try
        {
            issueDAO.delete(id);
        }
        catch (DataAccessException e)
        {
            throw new IssueNotFoundException();
        }
    }
}