package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.hibernate.collection.internal.PersistentBag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxFailure;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxFailureItem;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxResponse;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxSuccess;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AuthorityPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.AuthorityService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.UserService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorityEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorityListEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorizationConstants;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.DateEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.HelperFunctions;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.IntegerEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Paginator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.UserValidator;

@Controller
@PreAuthorize(AuthorizationConstants.USER_WRITE)
@RequestMapping(value = "/user")
public class UserController
{
    @Autowired
    private UserValidator    userValidator;

    @Autowired
    private Paginator<User>  paginationHelper;

    @Autowired
    private HelperFunctions  helperFunctions;

    @Autowired
    private MessageSource    messageSource;

    @Autowired
    private UserService      userService;

    @Autowired
    private AuthorityService authorityService;

    @InitBinder
    private void initBinder(WebDataBinder binder)
    {
        // Integer <-> String
        binder.registerCustomEditor(Integer.class, new IntegerEditor());

        // Date <-> String
        binder.registerCustomEditor(Date.class, new DateEditor());

        binder.registerCustomEditor(Authority.class, new AuthorityEditor());

        binder.registerCustomEditor(PersistentBag.class, new AuthorityListEditor());
    }

    /**
     * 
     * @param page
     * @param pageSize
     * @param filter
     * @param sorter
     * @return
     * @throws SorterFieldNotFoundException
     * @throws SorterInvalidTypeException
     */
    @RequestMapping(value = { "", "/", "/list" })
    public ModelAndView listOfSolutions(@RequestParam(value = "page", required = false) String page,
            @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "filter", required = false) String filter,
            @RequestParam(value = "sorter", required = false) String sorter)
                    throws SorterFieldNotFoundException, SorterInvalidTypeException
    {
        ModelAndView userView = new ModelAndView("index");

        // show solutions.jsp
        userView.addObject("jsp", "users");
        //
        // // get solutions by sorting and filtering criteria
        List<User> processedUsers = userService.getUsersByCriteria(null, null);
        //
        userService.getUsers();
        // Configure pagination
        paginationHelper.configure(processedUsers, pageSize, page);
        //
        // // model entries
        userView.addObject("userlist", paginationHelper.getPageList());
        userView.addObject("pagedListHolder", paginationHelper.getPagedListHolder());
        //
        // // get breadcrumbs and menu for action
        userView = helperFunctions.getBreadcrumbs("showusers", userView);
        userView = helperFunctions.getMenu("showusers", userView);

        return userView;
    }

    /**
     * 
     * @param username
     * @param previousModel
     * @return
     * @throws UserNotFoundException
     */
    @RequestMapping(value = "/user/{username}")
    public ModelAndView userProfile(@PathVariable String username, Model previousModel)
            throws UserNotFoundException
    {
        ModelAndView userView = new ModelAndView("index");

        User user = userService.getUser(username);

        // List<Authoritiy> authorityList = (List<Authoritiy>)
        // user.getAuthorities();

        userView.addObject("jsp", "adduser");
        userView.addObject("viewmode", "view");
        userView.addObject("user", user);

        ArrayList<String> list = new ArrayList<String>();
        list.add(username);
        userView = helperFunctions.getBreadcrumbs("userprofile", list, userView);
        userView = helperFunctions.getMenu("userprofile", list, userView);

        return userView;

    }

    /**
     * 
     * @param previousModel
     * @return
     * @throws UserNotFoundException
     */
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public ModelAndView addUserPage(Model previousModel) throws UserNotFoundException
    {
        User user;

        ModelAndView userView = new ModelAndView("index");

        if (previousModel.containsAttribute("user"))
        {
            user = (User) previousModel.asMap().get("user");
        }
        else
        {
            user = new User();
        }

        List<Authority> authoritylist = new ArrayList<Authority>();
        userView.addObject("authorylist", authoritylist);

        userView.addObject("jsp", "adduser");
        userView.addObject("viewmode", "add");
        userView.addObject("user", user);

        userView = helperFunctions.getBreadcrumbs("adduser", userView);
        userView = helperFunctions.getMenu("adduser", userView);

        return userView;
    }

    /**
     * eneral method for adding a User.
     * 
     * @param user
     *            the user object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param tabindex
     *            the desired tab
     * @param redirectAttributes
     *            needed to save values during redirects
     * @return
     * @throws UserPersistenceException
     * @throws AuthorityPersistenceException
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addingUser(@ModelAttribute("user") User user, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttributes)
                    throws UserPersistenceException, AuthorityPersistenceException
    {
        userValidator.validate(user, bindingResult);

        if (bindingResult.hasErrors())
        {
            redirectAttributes.addFlashAttribute("user", user);
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.user", bindingResult);
            redirectAttributes.addFlashAttribute("tabindex", tabindex);
        }
        else
        {
            User savedUser;

            savedUser = userService.saveUser(user);

            redirectAttributes.addFlashAttribute("messagestatus", "success");
            redirectAttributes.addFlashAttribute("messagecode", "adduser.success");

            List<String> params = new ArrayList<String>();
            params.add(savedUser.getUsername());
            redirectAttributes.addFlashAttribute("messageparams", params);
        }

        return "redirect:/user/add";
    }

    /**
     * Shows the mask for editing a user. Generic method.
     * 
     * @param username
     *            the username of the user to be edited
     * @param previousModel
     *            needed to conserve bindingResult and validation of former user
     * @return view/mask for editing a user
     * @throws UserNotFoundException
     *             exception if user is not found
     */
    @RequestMapping(value = "/edit/{username}", method = RequestMethod.GET)
    public ModelAndView editUserPage(@PathVariable String username, Model previousModel)
            throws UserNotFoundException
    {
        ModelAndView userView = new ModelAndView("index");

        if (!previousModel.containsAttribute("user"))
        {
            User user = userService.getUser(username);
            userView.addObject("user", user);
        }

        userView.addObject("jsp", "adduser");
        userView.addObject("viewmode", "edit");

        ArrayList<String> list = new ArrayList<String>();
        list.add(username);
        userView = helperFunctions.getBreadcrumbs("edituser", list, userView);
        userView = helperFunctions.getMenu("edituser", list, userView);

        return userView;
    }

    /**
     * General method for editing a user.
     * 
     * @param user
     *            the user object parsed from input fields
     * @param bindingResult
     *            contains information about parsing success
     * @param tabindex
     *            the desired tab
     * @param redirectAttributes
     *            redirectAttributes needed to save values during redirects
     * @return stays on mask to edit a user and shows a success/failure message.
     * @throws UserPersistenceException
     *             exception if user could not be saved
     * @throws AuthorityPersistenceException
     *             exception if authority could not be saved
     */
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public String editingUser(@ModelAttribute("user") User user, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttributes)
                    throws UserPersistenceException, AuthorityPersistenceException
    {
        userValidator.validate(user, bindingResult);

        if (bindingResult.hasErrors())
        {
            redirectAttributes.addFlashAttribute(
                    "org.springframework.validation.BindingResult.user", bindingResult);
        }
        else
        {
            userService.editUser(user);

            redirectAttributes.addFlashAttribute("messagestatus", "succes");
            redirectAttributes.addFlashAttribute("messagecode", "edituser.success");
        }
        List<String> params = new ArrayList<String>();
        params.add(user.getUsername());
        redirectAttributes.addFlashAttribute("messageparams", params);

        redirectAttributes.addFlashAttribute("user", user);
        redirectAttributes.addFlashAttribute("tabindex", tabindex);

        // get Authorities for User
        List<Authority> authorityList = authorityService.getAuthorities();
        redirectAttributes.addFlashAttribute("authoritylist", authorityList);
        // get username
        redirectAttributes.addAttribute("username", user.getUsername());
        return "redirect:/user/edit/{username}";
    }

    /**
     * 
     * @param user
     * @param bindingResult
     * @return
     * @throws UserPersistenceException
     * @throws AuthorityPersistenceException
     */
    @RequestMapping(value = "/editinline", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingUserInLine(@ModelAttribute("user") User user,
            BindingResult bindingResult)
                    throws UserPersistenceException, AuthorityPersistenceException
    {
        userValidator.validate(user, bindingResult);
        if (bindingResult.hasErrors())
        {
            Locale locale = LocaleContextHolder.getLocale();
            AjaxFailure ajaxFailure = new AjaxFailure();

            for (ObjectError error : bindingResult.getAllErrors())
            {
                AjaxFailureItem ajaxFailureItem = new AjaxFailureItem();

                ajaxFailureItem.setErrorCode(error.getCodes()[0]);
                ajaxFailureItem.setErrorArguments(error.getArguments());

                String message = "";
                try
                {
                    message = messageSource.getMessage(error.getCodes()[0], error.getArguments(),
                            locale);
                }
                catch (NoSuchMessageException e)
                {
                    message = "The data you entered seems to be invalid.";
                }
                ajaxFailureItem.setErrorMessage(message);

                FieldError fieldError = (FieldError) error;

                ajaxFailureItem.setErrorFieldName(fieldError.getField());
                ajaxFailure.addAjaxFailureItem(ajaxFailureItem);
            }
            return ajaxFailure;
        }
        else
        {
            userService.editUser(user);
            AjaxSuccess ajaxSuccess = new AjaxSuccess();
            ajaxSuccess.setLastModifier(
                    SecurityContextHolder.getContext().getAuthentication().getName());
            Format format = new SimpleDateFormat("yyyy-MM-dd, HH:mm:ss");
            Date modificationDate = new Date();
            ajaxSuccess.setModificationDate(format.format((Date) modificationDate));
            return ajaxSuccess;
        }
    }

    /**
     * 
     * @param username
     * @return
     * @throws UserNotFoundException
     */
    @RequestMapping(value = "/delete/{username}", method = RequestMethod.GET)
    public ModelAndView deleteUserPage(@PathVariable String username) throws UserNotFoundException
    {
        ModelAndView userView = new ModelAndView("index");
        User user = userService.getUser(username);

        userView.addObject("jsp", "adduser");
        userView.addObject("viewmode", "delete");
        userView.addObject("user", user);

        ArrayList<String> list = new ArrayList<String>();
        list.add(username);
        userView = helperFunctions.getBreadcrumbs("deleteuser", list, userView);
        userView = helperFunctions.getMenu("deleteuser", list, userView);

        return userView;

    }

    /**
     * @param username
     * 
     * @return
     * @throws UserNotFoundException
     */
    @RequestMapping(value = "/delete/{username}", method = RequestMethod.POST)
    public String deletingUser(@PathVariable String username, RedirectAttributes redirectAttributes)
            throws UserNotFoundException
    {
        userService.deleteUser(username);

        redirectAttributes.addFlashAttribute("messagestatus", "success");

        redirectAttributes.addFlashAttribute("messagecode", "deleteuser.success");

        List<String> params = new ArrayList<String>();
        params.add(username);
        redirectAttributes.addFlashAttribute("messageparams", params);

        return "redirect:/user/list";
    }

    @ModelAttribute("controlbar")
    public Map<String, String> controllbarConfig()
    {
        Map<String, String> controlbar = new LinkedHashMap<String, String>();

        controlbar.put("filteringAllowed", "false");
        controlbar.put("sortingAllowed", "true");
        controlbar.put("pageSizeAllowed", "true");
        controlbar.put("paginationAllowed", "true");
        controlbar.put("modelName", "users");

        return controlbar;
    }

    /**
     * CSS-Styling: set user view as active view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return String 'activeview' containing 'project'
     */
    @ModelAttribute("activeview")
    public String cssActiveView()
    {
        return "user";
    }

}
