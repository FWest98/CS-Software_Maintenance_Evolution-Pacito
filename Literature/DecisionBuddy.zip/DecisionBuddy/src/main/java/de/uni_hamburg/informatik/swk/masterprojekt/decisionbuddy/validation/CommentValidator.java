package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class validates a Comment.
 *
 * @author Tim
 *
 */
@Component
public class CommentValidator extends ExtendedValidator implements Validator
{
    /**
     * Tests if the validator can validate the given object.
     * 
     * @param object an object to be validated
     * @return boolean if the object can be validated as a comment
     */
    @Override
    public boolean supports(Class<?> object)
    {
        return (Comment.class).isAssignableFrom(object);
    }

    /**
     * Checks if a given Comment object is considered valid.
     * 
     * @param object the given object
     * @param errors collects encountered field errors
     */
    @Override
    public void validate(Object object, Errors errors)
    {
        checkMandatoryFields(errors);
        checkMaxLength(errors);
    }

    /**
     * Validates that fields don't exceed max length.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMaxLength(Errors errors)
    {
        rejectIfStringTooLong(errors, "comment", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "commentator", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
    }

    /**
     * Validates that mandatory fields are not empty.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMandatoryFields(Errors errors)
    {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "comment", ErrorCodes.REQUIRED);
    }
}