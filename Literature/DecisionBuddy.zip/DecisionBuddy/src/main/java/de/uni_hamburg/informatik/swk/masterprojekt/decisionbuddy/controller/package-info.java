/**
 * This package contains controller classes for the web app.
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;