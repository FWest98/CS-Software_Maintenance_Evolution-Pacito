package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementDesignPatternNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementDesignPatternPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;

/**
 * Overview of interfaces of class ElementMetricService.
 * 
 * @see architectural specification
 *
 * @author Oliver
 *
 */
public interface ElementDesignPatternService
{
    /**
     * Adds a given ElementDesignPattern to the database.
     * 
     * @param ElementDesignPattern the ElementDesignPattern to be persisted
     * 
     * @return the saved ElementDesignPattern object
     * 
     * @throws ElementDesignPatternPersistenceException Exception if
     *             ElementDesignPattern could not be persisted
     */
    ElementDesignPattern saveElementDesignPattern(ElementDesignPattern elementDesignPattern)
            throws ElementDesignPatternPersistenceException;

    /**
     * Deletes all ElementDesignPatterns which belong to the specified project.
     * 
     * @param id the id of the project which ElementDesignPatterns should be
     *            deleted
     * 
     * @throws ElementDesignPatternNotFoundException Exception if
     *             ElementDesignPattern is not found
     */
    void deleteElementDesignPatternsByProjectId(long id) throws ElementDesignPatternNotFoundException;
}
