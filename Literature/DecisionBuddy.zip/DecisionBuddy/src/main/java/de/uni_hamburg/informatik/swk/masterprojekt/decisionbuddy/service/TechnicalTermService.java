package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.Comparator;
import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * 
 * Overview of interface of class TechnicalTermService.
 * 
 * @see architectural specification
 * 
 * @author schaak
 *
 */
public interface TechnicalTermService
{
    /**
     * Adds a TechnicalTerm to the database.
     * 
     * @param technicalTerm The TechnicalTerm to be persisted.
     * 
     * @return the saved TechnicalTerm
     * 
     * @throws TechnicalTermPersistenceException Exception if TechnicalTerm
     *             could not be persisted.
     */
    TechnicalTerm saveTechnicalTerm(TechnicalTerm technicalTerm) throws TechnicalTermPersistenceException;

    /**
     * Find a TechnicalTerm by a given id.
     * 
     * @param id The id of the desired TechnicalTerm.
     * 
     * @return The matching TechnicalTerm.
     * 
     * @throws TechnicalTermNotFoundException Exception if TechnicalTerm is not
     *             found.
     */
    TechnicalTerm getTechnicalTermById(long id) throws TechnicalTermNotFoundException;

    /**
     * Delete a TechnicalTerm with the given id.
     * 
     * @param id The id of the technicalTerm to be deleted
     * 
     * @throws TechnicalTermNotFoundException Exception if TechnicalTerm is not
     *             found.
     */
    void deleteTechnicalTerm(long id) throws TechnicalTermNotFoundException;

    /**
     * Get a list of technicalTerms, given a Filter and a Sorter.
     * 
     * @see Filter
     * @see Comparator
     * 
     * @param filter a Filter object to reduce the result set
     * @param sorter a Sorter object to arrange the result items by criteria
     * 
     * @return List of technicalTerms
     */
    List<TechnicalTerm> getTechnicalTermsByCriteria(Filter<TechnicalTerm> filter, Comparator<TechnicalTerm> sorter);
}