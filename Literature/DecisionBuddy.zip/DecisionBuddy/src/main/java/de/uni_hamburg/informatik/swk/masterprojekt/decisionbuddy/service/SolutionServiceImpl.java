package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ArchitecturalPatternCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.COTSCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DesignPatternCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RefactoringCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Service class for managing solutions.
 * 
 * @author Lucas, Tim
 * 
 */
@Service
@Transactional
public class SolutionServiceImpl implements SolutionService
{
    @Autowired
    private SolutionDAO solutionDAO;

    @Autowired
    private FrameworkCategoryDAO frameworkCategoryDAO;

    @Autowired
    private COTSCategoryDAO cotsCategoryDAO;

    @Autowired
    private ArchitecturalPatternCategoryDAO architecturalPatternCategoryDAO;

    @Autowired
    private DesignPatternCategoryDAO designPatternCategoryDAO;

    @Autowired
    private RefactoringCategoryDAO refactoringCategoryDAO;

    /**
     * Adds a new Solution to the database.
     * 
     * @param solution the solution to save
     * 
     * @return the saved solution object
     * 
     * @throws SolutionPersistenceException Exception if Solution could not be
     *             persisted
     */
    @Override
    public Solution saveSolution(Solution solution) throws SolutionPersistenceException
    {
        // restore constraint connections
        for (Constraint constraint : solution.getConstraints())
        {
            for (ConstraintElement constraintElement : constraint.getElements())
            {
                constraintElement.setConstraint(constraint);
            }
        }

        Solution savedSolution;
        savedSolution = solutionDAO.saveAndFlush(solution);

        if (savedSolution == null)
        {
            throw new SolutionPersistenceException();
        }

        return savedSolution;
    }

    /**
     * Finds a solution with the specified ID.
     * 
     * @param id ID of the Solution
     * 
     * @return Solution with the id.
     * 
     * @throws SolutionNotFoundException Exception if Solution is not found
     */
    @Override
    public Solution getSolutionById(long id) throws SolutionNotFoundException
    {
        Solution solution = solutionDAO.findOne(id);

        if (solution == null)
        {
            throw new SolutionNotFoundException();
        }

        return solution;
    }

    /**
     * Find a solution by given name.
     * 
     * @param name the name of desired solution
     * 
     * @return the matching solution
     * 
     * @throws SolutionNotFoundException Exception if Solution is not found
     */
    @Override
    public Solution getSolutionByName(String name) throws SolutionNotFoundException
    {
        Solution solution = solutionDAO.findByName(name);

        if (solution == null)
        {
            throw new SolutionNotFoundException();
        }

        return solution;
    }

    /**
     * Deletes a solution with the specified ID.
     * 
     * @param id the id of the solution to be deleted
     * 
     * @throws SolutionNotFoundException Exception if Solution is not found
     */
    @Override
    public void deleteSolution(int id) throws SolutionNotFoundException
    {
        Solution solution = getSolutionById(Long.valueOf(id));

        solutionDAO.delete(solution.getId());
    }

    /**
     * Returns all solutions.
     * 
     * @return a List of all solutions.
     */
    @Override
    public List<Solution> getSolutionCatalog()
    {
        return solutionDAO.findAll();
    }

    /**
     * Filters the solution catalog using the specified Filter and sorts the
     * result.
     * 
     * See Filter.java for an example on how to use this method.
     * 
     * @param filter Specifies how the catalog should be filtered.
     * @param sorter Specifies how the result should be sorted. See
     *            documentation of java.util.Comparator for details.
     * 
     * @return Filtered and sorted list of the solution catalog.
     */
    @Override
    public List<Solution> getSolutionsByCriteria(Filter<Solution> filter, Comparator<Solution> sorter)
    {
        List<Solution> catalog = solutionDAO.findAll();
        List<Solution> result = new ArrayList<Solution>();

        if (filter != null)
        {
            for (Solution element : catalog)
            {
                if (filter.isInResult(element))
                {
                    result.add(element);
                }
            }
        }
        else
        {
            result = catalog;
        }

        if (sorter != null)
        {
            Collections.sort(result, sorter);
        }

        return result;
    }

    /**
     * Returns all FrameworkCategories.
     * 
     * @return All framework categories.
     */
    @Override
    public List<FrameworkCategory> getFrameworkCategories()
    {
        return frameworkCategoryDAO.findAll();
    }

    /**
     * Returns all FrameworkCategories.
     * 
     * @return All framework categories.
     */
    @Override
    public List<COTSCategory> getCOTSCategories()
    {
        return cotsCategoryDAO.findAll();
    }

    /**
     * Returns all ArchitecturalPatternCategories.
     * 
     * @return All architectural pattern categories.
     */
    @Override
    public List<ArchitecturalPatternCategory> getArchitecturalPatternCategories()
    {
        return architecturalPatternCategoryDAO.findAll();
    }

    /**
     * Returns all DesignPatternCategories.
     * 
     * @return All DesignPatternCategoriess.
     */
    @Override
    public List<DesignPatternCategory> getDesignPatternCategories()
    {
        return designPatternCategoryDAO.findAll();
    }

    /**
     * Returns all RefactoringCategories.
     * 
     * @return All Refactoring categories.
     */
    @Override
    public List<RefactoringCategory> getRefactoringCategories()
    {
        return refactoringCategoryDAO.findAll();
    }

    /*
     * TODO: Necessary functionality not implemented yet.
     * 
     * Checks if there are any Issues using this Solution.
     * 
     * @param solution The solution to be checked
     * 
     * @return True if the Solution is in use by any Issue. False otherwise.
     * 
     * 
     * public boolean isUsed(Solution solution) { // TODO implement return
     * false; }
     */

    /*
     * TODO: import not yet implemented
     * 
     * public Set<Solution> importSolutionsWeb(String url) { // TODO implement
     * return null; }
     * 
     * public Set<Solution> importSolutionsOS(File file) { // TODO implement
     * return null; }
     * 
     * public boolean importSolutions(Set<Solution> solutions) { // TODO
     * implement return false; }
     */
}