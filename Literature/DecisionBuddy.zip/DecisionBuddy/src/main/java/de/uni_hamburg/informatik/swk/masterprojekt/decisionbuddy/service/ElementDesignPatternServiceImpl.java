package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementDesignPatternDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementDesignPatternNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementDesignPatternPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;

/**
 * Service class for managing ElementDesignPatterns.
 *
 * @author Oliver
 *
 */
@Service
@Transactional
public class ElementDesignPatternServiceImpl implements ElementDesignPatternService
{

    @Autowired
    private ElementDesignPatternDAO elementDesignPatternDAO;

    /**
     * Adds a new ElementDesignPattern to the database.
     * 
     * @param ElementDesignPattern the ElementDesignPattern to save
     * 
     * @return the saved ElementDesignPattern object
     * 
     * @throws ElementDesignPatternPersistenceException Exception if
     *             ElementDesignPattern could not be persisted
     */
    @Override
    public ElementDesignPattern saveElementDesignPattern(ElementDesignPattern elementDesignPattern)
            throws ElementDesignPatternPersistenceException
    {
        ElementDesignPattern savedElementDesignPattern;
        savedElementDesignPattern = elementDesignPatternDAO.saveAndFlush(elementDesignPattern);

        if (savedElementDesignPattern == null)
        {
            throw new ElementDesignPatternPersistenceException();
        }

        return savedElementDesignPattern;
    }

    /**
     * Deletes all ElementDesignPatterns which belong to the specified project.
     * 
     * @param id the id of the project which ElementDesignPatterns should be
     *            deleted
     * 
     * @throws ElementDesignPatternNotFoundException Exception if
     *             ElementDesignPattern is not found
     */
    @Override
    public void deleteElementDesignPatternsByProjectId(long projectId) throws ElementDesignPatternNotFoundException
    {
        try
        {
            elementDesignPatternDAO.deleteByProjectId(projectId);
        }
        catch (DataAccessException e)
        {
            throw new ElementDesignPatternNotFoundException();
        }
    }
}