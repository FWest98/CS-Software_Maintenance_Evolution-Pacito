package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;

/**
 * A DAO class for Project.
 * 
 * @author Vlad
 *
 */
public interface ProjectDAO extends JpaRepository<Project, Long>
{

}
