package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

/**
 * A DAO class for MetricValue.
 * 
 * @author Burak
 *
 */
public interface MetricValueDAO extends JpaRepository<MetricValue, Long>
{
    Long countByMetricId(Long metricId);

    /**
     * Find all MetricValues belonging to an element.
     * 
     * @param elementId the element for which you want to find the MetricValues
     * @return all issues belonging to that element
     */
    List<MetricValue> findByElementId(Long elementId);

    /**
     * Find MetricValue belonging to a Metric.
     * 
     * @param metricId the metric for which you want to find the MetricValue
     * @return issue belonging to that metric
     */
    MetricValue findByMetricId(Long metricId);

    /**
     * Find MetricValues belonging to a Project with a certain Metric type and
     * subtype.
     * 
     * @param projectid Id of the Project the Metricvalues belong to.
     * @param type Type of the Metricvalues to be returned.
     * @param subtype Subtype of the Metricvalues to be returned.
     * @return List of Metricvalues
     */
    @Query("SELECT mv FROM MetricValue mv , Metric m, Element e WHERE mv.metric.id = m.id AND mv.element.id = e.id"
            + " AND e.project.id = ?1 AND m.type = ?2 AND m.subType = ?3 ORDER BY m.order ASC")
    List<MetricValue> findByMetric_TypeAndMetric_SubTypeAndElement_Project(long project, MetricType type,
            MetricSubType subType);

    /**
     * Find MetricValues belonging to a Element with a certain Metric type.
     * 
     * @param elementid Id of the Element the Metricvalues belong to.
     * @param type Type of the Metricvalues to be returned.
     * @return List of Metricvalues
     */
    @Query("SELECT mv FROM MetricValue mv, Metric m WHERE mv.metric.id = m.id AND mv.element.id = ?1 AND m.type = ?2 ORDER BY m.order ASC")
    List<MetricValue> findByElementIdAndMetric_Type(long elementid, MetricType type);
}
