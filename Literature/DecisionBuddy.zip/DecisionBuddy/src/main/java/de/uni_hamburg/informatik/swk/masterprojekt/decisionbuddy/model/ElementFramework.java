package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * This Class represents the ElementFramework table from the database. Two
 * ElementFrameworks are considered equal if their Ids are equal.
 *
 * @author Burak
 *
 */
@Entity
@Table(name = "ElementFramework")
public class ElementFramework
{
    @Id
    @Column(name = "ID")
    @GeneratedValue
    private Long id;

    @OneToOne(targetEntity = Solution.class, optional = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "FrameworkID", referencedColumnName = "ID", nullable = true)
    private Solution solution;

    @OneToOne(targetEntity = Project.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "ProjectID", referencedColumnName = "ID", nullable = false)
    private Project project;

    @Column(name = "ClassPath", nullable = false, length = ColumnLength.SHORT)
    private String classPath;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "Type", nullable = false)
    private ElementType type;

    @Column(name = "AltName", length = ColumnLength.SHORT)
    private String altName;

    @Column(name = "AltUrl", length = ColumnLength.SHORT)
    private String altUrl;

    /**
     * Constructor.
     */
    public ElementFramework()
    {

    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Solution getSolution()
    {
        return solution;
    }

    public void setSolution(Solution solution)
    {
        this.solution = solution;
    }

    public Project getProject()
    {
        return project;
    }

    public void setProject(Project project)
    {
        this.project = project;
    }

    public String getClassPath()
    {
        return classPath;
    }

    public void setClassPath(String classPath)
    {
        this.classPath = classPath;
    }

    public ElementType getType()
    {
        return type;
    }

    public void setType(ElementType type)
    {
        this.type = type;
    }

    public String getAltName()
    {
        return altName;
    }

    public void setAltName(String altName)
    {
        this.altName = altName;
    }

    public String getAltUrl()
    {
        return altUrl;
    }

    public void setAltUrl(String altUrl)
    {
        this.altUrl = altUrl;
    }

    @Override
    public String toString()
    {
        return "ID:" + id + "," + "Solution:" + solution + "," + "Project:" + project + "," + "ClassPath:" + classPath
                + "," + "Type:" + type + "," + "AltName:" + altName + "," + "AltUrl:" + altUrl;
    }

    @Override
    public int hashCode()
    {
        return ((id == null) ? 0 : id.hashCode());
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        ElementFramework other = (ElementFramework) obj;
        return other.getId().equals(this.getId());
    }
}
