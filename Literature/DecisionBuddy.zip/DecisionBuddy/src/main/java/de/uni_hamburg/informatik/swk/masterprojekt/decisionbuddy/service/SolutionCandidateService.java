package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionCandidatePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate;

/**
 * 
 * Overview of interface of class SolutionCandidateService.
 * 
 * @see architectural specification
 * 
 * @author Lucas
 *
 */
public interface SolutionCandidateService
{
    /**
     * Saves a SolutionCandidate to the database.
     * 
     * @param solutionCandidate A SolutionCandidate
     * @return The saved SolutionCandidate
     * @throws SolutionCandidatePersistenceException Thrown if the object could
     *             not be saved to the database
     */
    SolutionCandidate saveCandidate(SolutionCandidate solutionCandidate) throws SolutionCandidatePersistenceException;

}
