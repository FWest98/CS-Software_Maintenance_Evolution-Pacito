package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

/**
 * This class contains AuthorizationConstants as String that are required for
 * the @PreAuthorize annotations inside the Controllers. Authorization check is
 * done by role.
 * 
 * @author Vlad
 *
 */
public final class AuthorizationConstants
{
    /**
     * private empty constructor.
     */
    private AuthorizationConstants()
    {

    }

    public static final String PROJECT_READ = "hasAuthority('ROLE_PROJECTMEMBER')"
            + " or hasAuthority('ROLE_PROJECTADMIN')" + " or hasAuthority('ROLE_SUPERADMIN')"
            + " or hasAuthority('ROLE_DEVELOPER')";
    public static final String PROJECT_WRITE = "hasAuthority('ROLE_PROJECTADMIN')"
            + " or hasAuthority('ROLE_SUPERADMIN')" + " or hasAuthority('ROLE_DEVELOPER')";

    public static final String CATALOG_WRITE = "hasAuthority('ROLE_CATALOGADMIN')"
            + " or hasAuthority('ROLE_SUPERADMIN')" + " or hasAuthority('ROLE_DEVELOPER')";

    public static final String CONSTRAINT_READ = "hasAuthority('ROLE_SUPERADMIN')"
            + " or hasAuthority('ROLE_CONSTRAINTADMIN')" + " or hasAuthority('ROLE_PROJECTADMIN')"
            + " or hasAuthority('ROLE_CATALOGADMIN')" + " or hasAuthority('ROLE_DEVELOPER')";

    public static final String CONSTRAINT_WRITE = "hasAuthority('ROLE_SUPERADMIN')"
            + " or hasAuthority('ROLE_CONSTRAINTADMIN')";
    public static final String USER_WRITE = "hasAuthority('ROLE_SUPERADMIN')" + " or hasAuthority('ROLE_USERADMIN')";
}
