package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class representing the highest and most abstract custom
 * exception.
 * 
 * Sets the format for all custom thrown exceptions.
 * 
 * @author schaak
 *
 */
public abstract class GeneralException extends Exception
{
    private static final long serialVersionUID = 1L;
    private String exceptionType;

    public String getExceptionType()
    {
        return exceptionType;
    }

    public void setExceptionType(String exceptionType)
    {
        this.exceptionType = exceptionType;
    }
}