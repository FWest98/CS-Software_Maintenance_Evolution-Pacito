package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.Comparator;
import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Overview of interfaces of class SolutionService.
 * 
 * @see architectural specification
 *
 * @author schaak
 *
 */
public interface SolutionService
{
    /**
     * Adds a given solution to the database.
     * 
     * @param solution the solution to be persisted
     * 
     * @return the saved solution object
     * 
     * @throws SolutionPersistenceException Exception if Solution could not be
     *             persisted
     */
    Solution saveSolution(Solution solution) throws SolutionPersistenceException;

    /**
     * Find a solution by given id.
     * 
     * @param id the id of desired solution
     * 
     * @return the matching solution
     * 
     * @throws SolutionNotFoundException Exception if Solution is not found
     */
    Solution getSolutionById(long id) throws SolutionNotFoundException;

    /**
     * Find a solution by given name.
     * 
     * @param name the name of desired solution
     * 
     * @return the matching solution
     * 
     * @throws SolutionNotFoundException Exception if Solution is not found
     */
    Solution getSolutionByName(String name) throws SolutionNotFoundException;

    /**
     * Delete a solution by given id.
     * 
     * @param id the id of the solution that should be deleted
     * 
     * @throws SolutionNotFoundException Exception if Solution is not found
     */
    void deleteSolution(int id) throws SolutionNotFoundException;

    /**
     * Get a list of all current solutions.
     * 
     * @return List of all solutions
     */
    List<Solution> getSolutionCatalog();

    /**
     * Get a list of solutions, given a Filter and a Sorter.
     * 
     * @see Filter
     * @see Comparator
     * 
     * @param filter a Filter object to reduce the result set
     * @param sorter a Sorter object to arrange the result items by criteria
     * 
     * @return List of solutions
     */
    List<Solution> getSolutionsByCriteria(Filter<Solution> filter, Comparator<Solution> sorter);

    /**
     * Get all Framework categories.
     * 
     * @return List of all Framework categories
     */
    List<FrameworkCategory> getFrameworkCategories();

    /**
     * Get all COTS categories.
     * 
     * @return List of all COTS categories
     */
    List<COTSCategory> getCOTSCategories();

    /**
     * Get all ArchitecturalPattern categories.
     * 
     * @return List of all Framework categories
     */
    List<ArchitecturalPatternCategory> getArchitecturalPatternCategories();

    /**
     * Get all DesignPattern categories.
     * 
     * @return List of all DesignPattern categories
     */
    List<DesignPatternCategory> getDesignPatternCategories();

    /**
     * Get all Refactoring categories.
     * 
     * @return List of all Refactoring categories
     */
    List<RefactoringCategory> getRefactoringCategories();

    /**
     * Return if the solution is currently used in any project.
     * 
     * @param solution the solution to be checked upon
     * 
     * @return Boolean if the solution is currently used in any project
     */
    // boolean isUsed(Solution solution);

    /**
     * Imports a set of solutions by a given url to a solution catalog.
     * 
     * @param url url to a solution catalog in the web
     * 
     * @return a set of solutions
     */
    // Set<Solution> importSolutionsWeb(String url);

    /**
     * Imports a set of solutions by a given file representing a solution
     * catalog.
     * 
     * @param file file to a local solution catalog
     * 
     * @return a set of solutions
     */
    // Set<Solution> importSolutionsOS(File file);

    /**
     * Imports a set of solutions by a given set of solutions.
     * 
     * @param solutions the solutions to be imported
     * 
     * @return success of the import operation
     */
    // boolean importSolutions(Set<Solution> solutions);
}