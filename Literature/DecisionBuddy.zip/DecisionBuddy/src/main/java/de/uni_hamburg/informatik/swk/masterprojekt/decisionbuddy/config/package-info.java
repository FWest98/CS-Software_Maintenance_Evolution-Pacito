/**
 * This package contains the configuration files for the web application,
 * database connectivity etc.
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config;