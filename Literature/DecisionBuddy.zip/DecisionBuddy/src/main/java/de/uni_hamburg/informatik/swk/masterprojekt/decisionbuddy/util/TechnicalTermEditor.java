package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;

/**
 * Property editor to convert an Id for a TechnicalTerm given as String to an
 * actual TechnicalTerm object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class TechnicalTermEditor extends PropertyEditorSupport
{
    /**
     * Converts a TechnicalTerm id to a TechnicalTerm object.
     * 
     * @param id the id of the TechnicalTerm
     */
    @Override
    public void setAsText(String id)
    {
        TechnicalTerm technicalTerm = new TechnicalTerm();

        technicalTerm.setId(Long.valueOf(id));
        this.setValue(technicalTerm);
    }

    /**
     * Converts a TechnicalTerm object to the id.
     * 
     * @return id of the TechnicalTerm
     */
    @Override
    public String getAsText()
    {
        TechnicalTerm technicalTerm = (TechnicalTerm) this.getValue();
        String parsedId = String.valueOf(technicalTerm.getId());
        return parsedId;
    }
}