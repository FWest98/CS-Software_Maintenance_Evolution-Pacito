package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

public enum MetricAggrFunction
{
    Average, Count, Maximum, Median, Minimum, Mode, Sum
}
