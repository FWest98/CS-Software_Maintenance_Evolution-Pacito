package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.UserService;

@Component
public class AuthenticationProviderImpl implements AuthenticationProvider
{

    static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationProviderImpl.class);

    @Autowired
    private UserService userService;

    @Autowired
    private MessageSource messageSource;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException
    {
        LOGGER.debug("Fetching authentication details for " + authentication.toString());
        UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authentication;
        String username = String.valueOf(auth.getPrincipal());
        String password = String.valueOf(auth.getCredentials());

        LOGGER.debug("username: " + username);
        LOGGER.debug("password: " + password);

        User user = new User();
        try
        {
            user = userService.getUser(username);
        }
        catch (UserNotFoundException e)
        {
            throw new BadCredentialsException(messageSource.getMessage("exception.loginfailed.message", null,
                    LocaleContextHolder.getLocale()));
        }

        if (!user.getPassword().equals(password))
        {
            throw new BadCredentialsException(messageSource.getMessage("exception.loginfailed.message", null,
                    LocaleContextHolder.getLocale()));
        }
        // Remove input from variables
        username = "";
        password = "";
        return new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
    }

    @Override
    public boolean supports(Class<?> authentication)
    {
        // TODO Auto-generated method stub
        return true;
    }

}
