package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the Property table from the database.
 *
 * @author Tim
 *
 */
@Entity
@Table(name = "Property")
public class Property
{
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Name", unique = true, nullable = false, length = ColumnLength.SHORT)
    private String name;

    @Column(name = "Description", nullable = true, length = ColumnLength.LONG)
    private String description;

    /**
     * Constructor.
     */
    public Property()
    {

    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    @Override
    public String toString()
    {
        return id + "," + name + "," + description;
    }

    @Override
    public int hashCode()
    {
        int result;
        if (id == null)
        {
            result = 0;
        }
        else
        {
            result = id.hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Property other = (Property) obj;
        return other.getId().equals(this.getId());
    }
}