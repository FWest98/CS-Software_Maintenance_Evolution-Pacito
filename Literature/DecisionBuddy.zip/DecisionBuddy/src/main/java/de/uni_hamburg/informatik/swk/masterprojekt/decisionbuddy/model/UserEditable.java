package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.Date;

/**
 * A common interface for projects, issues, solutions. Shares functionality for
 * creating and editing objects
 * 
 * @author 4biryuk
 *
 */
public interface UserEditable
{
    /**
     * Get id of object.
     * 
     * @return id
     */
    Long getId();

    /**
     * Set id of object.
     * 
     * @param id the id of the object
     */
    void setId(Long id);

    /**
     * Get creator of object.
     * 
     * @return creator
     */
    String getCreator();

    /**
     * Set creator of object.
     * 
     * @param creator the creator of the object
     */
    void setCreator(String creator);

    /**
     * Get creation date of object.
     * 
     * @return the creation date of object
     */
    Date getCreationDate();

    /**
     * Set creation date of object.
     * 
     * @param creationDate the creation date of the object
     */
    void setCreationDate(Date creationDate);

    /**
     * Get last modifier of object.
     * 
     * @return the last modifier of the object
     */
    String getLastModifier();

    /**
     * Set last modifier of object.
     * 
     * @param lastModifier the last modifier of the object
     */
    void setLastModifier(String lastModifier);

    /**
     * Get modification date of object.
     * 
     * @return the modification date of the object
     */
    Date getModificationDate();

    /**
     * Set modification date of object.
     * 
     * @param modificationDate the modification date of the object
     */
    void setModificationDate(Date modificationDate);
}
