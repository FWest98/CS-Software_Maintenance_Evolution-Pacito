package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.HelperFunctions;

/**
 * This controller class specifies requests to the index page.
 * 
 * @author Vlad, schaak
 *
 */
@Controller
public class HomeController
{
    @Autowired
    private HelperFunctions helperFunctions;

    /**
     * Root path/index is also mapped to the index page.
     * 
     * @return index page
     */
    @RequestMapping(value = { "/home", "/" })
    public ModelAndView indexPage()
    {
        ModelAndView homeView = new ModelAndView("index");

        // get breadcrumbs and menu for action
        homeView = helperFunctions.getBreadcrumbs("home", homeView);
        homeView = helperFunctions.getMenu("home", homeView);

        return homeView;
    }

    /**
     * CSS-Styling: set home view as active view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return String 'activeview' containing 'catalog'
     */
    @ModelAttribute("activeview")
    public String cssActiveView()
    {
        return "home";
    }

    /**
     * If Status 403 (permission denied) occurs the method calls custom 403
     * page. This is a workaround for now. There has to be a possibility to do
     * this with web.xml.
     * 
     * @return custom 403 view
     */
    @RequestMapping(value = "/error403")
    public ModelAndView status403page()
    {
        ModelAndView view403 = new ModelAndView("error403");
        return view403;
    }
}