package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.CommentDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;

/**
 * Service class for managing comments.
 * 
 * @author schaak
 * 
 */
@Service
@Transactional
public class CommentServiceImpl implements CommentService
{
    @Autowired
    private CommentDAO commentDAO;

    @Autowired
    private IssueService issueService;

    /**
     * Adds a new Comment to the database.
     * 
     * @param comment the comment to save
     * 
     * @return the saved comment object
     * 
     * @throws CommentPersistenceException Exception if Comment could not be
     *             persisted
     */
    @Override
    public Comment saveComment(Comment comment) throws CommentPersistenceException
    {
        Comment savedComment;
        savedComment = commentDAO.saveAndFlush(comment);

        if (savedComment == null)
        {
            throw new CommentPersistenceException();
        }

        return savedComment;
    }

    /**
     * Finds comments of the specified issue id.
     * 
     * @param id ID of the Issue
     * 
     * @return list of comments for that issue
     * 
     * @throws IssueNotFoundException Exception if Issue is not found
     */
    @Override
    public List<Comment> getCommentsByIssueID(long id) throws IssueNotFoundException
    {
        Issue issue = issueService.getIssueById(id);
        Decision decision = issue.getDecision();

        if (decision != null)
        {
            return commentDAO.findByDecisionId(decision.getId());
        }
        else
        {
            return new ArrayList<Comment>();
        }
    }

    /**
     * Finds an comment with the specified ID.
     * 
     * @param id ID of the Comment
     * 
     * @return Comment with the id.
     * 
     * @throws CommentNotFoundException Exception if Comment is not found
     */
    @Override
    public Comment getCommentById(long id) throws CommentNotFoundException
    {
        Comment comment = commentDAO.findOne(id);

        if (comment == null)
        {
            throw new CommentNotFoundException();
        }

        return comment;
    }
}