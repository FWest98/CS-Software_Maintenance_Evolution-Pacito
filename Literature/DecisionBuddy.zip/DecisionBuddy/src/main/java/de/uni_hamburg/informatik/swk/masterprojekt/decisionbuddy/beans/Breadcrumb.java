package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * An instance of this class represents one item in the breadcrumb menu.
 *
 * @author schaak
 * 
 */
public class Breadcrumb implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String name;
    private String url;
    private List<String> params;

    /**
     * Constructor to create a Breadcrumb item.
     * 
     * @param name the text to be displayed as a breadcrumb item
     * @param url the link of the breadcrumb item
     */
    public Breadcrumb(String name, String url)
    {
        this.name = name;
        this.url = url;
        this.params = new ArrayList<String>();
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getUrl()
    {
        return url;
    }

    public void setUrl(String url)
    {
        this.url = url;
    }

    public List<String> getParams()
    {
        return params;
    }

    public void setParams(List<String> params)
    {
        this.params = params;
    }

    /**
     * Adds a single param to params collection.
     * 
     * @param param the string to be added to params collection
     */
    public void addParam(String param)
    {
        this.params.add(param);
    }
}