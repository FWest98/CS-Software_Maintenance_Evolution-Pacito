package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * Interface for GSSRatingService.
 * 
 * @author Lucas
 *
 */
public interface GSSRatingService
{
    /**
     * Rates a solution based on the goal solution scheme.
     * 
     * @param issue The issue, for which the solution should be rated
     * @param solution The solution to be rated
     * @return A value between 0 (bad) and 1 (perfect match)
     */
    float rateSolution(Issue issue, Solution solution);
}
