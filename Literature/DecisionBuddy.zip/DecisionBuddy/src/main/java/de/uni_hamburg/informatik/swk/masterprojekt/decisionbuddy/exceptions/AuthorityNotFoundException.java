package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if an authority is not found / does not
 * exist (anymore).
 * 
 * @author Vlad
 *
 */
public class AuthorityNotFoundException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public AuthorityNotFoundException()
    {
        setExceptionType("authoritynotfound");
    }
}