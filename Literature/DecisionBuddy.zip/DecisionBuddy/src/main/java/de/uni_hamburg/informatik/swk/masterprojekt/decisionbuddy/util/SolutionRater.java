package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RatingDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal;

/**
 * This class is used to get a Score for the solution for the ranking.
 * 
 */
@Component
public class SolutionRater
{
    private final Float userWeight = 0.3f;

    @Autowired
    private RatingDAO ratingDAO;

    /**
     * Empty Constructor.
     */
    public SolutionRater()
    {
    }

    /**
     * Return the score of the solution. Uses the GSS value and the user ratings
     * of the WeightedQualityGoals.
     * 
     * @param solution the score is returned for.
     * @param weightedQualityGoals which are regarded for the score.
     * 
     * @return the score in regard to the weightedQualityGoals.
     */
    public Float assignSolutionScore(Solution solution, List<WeightedQualityGoal> weightedQualityGoals)
    {
        Float userScore = getSolutionUserScore(solution, weightedQualityGoals);
        Float gssScore = FakeGSS.getSolutionRating(solution, weightedQualityGoals);
        Float score = userWeight * userScore + (1 - userWeight) * gssScore;

        solution.setGssScore(round(gssScore, 2));
        solution.setUserScore(round(userScore, 2));
        solution.setOverallScore(round(score, 2));

        return score;
    }

    /**
     * Return the user score of the solution for the weightedQualityGoals.
     * 
     * @param solution the score is returned for.
     * @param weightedQualityGoals which are regarded for the score.
     * 
     * @return the user score in regard to the weightedQualityGoals.
     */
    public Float getSolutionUserScore(Solution solution, List<WeightedQualityGoal> weightedQualityGoals)
    {
        Float result;
        Float score = 0f;
        Float totalWeight = 0f;
        if (weightedQualityGoals != null)
        {
            List<Rating> ratings = ratingDAO.findBySolution(solution);
            for (WeightedQualityGoal weightedQualityGoal : weightedQualityGoals)
            {
                weightedQualityGoal.getQualityGoal();
                weightedQualityGoal.getWeight();
                result = getSolutionUserRatingScoreForQualityGoal(solution, weightedQualityGoal.getQualityGoal(),
                        ratings);
                if (!result.equals(2f))
                {
                    score += result * weightedQualityGoal.getWeight();
                    totalWeight += weightedQualityGoal.getWeight();
                }
            }
            if (totalWeight > 0f)
            {
                score = score / totalWeight;
            }
        }
        return score;
    }

    /**
     * Return the gss score of the solution for the weightedQualityGoals.
     * 
     * @param solution the score is returned for.
     * @param weightedQualityGoals which are regarded for the score.
     * 
     * @return the gss score in regard to the weightedQualityGoals.
     */
    public Float getSolutionGssScore(Solution solution, List<WeightedQualityGoal> weightedQualityGoals)
    {
        return FakeGSS.getSolutionRating(solution, weightedQualityGoals);
    }

    /**
     * Return the user score of the solution for a qualityGoal.
     * 
     * @param solution the score is returned for.
     * @param qualityGoal which is regarded.
     * @param ratings all ratings for the solution.
     * 
     * @return the user score in regard to the qualityGoal.
     */
    private Float getSolutionUserRatingScoreForQualityGoal(Solution solution, QualityGoal qualityGoal,
            List<Rating> ratings)
    {
        int quantity = 0;
        Float score = 0f;
        for (Rating rating : ratings)
        {
            if (rating.getQualityGoal() != null && rating.getQualityGoal().equals(qualityGoal))
            {
                score += ratingToFloat(rating.getRating());
                quantity++;
            }
        }
        // If no Ratings were found 2f is returned to signal that this
        // QualityGoal should be ignored.
        if (quantity > 0)
        {
            score = score / quantity;
        }
        else
        {
            return 2f;
        }
        return score;
    }

    /**
     * Gives a Float value to a natural language rating.
     * 
     * @param rating the rating in natural language.
     * 
     * @return Float value for the natural language rating.
     */
    private static Float ratingToFloat(String rating)
    {
        final Float fiveStar = 1f;
        final Float fourStar = 0.75f;
        final Float threeStar = 0.5f;
        final Float twoStar = 0.25f;
        final Float oneStar = 0f;
        Float score;
        switch (rating)
        {
            case "5":
                score = fiveStar;
                break;
            case "4":
                score = fourStar;
                break;
            case "3":
                score = threeStar;
                break;
            case "2":
                score = twoStar;
                break;
            case "1":
                score = oneStar;
                break;
            default:
                score = 1f;
                break;
        }
        return score;
    }

    /**
     * Returns a rounded double.
     * 
     * @param value the number that should be rounded.
     * @param places the number of places for the rounded number.
     * @return rounded double.
     */
    public float round(float value, int places)
    {
        if (places < 0)
        {
            return 0;
        }
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.floatValue();
    }

}