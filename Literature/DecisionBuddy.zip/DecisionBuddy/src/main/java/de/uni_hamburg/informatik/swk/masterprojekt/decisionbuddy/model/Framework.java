package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the Framework table from the database.
 *
 * @author Vlad
 *
 */
@Entity
@Table(name = "Framework")
@PrimaryKeyJoinColumn(name = "SolutionID")
public class Framework extends Solution
{
    @ManyToOne(targetEntity = FrameworkCategory.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "FrameworkCategoryID", referencedColumnName = "ID", nullable = false)
    private FrameworkCategory frameworkCategory;

    @Column(name = "CurrentVersion", nullable = true, length = ColumnLength.SHORT)
    private String currentVersion;

    @Column(name = "DevelopmentStatus", nullable = true, length = ColumnLength.SHORT)
    private String developmentStatus;

    @Column(name = "Description", nullable = true, columnDefinition = "text")
    private String description;

    @Column(name = "OperatingSystem", nullable = true, columnDefinition = "text")
    private String operatingSystem;

    @Column(name = "ProgrammingLanguage", nullable = true, columnDefinition = "text")
    private String programmingLanguage;

    @Column(name = "Dependencies", nullable = true, columnDefinition = "text")
    private String dependencies;

    @Column(name = "Developer", nullable = true, length = ColumnLength.SHORT)
    private String developer;

    @Column(name = "Website", nullable = true, length = ColumnLength.SHORT)
    private String website;

    @Column(name = "License", nullable = true, length = ColumnLength.SHORT)
    private String license;

    @Column(name = "Support", nullable = true, length = ColumnLength.SHORT)
    private String support;

    @Column(name = "Documentation", nullable = true, length = ColumnLength.SHORT)
    private String documentation;

    @Column(name = "Community", nullable = true, length = ColumnLength.SHORT)
    private String community;

    @Column(name = "Size", nullable = true)
    private Integer size;

    @Column(name = "mvngroupid", nullable = true, length = ColumnLength.SHORT)
    private String mvngroupid;

    @Column(name = "mvnartefactid", nullable = true, length = ColumnLength.SHORT)
    private String mvnartefactid;

    /**
     * Constructor.
     */
    public Framework()
    {
        // set reasonable default values
        this.setType("Framework");

        // default: application framework
        FrameworkCategory fc = new FrameworkCategory();
        fc.setId(Long.valueOf("1"));
        this.setFrameworkCategory(fc);

        this.setDevelopmentStatus("unknown");
        this.setCommunity("unknown");
        this.setLicense("unknown");
        this.setProgrammingLanguage("unknown");
        this.setOperatingSystem("unknown");

        this.setDocumentation("3");
        this.setSupport("3");
    }

    public FrameworkCategory getFrameworkCategory()
    {
        return frameworkCategory;
    }

    public void setFrameworkCategory(FrameworkCategory frameworkCategory)
    {
        this.frameworkCategory = frameworkCategory;
    }

    public String getCurrentVersion()
    {
        return currentVersion;
    }

    public void setCurrentVersion(String currentVersion)
    {
        this.currentVersion = currentVersion;
    }

    public String getDevelopmentStatus()
    {
        return developmentStatus;
    }

    public void setDevelopmentStatus(String developmentStatus)
    {
        this.developmentStatus = developmentStatus;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getOperatingSystem()
    {
        return operatingSystem;
    }

    public void setOperatingSystem(String operatingSystem)
    {
        this.operatingSystem = operatingSystem;
    }

    public String getProgrammingLanguage()
    {
        return programmingLanguage;
    }

    public void setProgrammingLanguage(String programmingLanguage)
    {
        this.programmingLanguage = programmingLanguage;
    }

    public String getDependencies()
    {
        return dependencies;
    }

    public void setDependencies(String dependencies)
    {
        this.dependencies = dependencies;
    }

    public String getDeveloper()
    {
        return developer;
    }

    public void setDeveloper(String developer)
    {
        this.developer = developer;
    }

    public String getWebsite()
    {
        return website;
    }

    public void setWebsite(String website)
    {
        this.website = website;
    }

    public String getLicense()
    {
        return license;
    }

    public void setLicense(String license)
    {
        this.license = license;
    }

    public String getSupport()
    {
        return support;
    }

    public void setSupport(String support)
    {
        this.support = support;
    }

    public String getDocumentation()
    {
        return documentation;
    }

    public void setDocumentation(String documentation)
    {
        this.documentation = documentation;
    }

    public String getCommunity()
    {
        return community;
    }

    public void setCommunity(String community)
    {
        this.community = community;
    }

    public Integer getSize()
    {
        return size;
    }

    public void setSize(Integer size)
    {
        this.size = size;
    }

    public String getMvngroupid()
    {
        return mvngroupid;
    }

    public void setMvngroupid(String mvngroupid)
    {
        this.mvngroupid = mvngroupid;
    }

    public String getMvnartefactid()
    {
        return mvnartefactid;
    }

    public void setMvnartefactid(String mvnartefactid)
    {
        this.mvnartefactid = mvnartefactid;
    }

    @Override
    public String toString()
    {

        return super.toString() + "Framework \n frameworkCategoryId="
                + (frameworkCategory != null ? frameworkCategory.getId() : "unknown") + "\n currentVersion="
                + currentVersion + "\n developmentStatus=" + developmentStatus + "\n description=" + description
                + "\n operatingSystem=" + operatingSystem + "\n programmingLanguage=" + programmingLanguage
                + "\n dependencies=" + dependencies + "\n developer=" + developer + "\n website=" + website
                + "\n license=" + license + "\n support=" + support + "\n documentation=" + documentation
                + "\n community=" + community + "\n size=" + size;
    }

    @Override
    public int hashCode()
    {
        int result = super.hashCode();
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Framework other = (Framework) obj;
        return other.getId().equals(this.getId());
    }
}
