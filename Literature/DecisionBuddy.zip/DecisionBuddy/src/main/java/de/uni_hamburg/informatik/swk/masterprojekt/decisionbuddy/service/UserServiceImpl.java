package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.UsersDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * @see UserService
 * @author Vlad
 *
 */
@Service
@Transactional
public class UserServiceImpl implements UserService
{
    @Autowired
    private UsersDAO userDAO;

    /**
     * {@inheritDoc}
     */
    @Override
    public User saveUser(User user) throws UserPersistenceException
    {
        User savedUser;
        if (userDAO.findOne(user.getUsername()) == null)
        {
            savedUser = userDAO.saveAndFlush(user);
            if (savedUser == null)
            {
                throw new UserPersistenceException();
            }
        }
        else
        {
            throw new UserPersistenceException();
        }

        return savedUser;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public User editUser(User user) throws UserPersistenceException
    {
        User savedUser = userDAO.saveAndFlush(user);
        if (savedUser == null)
        {
            throw new UserPersistenceException();
        }
        return savedUser;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public User getUser(String userName) throws UserNotFoundException
    {
        User user = userDAO.findOne(userName);
        if (user == null)
        {
            throw new UserNotFoundException();
        }
        return user;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<User> getUsers()
    {
        return userDAO.findAll();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteUser(String userName) throws UserNotFoundException
    {
        try
        {
            userDAO.delete(userName);
        }
        catch (DataAccessException e)
        {
            throw new UserNotFoundException();
        }
    }

    @Override
    public List<User> getUsersByCriteria(Filter<User> filter, Comparator<User> sorter)
    {
        List<User> users = getUsers();
        List<User> result = new ArrayList<User>();
        if (filter != null)
        {
            for (User user : users)
            {
                if (filter.isInResult(user))
                {
                    result.add(user);
                }
            }
        }
        else
        {
            result = users;
        }
        if (sorter != null)
        {
            Collections.sort(result, sorter);
        }
        return result;
    }

}
