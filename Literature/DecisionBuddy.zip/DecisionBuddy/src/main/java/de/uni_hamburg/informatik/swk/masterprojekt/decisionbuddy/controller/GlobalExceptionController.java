package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.GeneralException;

/**
 * Controller for handling exceptions on application level.
 * 
 * @author 0georg, schaak
 *
 */
@ControllerAdvice
public class GlobalExceptionController
{
    /**
     * An exception handler for every custom created exception in the
     * application.
     * 
     * @param ge thrown GeneralException object
     * @return error page
     */
    @ExceptionHandler(GeneralException.class)
    public ModelAndView handleGeneralExceptions(GeneralException ge)
    {
        ModelAndView errorPage = new ModelAndView("index");

        errorPage.addObject("jsp", "error");
        errorPage.addObject("exceptionType", ge.getExceptionType());

        return errorPage;
    }

    /**
     * An exception handler for unexpected exceptions in the application.
     * 
     * @param e thrown Exception object
     * @return error page
     */
    /*
     * We need to see errors for file upload.
     * 
     * @ExceptionHandler(Exception.class) public ModelAndView
     * handleExceptions(Exception e) { ModelAndView errorPage = new
     * ModelAndView("index");
     * 
     * errorPage.addObject("jsp", "error"); errorPage.addObject("exceptionType",
     * "unknown");
     * 
     * return errorPage; }
     */

}