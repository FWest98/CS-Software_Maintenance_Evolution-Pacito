package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a string value is not found / does not
 * exist (anymore).
 * 
 * @author schaak
 * 
 */
public class StringValueNotFoundException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public StringValueNotFoundException()
    {
        setExceptionType("stringvaluenotfound");
    }
}
