package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;

/**
 * Abstract class for functionality of validating a solution.
 *
 * @author schaak
 *
 */
abstract class SolutionValidator extends ExtendedValidator
{
    /**
     * Validates constraints of a solution.
     * 
     * @param object
     *            the solution object
     * @param errors
     *            collects encountered field errors
     */
    protected void validateConstraints(Object object, Errors errors)
    {
        Solution solution = (Solution) object;

        // validate constraint elements
        // constraints cannot be invalidated by user on frontend
        for (int i = 0; i < solution.getConstraints().size(); i++)
        {
            Constraint constraint = solution.getConstraints().get(i);

            TechnicalTerm technicalTerm = constraint.getTechnicalTerm();
            String type;
            if (technicalTerm != null)
            {
                type = technicalTerm.getType();
            }
            else
            {
                type = "";
            }

            for (int a = 0; a < constraint.getElements().size(); a++)
            {
                // ConstraintElement constraintElement =
                // constraint.getElements().get(a);

                if ("string".equalsIgnoreCase(type))
                {
                    ValidationUtils.rejectIfEmptyOrWhitespace(errors,
                            "constraints[" + i + "].elements[" + a + "].stringValue",
                            ErrorCodes.REQUIRED);
                }
                else if ("int".equalsIgnoreCase(type))
                {
                    ValidationUtils.rejectIfEmptyOrWhitespace(errors,
                            "constraints[" + i + "].elements[" + a + "].intValue",
                            ErrorCodes.REQUIRED);
                }
                else if ("stringint".equalsIgnoreCase(type))
                {
                    ValidationUtils.rejectIfEmptyOrWhitespace(errors,
                            "constraints[" + i + "].elements[" + a + "].stringValue",
                            ErrorCodes.REQUIRED);
                }
            }
        }
    }
}
