package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax;

import java.io.Serializable;

/**
 * An instance of this class represents a successfull AJAX call.
 *
 * @author schaak
 * 
 */
public class AjaxSuccess extends AjaxResponse implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String lastModifier;
    private String modificationDate;

    /**
     * Constructor to create an AjaxSuccess object.
     * 
     */
    public AjaxSuccess()
    {
        setType("success");
    }

    public String getLastModifier()
    {
        return lastModifier;
    }

    public void setLastModifier(String lastModifier)
    {
        this.lastModifier = lastModifier;
    }

    public String getModificationDate()
    {
        return modificationDate;
    }

    public void setModificationDate(String modificationDate)
    {
        this.modificationDate = modificationDate;
    }
}