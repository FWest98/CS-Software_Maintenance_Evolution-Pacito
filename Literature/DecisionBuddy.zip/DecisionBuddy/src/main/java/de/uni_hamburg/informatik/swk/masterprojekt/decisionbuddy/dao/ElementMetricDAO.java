package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementMetric;

/**
 * A DAO class for ElementMetric.
 * 
 * @author Oliver
 *
 */
public interface ElementMetricDAO extends JpaRepository<ElementMetric, Long>
{
    ElementMetric findByProjectId(Long id);
}
