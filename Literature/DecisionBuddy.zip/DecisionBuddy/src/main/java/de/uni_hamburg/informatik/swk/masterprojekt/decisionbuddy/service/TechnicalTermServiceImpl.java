package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.TechnicalTermDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Service class for managing technicalTerms.
 * 
 * @author Lucas
 *
 */
@Service
@Transactional
public class TechnicalTermServiceImpl implements TechnicalTermService
{
    @Autowired
    private TechnicalTermDAO technicalTermDAO;

    /**
     * Adds a TechnicalTerm to the database.
     * 
     * @param technicalTerm The TechnicalTerm to be persisted.
     * 
     * @return the saved TechnicalTerm
     * 
     * @throws TechnicalTermPersistenceException Exception if TechnicalTerm
     *             could not be persisted.
     */
    @Override
    public TechnicalTerm saveTechnicalTerm(TechnicalTerm technicalTerm) throws TechnicalTermPersistenceException
    {
        // restore connections
        for (StringValue value : technicalTerm.getStringValues())
        {
            value.setTechnicalTerm(technicalTerm);
        }

        TechnicalTerm savedTechnicalTerm;
        savedTechnicalTerm = technicalTermDAO.saveAndFlush(technicalTerm);

        if (savedTechnicalTerm == null)
        {
            throw new TechnicalTermPersistenceException();
        }

        return savedTechnicalTerm;
    }

    /**
     * Find a TechnicalTerm by a given id.
     * 
     * @param id The id of the desired TechnicalTerm.
     * 
     * @return The matching TechnicalTerm.
     * 
     * @throws TechnicalTermNotFoundException Exception if TechnicalTerm is not
     *             found.
     */
    @Override
    public TechnicalTerm getTechnicalTermById(long id) throws TechnicalTermNotFoundException
    {
        TechnicalTerm technicalTerm = technicalTermDAO.findOne(id);

        if (technicalTerm == null)
        {
            throw new TechnicalTermNotFoundException();
        }

        return technicalTerm;
    }

    /**
     * Delete a TechnicalTerm with the given id.
     * 
     * @param id The id of the technicalTerm to be deleted
     * 
     * @throws TechnicalTermNotFoundException Exception if TechnicalTerm is not
     *             found.
     */
    @Override
    public void deleteTechnicalTerm(long id) throws TechnicalTermNotFoundException
    {
        try
        {
            technicalTermDAO.delete(id);
        }
        catch (DataAccessException e)
        {
            throw new TechnicalTermNotFoundException();
        }
    }

    /**
     * Get a list of technicalTerms, given a Filter and a Sorter.
     * 
     * @see Filter
     * @see Comparator
     * 
     * @param filter a Filter object to reduce the result set
     * @param sorter a Sorter object to arrange the result items by criteria
     * 
     * @return List of technicalTerms
     */
    @Override
    public List<TechnicalTerm> getTechnicalTermsByCriteria(Filter<TechnicalTerm> filter,
            Comparator<TechnicalTerm> sorter)
    {
        List<TechnicalTerm> catalog = technicalTermDAO.findAll();
        List<TechnicalTerm> result = new ArrayList<TechnicalTerm>();

        if (filter != null)
        {
            for (TechnicalTerm element : catalog)
            {
                if (filter.isInResult(element))
                {
                    result.add(element);
                }
            }
        }
        else
        {
            result = catalog;
        }

        if (sorter != null)
        {
            Collections.sort(result, sorter);
        }

        return result;
    }
}