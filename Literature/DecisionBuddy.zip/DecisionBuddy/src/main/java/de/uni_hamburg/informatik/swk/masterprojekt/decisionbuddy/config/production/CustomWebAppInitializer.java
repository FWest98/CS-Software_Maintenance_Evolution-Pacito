package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.core.annotation.Order;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.filter.CharacterEncodingFilter;

/**
 * This Web App initializer comes first and sets Character encoding to UTF-8 for
 * POST.
 * 
 * @author Vlad
 *
 */
@Order(0)
public class CustomWebAppInitializer implements WebApplicationInitializer
{

    @Override
    public void onStartup(ServletContext servletContext) throws ServletException
    {
        FilterRegistration charEncodingfilterReg = servletContext.addFilter("CharacterEncodingFilter",
                CharacterEncodingFilter.class);
        charEncodingfilterReg.setInitParameter("encoding", "UTF-8");
        charEncodingfilterReg.setInitParameter("forceEncoding", "true");
        charEncodingfilterReg.addMappingForUrlPatterns(null, false, "/*");
    }
}