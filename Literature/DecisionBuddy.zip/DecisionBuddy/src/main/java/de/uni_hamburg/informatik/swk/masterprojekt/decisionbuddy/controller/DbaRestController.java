package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DbaCatalogDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DbaCatalogDAOImpl;

@RestController
public class DbaRestController
{
    @Autowired
    private DbaCatalogDAO dbaCatalogDAO;

    @RequestMapping("/dbacatalog")
    public FileSystemResource greeting()
    {
        dbaCatalogDAO.generateFrameworkCatalog();
        return new FileSystemResource(DbaCatalogDAOImpl.catalogFilePath());
    }

}
