package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * An instance of this class represents a failed AJAX call.
 *
 * @author schaak
 * 
 */
public class AjaxFailure extends AjaxResponse implements Serializable
{
    private static final long serialVersionUID = 1L;
    private List<AjaxFailureItem> ajaxFailureItems;

    /**
     * Constructor to create an AjaxFailure object.
     * 
     */
    public AjaxFailure()
    {
        setType("failure");
        ajaxFailureItems = new ArrayList<AjaxFailureItem>();
    }

    public List<AjaxFailureItem> getAjaxFailureItems()
    {
        return ajaxFailureItems;
    }

    public void setAjaxFailureItems(List<AjaxFailureItem> ajaxFailureItems)
    {
        this.ajaxFailureItems = ajaxFailureItems;
    }

    /**
     * Adds a FailureItem to the list of failure items.
     * 
     * @param ajaxFailureItem the item to be added
     */
    public void addAjaxFailureItem(AjaxFailureItem ajaxFailureItem)
    {
        this.ajaxFailureItems.add(ajaxFailureItem);
    }
}