package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AuthorityNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.AuthorityService;

/**
 * 
 * @author Vlad
 *
 */
@Component
public class AuthorityEditor extends PropertyEditorSupport
{
    @Autowired
    private AuthorityService authorityService;

    /**
     * Converts a Authority String id to a Authority object.
     * 
     * @param id the id of the StringValue
     */
    @Override
    public void setAsText(String authorityName)
    {
        Authority authority = null;
        try
        {
            authority = authorityService.getAuthorityByName(authorityName);
        }
        catch (AuthorityNotFoundException e)
        {
            e.printStackTrace();
        }
        setValue(authority);
    }

    /**
     * Converts an Authority object to an the id.
     * 
     * @return id of the StringValue
     */
    @Override
    public String getAsText()
    {
        Object object = getValue();
        Authority authority = (Authority) object;
        String authorityName = "";
        if (authority != null)
        {
            if (authority.getAuthority() != null)
            {
                authorityName = authority.getAuthority();
            }
        }
        return authorityName;
    }
}
