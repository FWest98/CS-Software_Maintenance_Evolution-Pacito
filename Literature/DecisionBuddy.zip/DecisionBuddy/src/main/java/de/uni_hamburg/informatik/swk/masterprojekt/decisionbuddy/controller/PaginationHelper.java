package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.util.List;

import org.springframework.beans.support.PagedListHolder;
import org.springframework.stereotype.Component;

/**
 * Generic class to handle Pagination.
 * 
 * @author 4biryuk
 * 
 * @param <E> the type of objects on the pages
 *
 */
@Component
public class PaginationHelper<E>
{
    private PagedListHolder<E> pagedListHolder;

    private static final int PAGE_SIZE_DEFAULT = 10;
    private static final int PAGE_NR_DEFAULT = 0;

    /**
     * Public default constructor.
     */
    public PaginationHelper()
    {
        pagedListHolder = new PagedListHolder<E>();
    }

    public PagedListHolder<E> getPagedListHolder()
    {
        return pagedListHolder;
    }

    public void setPagedListHolder(PagedListHolder<E> pagedListHolder)
    {
        this.pagedListHolder = pagedListHolder;
    }

    /**
     * Helper method to determine page size of lists.
     * 
     * @param pageSize the size of the page as string
     * 
     * @return the parsed page size as int
     * 
     */
    public int parsePageSize(String pageSize)
    {
        if (pageSize != null)
        {
            try
            {
                return Integer.parseInt(pageSize);
            }
            catch (NumberFormatException nfe)
            {
                return PAGE_SIZE_DEFAULT;
            }
        }
        else
        {
            return PAGE_SIZE_DEFAULT;
        }
    }

    /**
     * Helper method to determine current page of lists.
     * 
     * @param page the page number as string
     * 
     * @return the parsed page number
     * 
     */
    public int parsePage(String page)
    {
        if (page != null)
        {
            try
            {
                return Integer.parseInt(page);
            }
            catch (NumberFormatException nfe)
            {
                return PAGE_NR_DEFAULT;
            }
        }
        else
        {
            return PAGE_NR_DEFAULT;
        }
    }

    /**
     * Configures the pagedListHolder.
     * 
     * @param list the list of objects to organize in pages
     * @param pageSize the size of each page
     * @param page the page to show
     */
    public void configure(List<E> list, String pageSize, String page)
    {
        pagedListHolder.setSource(list);
        pagedListHolder.setPageSize(parsePageSize(pageSize));
        // internally starts with page 0, on frontend with page 1
        pagedListHolder.setPage((parsePage(page) > 0) ? parsePage(page) - 1 : parsePage(page));
    }

    /**
     * Gets a list of objects of type <E> from pagedListHolder.
     * 
     * @return List<E> the list of objects of current page
     */
    public List<E> getPageList()
    {
        return pagedListHolder.getPageList();
    }
}