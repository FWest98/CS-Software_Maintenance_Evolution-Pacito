/**
 * This package contains model validations.
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;