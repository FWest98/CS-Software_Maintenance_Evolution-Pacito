package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

/**
 * This class delivers constant values for column length values for the entity
 * beans.
 * 
 * @author Vlad
 * 
 */
public final class ColumnLength
{
    /**
     * Constructor is private because the class doesen't need to be
     * instanciated.
     */
    private ColumnLength()
    {

    }

    public static final int CREDENTIAL = 50;
    public static final int SHORT = 200;
    public static final int DESCRIPTION = 500;
    public static final int MEDIUM = 10000;
    public static final int LONG = 20000;
}