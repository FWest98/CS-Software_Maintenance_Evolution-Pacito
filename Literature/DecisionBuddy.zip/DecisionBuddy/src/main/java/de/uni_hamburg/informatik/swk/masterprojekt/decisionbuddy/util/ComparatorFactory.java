package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.lang.reflect.Field;
import java.util.Comparator;

import org.springframework.util.ReflectionUtils;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * Factory for Comparators.
 * 
 * @author Tim, Vlad
 * 
 * @param <T> Type of Comparator factory
 *
 */
public class ComparatorFactory<T>
{
    // Finding out the type of the T didn't work I tried several methods and
    // even typetools. Now it has to be set as a parameter in the constructor.
    private final Class<T> type;

    /**
     * Default public constructor.
     * 
     * @param type the type of the comparator factory
     */
    public ComparatorFactory(Class<T> type)
    {
        this.type = type;
    }

    /**
     * Generates the appropriate Comparator.
     * 
     * @param column the column by which the collection is to be sorted.
     * @return a comparator that can sort a collection of type T.
     * @throws SorterFieldNotFoundException sorting field is not found
     * @throws SorterInvalidTypeException sorting field type is invalid
     */
    public Comparator<T> generateComparator(String column) throws SorterFieldNotFoundException,
            SorterInvalidTypeException
    {
        if (column == null)
        {
            // default sorting attribute
            column = "id";
        }

        Comparator<T> comparator;

        final Field field = ReflectionUtils.findField(type, column);

        if (field == null)
        {
            throw new SorterFieldNotFoundException();
        }

        ReflectionUtils.makeAccessible(field);

        if (field.getType().equals(String.class))
        {
            comparator = generateStringComparator(field);
        }
        else if (field.getType().equals(Long.class))
        {
            comparator = generateLongComparator(field);
        }
        else if (field.getType().equals(Integer.class))
        {
            comparator = generateIntegerComparatator(field);
        }
        else
        {
            throw new SorterInvalidTypeException();
        }
        return comparator;
    }

    /**
     * Generator method for comparing two solutions based on overall scores.
     * 
     * @return a Comparator for overall score comparison.
     */
    public Comparator<Solution> generateScoreComparatator()
    {
        Comparator<Solution> solutionComparator = new Comparator<Solution>()
        {
            public int compare(Solution s1, Solution s2)
            {
                Float s1Value = s1.getOverallScore();
                Float s2Value = s2.getOverallScore();
                return s1Value.compareTo(s2Value);
            }
        };

        return solutionComparator;
    }

    /**
     * Generator method for String fields.
     * 
     * @param field the field by which the collection is sorted
     * @return a Comparator for String fields.
     */
    private Comparator<T> generateStringComparator(final Field field)
    {
        Comparator<T> comparator = new Comparator<T>()
        {
            public int compare(T t1, T t2)
            {
                String t1Value = (String) ReflectionUtils.getField(field, t1);
                String t2Value = (String) ReflectionUtils.getField(field, t2);
                return t1Value.toLowerCase().compareTo(t2Value.toLowerCase());
            }
        };

        return comparator;
    }

    /**
     * Generator method for Long fields.
     * 
     * @param field the field by which the collection is sorted
     * @return a Comparator for Long fields.
     */
    private Comparator<T> generateLongComparator(final Field field)
    {
        Comparator<T> comparator = new Comparator<T>()
        {
            public int compare(T t1, T t2)
            {
                Long t1Value = (Long) ReflectionUtils.getField(field, t1);
                Long t2Value = (Long) ReflectionUtils.getField(field, t2);
                return t1Value.compareTo(t2Value);
            }
        };

        return comparator;
    }

    /**
     * Generator method for Integer fields.
     * 
     * @param field the field by which the collection is sorted
     * @return a Comparator for Integer fields.
     */
    private Comparator<T> generateIntegerComparatator(final Field field)
    {
        Comparator<T> comparator = new Comparator<T>()
        {
            public int compare(T t1, T t2)
            {
                Integer t1Value = (Integer) ReflectionUtils.getField(field, t1);
                Integer t2Value = (Integer) ReflectionUtils.getField(field, t2);
                return t1Value.compareTo(t2Value);
            }
        };

        return comparator;
    }
}