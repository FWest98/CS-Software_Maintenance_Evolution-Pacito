package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * An instance of this class represents one item in the menu.
 * 
 * @author schaak
 *
 */
public class MenuItem implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String name;
    private String url;
    private String picture;
    private List<String> params;

    /**
     * Constructor to create menu item.
     * 
     * @param name the text to be displayed as a menu item
     * @param url the link of the menu item
     * @param picture the picture for a menu item
     */
    public MenuItem(String name, String url, String picture)
    {
        this.name = name;
        this.url = url;
        this.picture = picture;
        this.params = new ArrayList<String>();
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getUrl()
    {
        return url;
    }

    public void setUrl(String url)
    {
        this.url = url;
    }

    public String getPicture()
    {
        return picture;
    }

    public void setPicture(String picture)
    {
        this.picture = picture;
    }

    public List<String> getParams()
    {
        return params;
    }

    public void setParams(List<String> params)
    {
        this.params = params;
    }

    /**
     * Adds a single param to params collection.
     * 
     * @param param the string to be added to params collection
     */
    public void addParam(String param)
    {
        this.params.add(param);
    }
}