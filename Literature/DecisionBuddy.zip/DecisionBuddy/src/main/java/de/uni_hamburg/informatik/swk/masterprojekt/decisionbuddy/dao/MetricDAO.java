package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

/**
 * A DAO class for Metric.
 * 
 * @author Burak
 *
 */

public interface MetricDAO extends JpaRepository<Metric, Long>
{
    Metric findByNameLangFile(String nameLangFile);

    Metric findByNameXmlAndType(String nameXml, MetricType type);

    List<Metric> findByType(MetricType type);

    List<Metric> findBySubType(MetricSubType subType);

    List<Metric> findByTypeAndSubType(MetricType type, MetricSubType subType);
}
