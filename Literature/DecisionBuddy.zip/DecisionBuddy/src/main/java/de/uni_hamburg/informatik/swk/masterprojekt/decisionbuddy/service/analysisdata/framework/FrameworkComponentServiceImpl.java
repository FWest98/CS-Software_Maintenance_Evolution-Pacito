package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.framework;

import java.util.List;

import javassist.NotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementFrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

@Service
@Transactional
public class FrameworkComponentServiceImpl implements FrameworkComponentService
{

    @Autowired
    private ElementFrameworkDAO elementFrameworkDAO;

    @Override
    public List<ElementFramework> getFrameworksForElement(Long projectId, String classPath) throws NotFoundException
    {
        return elementFrameworkDAO.findByProjectIdAndClassPath(projectId, classPath);
    }

    @Override
    public List<ElementFramework> getFrameworksForProject(Long projectId, ElementType type) throws NotFoundException
    {
        return elementFrameworkDAO.findByProjectIdAndType(projectId, type);
    }

}
