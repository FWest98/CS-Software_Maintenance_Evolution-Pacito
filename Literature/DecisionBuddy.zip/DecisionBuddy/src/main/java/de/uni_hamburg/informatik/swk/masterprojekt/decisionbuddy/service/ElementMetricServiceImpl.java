package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementMetricDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementMetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementMetricPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementMetric;

/**
 * Service class for managing projects.
 *
 * @author Oliver
 *
 */
@Service
@Transactional
public class ElementMetricServiceImpl implements ElementMetricService
{

    // @Autowired
    // private ProjectDAO projectDAO;

    @Autowired
    private ElementMetricDAO elementMetricDAO;

    /**
     * Adds a new Project to the database.
     * 
     * @param project the project to save
     * 
     * @return the saved project object
     * 
     * @throws ElementMetricPersistenceException Exception if ElementMetric
     *             could not be persisted
     */
    @Override
    public ElementMetric saveElementMetric(ElementMetric elementMetric) throws ElementMetricPersistenceException
    {
        ElementMetric savedElementMetric;
        savedElementMetric = elementMetricDAO.saveAndFlush(elementMetric);

        if (savedElementMetric == null)
        {
            throw new ElementMetricPersistenceException();
        }

        return savedElementMetric;
    }

    /**
     * Deletes a project with the specified ID.
     * 
     * @param id the id of the project to be deleted
     * 
     * @throws ElementMetricNotFoundException Exception if ElementMetric is not
     *             found
     */
    @Override
    public void deleteElementMetric(long id) throws ElementMetricNotFoundException
    {
        try
        {
            elementMetricDAO.delete(id);
        }
        catch (DataAccessException e)
        {
            throw new ElementMetricNotFoundException();
        }
    }

    /**
     * Finds a project with the specified ID.
     * 
     * @param id ID of the Project
     * 
     * @return Project with the id.
     * 
     * @throws ElementMetricNotFoundException Exception if ElementMetric is not
     *             found
     */
    @Override
    public ElementMetric getElementMetricById(long id) throws ElementMetricNotFoundException
    {
        ElementMetric elementMetric = elementMetricDAO.findOne(id);

        if (elementMetric == null)
        {
            throw new ElementMetricNotFoundException();
        }

        return elementMetric;
    }

    @Override
    public ElementMetric getElementMetricByProjectId(long id) throws ElementMetricNotFoundException
    {
        ElementMetric elementMetric = elementMetricDAO.findByProjectId(id);

        if (elementMetric == null)
        {
            throw new ElementMetricNotFoundException();
        }

        return elementMetric;
    }
}