package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.metric;

import java.util.List;

import javassist.NotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementMetricService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.MetricService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.MetricValueService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

@Service
@Transactional
public class MetricComponentServiceImpl implements MetricComponentService
{

    @Autowired
    private ElementMetricService elementMetricService;
    @Autowired
    private MetricValueService metricValueService;
    @Autowired
    private MetricService metricService;

    @Override
    public Element getRootElementForProjectid(int projectId) throws NotFoundException
    {
        Element result = null;
        try
        {
            result = elementMetricService.getElementMetricByProjectId(projectId).getElement();
        }
        catch (Exception e)
        {
            throw new NotFoundException("No Project or RootElement Found.");
        }
        return result;
    }

    @Override
    public List<Metric> getMetricsByType(int projectId, MetricType type) throws NotFoundException
    {
        return metricService.getMetricsByType(type);
    }

    @Override
    public List<MetricValue> getMetricsByTypeAndSubtype(int projectId, MetricType type, MetricSubType subtype)
    {
        return metricValueService.getMetricValuesByProjectIDAndTypeAndSubType(projectId, type, subtype);
    }

    @Override
    public List<MetricValue> getMetricValuesForElement(long elementId, MetricType type) throws NotFoundException
    {
        return metricValueService.getMetricValuesByElementIDAndType(elementId, type);
    }
}
