/**
 * This package contains the "decision buddy" web application.
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy;