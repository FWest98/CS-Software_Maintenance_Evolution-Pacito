package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the DesignPattern table from the database.
 *
 * @author Tim
 *
 */
@Entity
@org.hibernate.annotations.Proxy(lazy = false)
@Table(name = "DesignPattern")
@PrimaryKeyJoinColumn(name = "SolutionID")
public class DesignPattern extends Solution
{
    /**
     * Constructor.
     */
    public DesignPattern()
    {
        this.setType("DesignPattern");
        DesignPatternCategory dp = new DesignPatternCategory();
        dp.setId(Long.valueOf("1"));
        this.setDesignPatternCategory(dp);
    }

    @ManyToOne(targetEntity = DesignPatternCategory.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "DesignPatternCategoryID", referencedColumnName = "ID", nullable = false)
    private DesignPatternCategory designPatternCategory;

    @Column(name = "AltName1", nullable = true, length = ColumnLength.SHORT)
    private String altName1;

    @Column(name = "AltName2", nullable = true, length = ColumnLength.SHORT)
    private String altName2;

    @Column(name = "Intent", nullable = true, columnDefinition = "text")
    private String intent;

    @Column(name = "Motivation", nullable = true, columnDefinition = "text")
    private String motivation;

    @Column(name = "Applicability", nullable = true, columnDefinition = "text")
    private String applicability;

    @Column(name = "Structure", columnDefinition = "blob", nullable = true)
    private java.sql.Blob structure;

    @Column(name = "Participants", nullable = true, columnDefinition = "text")
    private String participants;

    @Column(name = "Collaboration", nullable = true, columnDefinition = "text")
    private String collaboration;

    @Column(name = "Consequences", nullable = true, columnDefinition = "text")
    private String consequences;

    @Column(name = "Implementation", nullable = true, columnDefinition = "text")
    private String implementation;

    @Column(name = "SampleCode", nullable = true, columnDefinition = "text")
    private String sampleCode;

    @Column(name = "KnownUses", nullable = true, columnDefinition = "text")
    private String knownUses;

    @Column(name = "RelatedPatterns", nullable = true, columnDefinition = "text")
    private String relatedPatterns;

    public DesignPatternCategory getDesignPatternCategory()
    {
        return designPatternCategory;
    }

    public void setDesignPatternCategory(DesignPatternCategory designPatternCategory)
    {
        this.designPatternCategory = designPatternCategory;
    }

    public String getAltName1()
    {
        return altName1;
    }

    public void setAltName1(String altName1)
    {
        this.altName1 = altName1;
    }

    public String getAltName2()
    {
        return altName2;
    }

    public void setAltName2(String altName2)
    {
        this.altName2 = altName2;
    }

    public String getIntent()
    {
        return intent;
    }

    public void setIntent(String intent)
    {
        this.intent = intent;
    }

    public String getMotivation()
    {
        return motivation;
    }

    public void setMotivation(String motivation)
    {
        this.motivation = motivation;
    }

    public String getApplicability()
    {
        return applicability;
    }

    public void setApplicability(String applicability)
    {
        this.applicability = applicability;
    }

    public java.sql.Blob getStructure()
    {
        return structure;
    }

    public void setStructure(java.sql.Blob structure)
    {
        this.structure = structure;
    }

    public String getParticipants()
    {
        return participants;
    }

    public void setParticipants(String participants)
    {
        this.participants = participants;
    }

    public String getCollaboration()
    {
        return collaboration;
    }

    public void setCollaboration(String collaboration)
    {
        this.collaboration = collaboration;
    }

    public String getConsequences()
    {
        return consequences;
    }

    public void setConsequences(String consequences)
    {
        this.consequences = consequences;
    }

    public String getImplementation()
    {
        return implementation;
    }

    public void setImplementation(String implementation)
    {
        this.implementation = implementation;
    }

    public String getSampleCode()
    {
        return sampleCode;
    }

    public void setSampleCode(String sampleCode)
    {
        this.sampleCode = sampleCode;
    }

    public String getKnownUses()
    {
        return knownUses;
    }

    public void setKnownUses(String knownUses)
    {
        this.knownUses = knownUses;
    }

    public String getRelatedPatterns()
    {
        return relatedPatterns;
    }

    public void setRelatedPatterns(String relatedPatterns)
    {
        this.relatedPatterns = relatedPatterns;
    }

    @Override
    public int hashCode()
    {
        int result = super.hashCode();
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        DesignPattern other = (DesignPattern) obj;
        return other.getId().equals(this.getId());
    }
}