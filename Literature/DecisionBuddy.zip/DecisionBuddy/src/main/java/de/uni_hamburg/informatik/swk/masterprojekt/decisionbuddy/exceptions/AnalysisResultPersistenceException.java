package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * Exception for persisting DecisionBuddy-conform Analysis Results.
 * 
 * @author 1vietor
 *
 */
public class AnalysisResultPersistenceException extends AnalysisResultException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public AnalysisResultPersistenceException()
    {
        setExceptionType("analysisresultpersistence");
    }

    @Override
    public String getViewMode()
    {
        return "result.error.persistence";
    }
}
