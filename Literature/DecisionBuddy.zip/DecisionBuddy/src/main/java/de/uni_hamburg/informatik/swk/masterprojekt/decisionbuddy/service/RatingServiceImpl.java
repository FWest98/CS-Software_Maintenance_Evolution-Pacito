package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RatingDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.RatingNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.RatingPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * Service class for managing ratings.
 * 
 * @author schaak
 * 
 */
@Service
@Transactional
public class RatingServiceImpl implements RatingService
{
    @Autowired
    private RatingDAO ratingDAO;

    @Autowired
    private SolutionService solutionService;

    /**
     * Adds a new Rating to the database.
     * 
     * @param rating the rating to save
     * 
     * @return the saved rating object
     * 
     * @throws RatingPersistenceException Exception if Rating could not be
     *             persisted
     */
    @Override
    public Rating saveRating(Rating rating) throws RatingPersistenceException
    {
        Rating savedRating;
        savedRating = ratingDAO.saveAndFlush(rating);

        if (savedRating == null)
        {
            throw new RatingPersistenceException();
        }

        return savedRating;
    }

    /**
     * Finds ratings of the specified solution id.
     * 
     * @param id ID of the Solution
     * 
     * @return list of ratings for that solution
     * 
     * @throws SolutionNotFoundException Exception if Solution is not found
     */
    @Override
    public List<Rating> getRatingsBySolutionID(long id) throws SolutionNotFoundException
    {
        Solution solution = solutionService.getSolutionById(id);

        return ratingDAO.findBySolutionId(solution.getId());
    }

    /**
     * Finds an rating with the specified ID.
     * 
     * @param id ID of the Rating
     * 
     * @return Rating with the id.
     * 
     * @throws RatingNotFoundException Exception if Rating is not found
     */
    @Override
    public Rating getRatingById(long id) throws RatingNotFoundException
    {
        Rating rating = ratingDAO.findOne(id);

        if (rating == null)
        {
            throw new RatingNotFoundException();
        }

        return rating;
    }
}