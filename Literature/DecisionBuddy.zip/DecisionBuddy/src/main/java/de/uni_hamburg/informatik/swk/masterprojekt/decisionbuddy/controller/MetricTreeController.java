package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.MetricValueService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.designpattern.DesignPatternComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.framework.FrameworkComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.metric.MetricComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorizationConstants;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;
import javassist.NotFoundException;

/**
 * Controller to lazy load structural metrics.
 * 
 * @author 1fechner
 *
 */
@Controller
@RequestMapping(value = "/project")
public class MetricTreeController {
	private static final String ANALYSIS_METRICS_THRESHOLD_OK = "analysis.metrics.threshold.ok";
	private static final String ANALYSIS_METRICS_THRESHOLD_TOHIGH = "analysis.metrics.threshold.tohigh";
	private static final String ANALYSIS_METRICS_THRESHOLD_TOLOW = "analysis.metrics.threshold.tolow";
	private static final String ANALYSIS_METRICS_DESCRIPTION = "analysis.metrics.%s.description";
	private static final String ANALYSIS_METRICS = "analysis.metrics.%s";
	// Constants for JSON keys
	private static final String KEY_ID = "id";
	private static final String KEY_PARENT = "parent";
	private static final String KEY_PATH = "path";
	private static final String KEY_TYPE = "type";
	private static final String KEY_EXPANDABILITY = "expandability";
	private static final String KEY_VALUE = "value";
	private static final String KEY_THRESHOLD = "thresh";
	private static final String KEY_THRESHOLD_REASON = "threshreason";
	private static final String KEY_NAME = "name";
	private static final String KEY_DESCRIPTION = "desc";
	// private static final String KEY_IS_PACKAGE = "isPackage";
	private static final String KEY_METRICS = "metrics";
	private static final String KEY_FRAMEWORKS = "frameworks";
	private static final String KEY_PATTERNS = "patterns";
	private static final String KEY_NODES = "nodes";
	private static final String KEY_METRIC_VALUES = "metricValues";
	private static final String KEY_IN_CATALOG = "inCatalog";
	private static final String KEY_URL = "url";
	private static final String KEY_ROLE = "role";

	// Constants for expandablility
	private static final String EXPANDABLE = "expandable";
	private static final String NOT_EXPANDABLE = "notexpandable";

	// Constants for type
	private static final String FOLDER = "folder";
	private static final String FILE = "file";

	// Constants for default JSON-Values
	private static final String EMPTY = "";
	private static final String NONE = "-";

	@Autowired
	private ElementService elementService;

	@Autowired
	private MetricValueService metricValueService;

	@Autowired
	private MetricComponentService metricComponentService;

	@Autowired
	private FrameworkComponentService frameworkComponentService;

	@Autowired
	private DesignPatternComponentService designpatternComponentService;

	@Autowired
	private MessageSource messageSource;

	/**
	 * Return a list of children for the node with the given id.
	 * 
	 * @param projectId
	 *            The project the node belongs to
	 * @param id
	 *            The id of the node whose children are to be found
	 * @return A JSON-String containing all child-nodes of the given node
	 * @throws NotFoundException
	 * @throws ElementNotFoundException
	 */
	@SuppressWarnings("unchecked")
	@PreAuthorize(AuthorizationConstants.PROJECT_READ)
	@RequestMapping(value = "/project/{projectId}/metrics/child", produces = "application/json", method = RequestMethod.GET)
	public @ResponseBody String getChildNodes(@PathVariable Integer projectId,
			@RequestParam("id") Integer id) throws NotFoundException,
			ElementNotFoundException {
		// Read the relevant Metrics which tell us the number and position of
		List<Metric> relevantMetrics = metricComponentService.getMetricsByType(
				projectId, MetricType.Structural);

		// Create List
		JSONArray nodes = new JSONArray();

		// Get all child nodes to the given node id from database
		List<Element> childElements = elementService
				.getElementsByParentId((long) id);

		// Now we loop through all child elements
		for (Element element : childElements) {
			// Remark: added @SuppressWarnings("unchecked") annotation to
			// prevent eclipse nagging on raw types in map.put(<K,V>)...
			JSONObject a = new JSONObject();

			// We get all metric values for our current element
			List<MetricValue> elementMetrics = metricValueService
					.getMetricValuesByElementID(element.getId());

			// Put the static data of the element like id, parent and name
			a.put(KEY_ID, element.getId());
			a.put(KEY_PARENT, element.getParent().getId());
			a.put(KEY_PATH, element.getName());
			a.put(KEY_TYPE, this.elementTypeToString(element.getType()));
			a.put(KEY_EXPANDABILITY,
					this.getExpandability((long) element.getId()));

			JSONObject metricValuesJson = new JSONObject();
			int order = 0;

			// As our JSON is used to fill an html table we need to pass as many
			// elements as in the table header, thus we need to only show those
			// metrics of the element which are also part of relevantMetrics
			for (Metric relevantMetric : relevantMetrics) {
				order++;

				// Init Json Object to put current metric data
				JSONObject metric = new JSONObject();

				// Find the correct metric for our column
				MetricValue metricValue = findMetricInList(elementMetrics,
						relevantMetric);

				prepareJSONObject(metric, metricValue);

				// Put metric value to our JSON Object of all metric values of
				// current row
				metricValuesJson.put(order, (Object) metric);
				a.put(KEY_METRIC_VALUES, metricValuesJson);

			}

			nodes.add(a);
		}

		JSONObject jSONObject = new JSONObject();
		jSONObject.put(KEY_NODES, (Object) nodes);

		return jSONObject.toJSONString();
	}

	/**
	 * Returns an object containing additional information for the given node.
	 * 
	 * @param projectId
	 *            The id of the project the current node belongs to
	 * @param id
	 *            The id of the node whose additional information are to be
	 *            displayed
	 * @return A JSON-String
	 */
	@SuppressWarnings("unchecked")
	@PreAuthorize(AuthorizationConstants.PROJECT_READ)
	@RequestMapping(value = "/project/{projectId}/metrics/additional", produces = "application/json", method = RequestMethod.GET)
	public @ResponseBody String getAdditionalInformationForNode(
			@PathVariable Integer projectId,
			@RequestParam("id") Integer id,
			@RequestParam(value = "classpath", required = false) String classPath) {
		// Create object for list and serialize
		JSONObject ret = new JSONObject();

		ret.put(KEY_METRICS, (Object) getAdditionalMetrics(id));
		ret.put(KEY_FRAMEWORKS,
				(Object) getAdditionalFrameworks(projectId, classPath));
		ret.put(KEY_PATTERNS,
				(Object) getAdditionalPatterns(projectId, classPath));

		return ret.toJSONString();
	}

	@SuppressWarnings("unchecked")
	private JSONArray getAdditionalMetrics(Integer id) {
		// Create list of additional values
		List<MetricValue> additionalValues = new ArrayList<>();

		// Get locale for translation
		Locale locale = LocaleContextHolder.getLocale();

		// Try getting values for element
		try {
			additionalValues = metricComponentService
					.getMetricValuesForElement(id, MetricType.Additional);
		} catch (NotFoundException e) {
			e.printStackTrace();
		}

		// Add metrics
		JSONArray metrics = new JSONArray();

		for (MetricValue value : additionalValues) {
			JSONObject v = new JSONObject();

			String name = value.getMetric().getNameLangFile();

			String translatedName = messageSource.getMessage(
					String.format(ANALYSIS_METRICS, name), null, locale);

			// Build JSON-Object
			v.put(KEY_NAME, translatedName);
			v.put(KEY_DESCRIPTION, messageSource.getMessage(
					String.format(ANALYSIS_METRICS_DESCRIPTION, name), null,
					locale));

			v = prepareJSONObject(v, value);

			// Add object to list
			metrics.add((Object) v);
		}
		return metrics;
	}

	@SuppressWarnings("unchecked")
	private JSONArray getAdditionalFrameworks(Integer projectId,
			String classPath) {

		List<ElementFramework> additionalFrameworks = new ArrayList<>();

		// Try getting frameworks for element
		try {
			Long longProjectId = Long.valueOf(projectId);

			
			//Remove Duplicates
			List<ElementFramework> additionalFrameworksWithDuplicates = 
					frameworkComponentService.getFrameworksForElement(longProjectId, classPath);
			for ( ElementFramework ef: additionalFrameworksWithDuplicates )
			{
				boolean contained = false;
				
				for ( ElementFramework efCompare: additionalFrameworks)
					if (efCompare.getSolution() == null)
					{
						if (efCompare.getAltName().equals(ef.getAltName()))
							contained = true;
					} 
					else
					{
						if (ef.getSolution() != null)
							if (efCompare.getSolution().getName().equals(ef.getSolution().getName()))
								contained = true;							
					}
						
					
				
				if (!contained)
					additionalFrameworks.add(ef);	

			}
			
			
		} catch (NotFoundException e) {
			e.printStackTrace();
		}

		// Add patterns
		JSONArray frameworks = new JSONArray();

		for (ElementFramework framework : additionalFrameworks) {

			JSONObject v = new JSONObject();
			
			/* In case there is a referenced solution we create an intern hyperlink
			 * to the solution in DecisionBuddy.
			 * If the framework is not referenced we take the alternative external URL */
			if (framework.getSolution() == null) {
				v.put(KEY_NAME, framework.getAltName());
				v.put(KEY_URL, framework.getAltUrl());
				v.put(KEY_IN_CATALOG, false);
			} else {
				v.put(KEY_NAME, framework.getSolution().getName());
				v.put(KEY_URL, framework.getSolution().getId());
				v.put(KEY_IN_CATALOG, true);
			}
			frameworks.add((Object) v);

		}

		return frameworks;
	}

	@SuppressWarnings("unchecked")
	private JSONArray getAdditionalPatterns(Integer projectId, String classPath) {
		// Create list of additional values
		List<ElementDesignPattern> additionalPatterns = new ArrayList<>();

		// Try getting patterns for element
		try {
			Long longProjectId = Long.valueOf(projectId);
									
			//Remove Duplicates
			List<ElementDesignPattern> additionalPatternsWithDuplicates = 
					designpatternComponentService.getDesignPatternsForElement(longProjectId, classPath);
			
			System.out.println(additionalPatternsWithDuplicates.size());
			for ( ElementDesignPattern edp: additionalPatternsWithDuplicates )
			{
				System.out.println("Try");
				boolean contained = false;
				
				for ( ElementDesignPattern edpCompare: additionalPatterns)
					if (edpCompare.getSolution().getName().equals(edp.getSolution().getName()))
					{
						contained = true;
						System.out.println("schon enthalten");
					}
						
				
				if (!contained)
					additionalPatterns.add(edp);	
			}

			//additionalPatterns = 
			//		designpatternComponentService.getDesignPatternsForElement(longProjectId, classPath);
			
		} catch (NotFoundException e) {
			e.printStackTrace();
		}

		// Add patterns
		JSONArray patterns = new JSONArray();

		for (ElementDesignPattern pattern : additionalPatterns) {
			JSONObject v = new JSONObject();

			// Build JSON-Object
			v.put(KEY_NAME, pattern.getSolution().getName());
			v.put(KEY_ROLE, pattern.getRole());
			v.put(KEY_TYPE, elementTypeToString(pattern.getType()));
			v.put(KEY_IN_CATALOG, true);
			v.put(KEY_URL, pattern.getSolution().getId());

			patterns.add((Object) v);
		}

		return patterns;
	}

	/**
	 * Prepare a JSON Object for sending.
	 * 
	 * @param obj
	 *            The object to be prepared
	 * @param metricValue
	 *            The value to prepare the object with
	 * @return The object inserted
	 */
	@SuppressWarnings("unchecked")
	private JSONObject prepareJSONObject(JSONObject obj, MetricValue metricValue) {
		obj.put(KEY_VALUE, metricValue != null ? ( Math.round(metricValue.getValue()*100)/100. ) : NONE);
		obj.put(KEY_THRESHOLD,
				metricValue != null ? metricValue.getThresholdStatus() : EMPTY);
		obj.put(KEY_THRESHOLD_REASON,
				metricValue != null ? getThresholdReason(metricValue) : NONE);
		return obj;
	}

	/**
	 * Returns a tooltip indicating why a metricValue exceeded its threshold.
	 * Empty if not exceeded
	 * 
	 * @return A translated tooltip including a reason, why the threshold was
	 *         exceeded
	 */
	private String getThresholdReason(MetricValue value) {
		// Get locale for translation
		Locale locale = LocaleContextHolder.getLocale();

		if (value.getValue() < value.getMetric().getMinThreshold()) {
			return messageSource.getMessage(ANALYSIS_METRICS_THRESHOLD_TOLOW,
					new Object[] { value.getMetric().getMinThreshold() },
					locale);
		} else if (value.getValue() > value.getMetric().getMaxThreshold()) {
			return messageSource.getMessage(ANALYSIS_METRICS_THRESHOLD_TOHIGH,
					new Object[] { value.getMetric().getMaxThreshold() },
					locale);
		} else {
			return messageSource.getMessage(ANALYSIS_METRICS_THRESHOLD_OK,
					null, locale);
		}
	}

	/**
	 * Returns information about expandability of an element.
	 * 
	 * In the future this should be returned by the ElementService directly
	 * 
	 * @param parentId
	 *            ID of a parent
	 * @return String expandable or notexpandable
	 */
	private String getExpandability(long parentId) {

		List<Element> subChildElements = elementService
				.getElementsByParentId(parentId);
		int numberOfSubchildren = subChildElements.size();

		return numberOfSubchildren > 0 ? EXPANDABLE : NOT_EXPANDABLE;
	}

	/**
	 * Returns the MetricValue that matches the demanded Metric.
	 * 
	 * @param elementMetrics
	 *            List of Metric Values
	 * 
	 * @param relevantMetric
	 *            Metric we are looking for
	 * 
	 * @return Requested MetricValue of the list of MetricValues or null if none
	 *         is found
	 */
	private MetricValue findMetricInList(List<MetricValue> elementMetrics,
			Metric relevantMetric) {
		for (MetricValue metricValue : elementMetrics) {
			if (metricValue.getMetric().getId().equals(relevantMetric.getId())) {
				return metricValue;
			}
		}
		return null;
	}

	/**
	 * Converts a type number to a type string.
	 * 
	 * @param typeInt
	 *            Number of a type
	 * @return String with type (folder or file)
	 */
	private String elementTypeToString(ElementType typeInt) {
		String typeString;

		switch (typeInt) {
		case Package:
			typeString = FOLDER;
			break;
		case File:
			typeString = FILE;
			break;
		default:
			typeString = EMPTY;
			break;
		}
		return typeString;
	}
}
