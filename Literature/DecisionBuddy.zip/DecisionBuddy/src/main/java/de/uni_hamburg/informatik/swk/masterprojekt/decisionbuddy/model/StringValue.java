package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the StringValue table from the database.
 *
 * @author Tim
 *
 */
@Entity
@Table(name = "StringValue")
public class StringValue
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(targetEntity = TechnicalTerm.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "TechnicalTermID", referencedColumnName = "ID", nullable = false)
    private TechnicalTerm technicalTerm;

    @Column(name = "StringValue", nullable = false, length = ColumnLength.SHORT)
    private String stringValue;

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public TechnicalTerm getTechnicalTerm()
    {
        return technicalTerm;
    }

    public void setTechnicalTerm(TechnicalTerm technicalTerm)
    {
        this.technicalTerm = technicalTerm;
    }

    public String getStringValue()
    {
        return stringValue;
    }

    public void setStringValue(String stringValue)
    {
        this.stringValue = stringValue;
    }

    @Override
    public String toString()
    {
        return String.valueOf(getId());
    }

    @Override
    public int hashCode()
    {
        int result;
        if (getId() == null)
        {
            result = 0;
        }
        else
        {
            result = getId().hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        StringValue other = (StringValue) obj;
        if (other.getId() == null || this.getId() == null)
        {
            return false;
        }
        return other.getId().equals(this.getId());
    }
}