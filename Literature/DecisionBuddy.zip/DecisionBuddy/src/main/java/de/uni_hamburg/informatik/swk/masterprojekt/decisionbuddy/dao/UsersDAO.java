package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;

/**
 * A DAO class for Users.
 * 
 * @author 4biryuk
 *
 */
public interface UsersDAO extends JpaRepository<User, String>
{

}
