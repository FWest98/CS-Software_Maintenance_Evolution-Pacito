package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Property;

/**
 * Property editor to convert an Id for a Property given as String to an actual
 * Property object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class PropertyEditor extends PropertyEditorSupport
{
    /**
     * Converts a Property id to a property object.
     * 
     * @param id the id of the Property
     */
    @Override
    public void setAsText(String id)
    {

        Property property = new Property();

        try
        {
            Long propId = Long.valueOf(id);
            property.setId(Long.valueOf(propId));
        }
        catch (NumberFormatException nfe)
        {

        }

        this.setValue(property);
    }

    /**
     * Converts a Property object to the id.
     * 
     * @return id of the Property
     */
    @Override
    public String getAsText()
    {
        if (this.getValue() != null)
        {
            Property property = (Property) this.getValue();
            String parsedId = String.valueOf(property.getId());
            return parsedId;
        }
        else
        {
            return "";
        }
    }
}