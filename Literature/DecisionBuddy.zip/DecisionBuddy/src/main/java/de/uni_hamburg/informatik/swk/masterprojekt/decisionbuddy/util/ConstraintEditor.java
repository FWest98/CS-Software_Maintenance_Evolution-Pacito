package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;

/**
 * Property editor to convert an Id for a Constraint given as String to an
 * actual Constraint object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class ConstraintEditor extends PropertyEditorSupport
{
    /**
     * Converts a Constraint id to a Constraint object.
     * 
     * @param id the id of the Constraint
     */
    @Override
    public void setAsText(String id)
    {

        Constraint constraint = new Constraint();

        try
        {
            Long constraintId = Long.valueOf(id);
            constraint.setId(Long.valueOf(constraintId));
        }
        catch (NumberFormatException nfe)
        {

        }

        this.setValue(constraint);
    }

    /**
     * Converts a Constraint object to the id.
     * 
     * @return id of the Constraint
     */
    @Override
    public String getAsText()
    {
        if (this.getValue() != null)
        {
            Constraint constraint = (Constraint) this.getValue();
            String parsedId = String.valueOf(constraint.getId());
            return parsedId;
        }
        else
        {
            return "";
        }
    }
}