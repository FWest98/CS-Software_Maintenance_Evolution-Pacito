package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * A DAO class for Rating.
 * 
 * @author Tim
 *
 */
public interface RatingDAO extends JpaRepository<Rating, Long>
{
    /**
     * Find all Ratings belonging to a Solution by the SolutionId.
     * 
     * @param solutionID of the Solution for which you want to find the Ratings
     * @return all Ratings belonging to that Solution
     */
    List<Rating> findBySolutionId(Long solutionID);

    /**
     * Find all Ratings belonging to a Solution.
     * 
     * @param solution for which you want to find the Ratings
     * @return all Ratings belonging to that Solution
     */
    List<Rating> findBySolution(Solution solution);

    /**
     * Find all Ratings belonging to a Solution.
     * 
     * @param solution for which you want to find the Ratings
     * @param qualityGoal for which you want to find the Ratings of the solution
     * @return all Ratings belonging to that Solution and QualityGoal
     */
    List<Rating> findBySolutionAndQualityGoal(Solution solution, QualityGoal qualityGoal);
}