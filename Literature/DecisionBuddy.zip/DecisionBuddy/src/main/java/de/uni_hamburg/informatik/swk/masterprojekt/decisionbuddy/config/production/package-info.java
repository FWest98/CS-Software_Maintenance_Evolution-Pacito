/**
 * This package contains the production configuration.
 * 
 * @author Vlad
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production;