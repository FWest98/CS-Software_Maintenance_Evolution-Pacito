package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

public interface DbaCatalogDAO
{
    void generateFrameworkCatalog();
}
