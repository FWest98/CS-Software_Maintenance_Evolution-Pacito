package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if an rating could not be written to the
 * database.
 * 
 * @author schaak
 *
 */
public class RatingPersistenceException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public RatingPersistenceException()
    {
        setExceptionType("ratingpersistence");
    }
}
