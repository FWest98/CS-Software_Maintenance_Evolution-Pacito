package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;

/**
 * Property editor to convert an Id for a String value given as String to an
 * actual StringValue object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class StringValueEditor extends PropertyEditorSupport
{
    /**
     * Converts a StringValue id to a StringValue object.
     * 
     * @param id the id of the StringValue
     */
    @Override
    public void setAsText(String id)
    {
        StringValue stringValue = new StringValue();
        stringValue.setId(Long.valueOf(id));

        this.setValue(stringValue);
    }

    /**
     * Converts a StringValue object to an the id.
     * 
     * @return id of the StringValue
     */
    @Override
    public String getAsText()
    {
        if (this.getValue() != null)
        {
            StringValue stringValue = (StringValue) this.getValue();
            String parsedId = String.valueOf(stringValue.getId());
            return parsedId;
        }
        else
        {
            return "";
        }

    }
}