package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AuthorityNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AuthorityPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;

/**
 * Authority service delivers a CRUD interface for authorities.
 * 
 * @author Vlad
 *
 */
public interface AuthorityService
{
    /**
     * Adds a given authority to the database.
     * 
     * @param authority the authority to be persisted
     * @return why does it return a parameter?
     */
    Authority saveAuthority(Authority authority) throws AuthorityPersistenceException;

    /**
     * Find a authority by given id.
     * 
     * @param authorityName
     * @return why does it return a parameter?
     */
    Authority getAuthorityByName(String authorityName) throws AuthorityNotFoundException;

    /**
     * Get a list of all current authorities.
     * 
     * @return a list of all authorities in the DB.
     */
    List<Authority> getAuthorities();

    /**
     * Delete a authority by given id.
     * 
     * @param authorityName the name of the authority to be deleted.
     */
    void deleteAuthority(String authorityName) throws AuthorityNotFoundException;
}
