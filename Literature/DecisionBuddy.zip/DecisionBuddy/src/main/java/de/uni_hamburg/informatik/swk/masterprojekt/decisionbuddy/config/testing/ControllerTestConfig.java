package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing;

import javax.persistence.EntityManagerFactory;

import org.hibernate.SessionFactory;
import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.PropertyDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.QualityGoalDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RatingDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionCandidateDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.StringValueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.TechnicalTermDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.AuthorityService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.CommentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ConstraintService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementDesignPatternService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementFrameworkService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementMetricService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.GSSRatingService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.IssueService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.MetricService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.MetricValueService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.RatingService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.SolutionCandidateService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.SolutionService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.TechnicalTermService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.UploadProcessingService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.UserService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.designpattern.DesignPatternComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.framework.FrameworkComponentService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.metric.MetricComponentService;

/**
 * Test configuration for Controller tests.
 * 
 * @author Vlad
 *
 */
@Configuration
// Enablig WebMvc for Controller tests is important so the test class cn "find"
// controller classes annotated with @Controller
@EnableWebMvc
// Profiling the config file is important to separate bean declarations from
// main config file
@Profile("ControllerTesting")
// Imports all packages but the one which contains the mocked components
@ComponentScan({ "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util" })
public class ControllerTestConfig
{
    /**
     * ConstraintService is being mocked by the Mockito Framework.
     * 
     * @return a mocked ConstraintService service
     */
    @Bean
    public ConstraintService constraintService()
    {
        return Mockito.mock(ConstraintService.class);
    }

    /**
     * IssueService is being mocked by the Mockito Framework.
     * 
     * @return a mocked Issue service
     */
    @Bean
    public IssueService issueService()
    {
        return Mockito.mock(IssueService.class);
    }

    /**
     * ProjectService is being mocked by the Mockito Framework.
     * 
     * @return a mocked Project service
     */
    @Bean
    public ProjectService projectService()
    {
        return Mockito.mock(ProjectService.class);
    }

    /**
     * SolutionCandidateService is being mocked by the Mockito Framework.
     * 
     * @return a mocked Solution service
     */
    @Bean
    public SolutionCandidateService solutionCandidateService()
    {
        return Mockito.mock(SolutionCandidateService.class);
    }

    /**
     * SolutionService is being mocked by the Mockito Framework.
     * 
     * @return a mocked Solution service
     */
    @Bean
    public SolutionService solutionService()
    {
        return Mockito.mock(SolutionService.class);
    }

    /**
     * TechnicalTermService is being mocked by the Mockito Framework.
     * 
     * @return a mocked TechnicalTerm service
     */
    @Bean
    public TechnicalTermService technicalTermService()
    {
        return Mockito.mock(TechnicalTermService.class);
    }

    /**
     * Mocking of a QualityGoalDAO.
     * 
     * @return a mocked QualityGoalDAO
     */
    @Bean
    public QualityGoalDAO qualityGoalDAO()
    {
        return Mockito.mock(QualityGoalDAO.class);
    }

    /**
     * Mocking of a PropertyDAO.
     * 
     * @return mocked PropertyDAO
     */
    @Bean
    public PropertyDAO propertyDAO()
    {
        return Mockito.mock(PropertyDAO.class);
    }

    /**
     * Mocking of a TechnicalTermDAO.
     * 
     * @return a mocked TechnicalTermDAO
     */
    @Bean
    public TechnicalTermDAO technicalTermDAO()
    {
        return Mockito.mock(TechnicalTermDAO.class);
    }

    /**
     * Mocking of a StringValueDAO.
     * 
     * @return a mocked StringValueDAO
     */
    @Bean
    public StringValueDAO stringValueDAO()
    {
        return Mockito.mock(StringValueDAO.class);
    }

    /**
     * Mocking of a RatingDAO.
     * 
     * @return a mocked RatingDAO
     */
    @Bean
    public RatingDAO ratingDAO()
    {
        return Mockito.mock(RatingDAO.class);
    }

    /**
     * Mocking of a SolutionCandidateDAO.
     * 
     * @return a mocked SolutionCandidateDAO
     */
    @Bean
    public SolutionCandidateDAO solutionCandidateDAO()
    {
        return Mockito.mock(SolutionCandidateDAO.class);
    }

    /**
     * Mocking of a UserService.
     * 
     * @return a mocked UserService
     */
    @Bean
    public UserService userService()
    {
        return Mockito.mock(UserService.class);
    }

    /**
     * Mocking of a AuthorityService.
     * 
     * @return a mocked AuthorityService
     */
    @Bean
    public AuthorityService authorityService()
    {
        return Mockito.mock(AuthorityService.class);
    }

    /**
     * Mocking of a CommentService.
     * 
     * @return a mocked CommentService
     */
    @Bean
    public CommentService commentService()
    {
        return Mockito.mock(CommentService.class);
    }

    /**
     * Mocking of a RatingService.
     * 
     * @return a mocked RatingService
     */
    @Bean
    public RatingService ratingService()
    {
        return Mockito.mock(RatingService.class);
    }

    /**
     * Mocking of a GSSRatingService.
     * 
     * @return a mocked GSSRatingService
     */
    @Bean
    public GSSRatingService gSSRatingService()
    {
        return Mockito.mock(GSSRatingService.class);
    }

    /**
     * Mocking of a EntityManagerFactory.
     * 
     * @return mocked EntityManagerFactory
     */
    @Bean
    public EntityManagerFactory entityManagerFactory()
    {
        return Mockito.mock(EntityManagerFactory.class);
    }

    /**
     * Mocking of a ElementMetricService.
     * 
     * @return a mocked ElementMetricService
     */
    @Bean
    public ElementMetricService elementMetricService()
    {
        return Mockito.mock(ElementMetricService.class);
    }

    /**
     * Mocking of a ElementService.
     * 
     * @return a mocked ElementService
     */
    @Bean
    public ElementService elementService()
    {
        return Mockito.mock(ElementService.class);
    }

    /**
     * Mocking of a MetricService.
     * 
     * @return a mocked MetricService
     */
    @Bean
    public MetricService metricService()
    {
        return Mockito.mock(MetricService.class);
    }

    /**
     * Mocking of a MetricValueService.
     * 
     * @return a mocked MetricValueService
     */
    @Bean
    public MetricValueService metricValueService()
    {
        return Mockito.mock(MetricValueService.class);
    }

    /**
     * Mocking of a MetricComponentService.
     * 
     * @return a mocked MetricComponentService
     */
    @Bean
    public MetricComponentService metricComponentService()
    {
        return Mockito.mock(MetricComponentService.class);
    }

    /**
     * Mocking of a UploadProcessingService.
     * 
     * @return a mocked UploadProcessingService
     */
    @Bean
    public UploadProcessingService uploadProcessingService()
    {
        return Mockito.mock(UploadProcessingService.class);
    }

    /**
     * Mocking of a ElementDesignPatternService.
     * 
     * @return mocked ElementDesignPatternService
     */
    @Bean
    public ElementDesignPatternService elementDesignPatternService()
    {
        return Mockito.mock(ElementDesignPatternService.class);
    }

    /**
     * Mocking of a ElementFrameworkService.
     * 
     * @return mocked ElementFrameworkService
     */
    @Bean
    public ElementFrameworkService elementFrameworkService()
    {
        return Mockito.mock(ElementFrameworkService.class);
    }

    /**
     * Mocking of a DesignPatternComponentService.
     * 
     * @return mocked DesignPatternComponentService
     */
    @Bean
    public DesignPatternComponentService designPatternComponentkService()
    {
        return Mockito.mock(DesignPatternComponentService.class);
    }

    /**
     * Mocking of a FrameworkComponentService.
     * 
     * @return mocked FrameworkComponentService
     */
    @Bean
    public FrameworkComponentService frameworkComponentkService()
    {
        return Mockito.mock(FrameworkComponentService.class);
    }

    /**
     * Mocking of a EntityManagerFactory.
     * 
     * @return mocked EntityManagerFactory
     */
    @Bean
    public SessionFactory sessionFactory()
    {
        return Mockito.mock(SessionFactory.class);
    }
}
