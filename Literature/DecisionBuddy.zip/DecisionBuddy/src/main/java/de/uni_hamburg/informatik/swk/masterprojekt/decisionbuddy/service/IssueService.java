package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;

/**
 * Overview of interfaces of class IssueService.
 * 
 * @see architectural specification
 *
 * @author schaak
 *
 */
public interface IssueService
{
    /**
     * Adds an issue to the database.
     * 
     * @param issue the issue to be added
     * 
     * @return the saved issue object
     * 
     * @throws IssuePersistenceException Exception if Issue could not be
     *             persisted
     */
    Issue saveIssue(Issue issue) throws IssuePersistenceException, CommentPersistenceException;

    /**
     * Finds an issue by given id.
     * 
     * @param id id of desired issue
     * 
     * @return desired issue
     * 
     * @throws IssueNotFoundException Exception if Issue is not found
     */
    Issue getIssueById(long id) throws IssueNotFoundException;

    /**
     * Finds all Issues that belong to the project with the specified ID.
     * 
     * @param id ID of the Project
     * 
     * @return List of Issues that belong to the project with id. List may be
     *         empty if no Issues were found.
     * 
     * @throws ProjectNotFoundException Exception if Project is not found
     */
    List<Issue> getIssuesByProjectID(long id) throws ProjectNotFoundException;

    /**
     * Deletes an issue.
     * 
     * @param id id of issue that should be deleted
     * 
     * @throws IssueNotFoundException Exception if Issue is not found
     */
    void deleteIssue(long id) throws IssueNotFoundException;

    /**
     * Add a comment to an existing issue given by id.
     * 
     * @param issueID id of issue to be commented on
     * @param text the comment itself
     */
    // public boolean commentOnDecision(int issueID, String text); TODO

    /**
     * Mark an Issue as (un-)decided.
     * 
     * @param id The issue id
     * @param decided True if the decision status should be 'decided', false
     *            otherwise.
     * @return ???
     */
    // public boolean decideIssue(long id, boolean decided); TODO

    // TODO Revisit architecture: boolean return values, getAllIssues()
}