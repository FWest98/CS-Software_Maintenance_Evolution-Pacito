package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;

/**
 * A DAO class for Authorities.
 * 
 * @author 4biryuk
 *
 */
public interface AuthoritiesDAO extends JpaRepository<Authority, String>
{
    // Gets user frequencies by role name. Could be useful in future
    // @Query(nativeQuery = true, value =
    // "SELECT `authorities1authority`, COUNT(*) as `usage` FROM `userauthorities1` GROUP BY `authorities1authority` ORDER BY `usage` DESC;")
    // public List<Object[]> findAuthoritiesByUsers();
}
