package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * Exception for unknown output formats in DecisionBuddy.
 * 
 * @author 1fechner
 *
 */
public class AnalysisResultFormatUnknownException extends AnalysisResultException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public AnalysisResultFormatUnknownException()
    {
        setExceptionType("analysisresultformatunknown");
    }

    @Override
    public String getViewMode()
    {
        return "result.error.formatunknown";
    }
}
