package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a metric could not be written to the
 * database.
 * 
 * @author Burak
 *
 */
public class MetricPersistenceException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public MetricPersistenceException()
    {
        setExceptionType("metricpersistence");
    }
}
