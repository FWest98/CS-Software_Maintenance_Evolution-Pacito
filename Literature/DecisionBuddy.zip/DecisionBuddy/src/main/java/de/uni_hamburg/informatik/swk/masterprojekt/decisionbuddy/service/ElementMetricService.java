package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementMetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementMetricPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementMetric;

/**
 * Overview of interfaces of class ElementMetricService.
 * 
 * @see architectural specification
 *
 * @author Oliver
 *
 */
public interface ElementMetricService
{
    /**
     * Adds a given ElementMetric to the database.
     * 
     * @param ElementMetric the ElementMetric to be persisted
     * 
     * @return the saved ElementMetric object
     * 
     * @throws ElementMetricPersistenceException Exception if ElementMetric
     *             could not be persisted
     */
    ElementMetric saveElementMetric(ElementMetric elementMetric) throws ElementMetricPersistenceException;

    /**
     * Delete an ElementMetric by given id.
     * 
     * @param id the id of the ElementMetric that should be deleted
     * 
     * @throws ElementMetricNotFoundException Exception if ElementMetric is not
     *             found
     */
    void deleteElementMetric(long id) throws ElementMetricNotFoundException;

    /**
     * Find a ElementMetric by given id.
     * 
     * @param id the id of desired ElementMetric
     * 
     * @return the matching ElementMetric
     * 
     * @throws ElementMetricNotFoundException Exception if ElementMetric is not
     *             found
     */
    ElementMetric getElementMetricById(long id) throws ElementMetricNotFoundException;

    /**
     * Find all ElementMetrics by given Project id.
     * 
     * @param id the id of desired project
     * 
     * @return the matching ElementMetrics
     * 
     * @throws ElementMetricNotFoundException Exception if ElementMetric is not
     *             found
     */
    ElementMetric getElementMetricByProjectId(long id) throws ElementMetricNotFoundException;

}
