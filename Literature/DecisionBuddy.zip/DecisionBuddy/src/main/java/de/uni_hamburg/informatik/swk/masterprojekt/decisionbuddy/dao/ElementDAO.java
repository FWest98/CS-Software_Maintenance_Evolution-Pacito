package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * A DAO class for Element.
 * 
 * @author Burak
 *
 */

public interface ElementDAO extends JpaRepository<Element, Long>
{
    Element findByName(String name);

    @Query("SELECT e FROM Element e WHERE e.parent.id = ?1 and e.type <> 2 ORDER BY e.type, e.name")
    List<Element> findByParentId(Long parentId);

    List<Element> findByType(ElementType type);

    List<Element> findByProjectId(Long id);

    Element findByProjectIdAndName(Long id, String name);
}
