package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class validates a issue.
 *
 * @author Tim
 *
 */
@Component
public class IssueValidator extends ExtendedValidator implements Validator
{
    /**
     * Tests if the validator can validate the given object.
     * 
     * @param object
     *            an object to be validated
     * @return boolean if the object can be validated as a issue
     */
    @Override
    public boolean supports(Class<?> object)
    {
        return (Issue.class).isAssignableFrom(object);
    }

    /**
     * Checks if a given issue object is considered valid.
     * 
     * @param object
     *            the given object
     * @param errors
     *            collects encountered field errors
     */
    @Override
    public void validate(Object object, Errors errors)
    {
        // validate issue
        checkMandatoryFields(errors);
        checkMaxLength(errors);

        // validate constraint elements
        // constraints cannot be invalidated by user on frontend
        Issue issue = (Issue) object;

        for (int i = 0; i < issue.getConstraints().size(); i++)
        {
            Constraint constraint = issue.getConstraints().get(i);

            TechnicalTerm technicalTerm = constraint.getTechnicalTerm();
            String type;
            if (technicalTerm != null)
            {
                type = technicalTerm.getType();
            }
            else
            {
                type = "";
            }

            for (int a = 0; a < constraint.getElements().size(); a++)
            {
                // ConstraintElement constraintElement =
                // constraint.getElements().get(a);

                if ("string".equalsIgnoreCase(type))
                {
                    ValidationUtils.rejectIfEmptyOrWhitespace(errors,
                            "constraints[" + i + "].elements[" + a + "].stringValue",
                            ErrorCodes.REQUIRED);
                }
                else if ("int".equalsIgnoreCase(type))
                {
                    ValidationUtils.rejectIfEmptyOrWhitespace(errors,
                            "constraints[" + i + "].elements[" + a + "].intValue",
                            ErrorCodes.REQUIRED);
                }
                else if ("stringint".equalsIgnoreCase(type))
                {
                    ValidationUtils.rejectIfEmptyOrWhitespace(errors,
                            "constraints[" + i + "].elements[" + a + "].stringValue",
                            ErrorCodes.REQUIRED);
                }
            }
        }
    }

    /**
     * Validates that fields don't exceed max length.
     * 
     * @param errors
     *            collects encountered field errors
     */
    private void checkMaxLength(Errors errors)
    {
        rejectIfStringTooLong(errors, "name", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "description", ColumnLength.LONG, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "creator", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "lastModifier", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
    }

    /**
     * Validates that mandatory fields are not empty.
     * 
     * @param errors
     *            collects encountered field errors
     */
    private void checkMandatoryFields(Errors errors)
    {
        // ValidationUtils.rejectIfEmpty(errors, "id", ErrorCodes.REQUIRED);
        // ValidationUtils.rejectIfEmpty(errors, "projectId",
        // ErrorCodes.REQUIRED);
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", ErrorCodes.REQUIRED);
    }
}