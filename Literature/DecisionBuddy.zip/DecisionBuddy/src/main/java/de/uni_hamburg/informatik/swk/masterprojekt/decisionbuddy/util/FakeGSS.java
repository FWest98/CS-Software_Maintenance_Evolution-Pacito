package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal;

/**
 * Fake implementation of the GSS.
 * 
 */
public abstract class FakeGSS
{
    /**
     * Returns a GSS value base on hash of the names.
     * 
     * @param solution the score is returned for.
     * @param weightedQualityGoals which are regarded for the score.
     * 
     * @return the score in regard to the weightedQualityGoals.
     */
    public static float getSolutionRating(Solution solution, List<WeightedQualityGoal> weightedQualityGoals)
    {
        final float percent = 100;
        float result = 0;
        float totalWeight = 0;
        if (weightedQualityGoals != null)
        {
            for (int i = 0; i < weightedQualityGoals.size(); i++)
            {
                float add = weightedQualityGoals.get(i).getQualityGoal().getName().hashCode()
                        + solution.getName().hashCode();
                add = Math.abs(add % percent) / percent;
                add = add * weightedQualityGoals.get(i).getWeight();
                result = result + add;
                totalWeight += weightedQualityGoals.get(i).getWeight();
            }
        }
        if (totalWeight > 0)
        {
            result = result / totalWeight;
        }
        return result;
    }
}
