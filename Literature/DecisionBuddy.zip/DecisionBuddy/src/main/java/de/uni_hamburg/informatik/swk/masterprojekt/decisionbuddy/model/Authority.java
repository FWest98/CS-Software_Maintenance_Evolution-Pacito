package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.security.core.GrantedAuthority;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

@Entity
@Table(name = "authorities")
public class Authority implements GrantedAuthority
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "authority", length = ColumnLength.CREDENTIAL)
    private String authority;

    @ManyToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
    @JoinTable(name = "userauthorities", joinColumns = { @JoinColumn(name = "authorities1authority", referencedColumnName = "authority") }, inverseJoinColumns = { @JoinColumn(name = "users1username", referencedColumnName = "username") })
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<User> users;

    public Authority()
    {
        users = new ArrayList<User>();
    }

    public String getAuthority()
    {
        return authority;
    }

    public void setAuthority(String authority)
    {
        this.authority = authority;
    }

    public Collection<User> getUsers()
    {
        return users;
    }

    public void setUsers(List<User> users)
    {
        this.users = users;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((authority == null) ? 0 : authority.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Authority other = (Authority) obj;
        if (authority == null)
        {
            if (other.authority != null)
            {
                return false;
            }
        }
        else if (!authority.equals(other.authority))
        {
            return false;
        }
        return true;
    }

    @Override
    public String toString()
    {
        return authority;
    }

}
