package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production;

import org.springframework.core.annotation.Order;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**
 * This configuration class replaces the web.xml file from previous Spring
 * versions.
 * 
 * Starting with Spring MVC 3.2/ Spring 3.2, there is support for Servlet 3.0.
 * This version supports Servlet 3.0. With Servlet 3.0, the web.xml is not
 * required if you use the proper annotations in your configuration files.
 * further details:
 * 
 * http://docs.spring.io/spring/docs/4.0.x/spring-framework-reference/html/mvc.
 * html
 * 
 * http://stackoverflow.com/questions/15008126/spring-mvc-and-servlets-3-0-do-
 * you-still-need-web-xml
 * 
 * http://zeroturnaround.com/rebellabs/your-next-java-web-app-less-xml-no-long-
 * restarts-fewer-hassles-part-1/
 * 
 * http://tomcat.apache.org/whichversion.html
 * 
 * https://today.java.net/pub/a/today/2008/10/14/introduction-to-servlet-3.html#
 * annotations-vs-deployment-descriptor
 * 
 * @author Vlad
 *
 */
@Order(1)
public class MVCInitializer extends AbstractAnnotationConfigDispatcherServletInitializer
{

    @Override
    protected Class<?>[] getRootConfigClasses()
    {
        return new Class[] { DatabaseConfig.class };
    }

    @Override
    protected Class<?>[] getServletConfigClasses()
    {
        return new Class<?>[] { WebAppConfig.class };
    }

    @Override
    protected String[] getServletMappings()
    {
        return new String[] { "/" };
    }
}