package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Property;

/**
 * A DAO class for Property.
 * 
 * @author Tim
 *
 */
public interface PropertyDAO extends JpaRepository<Property, Long>
{

}
