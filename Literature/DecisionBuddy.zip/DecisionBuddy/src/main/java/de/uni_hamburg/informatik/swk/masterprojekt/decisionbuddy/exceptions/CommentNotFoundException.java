package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if an comment is not found / does not exist
 * (anymore).
 * 
 * @author schaak
 *
 */
public class CommentNotFoundException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public CommentNotFoundException()
    {
        setExceptionType("commentnotfound");
    }
}