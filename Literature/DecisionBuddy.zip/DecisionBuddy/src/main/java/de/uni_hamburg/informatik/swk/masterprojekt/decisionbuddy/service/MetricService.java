package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

/**
 * Overview of interfaces of class MetricService.
 * 
 * @see architectural specification
 *
 * @author Burak
 *
 */
public interface MetricService
{
    /**
     * Adds a given Metric to the database.
     * 
     * @param metric the metric to be persisted
     * 
     * @return the saved metric object
     * 
     * @throws MetricPersistenceException Exception if Metric could not be
     *             persisted
     */
    Metric saveMetric(Metric metric) throws MetricPersistenceException;

    /**
     * Find a metric by given id.
     * 
     * @param id the id of desired metric
     * 
     * @return the matching metric
     * 
     * @throws MetricNotFoundException Exception if Metric is not found
     */
    Metric getMetricById(long id) throws MetricNotFoundException;

    /**
     * Find a metric by given metric nameLangFile.
     * 
     * @param metricName
     * @return metric corresponding to the name
     * @throws MetricNotFoundException
     */
    Metric getMetricByNameLangFile(String metricName) throws MetricNotFoundException;

    /**
     * Find a metric by given metric nameXml.
     * 
     * @param metricName
     * @return metric corresponding to the name
     * @throws MetricNotFoundException
     */
    Metric getMetricByNameXmlAndType(String metricName, MetricType metricType) throws MetricNotFoundException;

    /**
     * Delete a metric by given id.
     * 
     * @param id the id of the metric that should be deleted
     * 
     * @throws MetricNotFoundException Exception if Metric is not found
     */
    void deleteMetric(int id) throws MetricNotFoundException;

    /**
     * Get a list of all current metrics that belong to the type.
     * 
     * @param type the type of the metrics that should be found
     * 
     * @return List of all metrics
     */
    List<Metric> getMetricsByType(MetricType type);

    /**
     * Get a list of all current metrics that belong to the subType.
     * 
     * @param subType the subType of the metrics that should be found
     * 
     * @return List of all metrics
     */
    List<Metric> getMetricsBySubType(MetricSubType subType);

    /**
     * Get a list of all current metrics that belong to a certain Type and
     * subType.
     * 
     * @param type the type of the metrics that should be found
     * 
     * @param subType the subType of the metrics that should be found
     * 
     * @return List of all metrics
     */
    List<Metric> getMetricsByTypeAndSubType(MetricType type, MetricSubType subType);

    /**
     * Get a list of all current metrics.
     * 
     * @return List of all metrics
     */
    List<Metric> getMetricCatalog();

}