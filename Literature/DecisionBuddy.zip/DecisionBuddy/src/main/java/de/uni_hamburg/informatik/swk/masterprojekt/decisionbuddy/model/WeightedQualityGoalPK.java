package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.io.Serializable;

public class WeightedQualityGoalPK implements Serializable
{
    private static final long serialVersionUID = 1L;
    private QualityGoal qualityGoal;
    private Issue issue;

    public WeightedQualityGoalPK()
    {

    }

    public QualityGoal getQualityGoal()
    {
        return qualityGoal;
    }

    public void setQualityGoal(QualityGoal qualityGoal)
    {
        this.qualityGoal = qualityGoal;
    }

    public Issue getIssue()
    {
        return issue;
    }

    public void setIssue(Issue issue)
    {
        this.issue = issue;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((issue == null) ? 0 : issue.hashCode());
        result = prime * result + ((qualityGoal == null) ? 0 : qualityGoal.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        WeightedQualityGoalPK other = (WeightedQualityGoalPK) obj;
        if (issue == null)
        {
            if (other.issue != null)
            {
                return false;
            }
        }
        else if (!issue.equals(other.issue))
        {
            return false;
        }
        if (qualityGoal == null)
        {
            if (other.qualityGoal != null)
            {
                return false;
            }
        }
        else if (!qualityGoal.equals(other.qualityGoal))
        {
            return false;
        }
        return true;
    }
}
