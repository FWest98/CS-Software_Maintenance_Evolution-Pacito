package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.util.ArrayList;
import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;

/**
 * 
 * A filter specifically made for comparing solution constraints with
 * constraints of an issue.
 * 
 * @author Lucas
 * 
 */
public class SolutionConstraintFilter implements Filter<Solution>
{

    private Issue issue;

    /**
     * Default constructor.
     * 
     * @param issue The issue that the solutions will be compared to
     */
    public SolutionConstraintFilter(Issue issue)
    {
        this.issue = issue;
    }

    @Override
    public boolean isInResult(Solution item)
    {
        boolean result = true;
        List<Constraint> issueConstraints = issue.getConstraints();
        List<Constraint> solutionConstraints = item.getConstraints();

        if (issueConstraints != null && solutionConstraints != null)
        {
            for (Constraint sc : solutionConstraints)
            {
                for (Constraint ic : issueConstraints)
                {
                    if (ic.getTechnicalTerm().equals(sc.getTechnicalTerm()))
                    {
                        if (!compareConstraints(ic, sc))
                        {
                            result = false;
                        }
                    }
                }
            }
        }

        return result;
    }

    /**
     * Compares 2 constraints. Only for comparing issue- and
     * solutionConstraints.
     * 
     * @param issueConstraint Constraint of an issue
     * @param solutionConstraint Constraint of a solution
     * @return true, if constraints are compatible, false otherwise
     */
    private boolean compareConstraints(Constraint issueConstraint, Constraint solutionConstraint)
    {
        boolean result = true;

        TechnicalTerm tt = issueConstraint.getTechnicalTerm();

        if (issueConstraint.getElements() == null || solutionConstraint.getElements() == null)
        {
            // a constraint contains no elements
            result = true;
        }
        else if (tt.getType().equals("string"))
        {
            result = compareStringConstraints(issueConstraint, solutionConstraint);
        }
        else if (tt.getType().equals("int"))
        {
            result = compareIntConstraints(issueConstraint, solutionConstraint);
        }
        else if (tt.getType().equals("stringint"))
        {
            result = compareStringIntConstraints(issueConstraint, solutionConstraint);
        }
        else
        {
            // error: invalid type
            result = false;
        }

        return result;
    }

    /**
     * Compares two constraints of type "int".
     * 
     * @param issueConstraint Constraint of an issue.
     * @param solutionConstraint Constraint of a solution.
     * @return true if constraints are compatible, false otherwise.
     */
    private boolean compareIntConstraints(Constraint issueConstraint, Constraint solutionConstraint)
    {
        boolean result = true;
        TechnicalTerm tt = issueConstraint.getTechnicalTerm();

        // Only consider first element in the list. Int constraints
        // should not contain multiple values
        ConstraintElement issueElement = issueConstraint.getElements().get(0);
        ConstraintElement solutionElement = solutionConstraint.getElements().get(0);

        if (tt.getDeliveredBy().equals("issue") && tt.getRequiredBy().equals("solution"))
        {
            if (!intCompare(issueElement.getIntValue(), solutionElement.getComparator(), solutionElement.getIntValue()))
            {
                result = false;
            }
        }
        else if (tt.getDeliveredBy().equals("solution") && tt.getRequiredBy().equals("issue"))
        {
            if (!intCompare(solutionElement.getIntValue(), issueElement.getComparator(), issueElement.getIntValue()))
            {
                result = false;
            }
        }
        else
        {
            // error: invalid delivered-required relation
            result = false;
        }

        return result;
    }

    /**
     * Compares two constraints of type "string".
     * 
     * @param issueConstraint Constraint of an issue.
     * @param solutionConstraint Constraint of a solution.
     * @return true if constraints are compatible, false otherwise.
     */
    private boolean compareStringConstraints(Constraint issueConstraint, Constraint solutionConstraint)
    {
        boolean result = true;
        List<String> issueStrings = new ArrayList<String>();

        for (ConstraintElement e1 : issueConstraint.getElements())
        {
            issueStrings.add(e1.getStringValue().getStringValue());
        }

        boolean intermediateResult = false;

        for (ConstraintElement e2 : solutionConstraint.getElements())
        {
            if (issueStrings.contains(e2.getStringValue().getStringValue()))
            {
                intermediateResult = true;
            }
        }

        if (!intermediateResult)
        {
            System.out.println(issueStrings.size() + ": " + issueStrings);
            System.out.println(solutionConstraint.getElements().size() + ": " + solutionConstraint.getElements());
            TechnicalTerm tt = issueConstraint.getTechnicalTerm();
            System.out.println(tt.getDeliveredBy().equals("solution") + ": " + tt.getRequiredBy().equals("issue"));

            // Only return false, if there are actually strings in the required
            // constraint
            if (tt.getDeliveredBy().equals("issue") && tt.getRequiredBy().equals("solution"))
            {
                if (solutionConstraint.getElements().size() != 0)
                {
                    result = false;
                }
            }
            else if (tt.getDeliveredBy().equals("solution") && tt.getRequiredBy().equals("issue"))
            {
                if (issueStrings.size() != 0)
                {
                    result = false;
                }
            }
            else
            {
                System.out.println("asd");
                // error: invalid delivered-required relation
                result = false;
            }
        }

        return result;
    }

    /**
     * Compares two constraints of type "stringint".
     * 
     * @param issueConstraint Constraint of an issue.
     * @param solutionConstraint Constraint of a solution.
     * @return true if constraints are compatible, false otherwise.
     */
    private boolean compareStringIntConstraints(Constraint issueConstraint, Constraint solutionConstraint)
    {
        boolean result = true;
        TechnicalTerm tt = issueConstraint.getTechnicalTerm();

        if (tt.getDeliveredBy().equals("issue") && tt.getRequiredBy().equals("solution"))
        {

            boolean intermediateResult = false;

            for (ConstraintElement e1 : solutionConstraint.getElements())
            {
                for (ConstraintElement e2 : issueConstraint.getElements())
                {
                    if (e1.getStringValue().getStringValue().equals(e2.getStringValue().getStringValue()))
                    {
                        if (intCompare(e2.getIntValue(), e1.getComparator(), e1.getIntValue()))
                        {
                            intermediateResult = true;
                        }
                    }
                }
            }

            if (!intermediateResult)
            {
                result = false;
            }

        }
        else if (tt.getDeliveredBy().equals("solution") && tt.getRequiredBy().equals("issue"))
        {
            boolean intermediateResult = false;

            for (ConstraintElement e1 : solutionConstraint.getElements())
            {
                for (ConstraintElement e2 : issueConstraint.getElements())
                {
                    if (e1.getStringValue().getStringValue().equals(e2.getStringValue().getStringValue()))
                    {
                        if (intCompare(e1.getIntValue(), e2.getComparator(), e2.getIntValue()))
                        {
                            intermediateResult = true;
                        }
                    }
                }
            }

            if (!intermediateResult)
            {
                result = false;
            }
        }
        else
        {
            // error: invalid delivered-required relation
            result = false;
        }

        return result;
    }

    /**
     * Compares two integer values based on a given comparator. Returns false,
     * if comparator is invalid.
     * 
     * @param int1 First integer.
     * @param comparator Comparator given as string. Possible values are equals,
     *            smaller, greater, smallerequal and greaterequal
     * @param int2 Second integer.
     * @return Result of comparison.
     */
    private boolean intCompare(Integer int1, String comparator, Integer int2)
    {
        boolean result = false;

        // if one of the int values is null -> comparison true
        if (int1 == null || int2 == null)
        {
            return true;
        }

        if (comparator.equals("equals"))
        {
            result = int1.equals(int2);
        }
        else if (comparator.equals("smaller"))
        {
            result = int1 < int2;
        }
        else if (comparator.equals("greater"))
        {
            result = int1 > int2;
        }
        else if (comparator.equals("smallerequal"))
        {
            result = int1 <= int2;
        }
        else if (comparator.equals("greaterequal"))
        {
            result = int1 >= int2;
        }
        else
        {
            // error: invalid comparator
            result = false;
        }

        return result;
    }
}
