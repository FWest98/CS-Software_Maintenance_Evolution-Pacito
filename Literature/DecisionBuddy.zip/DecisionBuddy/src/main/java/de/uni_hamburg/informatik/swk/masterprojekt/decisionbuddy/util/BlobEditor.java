package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

/**
 * Property editor to convert a Blob to a String. EXPERIMENTAL CHARACTER
 * 
 * @author schaak
 *
 */
@Component
public class BlobEditor extends PropertyEditorSupport
{

    /**
     * Converts a Blob object to a String containing the filename.
     * 
     * @return String containing filename
     */
    @Override
    public String getAsText()
    {
        return "test";
        // Blob blob = (Blob) this.getValue();
        // MultipartFile multipartFile = null;
        //
        // if (blob == null)
        // {
        // return "";
        // }
        // else
        // {
        // try
        // {
        //
        // return blob.getBinaryStream();
        // }
        // catch (SQLException e)
        // {
        // // TODO Auto-generated catch block
        // e.printStackTrace();
        // }
        //
        // return "";
        // }
    }
}