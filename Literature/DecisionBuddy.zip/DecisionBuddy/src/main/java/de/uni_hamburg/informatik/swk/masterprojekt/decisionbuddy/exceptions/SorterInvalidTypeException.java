package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a field could not be found for the
 * sorter.
 * 
 * @author Tim
 * 
 */
public class SorterInvalidTypeException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public SorterInvalidTypeException()
    {
        setExceptionType("sorterinvalidtype");
    }
}
