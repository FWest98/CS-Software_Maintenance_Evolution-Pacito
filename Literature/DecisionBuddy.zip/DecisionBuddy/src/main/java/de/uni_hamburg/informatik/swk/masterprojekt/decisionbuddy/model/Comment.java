package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.Comparator;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the Comment table from the database.
 *
 * @author Tim
 *
 */

@Entity
@Table(name = "Comment")
public class Comment
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue
    private Long id;

    @ManyToOne(targetEntity = Decision.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "DecisionID", referencedColumnName = "ID", nullable = false)
    private Decision decision;

    @Column(name = "Commentator", nullable = false, length = ColumnLength.SHORT)
    private String commentator;

    @Column(name = "Date", nullable = false)
    private Date date;

    @Column(name = "Comment", nullable = true, length = ColumnLength.LONG)
    private String comment;

    /**
     * Constructor without parameters.
     */
    public Comment()
    {
        date = new Date();
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Decision getDecision()
    {
        return decision;
    }

    public void setDecision(Decision decision)
    {
        this.decision = decision;
    }

    public String getCommentator()
    {
        return commentator;
    }

    public void setCommentator(String commentator)
    {
        this.commentator = commentator;
    }

    public Date getDate()
    {
        return date;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    public String getComment()
    {
        return comment;
    }

    public void setComment(String comment)
    {
        this.comment = comment;
    }

    @Override
    public int hashCode()
    {
        int result;
        if (getId() == null)
        {
            result = 0;
        }
        else
        {
            result = getId().hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Comment other = (Comment) obj;
        if (other.getId() == null || this.getId() == null)
        {
            return false;
        }
        return other.getId().equals(this.getId());
    }

    /**
     * Sorts Comments by Date.
     * 
     * @return the comparator which sorts by Date.
     */
    public static Comparator<Comment> getDateComprator()
    {
        Comparator<Comment> comparator = new Comparator<Comment>()
        {
            public int compare(Comment comment1, Comment comment2)
            {
                Date comment1Date = comment1.getDate();
                Date comment2Date = comment2.getDate();
                return comment1Date.compareTo(comment2Date);
            }
        };

        return comparator;
    }
}
