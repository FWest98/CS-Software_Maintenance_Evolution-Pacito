package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

import java.util.ArrayList;
import java.util.List;

/**
 * Different formats that can be imported into DecisionBuddy.
 * 
 * @author 1vietor
 *
 */
public enum AnalysisFileFormat
{
    // Formats
    DBAnalyzer, Pinot, Sonargraph/*Unkown*/;

    /**
     * Return names of all OutputFormates as list of strings.
     * 
     * @return A list of Strings
     */
    public static List<String> getFormatNames()
    {
        ArrayList<String> names = new ArrayList<>();

        for (AnalysisFileFormat o : AnalysisFileFormat.values())
        {
            names.add(o.name());
        }

        return names;
    }
}