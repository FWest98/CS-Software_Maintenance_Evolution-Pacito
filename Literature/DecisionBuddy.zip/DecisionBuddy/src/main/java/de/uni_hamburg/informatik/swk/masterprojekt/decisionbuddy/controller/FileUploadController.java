package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.UploadProcessingService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorizationConstants;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.HelperFunctions;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.AnalysisFileFormat;

/**
 * Controller to handle File Upload to DecicionBuddy. <br/>
 * Credits go to
 * <a href="https://spring.io/guides/gs/uploading-files/">https://spring
 * .io/guides/gs/uploading-files/</a>
 * 
 * @author 1fechner
 */
@Controller
@RequestMapping(value = "/project")
public class FileUploadController
{
    private static final String     PROJECT                = "project";
    private static final String     VIEWMODE               = "viewmode";
    private static final String     FORMAT_LIST            = "formatList";
    private static final String     JSP                    = "jsp";
    private static final String     ADD                    = "add";
    private static final String     INDEX                  = "index";
    private static final String     ADDANALYSISDATA        = "forms/addanalysisdata";

    private static final String     TMP_PREFIX             = "analyzeresult_";
    private static final String     TMP_EXTENSION          = ".tmp";

    private static final String     RESULT_SUCCESS         = "result.success";
    private static final String     RESULT_ERROR_UNDEFINED = "result.error.undefined";
    private static final String     RESULT_ERROR_EMPTYFILE = "result.error.emptyfile";

    @Autowired
    private UploadProcessingService _uploadProcessingService;

    @Autowired
    private ProjectService          _projectService;

    @Autowired
    private HelperFunctions         _helperFunctions;

    // 'Cached' ViewMode and outcome Message
    private String                  _viewmode;

    // private String _outcomeMessage;

    /**
     * Upload a file to DecisionBuddy. The upload is associated with a specific
     * project. While uploading, the (analysis)
     * 
     * @param projectId
     *            Id of the project the uploaded results are to be inserted into
     * @param outputFormat
     *            The output format of the file to be processed by DecisionBuddy
     * @param file
     *            the file to be uploaded
     * @return
     * @throws ProjectNotFoundException
     */
    @RequestMapping(value = "/{projectId}/analysisdata/upload", method = RequestMethod.POST)
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    public @ResponseBody ModelAndView handleFileUpload(@PathVariable Integer projectId,
            @RequestParam("outputFormat") String outputFormat,
            @RequestParam("file") MultipartFile file) throws ProjectNotFoundException
    {
        if (!file.isEmpty())
        {
            try
            {
                byte[] bytes = file.getBytes();
                File tmpFile = File.createTempFile(TMP_PREFIX, TMP_EXTENSION);
                BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(tmpFile));
                stream.write(bytes);
                stream.close();
                _viewmode = handleProcessing(projectId, outputFormat, tmpFile.getAbsolutePath());

                // Remove temporary saved file
                tmpFile.delete();
            }
            catch (Exception e)
            {
                // If something happens, return an undefined error
                _viewmode = RESULT_ERROR_UNDEFINED;
            }
        }
        else
        {
            // File was empty
            _viewmode = RESULT_ERROR_EMPTYFILE;
        }

        return getResultModelAndView(projectId);
    }

    /**
     * Show the results of the last AnalysisUpload.
     * 
     * @param projectId
     *            Id of the project the uploaded results are inserted into
     * @return
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/{projectId}/analysisdata/upload", method = RequestMethod.GET)
    public ModelAndView showLastAnalysisResult(@PathVariable Integer projectId)
            throws ProjectNotFoundException
    {
        return getResultModelAndView(projectId);
    }

    /**
     * Show the form with file upload form and selection of data format to
     * initiate upload of analysis data.
     * 
     * @param projectId
     *            Id of the project the uploaded results are to be inserted into
     * @return
     */
    @PreAuthorize(AuthorizationConstants.PROJECT_WRITE)
    @RequestMapping(value = "/{projectId}/analysisdata/add", method = RequestMethod.GET)
    public ModelAndView addAnalysisUploadPage(@PathVariable Integer projectId)
            throws ProjectNotFoundException
    {
        ModelAndView addAnalysisDataView = new ModelAndView(INDEX);

        // get project from service
        Project project = _projectService.getProjectById(projectId);

        // add all possible formats to the selection
        List<String> formatList = AnalysisFileFormat.getFormatNames();

        // fill model
        addAnalysisDataView.addObject(JSP, ADDANALYSISDATA);
        addAnalysisDataView.addObject(VIEWMODE, ADD);
        addAnalysisDataView.addObject(FORMAT_LIST, formatList);
        addAnalysisDataView.addObject(PROJECT, project);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(projectId.toString());
        addAnalysisDataView = _helperFunctions.getBreadcrumbs(ADDANALYSISDATA, list,
                addAnalysisDataView);

        return addAnalysisDataView;
    }

    /**
     * Handles the uploaded file and triggers the parsing and persistence of the
     * uploaded file.
     * 
     * @param outputFormat
     *            The output format specified by the user
     * @param name
     *            The path of the file uploaded
     * @return If an error occurs, the error message, empty String else
     */
    private String handleProcessing(Integer projectId, String outputFormat, String name)
    {
        try
        {
            _uploadProcessingService.processAnalysisResult(projectId, outputFormat, name);
        }
        catch (AnalysisResultException e)
        {
            e.printStackTrace();
            return e.getViewMode();
        }

        return RESULT_SUCCESS;
    }

    /**
     * Return the result view. <br>
     * Extracted to avoid duplicates
     * 
     * @param projectId
     *            The Id of the currently selected project
     * @return A ModelAndView displaying the result of file upload and
     *         processing
     * @throws ProjectNotFoundException
     */
    private ModelAndView getResultModelAndView(Integer projectId) throws ProjectNotFoundException
    {
        // Lets create the view which renders our result
        ModelAndView resultModelAndView = new ModelAndView(INDEX);

        // get project from service
        Project project = _projectService.getProjectById(projectId);

        // Insert format to prevent empty combobox
        List<String> formatList = AnalysisFileFormat.getFormatNames();

        // fill model
        resultModelAndView.addObject(JSP, ADDANALYSISDATA);
        resultModelAndView.addObject(FORMAT_LIST, formatList);
        resultModelAndView.addObject(VIEWMODE, _viewmode);
        resultModelAndView.addObject(PROJECT, project);
        // resultModelAndView.addObject("outcomeMessage", _outcomeMessage);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(projectId.toString());
        resultModelAndView = _helperFunctions.getBreadcrumbs(ADDANALYSISDATA, list,
                resultModelAndView);

        return resultModelAndView;
    }
}
