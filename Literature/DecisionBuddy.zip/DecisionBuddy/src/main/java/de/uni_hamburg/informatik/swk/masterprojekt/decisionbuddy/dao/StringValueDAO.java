package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;

/**
 * A DAO class for StringValue.
 * 
 * @author Tim
 *
 */
public interface StringValueDAO extends JpaRepository<StringValue, Long>
{
    /**
     * Find all string values belonging to a technical term.
     * 
     * @param technicalTermId the technicalterm for which u want to find the
     *            StringValues
     * @return all string values belonging to that technical term
     */
    List<StringValue> findByTechnicalTermId(Long technicalTermId);
}
