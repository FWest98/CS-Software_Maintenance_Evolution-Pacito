package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricValuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

/**
 * 
 * Overview of interface of class MetricValueService.
 * 
 * @see architectural specification
 * 
 * @author Burak
 *
 */
public interface MetricValueService
{
    /**
     * Saves a MetricValue to the database.
     * 
     * @param metricValue A MetricValue
     * @return The saved MetricValue
     * @throws MetricValuePersistenceException Thrown if the object could not be
     *             saved to the database
     */
    MetricValue saveMetricValue(MetricValue metricValue) throws MetricValuePersistenceException;

    /**
     * Finds all MetricValue that belong to the Element with the specified ID.
     * 
     * @param id ID of the Element
     * 
     * @return List of MetricValue that belong to the Element with id. List may
     *         be empty if no MetricValues were found.
     * 
     * @throws ElementNotFoundException Exception if Element is not found
     */
    List<MetricValue> getMetricValuesByElementID(long id) throws ElementNotFoundException;

    /**
     * Finds MetricValue that belong to the Metric with the specified ID.
     * 
     * @param id ID of the Metric
     * 
     * @return MetricValue that belong to the Metric with id. Value may be empty
     *         if nothing was found.
     * 
     * @throws MetricNotFoundException Exception if Metric is not found
     */
    MetricValue getMetricValueByMetricID(long id) throws MetricNotFoundException;

    /**
     * Finds all Metricvalues of a Project with the specified ProjectID, Type
     * and Subtype.
     * 
     * @param projectid ID of the Project the Metricvalues belong to
     * @param type type of Metricvalues to be returned
     * @param subtype subtype of Metricvalues to be returned
     * 
     * @return List of MetricValues that belong to the Project with projectid.
     *         Values may be empty if nothing was found.
     */
    List<MetricValue> getMetricValuesByProjectIDAndTypeAndSubType(long projectid, MetricType type, MetricSubType subtype);

    /**
     * Finds all Metricvalues of an Element with the specified ElementID, Type.
     * 
     * @param elementid ID of the Project the Metricvalues belong to
     * @param type type of Metricvalues to be returned
     * 
     * @return List of MetricValues that belong to the Element with elementid.
     *         Values may be empty if nothing was found.
     */
    List<MetricValue> getMetricValuesByElementIDAndType(long elementid, MetricType type);

}
