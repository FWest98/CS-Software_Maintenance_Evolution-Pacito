package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * Service class for managing element.
 * 
 * @author Burak
 * 
 */

@Service
@Transactional
public class ElementServiceImpl implements ElementService
{

    @Autowired
    private ElementDAO elementDAO;

    /**
     * Adds a new Element to the database.
     * 
     * @param element the element to save
     * 
     * @return the saved element object
     * 
     * @throws ElementPersistenceException Exception if Element could not be
     *             persisted
     */
    @Override
    public Element saveElement(Element element) throws ElementPersistenceException
    {
        Element savedElement;
        savedElement = elementDAO.saveAndFlush(element);

        if (savedElement == null)
        {
            throw new ElementPersistenceException();
        }

        return savedElement;
    }

    /**
     * Finds an element with the specified ID.
     * 
     * @param id ID of the Element
     * 
     * @return Element with the id.
     * 
     * @throws ElementNotFoundException Exception if Element is not found
     */
    @Override
    public Element getElementById(long id) throws ElementNotFoundException
    {
        Element element = elementDAO.findOne(id);

        if (element == null)
        {
            throw new ElementNotFoundException();
        }

        return element;
    }

    /**
     * Deletes an Element with the specified ID.
     * 
     * @param id the id of the element to be deleted
     * 
     * @throws ElementNotFoundException Exception if Element is not found
     */
    @Override
    public void deleteElement(long id) throws ElementNotFoundException
    {
        try
        {
            elementDAO.delete(id);
        }
        catch (DataAccessException e)
        {
            throw new ElementNotFoundException();
        }
    }

    /**
     * Find an element by given element name.
     * 
     * @param elementName
     * @return element corresponding to the name
     * @throws ElementNotFoundException
     */
    @Override
    public Element getElementByName(String elementName) throws ElementNotFoundException
    {
        Element element = elementDAO.findByName(elementName);

        if (element == null)
        {
            throw new ElementNotFoundException();
        }

        return element;
    }

    /**
     * Find elements by given parent id.
     * 
     * @param parentId
     * @return childNotes all child nodes of a given parent id, returns empty
     *         list if no children exist
     */
    @Override
    public List<Element> getElementsByParentId(Long parentId)
    {
        List<Element> childNotes = elementDAO.findByParentId(parentId);
        return childNotes;
    }

    /**
     * Returns all elements that belong to a certain type.
     * 
     * @param type the type that we want
     * 
     * @return a List of all elements.
     */
    @Override
    public List<Element> getElementsByType(ElementType type)
    {
        return elementDAO.findByType(type);
    }

    /**
     * Returns all elements that belong to a certain project.
     * 
     * @param id the id of desired project
     * 
     * @return a List of all matching elements.
     */
    @Override
    public List<Element> getElementsByProjectId(long id)
    {
        return elementDAO.findByProjectId(id);
    }

    @Override
    public Element getElementByProjectIdAndName(long projectId, String name) throws ElementNotFoundException,
            ProjectNotFoundException
    {
        Element element = elementDAO.findByProjectIdAndName(projectId, name);

        if (element == null)
        {
            throw new ElementNotFoundException();

        }
        return element;
    }
}
