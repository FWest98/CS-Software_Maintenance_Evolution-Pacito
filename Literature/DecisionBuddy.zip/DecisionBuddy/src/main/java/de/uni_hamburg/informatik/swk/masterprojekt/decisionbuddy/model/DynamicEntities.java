package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.PropertyDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.QualityGoalDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.TechnicalTermService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ComparatorFactory;

/**
 * Class for all models that are dynamic (use content from db), but are used in
 * more than one controller.
 * 
 * @author schaak
 *
 */
@Component
public class DynamicEntities
{
    @Autowired
    private TechnicalTermService technicalTermService;

    @Autowired
    private QualityGoalDAO qualityGoalDAO;

    @Autowired
    private PropertyDAO propertyDAO;

    /**
     * Returns all TechnicalTerms for populating dropdown.
     * 
     * @return All technical terms.
     * 
     * @throws SorterInvalidTypeException exception if type is invalid
     * @throws SorterFieldNotFoundException exception if field is not found
     */
    public Map<String, String> getTechnicalTerms() throws SorterInvalidTypeException, SorterFieldNotFoundException
    {
        // get technicalTerms sorted on identifier
        Comparator<TechnicalTerm> technicalTermComparator = new ComparatorFactory<TechnicalTerm>(TechnicalTerm.class)
                .generateComparator("identifier");

        List<TechnicalTerm> technicalTermsFromDB = technicalTermService.getTechnicalTermsByCriteria(null,
                technicalTermComparator);
        Map<String, String> technicalTerms = new LinkedHashMap<String, String>();

        for (TechnicalTerm technicalTerm : technicalTermsFromDB)
        {
            // Type: Class name, Value: Display name
            technicalTerms.put(technicalTerm.getIdentifier(), technicalTerm.getId().toString());
        }

        return technicalTerms;
    }

    /**
     * Returns all QualityGoals for populating dropdown.
     * 
     * @return All quality goals.
     * 
     */
    public Map<String, String> getQualityGoals()
    {
        // get quality goals
        List<QualityGoal> qualityGoalsFromDB = qualityGoalDAO.findAll();

        Map<String, String> qualityGoals = new LinkedHashMap<String, String>();

        for (QualityGoal qualityGoal : qualityGoalsFromDB)
        {
            // Type: Class name, Value: Display name
            qualityGoals.put(qualityGoal.getId().toString(), qualityGoal.getName());
        }

        return qualityGoals;
    }

    /**
     * Returns all Properties for populating dropdown.
     * 
     * @return All quality properties.
     * 
     */
    public Map<String, String> getProperties()
    {
        // get properties
        List<Property> propertiesFromDB = propertyDAO.findAll();

        Map<String, String> properties = new LinkedHashMap<String, String>();

        for (Property property : propertiesFromDB)
        {
            // Type: Class name, Value: Display name
            properties.put(property.getId().toString(), property.getName());
        }

        return properties;
    }
}