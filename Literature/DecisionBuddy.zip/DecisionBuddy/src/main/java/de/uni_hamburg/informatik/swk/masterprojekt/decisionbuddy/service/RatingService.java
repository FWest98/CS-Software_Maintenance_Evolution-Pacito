package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.RatingNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.RatingPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;

/**
 * Overview of interfaces of class RatingService.
 * 
 * @see architectural specification
 *
 * @author schaak
 *
 */
public interface RatingService
{
    /**
     * Adds an rating to the database.
     * 
     * @param rating the rating to be added
     * 
     * @return the saved rating object
     * 
     * @throws RatingPersistenceException Exception if Rating could not be
     *             persisted
     */
    Rating saveRating(Rating rating) throws RatingPersistenceException;

    /**
     * Finds an rating by given id.
     * 
     * @param id id of desired rating
     * 
     * @return desired rating
     * 
     * @throws RatingNotFoundException Exception if Rating is not found
     */
    Rating getRatingById(long id) throws RatingNotFoundException;

    /**
     * Finds all Ratings that belong to the project with the specified ID.
     * 
     * @param id ID of the Solution
     * 
     * @return List of Ratings that belong to the solution with id. List may be
     *         empty if no Ratings were found.
     * 
     * @throws SolutionNotFoundException if Solution is not found
     */
    List<Rating> getRatingsBySolutionID(long id) throws SolutionNotFoundException;
}