package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultParsingException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementFrameworkNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementFrameworkPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementFrameworkService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.SolutionService;

/**
 * Importer for DecisionBuddyAnalyzer output files.
 * 
 * @author 1vietor
 *
 */
@Component
public class ImporterDecisionBuddyAnalyzer extends Importer
{

    @Autowired
    private ProjectService projectService;

    @Autowired
    private SolutionService solutionService;

    @Autowired
    private ElementFrameworkService elementFrameworkService;

    @Override
    protected String[] getValidFileIndicators()
    {
        String[] lineBeginnings = { "<?xml", "<root>", "<known" };
        return lineBeginnings;
    }

    @Override
    public boolean importFile(Integer projectId, String filePath) throws AnalysisResultException
    {
        removeOldData(projectId);

        try
        {
            Project project = projectService.getProjectById(projectId);
            File inputFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);

            // optional, but recommended
            // read this -
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            NodeList frameworks = doc.getElementsByTagName("framework");

            for (int countFrameworks = 0; countFrameworks < frameworks.getLength(); countFrameworks++)
            {
                Node nNode = frameworks.item(countFrameworks);

                if (nNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    Element framework = (Element) nNode;

                    Solution solution = null;
                    String altName = null;
                    String altUrl = null;

                    int id;
                    try
                    {
                        // <known>
                        String idString = getValue(framework, "id");
                        id = Integer.parseInt(idString);
                        try
                        {
                            solution = solutionService.getSolutionById(id);
                        }
                        catch (SolutionNotFoundException e)
                        {
                            continue;
                        }
                    }
                    catch (NullPointerException e)
                    {
                        // element "id" not found, thus this is an <unknown>
                        // framework
                        altName = getValue(framework, "name");
                        altUrl = getValue(framework, "url");
                        if (altUrl.equalsIgnoreCase("N/A"))
                        {
                            // no url given in pom.xml thus using google
                            altUrl = "https://www.google.com/search?q=" + UriUtils.encodeQueryParam(altName, "UTF-8") ;
                        }
                    }

                    // packages
                    NodeList packages = framework.getElementsByTagName("package");

                    if (packages.getLength() == 0)
                    {
                        // save framework that are in the .pom file but aren't
                        // used in imports
                        ElementFramework eleFrameworkPackage = new ElementFramework();
                        eleFrameworkPackage.setSolution(solution);
                        eleFrameworkPackage.setProject(project);
                        eleFrameworkPackage.setClassPath("");
                        eleFrameworkPackage.setType(ElementType.Undefined);
                        eleFrameworkPackage.setAltName(altName);
                        eleFrameworkPackage.setAltUrl(altUrl);
                        elementFrameworkService.saveElementFramework(eleFrameworkPackage);
                    }

                    for (int countPackages = 0; countPackages < packages.getLength(); countPackages++)
                    {
                        Node packageNode = packages.item(countPackages);

                        if (packageNode.getNodeType() == Node.ELEMENT_NODE)
                        {
                            Element packageElement = (Element) packageNode;

                            String packageName = packageElement.getAttribute("name");
                            NodeList classNodes = packageElement.getElementsByTagName("class");

                            // ElementFramework on package level
                            ElementFramework eleFrameworkPackage = new ElementFramework();
                            eleFrameworkPackage.setSolution(solution);
                            eleFrameworkPackage.setProject(project);
                            eleFrameworkPackage.setClassPath(packageName);
                            eleFrameworkPackage.setType(ElementType.Package);
                            eleFrameworkPackage.setAltName(altName);
                            eleFrameworkPackage.setAltUrl(altUrl);
                            elementFrameworkService.saveElementFramework(eleFrameworkPackage);

                            // classes
                            for (int countClasses = 0; countClasses < classNodes.getLength(); countClasses++)
                            {
                                Node classNode = classNodes.item(countClasses);

                                if (classNode.getNodeType() == Node.ELEMENT_NODE)
                                {
                                    String clazz = getValue(packageElement, "class", countClasses);

                                    // ElementFramework on file level
                                    ElementFramework eleFrameworkFile = new ElementFramework();
                                    eleFrameworkFile.setSolution(solution);
                                    eleFrameworkFile.setProject(project);
                                    eleFrameworkFile.setClassPath(packageName + "." + clazz);
                                    eleFrameworkFile.setType(ElementType.File);
                                    eleFrameworkFile.setAltName(altName);
                                    eleFrameworkFile.setAltUrl(altUrl);
                                    elementFrameworkService.saveElementFramework(eleFrameworkFile);
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (ParserConfigurationException | SAXException | IOException e)
        {
            throw new AnalysisResultParsingException();
        }
        catch (ProjectNotFoundException | ElementFrameworkPersistenceException e)
        {
            throw new AnalysisResultPersistenceException();
        }
        return true;
    }

    /**
     * Deletes all analysis data of the selected project.
     * 
     * @param projectId
     */
    private void removeOldData(Integer projectId)
    {
        try
        {
            elementFrameworkService.deleteElementFrameworksByProjectId(projectId);
        }
        catch (ElementFrameworkNotFoundException e)
        {
        }
    }

    /**
     * Extracts the node value of the first child element for a given tagName
     * 
     * @param element
     * @param tagName
     * @return
     */
    private String getValue(Element element, String tagName)
    {
        return element.getElementsByTagName(tagName).item(0).getFirstChild().getNodeValue();
    }

    /**
     * Extracts the counter'th node value of the first child element for a given
     * tagName
     * 
     * @param element
     * @param tagName
     * @param counter
     * @return
     */
    private String getValue(Element element, String tagName, int counter)
    {
        return element.getElementsByTagName(tagName).item(counter).getFirstChild().getNodeValue();
    }
}
