package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.Comparator;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the Rating table from the database.
 *
 * @author Tim
 *
 */

@Entity
@Table(name = "Rating")
public class Rating
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue
    private Long id;

    @ManyToOne(targetEntity = Solution.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "SolutionID", referencedColumnName = "ID", nullable = false)
    private Solution solution;

    @ManyToOne(targetEntity = Property.class, optional = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "PropertyID", referencedColumnName = "ID", nullable = false)
    private Property property;

    @ManyToOne(targetEntity = QualityGoal.class, optional = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "QualityGoalID", referencedColumnName = "ID", nullable = false)
    private QualityGoal qualityGoal;

    @Column(name = "Reasoning", nullable = false, length = ColumnLength.MEDIUM)
    private String reasoning;

    @Column(name = "Rating", nullable = false, length = ColumnLength.SHORT)
    private String rating;

    @Column(name = "Creator", nullable = false, length = ColumnLength.SHORT)
    private String creator;

    @Column(name = "CreationDate", nullable = false)
    private Date creationDate;

    /**
     * No-argument constructor.
     */
    public Rating()
    {
        creationDate = new Date();
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Solution getSolution()
    {
        return solution;
    }

    public void setSolution(Solution solution)
    {
        this.solution = solution;
    }

    public Property getProperty()
    {
        return property;
    }

    public void setProperty(Property property)
    {
        this.property = property;
    }

    public QualityGoal getQualityGoal()
    {
        return qualityGoal;
    }

    public void setQualityGoal(QualityGoal qualityGoal)
    {
        this.qualityGoal = qualityGoal;
    }

    public String getReasoning()
    {
        return reasoning;
    }

    public void setReasoning(String reasoning)
    {
        this.reasoning = reasoning;
    }

    public String getRating()
    {
        return rating;
    }

    public void setRating(String rating)
    {
        this.rating = rating;
    }

    public String getCreator()
    {
        return creator;
    }

    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    public Date getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(Date creationDate)
    {
        this.creationDate = creationDate;
    }

    @Override
    public int hashCode()
    {
        int result;
        if (id == null)
        {
            result = 0;
        }
        else
        {
            result = id.hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Rating other = (Rating) obj;
        return this.getId().equals(other.getId());
    }

    /**
     * Sorts Ratings by Date.
     * 
     * @return the comparator which sorts by Date.
     */
    public static Comparator<Rating> getDateComprator()
    {
        Comparator<Rating> comparator = new Comparator<Rating>()
        {
            public int compare(Rating rating1, Rating rating2)
            {
                Date rating1Date = rating1.getCreationDate();
                Date rating2Date = rating2.getCreationDate();
                return rating1Date.compareTo(rating2Date);
            }
        };

        return comparator;
    }
}
