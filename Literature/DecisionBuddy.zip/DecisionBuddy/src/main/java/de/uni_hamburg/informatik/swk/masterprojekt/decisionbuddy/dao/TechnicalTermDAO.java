package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;

/**
 * A DAO class for TechnicalTerm.
 * 
 * @author Tim
 *
 */
public interface TechnicalTermDAO extends JpaRepository<TechnicalTerm, Long>
{

}
