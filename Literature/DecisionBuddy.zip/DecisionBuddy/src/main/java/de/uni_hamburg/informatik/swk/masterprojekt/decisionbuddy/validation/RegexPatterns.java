package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

/**
 * Class for regex patterns. Static class. Do not autowire or instantiate!
 * 
 * @author Vlad
 *
 */
final class RegexPatterns
{
    /**
     * Private constructor.
     * 
     */
    private RegexPatterns()
    {

    }

    static final String RATING_PATTERN = "[1-5]";
    static final String VERSION_PATTERN = "[0-9]([\\.]?[0-9])*";
    static final String DEVELOPMENTSTATUS_PATTERN = "unknown|active|outdated|replaced|discontinued";
    static final String COMMUNITY_PATTERN = "unknown|small|medium|big|huge";
    static final String WEBSITE_PATTERN = "(http://)?[a-zA-Z1-9\\.]*[\\.]([a-zA-Z])+[a-zA-Z1-9\\./]*";
}
