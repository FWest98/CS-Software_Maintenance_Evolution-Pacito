package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

/**
 * Error codes for the validation.
 * 
 * @author Tim
 *
 */
public final class ErrorCodes
{
    public static final String REQUIRED = "required";
    public static final String MAX_LENGTH = "max_length";
    public static final String INVALID = "invalid";
    public static final String PASSWORD_INVALID = "password_invalid";

    /**
     * Constructor is private because the class doesen't need to be
     * instantiated.
     */
    private ErrorCodes()
    {
    }
}
