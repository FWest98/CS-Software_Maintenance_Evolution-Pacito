package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

/**
 * An interface used for generic filtering. Intended to be used as anonymous
 * inner class.
 * 
 * @author Lucas
 *
 * @param <T> the type of the filter
 */
public interface Filter<T>
{
    /**
     * Determines if the given item should be in the result or if it should be
     * filtered out.
     * 
     * @param item The item to be checked
     * @return True if the item is in the result set. False otherwise.
     */
    boolean isInResult(T item);

}