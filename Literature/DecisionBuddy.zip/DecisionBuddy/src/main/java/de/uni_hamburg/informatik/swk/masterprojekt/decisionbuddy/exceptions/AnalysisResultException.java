package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * Topmost exception for DecisionBuddy AnalysisResults.
 * 
 * @author 1fechner
 *
 */
public abstract class AnalysisResultException extends GeneralException
{

    /**
     * Constructor for Exception.
     */
    private static final long serialVersionUID = 1L;

    public AnalysisResultException()
    {
        setExceptionType("analysisresult");
    }

    public abstract String getViewMode();
}
