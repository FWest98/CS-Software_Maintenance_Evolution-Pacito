package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Validator validates a User.
 * 
 * @author Vlad
 *
 */
@Component
public class UserValidator extends ExtendedValidator implements Validator
{
    private Pattern passwordPattern;
    private Matcher passwordMatcher;

    // Match all alphanumeric character and some special characters. Password
    // must consists of at least 8 characters and not more than 15 characters.
    private static final String PASSWORD_PATTERN = "^([a-zA-Z0-9@*!§$%&=?]{8,15})$";

    @Override
    public boolean supports(Class<?> object)
    {
        return (User.class).isAssignableFrom(object);
    }

    @Override
    public void validate(Object object, Errors errors)
    {
        User user = (User) object;

        checkMandatoryFields(errors);
        checkMaxLength(errors);
        if (!checkPasswordRegex(user.getPassword()))
        {
            errors.rejectValue("password", ErrorCodes.PASSWORD_INVALID);
        }
    }

    /**
     * Validates that fields don't exceed max length.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMaxLength(Errors errors)
    {
        rejectIfStringTooLong(errors, "username", ColumnLength.CREDENTIAL, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "password", ColumnLength.CREDENTIAL, ErrorCodes.MAX_LENGTH);
    }

    /**
     * VAlidates that mandatory are not empty or contain whitespaces only.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMandatoryFields(Errors errors)
    {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", ErrorCodes.REQUIRED);
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", ErrorCodes.REQUIRED);
    }

    private boolean checkPasswordRegex(String password)
    {
        passwordPattern = Pattern.compile(PASSWORD_PATTERN);
        passwordMatcher = passwordPattern.matcher(password);
        return passwordMatcher.matches();
    }
}
