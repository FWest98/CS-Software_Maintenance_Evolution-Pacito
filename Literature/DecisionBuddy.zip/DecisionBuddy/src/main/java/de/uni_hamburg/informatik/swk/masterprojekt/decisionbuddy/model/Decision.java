package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

/**
 * This Class represents the Decision table from the database.
 *
 * @author Tim
 *
 */

@Entity
@Table(name = "Decision")
public class Decision
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue
    private Long id;

    @OneToOne(targetEntity = Issue.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "IssueID", referencedColumnName = "ID", nullable = false)
    private Issue issue;

    @Column(name = "Decided", nullable = false, columnDefinition = "TINYINT(1)")
    private boolean decided;

    @Column(name = "DecisionDate", nullable = true)
    private Date decisionDate;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "decision", orphanRemoval = true)
    private List<SolutionCandidate> solutionCandidates;

    @LazyCollection(LazyCollectionOption.FALSE)
    @OrderBy("date DESC")
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "decision", orphanRemoval = true)
    private List<Comment> comments;

    /**
     * Constructor without parameters.
     */
    public Decision()
    {
        decided = false;
        solutionCandidates = new ArrayList<SolutionCandidate>();
        comments = new ArrayList<Comment>();
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Issue getIssue()
    {
        return issue;
    }

    public void setIssue(Issue issue)
    {
        this.issue = issue;
    }

    public boolean isDecided()
    {
        return decided;
    }

    public void setDecided(boolean decided)
    {
        this.decided = decided;
    }

    public Date getDecisionDate()
    {
        return decisionDate;
    }

    public void setDecisionDate(Date decisionDate)
    {
        this.decisionDate = decisionDate;
    }

    public List<SolutionCandidate> getSolutionCandidates()
    {
        return solutionCandidates;
    }

    public void setSolutionCandidates(List<SolutionCandidate> solutionCandidates)
    {
        this.solutionCandidates = solutionCandidates;
    }

    /**
     * Add a new SolutionCandidate to this Decision.
     *
     * @param solutionCandidate This SolutionCandidate is added to the list.
     */
    public void addSolutionCandidate(SolutionCandidate solutionCandidate)
    {
        if (solutionCandidates == null)
        {
            solutionCandidates = new ArrayList<SolutionCandidate>();
        }
        solutionCandidate.setDecision(this);
        solutionCandidates.add(solutionCandidate);
    }

    /**
     * Removes a SolutionCandidate from this decision.
     *
     * @param solutionCandidate This solutionCandidate is removed from the list.
     */
    public void removeSolutionCandidate(SolutionCandidate solutionCandidate)
    {
        if (solutionCandidate != null)
        {
            solutionCandidate.setSolution(null);
            solutionCandidates.remove(solutionCandidate);
        }
    }

    public List<Comment> getComments()
    {
        return comments;
    }

    public void setComments(List<Comment> comments)
    {
        this.comments = comments;
    }

    /**
     * Add a new Comment to this Decision.
     *
     * @param comment This Comment is added to the list.
     */
    public void addComment(Comment comment)
    {
        if (comments == null)
        {
            comments = new ArrayList<Comment>();
        }
        comment.setDecision(this);
        comments.add(comment);
    }

    /**
     * Remove a Comment from this Decision.
     *
     * @param comment This Comment is removed from the list.
     */
    public void removeComment(Comment comment)
    {
        if (comments != null)
        {
            comment.setDecision(null);
            comments.remove(comment);
        }
    }

    @Override
    public int hashCode()
    {
        int result = ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Decision other = (Decision) obj;
        return other.getId().equals(this.getId());
    }
}