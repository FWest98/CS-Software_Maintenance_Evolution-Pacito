package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;

/**
 * A DAO class for Framework.
 * 
 * @author Vlad
 *
 */
public interface FrameworkDAO extends JpaRepository<Framework, Long>
{

}
