package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the Solution table from the database.
 *
 * @author Vlad
 *
 */
@Entity
@Table(name = "Solution")
@Inheritance(strategy = InheritanceType.JOINED)
public class Solution implements UserEditable
{
    @Id
    @GeneratedValue
    @Column(name = "ID")
    private Long id;

    @Column(name = "Name", nullable = false, length = ColumnLength.SHORT)
    private String name;

    @Column(name = "Type", nullable = false, length = ColumnLength.SHORT)
    private String type;

    @Column(name = "ShortDescription", nullable = false, length = ColumnLength.DESCRIPTION)
    private String shortDescription;

    @Column(name = "Creator", nullable = false, length = ColumnLength.SHORT)
    private String creator;

    @Column(name = "CreationDate", nullable = false)
    private Date creationDate;

    @Column(name = "LastModifier", length = ColumnLength.SHORT)
    private String lastModifier;

    @Column(name = "ModificationDate")
    private Date modificationDate;

    @OneToMany(cascade = { CascadeType.ALL }, orphanRemoval = true)
    @JoinTable(name = "Solution_Constraint", joinColumns = { @JoinColumn(name = "SolutionID", referencedColumnName = "ID") }, inverseJoinColumns = { @JoinColumn(name = "ConstraintID", referencedColumnName = "ID") })
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<Constraint> constraints;

    @Transient
    private Float userScore;

    @Transient
    private Float gssScore;

    @Transient
    private Float overallScore;

    /**
     * This is needed to get Statistics about solution usage.
     */
    /*
     * @OneToMany(cascade = { CascadeType.ALL }, orphanRemoval = true)
     * 
     * @JoinColumn(name = "SolutionID", referencedColumnName = "ID")
     * 
     * @LazyCollection(LazyCollectionOption.FALSE) private
     * List<SolutionCandidate> solutionCandidates;
     */

    /**
     * No-argument constructor.
     */
    public Solution()
    {
        creationDate = new Date();
        modificationDate = new Date();
        constraints = new ArrayList<Constraint>();
        userScore = 0f;
        gssScore = 0f;
        overallScore = 0f;
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getShortDescription()
    {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription)
    {
        this.shortDescription = shortDescription;
    }

    @Override
    public String getCreator()
    {
        return creator;
    }

    @Override
    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    @Override
    public Date getCreationDate()
    {
        return creationDate;
    }

    @Override
    public void setCreationDate(Date creationDate)
    {
        this.creationDate = creationDate;
    }

    @Override
    public String getLastModifier()
    {
        return lastModifier;
    }

    @Override
    public void setLastModifier(String lastModifier)
    {
        this.lastModifier = lastModifier;
    }

    @Override
    public Date getModificationDate()
    {
        return modificationDate;
    }

    @Override
    public void setModificationDate(Date modificationDate)
    {
        this.modificationDate = modificationDate;
    }

    public List<Constraint> getConstraints()
    {
        return constraints;
    }

    public void setConstraints(List<Constraint> constraints)
    {
        this.constraints = constraints;
    }

    /**
     * Add a new constraint to this solution.
     *
     * @param constraint This constraint is added to the list.
     */
    public void addConstraint(Constraint constraint)
    {
        constraints.add(constraint);
    }

    public float getUserScore()
    {
        return userScore;
    }

    public void setUserScore(float userScore)
    {
        this.userScore = userScore;
    }

    public float getGssScore()
    {
        return gssScore;
    }

    public void setGssScore(float gssScore)
    {
        this.gssScore = gssScore;
    }

    public float getOverallScore()
    {
        return overallScore;
    }

    public void setOverallScore(float overallScore)
    {
        this.overallScore = overallScore;
    }

    @Override
    public String toString()
    {
        return id + "," + name + "," + type + "," + shortDescription + "," + creator + "," + creationDate + ","
                + lastModifier + "," + modificationDate + ",";
    }

    @Override
    public int hashCode()
    {
        int result = ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Solution other = (Solution) obj;
        return other.getId().equals(this.getId());
    }
}