/**
 * This package contains the service layer.
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;