package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;

/**
 * A DAO class for FrameworkCategory.
 * 
 * @author Vlad
 *
 */
public interface FrameworkCategoryDAO extends JpaRepository<FrameworkCategory, Long>
{

}
