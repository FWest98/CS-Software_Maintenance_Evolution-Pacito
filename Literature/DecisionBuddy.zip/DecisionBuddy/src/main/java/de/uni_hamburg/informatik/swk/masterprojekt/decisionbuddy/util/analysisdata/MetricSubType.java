package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

public enum MetricSubType
{
    Structure, Cyclicity, Other
}
