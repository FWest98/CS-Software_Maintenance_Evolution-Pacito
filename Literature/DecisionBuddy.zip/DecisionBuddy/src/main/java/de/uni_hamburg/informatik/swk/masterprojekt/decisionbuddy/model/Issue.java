package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the Issue table from the database.
 *
 * @author Vlad
 *
 */
@Entity
@Table(name = "Issue")
public class Issue implements UserEditable
{
    @Id
    @Column(name = "ID")
    @GeneratedValue
    private Long id;

    @ManyToOne(targetEntity = Project.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "ProjectID", referencedColumnName = "ID", nullable = false)
    private Project project;

    @OneToOne(mappedBy = "issue", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private Decision decision;

    @Column(name = "Name", nullable = false, length = ColumnLength.SHORT)
    private String name;

    @Column(name = "Description", nullable = true, length = ColumnLength.LONG)
    private String description;

    @Column(name = "Creator", nullable = false, length = ColumnLength.SHORT)
    private String creator;

    @Column(name = "CreationDate", nullable = false)
    private Date creationDate;

    @Column(name = "LastModifier", nullable = true, length = ColumnLength.SHORT)
    private String lastModifier;

    @Column(name = "ModificationDate", nullable = true)
    private Date modificationDate;

    @OneToMany(cascade = { CascadeType.ALL }, orphanRemoval = true)
    @JoinTable(name = "Issue_Constraint", joinColumns = { @JoinColumn(name = "IssueID", referencedColumnName = "ID") }, inverseJoinColumns = { @JoinColumn(name = "ConstraintID", referencedColumnName = "ID") })
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<Constraint> constraints;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "issue", orphanRemoval = true)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<WeightedQualityGoal> weightedQualityGoals;

    /**
     * Constructor without parameters.
     */
    public Issue()
    {
        creationDate = new Date();
        modificationDate = new Date();
        constraints = new ArrayList<Constraint>();
        weightedQualityGoals = new ArrayList<WeightedQualityGoal>();
        decision = new Decision();
        decision.setIssue(this);
    }

    /**
     * Add a new WeightedQualityGoal to this issue.
     *
     * @param weightedQualityGoal This WeightedQualityGoal is added to the list.
     */
    public void addWeightedQualityGoal(WeightedQualityGoal weightedQualityGoal)
    {
        weightedQualityGoals.add(weightedQualityGoal);
        weightedQualityGoal.setIssue(this);
    }

    /**
     * Remove a WeightedQualityGoal to this issue.
     *
     * @param weightedQualityGoal This WeightedQualityGoal is removed from the
     *            list.
     */
    public void removeWeightedQualityGoal(WeightedQualityGoal weightedQualityGoal)
    {
        if (weightedQualityGoals != null)
        {
            weightedQualityGoals.remove(weightedQualityGoal);
        }
    }

    public List<WeightedQualityGoal> getWeightedQualityGoals()
    {
        return weightedQualityGoals;
    }

    public void setWeightedQualityGoals(List<WeightedQualityGoal> weightedQualityGoals)
    {
        this.weightedQualityGoals = weightedQualityGoals;
    }

    /**
     * Add a new constraint to this issue.
     *
     * @param constraint This constraint is added to the list.
     */
    public void addConstraint(Constraint constraint)
    {
        constraints.add(constraint);
    }

    public List<Constraint> getConstraints()
    {
        return constraints;
    }

    public void setConstraints(List<Constraint> constraints)
    {
        this.constraints = constraints;
    }

    public Decision getDecision()
    {
        return decision;
    }

    public void setDecision(Decision decision)
    {
        this.decision = decision;
    }

    public Long getId()
    {
        return this.id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Project getProject()
    {
        return project;
    }

    public void setProject(Project project)
    {
        this.project = project;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getCreator()
    {
        return creator;
    }

    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    public Date getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(Date creationDate)
    {
        this.creationDate = creationDate;
    }

    public String getLastModifier()
    {
        return lastModifier;
    }

    public void setLastModifier(String lastModifier)
    {
        this.lastModifier = lastModifier;
    }

    public Date getModificationDate()
    {
        return modificationDate;
    }

    public void setModificationDate(Date modificationDate)
    {
        this.modificationDate = modificationDate;
    }

    @Override
    public String toString()
    {
        return id + "," + name + "," + description + "," + creator + "," + creationDate + "," + lastModifier + ","
                + modificationDate;
    }

    @Override
    public int hashCode()
    {
        int result = id.hashCode();
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Issue other = (Issue) obj;
        return this.getId().equals(other.getId());
    }
}