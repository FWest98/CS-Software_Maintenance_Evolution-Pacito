/**
 * A package for all our custom exceptions.
 * 
 * @author schaak
 * 
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;