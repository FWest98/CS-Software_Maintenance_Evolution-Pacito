package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * Factory class for solution-specific filters. Static class: do not
 * autowire/instantiate!
 * 
 * @author Lucas
 *
 */
public final class SolutionFilterFactory
{
    /**
     * Private constructor.
     */
    private SolutionFilterFactory()
    {

    }

    /**
     * Generates a Filter based on a column and value of a Solution.
     * 
     * @param column The column, that will be filtered.
     * @param value The value, that will be displayed.
     * 
     * @return A Filter for the given criteria.
     */
    public static Filter<Solution> generateSolutionFilter(String column, String value)
    {
        if (column != null && column.equalsIgnoreCase("type"))
        {
            // Filter by type
            return generateSolutionFilterType(value);
        }
        // TODO add more cases
        else if (column != null && column.equalsIgnoreCase("name"))
        {
            // Filter by name
            return generateSolutionFilterName(value);
        }
        else
        {
            // Default filter. Show all solutions.
            return new Filter<Solution>()
            {
                public boolean isInResult(Solution solution)
                {
                    return true;
                }
            };
        }
    }

    /**
     * Helper method to create a Filter for the column "type".
     * 
     * @param value The value. See generateSolutionFilter(String column, String
     *            value) description.
     * 
     * @return A Filter for the given criteria.
     */
    private static Filter<Solution> generateSolutionFilterType(String value)
    {
        if (value == null)
        {
            value = "none";
        }
        final String val = value;
        if (!val.equals("none"))
        {
            return new Filter<Solution>()
            {
                public boolean isInResult(Solution solution)
                {
                    return solution.getType().equalsIgnoreCase(val);
                }
            };
        }
        else
        {
            return new Filter<Solution>()
            {
                public boolean isInResult(Solution solution)
                {
                    return true;
                }
            };
        }

    }

    /**
     * Helper method to create a Filter for the column "name" based on equality.
     * 
     * @param value The value. See generateSolutionFilter(String column, String
     *            value) description.
     * 
     * @return A Filter for the given criteria.
     */
    private static Filter<Solution> generateSolutionFilterName(String value)
    {
        if (value == null)
        {
            value = "none";
        }
        final String val = value;
        if (!val.equals("none"))
        {
            return new Filter<Solution>()
            {
                public boolean isInResult(Solution solution)
                {
                    return solution.getName().toLowerCase().contains(val.toLowerCase());
                }
            };
        }
        else
        {
            return new Filter<Solution>()
            {
                public boolean isInResult(Solution solution)
                {
                    return true;
                }
            };
        }

    }
}
