package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the Project table from the database. Two projects are
 * considered equal if their Ids are equal.
 *
 * @author Vlad
 *
 */
@Entity
@Table(name = "Project")
public class Project implements UserEditable
{
    @Id
    @Column(name = "ID")
    @GeneratedValue
    private Long id;

    @Column(name = "Name", nullable = false)
    private String name;

    @Column(name = "Description", nullable = true, length = ColumnLength.LONG)
    private String description;

    @Column(name = "Creator", nullable = false, length = ColumnLength.SHORT)
    private String creator;

    @Column(name = "CreationDate", nullable = false)
    private Date creationDate;

    @Column(name = "LastModifier", nullable = true, length = ColumnLength.SHORT)
    private String lastModifier;

    @Column(name = "ModificationDate", nullable = true)
    private Date modificationDate;

    /**
     * Constructor.
     */
    public Project()
    {
        creationDate = new Date();
        modificationDate = new Date();
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getCreator()
    {
        return creator;
    }

    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    public Date getCreationDate()
    {
        return creationDate;
    }

    public void setCreationDate(Date date)
    {
        this.creationDate = date;
    }

    public String getLastModifier()
    {
        return lastModifier;
    }

    public void setLastModifier(String lastModified)
    {
        this.lastModifier = lastModified;
    }

    public Date getModificationDate()
    {
        return modificationDate;
    }

    public void setModificationDate(Date modificationDate)
    {
        this.modificationDate = modificationDate;
    }

    @Override
    public int hashCode()
    {
        return ((id == null) ? 0 : id.hashCode());
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Project other = (Project) obj;
        return other.getId().equals(this.getId());
    }
}