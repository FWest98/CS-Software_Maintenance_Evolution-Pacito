package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class validates a design pattern.
 *
 * @author Tim
 *
 */
@Component
public class DesignPatternValidator extends SolutionValidator implements Validator
{
    // Example pattern for version format.
    private static final String TYPE = "DesignPattern";

    /**
     * Tests if the validator can validate the given object.
     * 
     * @param object an object to be validated
     * @return boolean if the object can be validated as a DesignPattern
     */
    @Override
    public boolean supports(Class<?> object)
    {
        return (DesignPattern.class).isAssignableFrom(object);
    }

    /**
     * Checks if a given design pattern object is considered valid.
     * 
     * @param object the given object
     * @param errors collects encountered field errors
     */
    @Override
    public void validate(Object object, Errors errors)
    {
        checkMandatoryFields(errors);
        checkMaxLength(errors);
        checkFormats(errors);

        validateConstraints(object, errors);
    }

    /**
     * Validates that fields are in the right format.
     * 
     * @param errors collects encountered field errors
     */
    private void checkFormats(Errors errors)
    {
        rejectIfStringInvalid(errors, "type", TYPE, ErrorCodes.INVALID);
    }

    /**
     * Validates that fields don't exceed max length.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMaxLength(Errors errors)
    {
        // Solution fields
        rejectIfStringTooLong(errors, "name", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "shortDescription", ColumnLength.DESCRIPTION, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "type", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "creator", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "lastModifier", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        // Specific fields
        rejectIfStringTooLong(errors, "altName1", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "altName2", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "intent", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "motivation", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "applicability", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "participants", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "collaboration", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "consequences", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "implementation", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "sampleCode", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "knownUses", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
    }

    /**
     * Validates that mandatory fields are not empty.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMandatoryFields(Errors errors)
    {
        // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", REQUIRED_EC);
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", ErrorCodes.REQUIRED);
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "shortDescription", ErrorCodes.REQUIRED);
        // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "creator",
        // REQUIRED_EC);
        // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "creationDate",
        // REQUIRED_EC);
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "designPatternCategory", ErrorCodes.REQUIRED);
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "type", ErrorCodes.REQUIRED);
    }
}