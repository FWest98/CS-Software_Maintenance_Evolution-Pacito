package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.WeightedQualityGoal;

/**
 * A DAO class for WeightedQualityGoal.
 * 
 * @author Tim
 *
 */
public interface WeightedQualityGoalDAO extends JpaRepository<WeightedQualityGoal, Long>
{

}
