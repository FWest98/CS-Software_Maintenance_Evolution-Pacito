package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * This Class represents the Element table from the database.
 * 
 * @author Burak
 *
 */

@Entity
@Table(name = "Element")
@Inheritance(strategy = InheritanceType.JOINED)
public class Element
{
    @Id
    @GeneratedValue
    @Column(name = "ID")
    private Long id;

    @Column(name = "Name", nullable = false, length = ColumnLength.SHORT)
    private String name;

    @ManyToOne(targetEntity = Element.class, optional = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "ParentID", referencedColumnName = "ID", nullable = true)
    private Element parent;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "Type")
    private ElementType type;

    @ManyToOne(targetEntity = Project.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "ProjectID", referencedColumnName = "ID", nullable = false)
    private Project project;

    /**
     * No-argument constructor.
     */
    public Element()
    {

    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Element getParent()
    {
        return parent;
    }

    public void setParent(Element parent)
    {
        this.parent = parent;
    }

    public ElementType getType()
    {
        return type;
    }

    public void setType(ElementType type)
    {
        this.type = type;
    }

    public Project getProject()
    {
        return project;
    }

    public void setProject(Project project)
    {
        this.project = project;
    }

    @Override
    public String toString()
    {
        return "ID:" + id + "," + "Name:" + name + "," + "Parent:" + parent + "," + "Type:" + type + "," + "Project:"
                + project;
    }

    @Override
    public int hashCode()
    {
        int result = ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Element other = (Element) obj;
        return other.getId().equals(this.getId());
    }

}
