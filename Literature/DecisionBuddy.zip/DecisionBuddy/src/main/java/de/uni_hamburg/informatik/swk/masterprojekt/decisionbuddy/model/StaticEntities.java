package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

/**
 * Class for all models that are static (not stored in db). Mostly concerns
 * fixed data for populating dropdowns.
 * 
 * @author schaak, tim
 *
 */
@Component
public class StaticEntities
{
    /**
     * Returns all Solution types.
     * 
     * @return All solution types.
     */
    public Map<String, String> getSolutionTypes()
    {
        Map<String, String> types = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        types.put("DesignPattern", "Design pattern");
        types.put("ArchitecturalPattern", "Architectural pattern");
        types.put("Framework", "Framework");
        types.put("COTS", "COTS");
        types.put("Refactoring", "Refactoring");

        return types;
    }

    /**
     * Returns all development stati.
     * 
     * @return All development stati
     */
    public Map<String, String> getDevelopmentStati()
    {
        Map<String, String> types = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        types.put("unknown", "unknown");
        types.put("active", "active");
        types.put("outdated", "out-dated");
        types.put("replaced", "replaced");
        types.put("discontinued", "discontinued");
        return types;
    }

    /**
     * Returns all community sizes.
     * 
     * @return All community sizes
     */
    public Map<String, String> getCommunitySizes()
    {
        Map<String, String> types = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        types.put("unknown", "unknown");
        types.put("small", "small");
        types.put("medium", "medium");
        types.put("big", "big");
        types.put("huge", "huge");

        return types;
    }

    /**
     * Returns all licenses.
     * 
     * @return All licenses
     */
    public Map<String, String> getLicenses()
    {
        Map<String, String> types = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        types.put("unknown", "unknown");
        types.put("bsd", "BSD");
        types.put("gpl", "GPL");
        types.put("lgpl", "LGPL");
        types.put("isc", "ISC");
        types.put("mit", "MIT");
        types.put("mpl", "MPL");
        types.put("npl", "NPL");

        return types;
    }

    /**
     * Returns all programming languages.
     * 
     * @return All programming languages
     */
    public Map<String, String> getProgrammingLanguages()
    {
        Map<String, String> types = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        types.put("unknown", "unknown");
        types.put("java", "Java");
        types.put("php", "PHP");
        types.put("c", "C");
        types.put("c++", "C++");
        types.put("c#", "C#");
        types.put("javascript", "JavaScript");
        types.put("python", "Python");
        return types;
    }

    /**
     * Returns all programming languages.
     * 
     * @return All programming languages
     */
    public Map<String, String> getOperatingSystems()
    {
        Map<String, String> types = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        types.put("unknown", "unknown");
        types.put("platform independent", "platform independent");
        types.put("windows vista", "Windows Vista");
        types.put("windows 7", "Windows 7");
        types.put("windows 8", "Windows 8");
        types.put("mac os x 10", "Mac Os X 10");
        types.put("linux", "Linux");

        return types;
    }

    /**
     * Returns all bad smells.
     * 
     * @return All bad smells
     */
    public Map<String, String> getBadSmells()
    {
        Map<String, String> types = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        types.put("none", "None");
        types.put("Duplicated Code", "Duplicated Code");
        types.put("Long Method", "Long Method");
        types.put("Large Class", "Large Class");
        types.put("Long Parameter List", "Long Parameter List");
        types.put("Divergent Change", "Divergent Change");
        types.put("Shotgun Surgery", "Shotgun Surgery");
        types.put("Feature Envy", "Feature Envy");
        types.put("Data Clumps", "Data Clumps");
        types.put("Primitive Obsession", "Primitive Obsession");
        types.put("Switch Statements", "Switch Statements");
        types.put("Parallel Inheritance Hierarchies", "Parallel Inheritance Hierarchies");
        types.put("Lazy Class", "Lazy Class");
        types.put("Speculative Generality", "Speculative Generality");
        types.put("Temporary Field", "Temporary Field");
        types.put("Message Chains", "Message Chains");
        types.put("Middle Man", "Middle Man");
        types.put("Inappropriate Intimacy", "Inappropriate Intimacy");
        types.put("Alternative Classes with Different Interfaces", "Alternative Classes with Different Interfaces");
        types.put("Incomplete Library Class", "Incomplete Library Class");
        types.put("Data Class", "Data Class");
        types.put("Refused Bequest", "Refused Bequest");
        return types;
    }

    /**
     * Returns all options for delivered / required by.
     * 
     * @return All options for required / delivered by
     */
    public Map<String, String> getRequiredDeliveredBy()
    {
        Map<String, String> options = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        options.put("solution", "solution");
        options.put("issue", "issue");

        return options;
    }

    /**
     * Returns all Technical Term types.
     * 
     * @return All technical term types.
     */
    public Map<String, String> getTechnicalTermTypes()
    {
        Map<String, String> technicalTermTypes = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        technicalTermTypes.put("string", "string");
        technicalTermTypes.put("int", "int");
        technicalTermTypes.put("stringint", "stringint");

        return technicalTermTypes;
    }

    /**
     * Returns all Constraint comparators.
     * 
     * @return All constraint comparators.
     */
    public Map<String, String> getConstraintComparators()
    {
        Map<String, String> constraintComparators = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        constraintComparators.put("equals", "= (equals)");
        constraintComparators.put("smaller", "< (smaller)");
        constraintComparators.put("greater", "> (greater)");
        constraintComparators.put("smallerequal", "<= (smaller or equal)");
        constraintComparators.put("greaterequal", ">= (greater or equal)");

        return constraintComparators;
    }

    /**
     * Returns all candidate decision stati.
     * 
     * @return All candidate decision stati
     */
    public Map<String, String> getCandidateDecisionStati()
    {
        Map<String, String> types = new LinkedHashMap<String, String>();

        // Type: Class name, Value: Display name
        types.put("0", "undecided");
        types.put("1", "approved");
        types.put("2", "rejected");

        return types;
    }
}