package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ImporterFactory
{
    @Autowired
    private ImporterDecisionBuddyAnalyzer importerDecisionBuddyAnalyzer;

    @Autowired
    private ImporterPinot importerPinot;

    @Autowired
    private ImporterSonargraph importerSonargraph;

    /**
     * Returns Importer based on the received String Parameter.
     * 
     * @param format
     * @return Importer based on the received importerType
     */
    public Importer getImporter(AnalysisFileFormat format)
    {
        // Importer
        Importer result = null;

        // Decides which kind of Importer to generate based on the received
        // String
        switch (format)
        {
            case DBAnalyzer:
                result = importerDecisionBuddyAnalyzer;
                break;
            case Pinot:
                result = importerPinot;
                break;
            case Sonargraph:
                result = importerSonargraph;
                break;
            default:
                System.out.printf("String does not resolve to a valid Importer Type");
                // TODO Error-Message. Exception maybe?
        }
        return result;
    }
}
