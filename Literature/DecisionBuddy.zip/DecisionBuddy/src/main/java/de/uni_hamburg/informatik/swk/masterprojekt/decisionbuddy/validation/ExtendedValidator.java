package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

import org.springframework.validation.Errors;

/**
 * Abstract class for core functionality of validators.
 *
 * @author Tim
 *
 */
abstract class ExtendedValidator
{
    /**
     * Validates that string fields don't exceed max length.
     * 
     * @param errors collects encountered field errors
     * @param field field to check length
     * @param maxLength maximum excepted length
     * @param errorCode error code for rejection
     */
    protected void rejectIfStringTooLong(Errors errors, String field, int maxLength, String errorCode)
    {
        String value = (String) errors.getFieldValue(field);
        if (value != null && value.length() > maxLength)
        {
            errors.rejectValue(field, errorCode,
                    new Object[] { String.valueOf(maxLength), String.valueOf(value.length() - maxLength) },
                    "No message definied.");
        }
    }

    /**
     * Validates that string fields don't exceed max length.
     * 
     * @param errors collects encountered field errors
     * @param field field to check length
     * @param pattern the pattern the string has to match
     * @param errorCode error code for rejection
     */
    protected void rejectIfStringInvalid(Errors errors, String field, String pattern, String errorCode)
    {
        String value = (String) errors.getFieldValue(field);
        if (value != null && value.length() > 0 && !value.matches(pattern))
        {
            errors.rejectValue(field, errorCode, new Object[] { "'" + value + "'" }, "No message definied.");
        }
    }
}
