package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;

/**
 * A DAO class for Comment.
 * 
 * @author Tim
 *
 */
public interface CommentDAO extends JpaRepository<Comment, Long>
{
    /**
     * Find all Ratings belonging to a Decision by the DecisionId.
     * 
     * @param decisionID of the Decision for which you want to find the Ratings
     * @return all Ratings belonging to that Decision
     */
    List<Comment> findByDecisionId(Long decisionID);

    /**
     * Find all Ratings belonging to a Decision.
     * 
     * @param decision for which you want to find the Ratings
     * @return all Ratings belonging to that Decision
     */
    List<Comment> findByDecision(Decision decision);

}
