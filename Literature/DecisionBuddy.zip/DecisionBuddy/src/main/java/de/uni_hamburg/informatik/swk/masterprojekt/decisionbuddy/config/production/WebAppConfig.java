package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.Ordered;
import org.springframework.ui.context.ThemeSource;
import org.springframework.ui.context.support.ResourceBundleThemeSource;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ThemeResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.theme.CookieThemeResolver;
import org.springframework.web.servlet.theme.ThemeChangeInterceptor;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

/**
 * Configuration class for the WebMVC architecture and resources for the web
 * application.
 * 
 * @author Vlad
 *
 */
@Configuration
@EnableWebMvc
@ComponentScan("de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy")
@Import({ WebAppSecurityConfig.class })
public class WebAppConfig extends WebMvcConfigurerAdapter
{
    // file upload constants
    // private static final long MAX_FILE_UPLOAD_SIZE = 1024 * 1024 * 5;
    // 115 Mb file limit
    // private static final int FILE_SIZE_THRESHOLD = 1024 * 1024;
    // After 1Mb write files to disk

    public void addViewControllers(ViewControllerRegistry registry)
    {
        registry.addViewController("/login").setViewName("login");
        registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
    }

    /**
     * Configures the URLResolver.
     * 
     * @return a URLResolver object
     */
    @Bean
    public UrlBasedViewResolver setupViewResolver()
    {
        UrlBasedViewResolver resolver = new UrlBasedViewResolver();
        resolver.setPrefix("/WEB-INF/views/");
        resolver.setSuffix(".jsp");
        resolver.setViewClass(JstlView.class);
        return resolver;
    }

    /**
     * Maps resources path to webapp/resources where the css and JavaScript
     * recources reside.
     * 
     * @param registry
     *            a registry handler object
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry)
    {
        registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
    }

    /**
     * Registers the application�s interceptors.
     * 
     * @param registry
     *            the interceptor registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry)
    {
        registry.addInterceptor(localeChangeInterceptor());
        registry.addInterceptor(themeChangeInterceptor());
    }

    /**
     * An interceptor to switch locales / languages.
     * 
     * @return the interceptor
     */
    @Bean
    public HandlerInterceptor localeChangeInterceptor()
    {
        LocaleChangeInterceptor localeChangeInterceptor;
        localeChangeInterceptor = new LocaleChangeInterceptor();
        localeChangeInterceptor.setParamName("lang");

        return localeChangeInterceptor;
    }

    /**
     * An interceptor to switch themes.
     * 
     * @return the interceptor
     */
    @Bean
    public HandlerInterceptor themeChangeInterceptor()
    {
        ThemeChangeInterceptor themeChangeInterceptor;
        themeChangeInterceptor = new ThemeChangeInterceptor();
        themeChangeInterceptor.setParamName("theme");

        return themeChangeInterceptor;
    }

    /**
     * Saves the locale in cookies.
     * 
     * @return a LocaleResolver
     */
    @Bean
    public LocaleResolver localeResolver()
    {
        return new CookieLocaleResolver();
    }

    /**
     * Saves the theme in cookies.
     * 
     * @return a ThemeResolver
     */
    @Bean
    public ThemeResolver themeResolver()
    {
        CookieThemeResolver cookieThemeResolver;
        cookieThemeResolver = new CookieThemeResolver();
        cookieThemeResolver.setDefaultThemeName("classic");

        return cookieThemeResolver;
    }

    /**
     * Provides internationalization of messages.
     * 
     * @return a MessageSource object
     */
    @Bean
    public MessageSource messageSource()
    {
        ReloadableResourceBundleMessageSource messageSource;
        messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:/messages");
        messageSource.setUseCodeAsDefaultMessage(true);
        messageSource.setFallbackToSystemLocale(false);
        messageSource.setDefaultEncoding("UTF-8");

        return messageSource;
    }

    /**
     * Provides individual theming.
     * 
     * @return a ThemeSource object
     */
    @Bean
    public ThemeSource themeSource()
    {
        ResourceBundleThemeSource themeSource;
        themeSource = new ResourceBundleThemeSource();
        themeSource.setBasenamePrefix("theme_");

        return themeSource;
    }

    @Bean(name = "multipartResolver")
    public CommonsMultipartResolver createMultipartResolver()
    {
        CommonsMultipartResolver resolver = new CommonsMultipartResolver();
        resolver.setDefaultEncoding("utf-8");
        return resolver;
    }

}