package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the ConstraintElement table from the database. LOl
 *
 * @author Tim
 *
 */
@Entity
@Table(name = "ConstraintElement")
public class ConstraintElement
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(targetEntity = Constraint.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "ConstraintID", referencedColumnName = "ID", nullable = false)
    private Constraint constraint;

    @Column(name = "IntValue", nullable = true)
    private Integer intValue;

    @ManyToOne(targetEntity = StringValue.class, fetch = FetchType.EAGER)
    @org.hibernate.annotations.Cascade({ org.hibernate.annotations.CascadeType.LOCK })
    @JoinColumn(name = "StringValueID", referencedColumnName = "ID")
    private StringValue stringValue;

    @Column(name = "Comparator", nullable = true, length = ColumnLength.SHORT)
    private String comparator;

    /**
     * No-argument constructor.
     */
    public ConstraintElement()
    {
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Constraint getConstraint()
    {
        return constraint;
    }

    public void setConstraint(Constraint constraint)
    {
        this.constraint = constraint;
    }

    public Integer getIntValue()
    {
        return intValue;
    }

    public void setIntValue(Integer intValue)
    {
        this.intValue = intValue;
    }

    public StringValue getStringValue()
    {
        return stringValue;
    }

    public void setStringValue(StringValue stringValue)
    {
        this.stringValue = stringValue;
    }

    public String getComparator()
    {
        return comparator;
    }

    public void setComparator(String comparator)
    {
        this.comparator = comparator;
    }

    @Override
    public int hashCode()
    {
        int result;
        if (getId() == null)
        {
            result = 0;
        }
        else
        {
            result = getId().hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        ConstraintElement other = (ConstraintElement) obj;
        if (other.getId() == null || this.getId() == null)
        {
            return false;
        }
        return other.getId().equals(this.getId());
    }
}
