package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.StringValueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.TechnicalTermDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;

/**
 * This class proposes constraints that are derived from model values of
 * solutions.
 * 
 * @author Tim
 * 
 */
@Component
public class ConstraintProposer
{
    @Autowired
    private TechnicalTermDAO technicalTermDAO;

    @Autowired
    private StringValueDAO stringValueDAO;

    // The percentage of characters that are at most changed.
    private final double differenceThreshold = 0.4;

    /**
     * This methods gives potential constraints for a Solution based of its
     * model values.
     * 
     * @param solution for which Constraints should be proposed.
     * @return a list of potential constraints.
     */
    public List<Constraint> proposeConstraintsFromModel(Solution solution)
    {
        String type = solution.getType();

        if ("framework".equalsIgnoreCase(type))
        {
            Framework framework = (Framework) solution;
            return proposeConstraintsFromModel(framework);
        }
        else if ("designpattern".equalsIgnoreCase(type))
        {
            DesignPattern designPattern = (DesignPattern) solution;
            return proposeConstraintsFromModel(designPattern);
        }
        else if ("architecturalpattern".equalsIgnoreCase(type))
        {
            ArchitecturalPattern architecturalPattern = (ArchitecturalPattern) solution;
            return proposeConstraintsFromModel(architecturalPattern);
        }
        else if ("cots".equalsIgnoreCase(type))
        {
            COTS cots = (COTS) solution;
            return proposeConstraintsFromModel(cots);
        }
        else if ("refactoring".equalsIgnoreCase(type))
        {
            Refactoring refactoring = (Refactoring) solution;
            return proposeConstraintsFromModel(refactoring);
        }
        else
        {
            return new ArrayList<Constraint>();
        }
    }

    /**
     * This methods gives potential constraints for a Framework based of its
     * model values.
     * 
     * @param framework for which Constraints should be proposed.
     * @return a list of potential constraints.
     */
    public List<Constraint> proposeConstraintsFromModel(Framework framework)
    {
        List<Constraint> candidates = new ArrayList<Constraint>();
        // Find Constraint for category
        Constraint category = findStringConstraint("COTSCategory", framework.getFrameworkCategory().getName());
        if (category != null)
        {
            candidates.add(category);
        }
        // Find Constraint for ProgrammingLanguage
        Constraint programmingLanguage = findStringConstraint("ProgrammingLanguage", framework.getProgrammingLanguage());
        if (programmingLanguage != null)
        {
            candidates.add(programmingLanguage);
        }
        // Find Constraint for OperatingSystem
        Constraint operatingSystem = findStringConstraint("OperatingSystem", framework.getOperatingSystem());
        if (operatingSystem != null)
        {
            candidates.add(operatingSystem);
        }
        // Find Constraint for DevelopmentStatus
        Constraint developmentStatus = findStringConstraint("DevelopmentStatus", framework.getDevelopmentStatus());
        if (developmentStatus != null)
        {
            candidates.add(developmentStatus);
        }
        // Find Constraint for Developer
        Constraint developer = findStringConstraint("Developer", framework.getDeveloper());
        if (developer != null)
        {
            candidates.add(developer);
        }
        // Find Constraint for Support
        Constraint support = findIntegerConstraint("Support", Integer.valueOf(framework.getSupport()));
        if (support != null)
        {
            candidates.add(support);
        }
        // Find Constraint for Documentation
        Constraint documentation = findIntegerConstraint("Documentation", Integer.valueOf(framework.getDocumentation()));
        if (documentation != null)
        {
            candidates.add(documentation);
        }
        // Find Constraint for Community
        Constraint community = findStringConstraint("Community", framework.getCommunity());
        if (community != null)
        {
            candidates.add(community);
        }
        // Find Constraint for Size
        Constraint size = findIntegerConstraint("Size", framework.getSize());
        if (size != null)
        {
            candidates.add(size);
        }
        return candidates;
    }

    /**
     * This methods gives potential constraints for a COTS based of its model
     * values.
     * 
     * @param cots for which Constraints should be proposed.
     * @return a list of potential constraints.
     */
    public List<Constraint> proposeConstraintsFromModel(COTS cots)
    {
        List<Constraint> candidates = new ArrayList<Constraint>();
        // Find Constraint for category
        Constraint category = 
        		findStringConstraint("COTSCategory", cots.getCotsCategory().getName());
        if (category != null)
        {
            candidates.add(category);
        }
        // Find Constraint for ProgrammingLanguage
        Constraint programmingLanguage = findStringConstraint("ProgrammingLanguage", cots.getProgrammingLanguage());
        if (programmingLanguage != null)
        {
            candidates.add(programmingLanguage);
        }
        // Find Constraint for OperatingSystem
        Constraint operatingSystem = findStringConstraint("OperatingSystem", cots.getOperatingSystem());
        if (operatingSystem != null)
        {
            candidates.add(operatingSystem);
        }
        // Find Constraint for DevelopmentStatus
        Constraint developmentStatus = findStringConstraint("DevelopmentStatus", cots.getDevelopmentStatus());
        if (developmentStatus != null)
        {
            candidates.add(developmentStatus);
        }
        // Find Constraint for Developer
        Constraint developer = findStringConstraint("Developer", cots.getDeveloper());
        if (developer != null)
        {
            candidates.add(developer);
        }
        // Find Constraint for Support
        Constraint support = findIntegerConstraint("Support", Integer.valueOf(cots.getSupport()));
        if (support != null)
        {
            candidates.add(support);
        }
        // Find Constraint for Documentation
        Constraint documentation = findIntegerConstraint("Documentation", Integer.valueOf(cots.getDocumentation()));
        if (documentation != null)
        {
            candidates.add(documentation);
        }
        // Find Constraint for Community
        Constraint community = findStringConstraint("Community", cots.getCommunity());
        if (community != null)
        {
            candidates.add(community);
        }
        // Find Constraint for Testing
        Constraint testing = findStringConstraint("Testing", cots.getTesting());
        if (testing != null)
        {
            candidates.add(testing);
        }
        // Find Constraint for Size
        Constraint size = findIntegerConstraint("Size", cots.getSize());
        if (size != null)
        {
            candidates.add(size);
        }
        return candidates;
    }

    /**
     * This methods gives potential constraints for a Refactoring based of its
     * model values.
     * 
     * @param refactoring for which Constraints should be proposed.
     * @return a list of potential constraints.
     */
    public List<Constraint> proposeConstraintsFromModel(Refactoring refactoring)
    {
        List<Constraint> candidates = new ArrayList<Constraint>();
        // Find Constraint for category
        Constraint category = findStringConstraint("RefactoringCategory", refactoring.getRefactoringCategory()
                .getName());
        if (category != null)
        {
            candidates.add(category);
        }
        // Find Constraint for ProgrammingLanguage
        Constraint badSmell = findStringConstraint("BadSmell", refactoring.getBadSmell());
        if (badSmell != null)
        {
            candidates.add(badSmell);
        }
        // Return all found constraints.
        return candidates;
    }

    /**
     * This methods gives potential constraints for a DesignPattern based of its
     * model values.
     * 
     * @param designPattern for which Constraints should be proposed.
     * @return a list of potential constraints.
     */
    public List<Constraint> proposeConstraintsFromModel(DesignPattern designPattern)
    {
        List<Constraint> candidates = new ArrayList<Constraint>();
        // Find Constraint for category
        Constraint category = findStringConstraint("DesignPatternCategory", designPattern.getDesignPatternCategory()
                .getName());
        if (category != null)
        {
            candidates.add(category);
        }
        // Return all found constraints.
        return candidates;
    }

    /**
     * This methods gives potential constraints for a ArchitecturalPattern based
     * of its model values.
     * 
     * @param architecturalPattern for which Constraints should be proposed.
     * @return a list of potential constraints.
     */
    public List<Constraint> proposeConstraintsFromModel(ArchitecturalPattern architecturalPattern)
    {
        List<Constraint> candidates = new ArrayList<Constraint>();
        // Find Constraint for category
        Constraint category = findStringConstraint("ArchitecturalPatternCategory", architecturalPattern
                .getArchitecturalPatternCategory().getName());
        if (category != null)
        {
            candidates.add(category);
        }
        // Return all found constraints.
        return candidates;
    }

    /**
     * This methods finds a potential constraint for a field with a string
     * value.
     * 
     * @param fieldName for which the TechnicalTerm should be found.
     * @param fieldValue for which the StringValue should be found.
     * @return Constraint with the right TechnicalTerm and
     *         StringValue(ConstraintElement)
     */
    private Constraint findStringConstraint(String fieldName, String fieldValue)
    {
        TechnicalTerm technicalTerm = findTechnicalTerm(fieldName);
        if (technicalTerm != null)
        {
            StringValue stringValue = findStringValue(fieldValue, technicalTerm.getId());
            if (stringValue != null)
            {
                Constraint constraint = new Constraint();
                constraint.setTechnicalTerm(technicalTerm);
                ConstraintElement constraintElement = new ConstraintElement();
                constraintElement.setStringValue(stringValue);
                constraint.addElement(constraintElement);
                return constraint;
            }
        }
        return null;
    }

    /**
     * This methods finds a potential constraints for a field with an integer
     * value.
     * 
     * @param fieldName for which the TechnicalTerm should be found.
     * @param fieldValue for which the StringValue should be found.
     * @return Constraint with the right TechnicalTerm and
     *         StringValue(ConstraintElement)
     */
    private Constraint findIntegerConstraint(String fieldName, Integer fieldValue)
    {
        TechnicalTerm technicalTerm = findTechnicalTerm(fieldName);
        if (technicalTerm != null)
        {
            Constraint constraint = new Constraint();
            constraint.setTechnicalTerm(technicalTerm);
            ConstraintElement constraintElement = new ConstraintElement();
            constraintElement.setIntValue(fieldValue);
            constraint.addElement(constraintElement);
            return constraint;
        }
        return null;
    }

    /**
     * This method returns a TechnicalTerm with the smallest LevenshteinDistance
     * for the fieldName.
     * 
     * @param fieldName for which a TechnicalTerm should be found.
     * @return null or the most fitting TechnicalTerm.
     */
    public TechnicalTerm findTechnicalTerm(String fieldName)
    {
        Integer minElement = 0;
        Integer distance = 0;
        Integer minDistance = Integer.MAX_VALUE;
        int i = 0;
        String normalizedFieldName = StringUtils.deleteWhitespace(fieldName.toLowerCase());
        // If the fieldName is empty no reasonable matches can be found
        if (normalizedFieldName.length() == 0)
        {
            return null;
        }
        List<TechnicalTerm> technicalTerms = technicalTermDAO.findAll();
        // Iterates through all TechnicalTerms and finds the one with the
        // smallest LevenshteinDistance.
        for (TechnicalTerm technicalTerm : technicalTerms)
        {
            String normalizedIdentifier = StringUtils.deleteWhitespace(technicalTerm.getIdentifier().toLowerCase());
            distance = StringUtils.getLevenshteinDistance(normalizedFieldName, normalizedIdentifier);
            if (distance < minDistance)
            {
                minDistance = distance;
                minElement = i;
            }
            i++;
        }
        // If the best match is above the threshold in difference null is
        // returned
        if ((double) minDistance / (double) normalizedFieldName.length() > differenceThreshold)
        {
            return null;
        }
        return technicalTerms.get(minElement);
    }

    /**
     * This method returns a StringValue with the smallest LevenshteinDistance
     * for the fieldValue.
     * 
     * @param technicalTermId of the TechnicalTerm StringValues should be found.
     * @param fieldValue for which a StringValue should be found.
     * @return null or the most fitting StringValue.
     */
    public StringValue findStringValue(String fieldValue, Long technicalTermId)
    {
        Integer minElement = 0;
        Integer distance = 0;
        Integer minDistance = Integer.MAX_VALUE;
        int i = 0;
        String normalizedFieldValue = StringUtils.deleteWhitespace(fieldValue.toLowerCase());
        // If the fieldValue is empty no reasonable matches can be found
        if (normalizedFieldValue.length() == 0)
        {
            return null;
        }
        List<StringValue> stringValues = stringValueDAO.findByTechnicalTermId(technicalTermId);
        // Iterates through all stringValues and find the one with the
        // smallest LevenshteinDistance.
        for (StringValue stringValue : stringValues)
        {
            String normalizedValue = StringUtils.deleteWhitespace(stringValue.getStringValue().toLowerCase());
            distance = StringUtils.getLevenshteinDistance(normalizedFieldValue, normalizedValue);
            if (distance < minDistance)
            {
                minDistance = distance;
                minElement = i;
            }
            i++;
        }
        // If the best match is above the threshold in difference null is
        // returned
        if ((double) minDistance / (double) normalizedFieldValue.length() > differenceThreshold)
        {
            return null;
        }
        return stringValues.get(minElement);
    }
}