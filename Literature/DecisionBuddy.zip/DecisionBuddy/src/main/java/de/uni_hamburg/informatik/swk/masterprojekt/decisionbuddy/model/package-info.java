/**
 * This package contains the Model of the web application.
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;