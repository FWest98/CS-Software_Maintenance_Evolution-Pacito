package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ConstraintDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ConstraintElementDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ConstraintNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ConstraintPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Service class for managing constraints.
 * 
 * @author Lucas
 *
 */
@Service
@Transactional
public class ConstraintServiceImpl implements ConstraintService
{

    @Autowired
    private ConstraintDAO constraintDAO;

    @Autowired
    private ConstraintElementDAO constraintElementDAO;

    @Autowired
    private IssueService issueService;

    @Autowired
    private SolutionService solutionService;

//    /**
//     * Adds a Constraint to the database.
//     * 
//     * @param constraint The Constraint to be persisted.
//     * 
//     * @return the saved constraint
//     * @throws ConstraintPersistenceException Exception if Constraint could not
//     *             be persisted.
//     */
//    private Constraint saveConstraint(Constraint constraint) throws ConstraintPersistenceException
//    {
//        Constraint savedConstraint;
//        savedConstraint = constraintDAO.saveAndFlush(constraint);
//        if (savedConstraint == null)
//        {
//            throw new ConstraintPersistenceException();
//        }
//        return savedConstraint;
//    }

    /**
     * Find a Constraint by a given id.
     * 
     * @param id The id of the desired Constraint.
     * 
     * @return The matching Constraint.
     * 
     * @throws ConstraintNotFoundException Exception if Constraint is not found.
     */
    @Override
    public Constraint getConstraintById(long id) throws ConstraintNotFoundException
    {
        Constraint constraint = constraintDAO.findOne(id);

        if (constraint == null)
        {
            throw new ConstraintNotFoundException();
        }

        return constraint;
    }

    /**
     * Delete a Constraint with the given id.
     * 
     * @param id The id of the constraint to be deleted
     * 
     * @throws ConstraintNotFoundException Exception if Constraint is not found.
     */
    @Override
    public void deleteConstraint(long id) throws ConstraintNotFoundException
    {
        try
        {
            constraintDAO.delete(id);
        }
        catch (DataAccessException e)
        {
            throw new ConstraintNotFoundException();
        }
    }

    /**
     * Delete a ConstraintElement with the given id.
     * 
     * @param id The id of the constraintelement to be deleted
     * 
     */
    @Override
    public void deleteConstraintElement(long id)
    {
        constraintElementDAO.delete(id);
    }

    /**
     * Assigns a Constraintlist to an Issue and adds it to the database.
     * 
     * @param constraintlist the constraintlist to be added.
     * @param issue the issue to which the Constraints should be added.
     * 
     * @throws ConstraintPersistenceException Exception if Constraint could not
     *             be persisted.
     * @throws IssuePersistenceException Exception if Issue could not be
     *             persisted.
     * @throws IssueNotFoundException Exception if the Issue is not found.
     */
    @Override
    public void assignToIssueAndSave(List<Constraint> constraintlist, Issue issue)
            throws ConstraintPersistenceException, IssuePersistenceException, IssueNotFoundException,
            CommentPersistenceException
    {

        // iterate through constraints
        for (Constraint constraint : constraintlist)
        {
            // assign constraint to issue
            issue.addConstraint(constraint);
        }

        // save issue and all attached constraints
        issueService.saveIssue(issue);
    }

    /**
     * Assigns a Constraintlist to a Solution and adds it to the database.
     * 
     * @param constraintlist the constraintlist to be added.
     * @param solution the Solution to which the Constraintlist should be added.
     * 
     * @throws ConstraintPersistenceException Exception if Constraint could not
     *             be persisted.
     * @throws SolutionPersistenceException Exception if Solution could not be
     *             persisted.
     * @throws SolutionNotFoundException Exception if the Solution is not found.
     */
    @Override
    public void assignToSolutionAndSave(List<Constraint> constraintlist, Solution solution)
            throws ConstraintPersistenceException, SolutionPersistenceException, SolutionNotFoundException
    {
        // iterate through constraints
        for (Constraint constraint : constraintlist)
        {
            // assign constraint to solution
            solution.addConstraint(constraint);
        }

        // save solution and all attached constraints
        solutionService.saveSolution(solution);
    }

    /**
     * Get a list of constraints that belong to the given Issue.
     * 
     * @param issueId The id for the Issue to get the constraints for.
     * 
     * @return List of all constraints that belong to issue.
     * 
     * @throws IssueNotFoundException Exception if the Issue is not found.
     */
    @Override
    public List<Constraint> getConstraintsForIssue(long issueId) throws IssueNotFoundException
    {
        Issue issue = issueService.getIssueById(issueId);

        return issue.getConstraints();
    }

    /**
     * Get a list of constraints that belong to the given Solution.
     * 
     * @param solutionId The id of the Solution to get the constraints for.
     * 
     * @return List of all constraints that belong to solution.
     * 
     * @throws SolutionNotFoundException Exception if the solution is not found.
     */
    @Override
    public List<Constraint> getConstraintsForSolution(long solutionId) throws SolutionNotFoundException
    {
        Solution solution = solutionService.getSolutionById(solutionId);

        return solution.getConstraints();
    }

    /**
     * Get a list of constraints, given a Filter and a Sorter.
     * 
     * @see Filter
     * @see Comparator
     * 
     * @param filter a Filter object to reduce the result set
     * @param sorter a Sorter object to arrange the result items by criteria
     * 
     * @return List of constraints
     */
    @Override
    public List<Constraint> getConstraintsByCriteria(Filter<Constraint> filter, Comparator<Constraint> sorter)
    {
        List<Constraint> catalog = constraintDAO.findAll();
        List<Constraint> result = new ArrayList<Constraint>();

        if (filter != null)
        {
            for (Constraint element : catalog)
            {
                if (filter.isInResult(element))
                {
                    result.add(element);
                }
            }
        }
        else
        {
            result = catalog;
        }

        if (sorter != null)
        {
            Collections.sort(result, sorter);
        }

        return result;
    }
}