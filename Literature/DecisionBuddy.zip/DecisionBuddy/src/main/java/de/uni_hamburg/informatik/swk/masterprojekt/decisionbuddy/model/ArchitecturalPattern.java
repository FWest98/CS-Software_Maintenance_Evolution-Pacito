package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the ArchitecturalPattern table from the database.
 *
 * @author Tim
 *
 */
@Entity
@org.hibernate.annotations.Proxy(lazy = false)
@Table(name = "ArchitecturalPattern")
@PrimaryKeyJoinColumn(name = "SolutionID")
public class ArchitecturalPattern extends Solution
{

    /**
     * Constructor.
     */
    public ArchitecturalPattern()
    {
        this.setType("ArchitecturalPattern");
        ArchitecturalPatternCategory apc = new ArchitecturalPatternCategory();
        apc.setId(Long.valueOf("1"));
        this.setArchitecturalPatternCategory(apc);
    }

    @ManyToOne(targetEntity = ArchitecturalPatternCategory.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "ArchitecturalPatternCategoryID", referencedColumnName = "ID", nullable = false)
    private ArchitecturalPatternCategory architecturalPatternCategory;

    @Column(name = "AltName1", nullable = true, length = ColumnLength.SHORT)
    private String altName1;

    @Column(name = "AltName2", nullable = true, length = ColumnLength.SHORT)
    private String altName2;

    @Column(name = "Motivation", nullable = true, columnDefinition = "text")
    private String motivation;

    @Column(name = "Applicability", nullable = true, columnDefinition = "text")
    private String applicability;

    @Column(name = "Structure", columnDefinition = "blob", nullable = true)
    private java.sql.Blob structure;

    @Column(name = "Participants", nullable = true, columnDefinition = "text")
    private String participants;

    @Column(name = "Collaboration", nullable = true, columnDefinition = "text")
    private String collaboration;

    @Column(name = "Consequences", nullable = true, columnDefinition = "text")
    private String consequences;

    @Column(name = "Usance", nullable = true, columnDefinition = "text")
    private String usance;

    @Column(name = "KnownUses", nullable = true, columnDefinition = "text")
    private String knownUses;

    @Column(name = "RelatedPatterns", nullable = true, columnDefinition = "text")
    private String relatedPatterns;

    public void setAltName1(String value)
    {
        this.altName1 = value;
    }

    public String getAltName1()
    {
        return altName1;
    }

    public void setAltName2(String value)
    {
        this.altName2 = value;
    }

    public String getAltName2()
    {
        return altName2;
    }

    public void setMotivation(String value)
    {
        this.motivation = value;
    }

    public String getMotivation()
    {
        return motivation;
    }

    public void setApplicability(String value)
    {
        this.applicability = value;
    }

    public String getApplicability()
    {
        return applicability;
    }

    public void setStructure(java.sql.Blob value)
    {
        this.structure = value;
    }

    public java.sql.Blob getStructure()
    {
        return structure;
    }

    public void setParticipants(String value)
    {
        this.participants = value;
    }

    public String getParticipants()
    {
        return participants;
    }

    public void setCollaboration(String value)
    {
        this.collaboration = value;
    }

    public String getCollaboration()
    {
        return collaboration;
    }

    public void setConsequences(String value)
    {
        this.consequences = value;
    }

    public String getConsequences()
    {
        return consequences;
    }

    public void setUsance(String value)
    {
        this.usance = value;
    }

    public String getUsance()
    {
        return usance;
    }

    public void setKnownUses(String value)
    {
        this.knownUses = value;
    }

    public String getKnownUses()
    {
        return knownUses;
    }

    public void setRelatedPatterns(String value)
    {
        this.relatedPatterns = value;
    }

    public String getRelatedPatterns()
    {
        return relatedPatterns;
    }

    public void setArchitecturalPatternCategory(ArchitecturalPatternCategory value)
    {
        this.architecturalPatternCategory = value;
    }

    public ArchitecturalPatternCategory getArchitecturalPatternCategory()
    {
        return architecturalPatternCategory;
    }

    @Override
    public int hashCode()
    {
        int result = super.hashCode();
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        ArchitecturalPattern other = (ArchitecturalPattern) obj;
        return other.getId().equals(this.getId());
    }
}