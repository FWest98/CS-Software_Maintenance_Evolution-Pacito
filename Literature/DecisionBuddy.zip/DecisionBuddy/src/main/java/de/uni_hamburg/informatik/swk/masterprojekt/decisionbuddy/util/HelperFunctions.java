package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.Breadcrumb;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.BreadcrumbManager;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.MenuItem;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.MenuManager;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.UserEditable;

/**
 * General purpose util class to provide common functionality.
 * 
 * @author schaak, Tim
 *
 */
@Component
public class HelperFunctions
{
    @Autowired
    private BreadcrumbManager breadcrumbManager;

    @Autowired
    private MenuManager menuManager;

    // @Autowired
    // private TechnicalTermService technicalTermService;
    //
    // @Autowired
    // private ConstraintService constraintService;

    /**
     * Public default constructor.
     */
    public HelperFunctions()
    {

    }

    /**
     * Helper method for displaying model data.
     * 
     * @param model the model to display data from
     * 
     * @return String containing all data values from model
     */
    @SuppressWarnings("rawtypes")
    public String showModelData(Model model)
    {
        String result = "";
        Map modelMap = model.asMap();

        for (Object modelKey : modelMap.keySet())
        {
            Object modelValue = modelMap.get(modelKey);
            result = result + modelKey + " : " + modelValue + ", ";
        }

        return result;
    }

    /**
     * Helper method for retrieving machine name as username. TO BE REMOVED WHEN
     * USERS ARE IMPLEMENTED
     * 
     * @return machine name to be used as username
     */
    public String createUsername()
    {
        // default
        String loggedInUser = "Anonymous";

        if (SecurityContextHolder.getContext().getAuthentication() != null)
        {
            if (SecurityContextHolder.getContext().getAuthentication().getName() != null)
            {
                loggedInUser = SecurityContextHolder.getContext().getAuthentication().getName();
            }
        }

        return loggedInUser;
    }

    /**
     * Helper method to add breadcrumbs to a given modelAndView object.
     * 
     * @param action the action to generate breadcrumbs for.
     * @param idList some actions (like edit) need additional ids.
     * @param modelAndView the modelAndView object you want to assign the
     *            breadcrumbs to.
     * 
     * @return the ModelAndView object with correctly assigned breadcrumbs.
     * 
     */
    public ModelAndView getBreadcrumbs(String action, ArrayList<String> idList, ModelAndView modelAndView)
    {
        ArrayList<Breadcrumb> breadcrumbs = new ArrayList<Breadcrumb>();
        breadcrumbs = breadcrumbManager.getBreadcrumbs(action, idList);
        return modelAndView.addObject("breadcrumbs", breadcrumbs);
    }

    /**
     * Overloaded method.
     * 
     * @see getBreadcrumbs(String action, String id, ModelAndView modelAndView)
     * 
     * @param action the action to generate breadcrumbs for.
     * @param modelAndView the modelAndView object you want to assign the
     *            breadcrumbs to.
     * 
     * @return the ModelAndView object with correctly assigned breadcrumbs.
     * 
     */
    public ModelAndView getBreadcrumbs(String action, ModelAndView modelAndView)
    {
        String id = "0";
        ArrayList<String> list = new ArrayList<String>();
        list.add(id);
        return getBreadcrumbs(action, list, modelAndView);
    }

    /**
     * Helper method to add a menu to a given modelAndView object.
     * 
     * @param action the action to generate a menu for.
     * @param idList some actions (like edit) need additional ids.
     * @param modelAndView the modelAndView object you want to assign the menu
     *            to.
     * 
     * @return the ModelAndView object with correctly assigned menu.
     * 
     */
    public ModelAndView getMenu(String action, ArrayList<String> idList, ModelAndView modelAndView)
    {
        ArrayList<MenuItem> menu = new ArrayList<MenuItem>();
        menu = menuManager.getMenu(action, idList);
        return modelAndView.addObject("menu", menu);
    }

    /**
     * Overloaded method.
     * 
     * @see getMenu(String action, String id, ModelAndView modelAndView)
     * 
     * @param action the action to generate a menu for.
     * @param modelAndView the modelAndView object you want to assign the menu
     *            to.
     * 
     * @return the ModelAndView object with correctly assigned breadcrumbs.
     * 
     */
    public ModelAndView getMenu(String action, ModelAndView modelAndView)
    {
        String id = "0";
        ArrayList<String> list = new ArrayList<String>();
        list.add(id);

        return getMenu(action, list, modelAndView);
    }

    /**
     * Finalizing user editables for saving.
     * 
     * @param object the object to be finalized
     * 
     * @return fully populated object ready to be saved
     */
    public UserEditable finalizeUserEditable(UserEditable object)
    {
        Date date = new Date();
        String user = createUsername();

        // if object is newly created, set creator and creationdate
        if (object.getId() == null)
        {
            object.setCreator(user);
            object.setCreationDate(date);
        }

        object.setLastModifier(user);
        object.setModificationDate(date);

        // in case of issue, also finalize solutioncandidates
        if (object instanceof Issue)
        {
            Issue issue = (Issue) object;
            for (SolutionCandidate candidate : issue.getDecision().getSolutionCandidates())
            {
                finalizeUserEditable(candidate);
            }
        }
        return object;
    }

    /**
     * Skips all error codes with indices.
     * 
     * @param codes the error codes with possible indices.
     * @return the first error code without an index.
     */
    public String skipIndexedCodes(String[] codes)
    {
        String code = "";
        for (int i = 0; i < codes.length; i++)
        {
            code = codes[i];
            if (!code.contains("["))
            {
                break;
            }
        }
        return code;
    }
}