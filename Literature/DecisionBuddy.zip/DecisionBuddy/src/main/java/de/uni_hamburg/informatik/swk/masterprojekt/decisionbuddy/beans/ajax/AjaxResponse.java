package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax;

import java.io.Serializable;

/**
 * An instance of this class represents a (neutral) AJAX response. Serves as a
 * wrapper class for AjaxSuccess and AjaxFailure
 *
 * @author schaak
 * 
 */
public abstract class AjaxResponse implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String type;

    /**
     * Constructor to create an AjaxResponse object.
     * 
     */
    public AjaxResponse()
    {

    }

    public String getType()
    {
        return this.type;
    }

    public void setType(String type)
    {
        this.type = type;
    }
}