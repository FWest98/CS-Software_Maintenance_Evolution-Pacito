package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ConstraintElement;

/**
 * A DAO class for ConstraintElement.
 * 
 * @author Tim
 *
 */
public interface ConstraintElementDAO extends JpaRepository<ConstraintElement, Long>
{
    /**
     * Find all elements belonging to a constraint.
     * 
     * @param constraintId the constraint for which you want to find the
     *            elements
     * @return all elements belonging to that constraint
     */
    List<ConstraintElement> findByConstraintId(Long constraintId);
}