package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;

/**
 * Property editor to convert an Id for a Project given as String to an actual
 * Project object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class ProjectEditor extends PropertyEditorSupport
{
    /**
     * Converts a Project id to a Project object.
     * 
     * @param id the id of the Project
     */
    @Override
    public void setAsText(String id)
    {
        Project project = new Project();
        project.setId(Long.valueOf(id));

        this.setValue(project);
    }

    /**
     * Converts a Project object to an the id.
     * 
     * @return id of the Project
     */
    @Override
    public String getAsText()
    {
        Project project = (Project) this.getValue();
        String parsedId = String.valueOf(project.getId());
        return parsedId;
    }
}