package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionCandidateDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionCandidatePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.SolutionCandidate;

/**
 * ServiceClass for managing SolutionCandidates.
 * 
 * @author wulbrandt
 *
 */
@Service
@Transactional
public class SolutionCandidateServiceImpl implements SolutionCandidateService
{
    @Autowired
    private SolutionCandidateDAO solutionCandidateDAO;

    // @Autowired
    // private IssueDAO issueDAO;

    // @Autowired
    // private SolutionDAO solutionDAO;

    @Override
    public SolutionCandidate saveCandidate(SolutionCandidate solutionCandidate)
            throws SolutionCandidatePersistenceException
    {
        SolutionCandidate savedCandidate = solutionCandidateDAO.saveAndFlush(solutionCandidate);

        if (savedCandidate == null)
        {
            throw new SolutionCandidatePersistenceException();
        }

        return savedCandidate;
    }
}
