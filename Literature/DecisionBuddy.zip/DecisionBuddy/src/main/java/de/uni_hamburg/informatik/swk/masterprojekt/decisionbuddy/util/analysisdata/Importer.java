package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultParsingException;

/**
 * Abstract Importer Class to support Usage of different Importers.
 */
public abstract class Importer
{
    /**
     * Imports an analysis file.
     * 
     * @param projectId
     * @param filePath
     * @return true if successfull, false if failed.
     * @throws AnalysisResultException
     */
    public abstract boolean importFile(Integer projectId, String filePath) throws AnalysisResultException;

    /**
     * Rudimentary checks if a file is valid
     * 
     * @param filePath
     * @return true if valid, false otherwise
     * @throws AnalysisResultException
     */
    public boolean validateFile(String filePath) throws AnalysisResultException
    {
        try (Scanner scanner = new Scanner(new File(filePath)))
        {
            for (String lineStart : getValidFileIndicators())
            {
                if (scanner.hasNextLine())
                {
                    String line = scanner.nextLine().trim();

                    if (!line.isEmpty() && !line.startsWith(lineStart))
                    {
                        throw new AnalysisResultParsingException();
                    }
                }
                else
                {
                    throw new AnalysisResultParsingException();
                }
            }
        }
        catch (FileNotFoundException e)
        {
            throw new AnalysisResultParsingException();
        }
        return true;
    }

    /**
     * Valid beginnings of lines for each Importer
     * 
     * @return array with beginning of lines indicating a valid file
     */
    protected abstract String[] getValidFileIndicators();
}
