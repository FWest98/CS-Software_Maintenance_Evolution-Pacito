package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if an comment could not be written to the
 * database.
 * 
 * @author schaak
 *
 */
public class CommentPersistenceException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public CommentPersistenceException()
    {
        setExceptionType("commentpersistence");
    }
}
