package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;

/**
 * Property editor to convert an Id for an Design pattern category given as
 * String to an actual DesignPattern object and vice versa.
 * 
 * @author Tim
 * 
 */
@Component
public class DesignPatternCategoryEditor extends PropertyEditorSupport
{
    /**
     * Converts an DesignPattern id to a DesignPatternCategory object.
     * 
     * @param id the id of the Design pattern category
     */
    @Override
    public void setAsText(String id)
    {
        DesignPatternCategory apc = new DesignPatternCategory();
        apc.setId(Long.valueOf(id));

        this.setValue(apc);
    }

    /**
     * Converts an DesignPatternCategory object to an the id.
     * 
     * @return id of the Design pattern Category
     */
    @Override
    public String getAsText()
    {
        DesignPatternCategory apc = (DesignPatternCategory) this.getValue();
        String parsedId = String.valueOf(apc.getId());
        return parsedId;
    }
}