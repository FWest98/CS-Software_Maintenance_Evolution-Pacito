package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Issue;

/**
 * Property editor to convert an Id for an Issue given as String to an actual
 * Issue object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class IssueEditor extends PropertyEditorSupport
{
    /**
     * Converts a Issue id to a Issue object.
     * 
     * @param id the id of the Issue
     */
    @Override
    public void setAsText(String id)
    {
        Issue issue = new Issue();
        issue.setId(Long.valueOf(id));

        this.setValue(issue);
    }

    /**
     * Converts a Issue object to an the id.
     * 
     * @return id of the Issue
     */
    @Override
    public String getAsText()
    {
        Issue issue = (Issue) this.getValue();
        String parsedId = String.valueOf(issue.getId());
        return parsedId;
    }
}