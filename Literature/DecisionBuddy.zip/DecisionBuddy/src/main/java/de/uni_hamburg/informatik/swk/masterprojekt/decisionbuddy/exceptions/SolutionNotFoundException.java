package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a solution is not found / does not exist
 * (anymore).
 * 
 * @author schaak
 *
 */
public class SolutionNotFoundException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public SolutionNotFoundException()
    {
        setExceptionType("solutionnotfound");
    }
}