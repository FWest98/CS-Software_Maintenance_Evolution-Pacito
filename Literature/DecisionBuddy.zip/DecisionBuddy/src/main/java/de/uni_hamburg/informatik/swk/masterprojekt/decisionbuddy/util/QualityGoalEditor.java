package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;

/**
 * Property editor to convert an Id for a QualityGoal given as String to an
 * actual QualityGoal object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class QualityGoalEditor extends PropertyEditorSupport
{
    /**
     * Converts a QualityGoal id to a Qualitygoal object.
     * 
     * @param id the id of the QualityGoal
     */
    @Override
    public void setAsText(String id)
    {

        QualityGoal qualityGoal = new QualityGoal();

        try
        {
            Long goalId = Long.valueOf(id);
            qualityGoal.setId(Long.valueOf(goalId));
        }
        catch (NumberFormatException nfe)
        {

        }

        this.setValue(qualityGoal);
    }

    /**
     * Converts a QualityGoal object to the id.
     * 
     * @return id of the QualityGoal
     */
    @Override
    public String getAsText()
    {
        if (this.getValue() != null)
        {
            QualityGoal qualityGoal = (QualityGoal) this.getValue();
            String parsedId = String.valueOf(qualityGoal.getId());
            return parsedId;
        }
        else
        {
            return "";
        }
    }
}