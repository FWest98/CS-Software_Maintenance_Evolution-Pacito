package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultParsingException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementDesignPatternNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementDesignPatternPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementDesignPatternService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.SolutionService;

/**
 * Importer for Pinot output files.
 * 
 * @author 1vietor
 *
 */
@Component
public class ImporterPinot extends Importer
{
    @Autowired
    private ProjectService projectService;

    @Autowired
    private PinotParserFactory pinotParserFactory;

    @Autowired
    private ElementDesignPatternService elementDesignPatternService;

    @Autowired
    private SolutionService solutionService;

    // @Autowired
    // private SessionFactory sessionFactory;

    @Override
    protected String[] getValidFileIndicators()
    {
        String[] lineBeginnings = { "--------- Original GoF Patterns", "--------- Original GoF Patterns",
                "--------- Original GoF Patterns" };
        return lineBeginnings;
    }

    /**
     * Ersetzt Slashes durch Punkte. <br>
     * Beispiel-Input:
     * /Mediathek_Vorlage_Blatt06/src/de/uni_hamburg/package/KlassenName.java <br>
     * Beispiel-Output: de.uni_hamburg.package
     * 
     * @param path
     * @return [0] = path, [1] = fileName
     */
    private String[] changePathToPackageStrucutre(String path)
    {
        String fileName = path.substring(path.lastIndexOf("/") + 1);

        if(path.contains("src/main/java/")) {
            // von /src/main/java bis Ende, wobei Dateiname abgeschnitten wird
            path = path.substring(path.indexOf("/src/main/java/") + 15, path.lastIndexOf('/'));
        }
        else {
            // von /src/ bis Ende, wobei Dateiname abgeschnitten wird
            path = path.substring(path.indexOf("/src/") + 5, path.lastIndexOf('/'));
        }
        return new String[] { path.replace('/', '.'), fileName };
    }

    @Override
    public boolean importFile(Integer projectId, String filePath) throws AnalysisResultException
    {
        long start = System.currentTimeMillis();

        // ggf. alte Daten zunächst Löschen
        try
        {
            elementDesignPatternService.deleteElementDesignPatternsByProjectId(projectId);
        }
        catch (ElementDesignPatternNotFoundException e)
        {
        }

        Pattern patternNewLine = Pattern.compile("[\\r\\n]+");
        Pattern patternDesignPattern = Pattern.compile("^([\\w ]+?)(?: [pP]attern)?(?: [fF]ound)?\\.?$");
        Pattern patternDesignPatternBridge = Pattern.compile("^[\\w:]+ is the pivot point\\.$");

        try (Scanner scanner = new Scanner(new File(filePath)))
        {
            Project project = projectService.getProjectById(projectId);

            scanner.useDelimiter("(\\r?\\n){2,}");
            while (scanner.hasNext())
            {
                String designPatternGroup = scanner.next();

                String[] designPatternLines = patternNewLine.split(designPatternGroup);

                if (designPatternLines.length > 0)
                {
                    Matcher matcher = patternDesignPattern.matcher(designPatternLines[0]);
                    Matcher matcherBridgePattern = patternDesignPatternBridge.matcher(designPatternLines[0]);
                    if (matcher.find())
                    {
                        String designPatternName = matcher.group(1);
                        PinotParser pinotParser = pinotParserFactory.getParser(designPatternName);

                        pinotParser.parse(project, designPatternName, designPatternLines);
                    }
                    else if (matcherBridgePattern.find())
                    {
                        Matcher matcherPattern = patternDesignPattern.matcher(designPatternLines[1]);
                        if (matcherPattern.find())
                        {
                            String designPatternName = matcherPattern.group(1);
                            PinotParser pinotParser = pinotParserFactory.getParser(designPatternName);

                            pinotParser.parse(project, designPatternName, designPatternLines);
                        }
                    }
                }
            }

        }
        catch (IOException e)
        {
            throw new AnalysisResultParsingException();
        }
        catch (ProjectNotFoundException e)
        {
            throw new AnalysisResultPersistenceException();
        }

        long time = System.currentTimeMillis() - start;
        System.out.println("PinotImporter: " + time + "ms (" + (time / 1000) + "s)");
        return true;
    }

    @Component
    private class PinotParserFactory
    {
        @Autowired
        private PinotParserDefault pinotParserDefault;

        @Autowired
        private PinotParserMediator pinotParserMediator;

        /**
         * No-argument constructor.
         */
        @Autowired
        PinotParserFactory()
        {
        }

        /**
         * Returns parser based on the received String Parameter.
         *
         * @param pattern
         * @return parser based on the received pattern
         */
        public PinotParser getParser(String pattern)
        {
            PinotParser result = null;

            switch (pattern)
            {
            // case "Strategy":
            // result = pinotParserStrategy;
            // break;
                case "Mediator":
                    result = pinotParserMediator;
                    break;
                default:
                    result = pinotParserDefault;
            }
            return result;
        }
    }

    /**
     * Abstract Pinot Parser Class to support usage of different Parsers for
     * each design pattern.
     */
    private abstract class PinotParser
    {
        public abstract void parse(Project project, String patternName, String[] details)
                throws AnalysisResultException;

        /**
         * Save pattern details on package and file level
         * 
         * @param project
         * @param patternName
         * @param roleMap
         * @param fileMap
         * @throws AnalysisResultPersistenceException
         */
        protected void savePatterns(Project project, String patternName, Map<String, String> roleMap,
                Map<String, String> fileMap) throws AnalysisResultPersistenceException
        {
            // save pattern information on file level
            for (Entry<String, String> entry : roleMap.entrySet())
            {
                String fileName = entry.getKey();
                String role = entry.getValue();
                try
                {
                    if (fileMap.containsKey(fileName))
                    {
                        String fullPath = fileMap.get(fileName) + "." + fileName;

                        Solution solution = solutionService.getSolutionByName(patternName);
                        ElementDesignPattern elementDesignPattern = new ElementDesignPattern();
                        elementDesignPattern.setProject(project);
                        elementDesignPattern.setClassPath(fullPath);
                        elementDesignPattern.setRole(role);
                        elementDesignPattern.setSolution(solution);
                        elementDesignPattern.setType(ElementType.File);
                        elementDesignPatternService.saveElementDesignPattern(elementDesignPattern);
                    }
                }
                catch (SolutionNotFoundException e)
                {
                }
                catch (ElementDesignPatternPersistenceException e)
                {
                    throw new AnalysisResultPersistenceException();
                }
            }

            // save pattern information on package level
            for (Entry<String, String> entry : fileMap.entrySet())
            {
                String patternClassPath = entry.getValue();
                try
                {
                    Solution solution = solutionService.getSolutionByName(patternName);
                    ElementDesignPattern elementDesignPattern = new ElementDesignPattern();
                    elementDesignPattern.setProject(project);
                    elementDesignPattern.setClassPath(patternClassPath);
                    elementDesignPattern.setRole(null);
                    elementDesignPattern.setSolution(solution);
                    elementDesignPattern.setType(ElementType.Package);
                    elementDesignPatternService.saveElementDesignPattern(elementDesignPattern);
                }
                catch (SolutionNotFoundException e)
                {
                }
                catch (ElementDesignPatternPersistenceException e)
                {
                    throw new AnalysisResultPersistenceException();
                }
            }
        }
    }

    @Component
    private class PinotParserDefault extends PinotParser
    {
        /**
         * No-argument constructor.
         */
        @Autowired
        PinotParserDefault()
        {
        }

        @Override
        public void parse(Project project, String patternName, String[] patternDetails) throws AnalysisResultException
        {
            Pattern patternFileLocation = Pattern
                    .compile("^(?:File ?[lL]ocation: |               )([\\w/\\.-]+)\\.java,?$");

            Pattern patternRole = Pattern.compile("^([\\w]+) is (?:the|an?) ([\\w ]+)\\.?$");

            Map<String, String> roleMap = new HashMap<String, String>();
            Map<String, String> fileMap = new HashMap<String, String>();

            for (String designPatternLine : patternDetails)
            {
                Matcher roleMatcher = patternRole.matcher(designPatternLine);
                Matcher lineMatcher = patternFileLocation.matcher(designPatternLine);

                if (roleMatcher.find())
                {
                    String fileName = roleMatcher.group(1);
                    String role = roleMatcher.group(2);

                    roleMap.put(fileName, role);
                }
                else if (lineMatcher.find()) // find file paths
                {
                    String[] path = changePathToPackageStrucutre(lineMatcher.group(1));
                    String classPath = path[0];
                    String fileName = path[1];

                    fileMap.put(fileName, classPath);
                }
            }

            savePatterns(project, patternName, roleMap, fileMap);
        }

    }

    @Component
    private class PinotParserMediator extends PinotParser
    {
        /**
         * No-argument constructor.
         */
        @Autowired
        PinotParserMediator()
        {
        }

        @Override
        public void parse(Project project, String patternName, String[] patternDetails) throws AnalysisResultException
        {
            Pattern patternFileLocation = Pattern
                    .compile("^(?:File ?[lL]ocation: |               )([\\w/\\.-]+)\\.java,?$");

            Pattern patternRole = Pattern.compile("^([\\w]+) is (?:the|an?) ([\\w ]+)\\.?$");
            Pattern patternRole2 = Pattern.compile("^Mediator: ([\\w]+)$");

            Map<String, String> roleMap = new HashMap<String, String>();
            Map<String, String> fileMap = new HashMap<String, String>();

            for (String designPatternLine : patternDetails)
            {
                Matcher roleMatcher = patternRole.matcher(designPatternLine);
                Matcher roleMatcher2 = patternRole2.matcher(designPatternLine);
                Matcher lineMatcher = patternFileLocation.matcher(designPatternLine);

                if (roleMatcher.find())
                {
                    String fileName = roleMatcher.group(1);
                    String role = roleMatcher.group(2);

                    roleMap.put(fileName, role);
                }
                else if (roleMatcher2.find())
                {
                    String fileName = roleMatcher2.group(1);
                    String role = "mediator class";

                    roleMap.put(fileName, role);
                }
                else if (lineMatcher.find()) // find file paths
                {
                    String[] path = changePathToPackageStrucutre(lineMatcher.group(1));
                    String classPath = path[0];
                    String fileName = path[1];

                    fileMap.put(fileName, classPath);
                }
            }

            savePatterns(project, patternName, roleMap, fileMap);
        }

    }

}
