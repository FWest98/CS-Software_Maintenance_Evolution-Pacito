package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.framework;

import java.util.List;

import javassist.NotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * Service wrapping access to frameworks found by decisionbuddy analyzer.
 * 
 * @author 1fechner
 */
public interface FrameworkComponentService
{
    /**
     * Returns a list of all frameworks for the element from the given project
     * with the given name.
     * 
     * @param projectId The project to be filtered by
     * @param classPath The classpath of the element to be filtered by
     * @return A List of entities from the table 'ElementFramework'
     * @throws NotFoundException If the project does not exist
     */
    List<ElementFramework> getFrameworksForElement(Long projectId, String classPath) throws NotFoundException;

    /**
     * 
     * @param projectId The project to be filtered by
     * @param type The type to be filtered by
     * @return A List of entities from the table 'ElementFramework'
     * @throws NotFoundException If the project or the type does not exist
     */
    List<ElementFramework> getFrameworksForProject(Long projectId, ElementType type) throws NotFoundException;
}
