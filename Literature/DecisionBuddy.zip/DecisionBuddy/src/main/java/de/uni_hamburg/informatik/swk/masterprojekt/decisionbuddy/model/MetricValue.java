package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * This Class represents the MetricValue table from the database.
 *
 * @author Burak
 *
 */

@Entity
@Table(name = "MetricValue")
public class MetricValue
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue
    private Long id;

    @ManyToOne(targetEntity = Metric.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "MetricID", referencedColumnName = "ID", nullable = false)
    private Metric metric;

    @ManyToOne(targetEntity = Element.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "ElementID", referencedColumnName = "ID", nullable = false)
    private Element element;

    @Column(name = "Value", nullable = false)
    private Float value;

    /**
     * Constructor without parameters.
     */
    public MetricValue()
    {

    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Element getElement()
    {
        return element;
    }

    public void setElement(Element element)
    {
        this.element = element;
    }

    public Metric getMetric()
    {
        return metric;
    }

    public void setMetric(Metric metric)
    {
        this.metric = metric;
    }

    public Float getValue()
    {
        return value;
    }

    public void setValue(Float value)
    {
        this.value = value;
    }

    @Override
    public String toString()
    {
        return "ID:" + id + "," + "Element:" + element + "," + "Metric:" + metric + "," + "Value:" + value;
    }

    @Override
    public int hashCode()
    {
        int result;
        if (getId() == null)
        {
            result = 0;
        }
        else
        {
            result = getId().hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        MetricValue other = (MetricValue) obj;
        if (other.getId() == null || this.getId() == null)
        {
            return false;
        }
        return other.getId().equals(this.getId());
    }

    /**
     * Returns whether this value exceeds the corresponding threshold.
     * 
     * @return
     */
    public String getThresholdStatus()
    {
        return (value < metric.getMinThreshold() || value > metric.getMaxThreshold()) ? "exceeded" : "ok";
    }

    /**
     * Returns a reason for why the value exceeded its threshold.
     * 
     * @return
     */
    public String getThresholdReason()
    {
        if (value < metric.getMinThreshold())
        {
            return "analysis.metrics.threshold.tolow";
        }
        else if (value > metric.getMaxThreshold())
        {
            return "analysis.metrics.threshold.tohigh";
        }
        else
        {
            return "analysis.metrics.threshold.ok";
        }
    }

    /**
     * DIRTY! Return the value that was exceeded 'cause spring's message
     * formatting is somewhat too stupid
     * 
     * @return
     */
    public float getThresholdExeeded()
    {
        if (value < metric.getMinThreshold())
        {
            return metric.getMinThreshold();
        }
        else if (value > metric.getMaxThreshold())
        {
            return metric.getMaxThreshold();
        }
        else
        {
            return 0;
        }
    }
}
