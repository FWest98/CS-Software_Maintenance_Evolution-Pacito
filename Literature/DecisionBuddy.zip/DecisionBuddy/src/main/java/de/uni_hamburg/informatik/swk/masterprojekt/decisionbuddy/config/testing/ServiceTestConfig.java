package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing;

import javax.persistence.EntityManagerFactory;

import org.hibernate.SessionFactory;
import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ArchitecturalPatternCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ArchitecturalPatternDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.AuthoritiesDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.COTSCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.COTSDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.CommentDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ConstraintDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ConstraintElementDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DbaCatalogDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DecisionDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.DesignPatternCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementDesignPatternDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementFrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementMetricDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.FrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.IssueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.MetricDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.MetricValueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ProjectDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.PropertyDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.QualityGoalDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RatingDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RefactoringCategoryDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.RefactoringDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionCandidateDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.StringValueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.TechnicalTermDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.UsersDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.WeightedQualityGoalDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementMetricService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.SolutionRater;

/**
 * Test configuration for Service tests.
 * 
 * @author Vlad
 *
 */
@Configuration
// Profile Name for service testing. !DIFFERENT! from controller testing
@Profile("ServiceTesting")
// Impl classes of the Servicer are found automatically by scanning the Service
// package
@ComponentScan({ "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation",
        "de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util" })
public class ServiceTestConfig
{
    /**
     * Mocking of a SolutionDAO.
     * 
     * @return mocked SolutionDAO
     */
    @Bean
    public SolutionDAO solutionDAO()
    {
        return Mockito.mock(SolutionDAO.class);
    }

    /**
     * Mocking of a RefactoringCategoryDAO.
     * 
     * @return mocked RefactoringCategoryDAO
     */
    @Bean
    public RefactoringCategoryDAO refactoringCategoryDAO()
    {
        return Mockito.mock(RefactoringCategoryDAO.class);
    }

    /**
     * Mocking of a RefactoringDAO.
     * 
     * @return mocked RefactoringDAO
     */
    @Bean
    public RefactoringDAO refactoringDAO()
    {
        return Mockito.mock(RefactoringDAO.class);
    }

    /**
     * Mocking of a COTSDAO.
     * 
     * @return mocked COTSDAO
     */
    @Bean
    public COTSDAO cotsDAO()
    {
        return Mockito.mock(COTSDAO.class);
    }

    /**
     * Mocking of a COTSCategoryDAO.
     * 
     * @return mocked COTSCategoryDAO
     */
    @Bean
    public COTSCategoryDAO cotsCategoryDAO()
    {
        return Mockito.mock(COTSCategoryDAO.class);
    }

    /**
     * Mocking of a FrameworkDAO.
     * 
     * @return mocked FrameworkDAO
     */
    @Bean
    public FrameworkDAO frameworkDAO()
    {
        return Mockito.mock(FrameworkDAO.class);
    }

    /**
     * Mocking of a FrameworkCategoryDAO.
     * 
     * @return mocked FrameworkCategoryDAO
     */
    @Bean
    public FrameworkCategoryDAO frameworkCategoryDAO()
    {
        return Mockito.mock(FrameworkCategoryDAO.class);
    }

    /**
     * Mocking of an ArchitecturalPatternDAO.
     * 
     * @return mocked ArchitecturalPatternDAO
     */
    @Bean
    public ArchitecturalPatternDAO architecturalPatternDAO()
    {
        return Mockito.mock(ArchitecturalPatternDAO.class);
    }

    /**
     * Mocking of an ArchitecturalPatternCategoryDAO.
     * 
     * @return mocked ArchitecturalPatternCategoryDAO
     */
    @Bean
    public ArchitecturalPatternCategoryDAO architecturalPatternCategoryDAO()
    {
        return Mockito.mock(ArchitecturalPatternCategoryDAO.class);
    }

    /**
     * Mocking of an DesignPatternCategoryDAO.
     * 
     * @return mocked DesignPatternCategoryDAO
     */
    @Bean
    public DesignPatternCategoryDAO designPatternCategoryDAO()
    {
        return Mockito.mock(DesignPatternCategoryDAO.class);
    }

    /**
     * Mocking of an IssueDAO.
     * 
     * @return mocked IssueDAO
     */
    @Bean
    public IssueDAO issueDAO()
    {
        return Mockito.mock(IssueDAO.class);
    }

    /**
     * Mocking of a ProjectDAO.
     * 
     * @return mocked ProjectDAO
     */
    @Bean
    public ProjectDAO projectDAO()
    {
        return Mockito.mock(ProjectDAO.class);
    }

    /**
     * Mocking of a ConstraintDAO.
     * 
     * @return mocked ConstraintDAO
     */
    @Bean
    public ConstraintDAO constraintDAO()
    {
        return Mockito.mock(ConstraintDAO.class);
    }

    /**
     * Mocking of a ConstraintElementDAO.
     * 
     * @return mocked ConstraintElementDAO
     */
    @Bean
    public ConstraintElementDAO constraintElementDAO()
    {
        return Mockito.mock(ConstraintElementDAO.class);
    }

    /**
     * Mocking of a SolutionCandidateDAO.
     * 
     * @return mocked SolutionCandidateDAO
     */
    @Bean
    public SolutionCandidateDAO solutionCandidateDAO()
    {
        return Mockito.mock(SolutionCandidateDAO.class);
    }

    /**
     * Mocking of a TechnicalTermDAO.
     * 
     * @return mocked TechnicalTermDAO
     */
    @Bean
    public TechnicalTermDAO technicalTermDAO()
    {
        return Mockito.mock(TechnicalTermDAO.class);
    }

    /**
     * Mocking of a StringValueDAO.
     * 
     * @return mocked StringValueDAO
     */
    @Bean
    public StringValueDAO stringValueDAO()
    {
        return Mockito.mock(StringValueDAO.class);
    }

    /**
     * Mocking of a UserDAO.
     * 
     * @return
     */
    @Bean
    public UsersDAO usersDAO()
    {
        return Mockito.mock(UsersDAO.class);
    }

    /**
     * Mocking of a AuthorityDAO.
     * 
     * @return
     */
    @Bean
    public AuthoritiesDAO authoritiesDAO()
    {
        return Mockito.mock(AuthoritiesDAO.class);
    }

    /**
     * Mocking of a QualityGoalDAO.
     * 
     * @return
     */
    @Bean
    public QualityGoalDAO qualityGoalDAO()
    {
        return Mockito.mock(QualityGoalDAO.class);
    }

    /**
     * Mocking of a RatingDAO.
     * 
     * @return mocked RatingDAO
     */
    @Bean
    public RatingDAO ratingDAO()
    {
        return Mockito.mock(RatingDAO.class);
    }

    /**
     * Mocking of a CommentDAO.
     * 
     * @return mocked CommentDAO
     */
    @Bean
    public CommentDAO commentDAO()
    {
        return Mockito.mock(CommentDAO.class);
    }

    /**
     * Mocking of a SolutionRater.
     * 
     * @return mocked SolutionRater
     */
    @Bean
    public SolutionRater solutionRater()
    {
        return Mockito.mock(SolutionRater.class);
    }

    /**
     * Mocking of a DecisionDAO.
     * 
     * @return mocked DecisionDAO
     */
    @Bean
    public DecisionDAO decisionDAO()
    {
        return Mockito.mock(DecisionDAO.class);
    }

    /**
     * Mocking of a PropertyDAO.
     * 
     * @return mocked PropertyDAO
     */
    @Bean
    public PropertyDAO propertyDAO()
    {
        return Mockito.mock(PropertyDAO.class);
    }

    /**
     * Mocking of a WeightedQualityGoalDAO.
     * 
     * @return mocked WeightedQualityGoalDAO
     */
    @Bean
    public WeightedQualityGoalDAO weightedQualityGoalDAO()
    {
        return Mockito.mock(WeightedQualityGoalDAO.class);
    }

    /**
     * Mocking of a EntityManagerFactory.
     * 
     * @return mocked EntityManagerFactory
     */
    @Bean
    public EntityManagerFactory entityManagerFactory()
    {
        return Mockito.mock(EntityManagerFactory.class);
    }

    /**
     * Mocking of a EntityManagerFactory.
     * 
     * @return mocked EntityManagerFactory
     */
    @Bean
    public SessionFactory sessionFactory()
    {
        return Mockito.mock(SessionFactory.class);
    }

    /**
     * Mocking of a DbaCatalogDAO.
     * 
     * @return mocked DbaCatalogDAO
     */
    @Bean
    public DbaCatalogDAO dbaCatalogDAO()
    {
        return Mockito.mock(DbaCatalogDAO.class);
    }

    /**
     * Mocking of a ElementDAO.
     * 
     * @return mocked ElementDAO
     */
    @Bean
    public ElementDAO elementDAO()
    {
        return Mockito.mock(ElementDAO.class);
    }

    /**
     * Mocking of a ElementMetricDAO.
     * 
     * @return mocked ElementMetricDAO
     */
    @Bean
    public ElementMetricDAO elementMetricDAO()
    {
        return Mockito.mock(ElementMetricDAO.class);
    }

    /**
     * Mocking of a MetricDAO.
     * 
     * @return mocked MetricDAO
     */
    @Bean
    public MetricDAO metricDAO()
    {
        return Mockito.mock(MetricDAO.class);
    }

    /**
     * Mocking of a MetricDAO.
     * 
     * @return mocked MetricDAO
     */
    @Bean
    public MetricValueDAO metricValueDAO()
    {
        return Mockito.mock(MetricValueDAO.class);
    }

    /**
     * Mocking of a ElementDesignPatternDAO.
     * 
     * @return mocked ElementDesignPatternDAO
     */
    @Bean
    public ElementDesignPatternDAO elementDesignPatternDAO()
    {
        return Mockito.mock(ElementDesignPatternDAO.class);
    }

    /**
     * Mocking of a ElementFrameworkDAO.
     * 
     * @return mocked ElementFrameworkDAO
     */
    @Bean
    public ElementFrameworkDAO elementFrameworkDAO()
    {
        return Mockito.mock(ElementFrameworkDAO.class);
    }

    /**
     * Mocking of a ElementMetricService.
     * 
     * @return mocked ElementMetricService
     */
    @Bean
    public ElementMetricService elementMetricService()
    {
        return Mockito.mock(ElementMetricService.class);
    }
}