package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.MetricDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

/**
 * Service class for managing metrics.
 * 
 * @author Burak
 * 
 */

@Service
@Transactional
public class MetricServiceImpl implements MetricService
{

    @Autowired
    private MetricDAO metricDAO;

    /**
     * Adds a new Metric to the database.
     * 
     * @param metric the metric to save
     * 
     * @return the saved metric object
     * 
     * @throws MetricPersistenceException Exception if Metric could not be
     *             persisted
     */
    @Override
    public Metric saveMetric(Metric metric) throws MetricPersistenceException
    {
        Metric savedMetric;
        savedMetric = metricDAO.saveAndFlush(metric);

        if (savedMetric == null)
        {
            throw new MetricPersistenceException();
        }

        return savedMetric;
    }

    /**
     * Finds a metric with the specified ID.
     * 
     * @param id ID of the Metric
     * 
     * @return Metric with the id.
     * 
     * @throws MetricNotFoundException Exception if Metric is not found
     */
    @Override
    public Metric getMetricById(long id) throws MetricNotFoundException
    {
        Metric metric = metricDAO.findOne(id);

        if (metric == null)
        {
            throw new MetricNotFoundException();
        }

        return metric;
    }

    /**
     * Find a metric by given metric nameLangFile.
     * 
     * @param metricName
     * @return metric corresponding to the name
     * @throws MetricNotFoundException
     */
    @Override
    public Metric getMetricByNameLangFile(String metricName) throws MetricNotFoundException
    {
        Metric metric = metricDAO.findByNameLangFile(metricName);

        if (metric == null)
        {
            throw new MetricNotFoundException();
        }

        return metric;
    }

    /**
     * Find a metric by given metric nameXml.
     * 
     * @param metricName
     * @return metric corresponding to the name
     * @throws MetricNotFoundException
     */
    @Override
    public Metric getMetricByNameXmlAndType(String metricName, MetricType metricType) throws MetricNotFoundException
    {
        Metric metric = metricDAO.findByNameXmlAndType(metricName, metricType);

        if (metric == null)
        {
            throw new MetricNotFoundException();
        }

        return metric;
    }

    /**
     * Deletes a metric with the specified ID.
     * 
     * @param id the id of the metric to be deleted
     * 
     * @throws MetricNotFoundException Exception if Metric is not found
     */
    @Override
    public void deleteMetric(int id) throws MetricNotFoundException
    {
        try
        {
            metricDAO.delete((long) id);
        }
        catch (DataAccessException e)
        {
            throw new MetricNotFoundException();
        }
    }

    /**
     * Returns all metrics that belong to a certain type.
     * 
     * @param type the type that we want
     * 
     * @return a List of all metrics.
     */
    @Override
    public List<Metric> getMetricsByType(MetricType type)
    {
        return metricDAO.findByType(type);
    }

    /**
     * Returns all metrics that belong to a certain subType.
     * 
     * @param subType the subType that we want
     * 
     * @return a List of all metrics.
     */
    @Override
    public List<Metric> getMetricsBySubType(MetricSubType subType)
    {
        return metricDAO.findBySubType(subType);
    }

    /**
     * Returns all metrics that belong to a certain type and subType.
     * 
     * @param subType the subType that we want
     * 
     * @param type the type that we want
     * 
     * @return a List of all metrics.
     */
    @Override
    public List<Metric> getMetricsByTypeAndSubType(MetricType type, MetricSubType subType)
    {
        return metricDAO.findByTypeAndSubType(type, subType);
    }

    /**
     * Returns all metrics.
     * 
     * @return a List of all metrics.
     */
    @Override
    public List<Metric> getMetricCatalog()
    {
        return metricDAO.findAll();
    }

}
