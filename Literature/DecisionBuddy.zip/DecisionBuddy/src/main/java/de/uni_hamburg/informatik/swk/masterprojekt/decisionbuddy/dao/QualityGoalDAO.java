package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;

/**
 * A DAO class for QualityGoal.
 * 
 * @author Tim
 *
 */
public interface QualityGoalDAO extends JpaRepository<QualityGoal, Long>
{

}
