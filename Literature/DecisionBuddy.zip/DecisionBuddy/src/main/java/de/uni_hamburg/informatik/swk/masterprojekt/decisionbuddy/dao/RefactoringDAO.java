package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;

/**
 * A DAO class for Refactoring.
 * 
 * @author Tim
 *
 */
public interface RefactoringDAO extends JpaRepository<Refactoring, Long>
{

}
