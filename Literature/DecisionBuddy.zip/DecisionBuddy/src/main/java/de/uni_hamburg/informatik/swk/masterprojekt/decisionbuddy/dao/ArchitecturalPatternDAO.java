package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern;

/**
 * A DAO class for Framework.
 * 
 * @author Tim
 *
 */
public interface ArchitecturalPatternDAO extends JpaRepository<ArchitecturalPattern, Long>
{

}
