package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;

/**
 * Property editor to convert an Id for a COTS category given as String to an
 * actual COTSCategory object and vice versa.
 * 
 * @author Tim
 *
 */
@Component
public class COTSCategoryEditor extends PropertyEditorSupport
{
    /**
     * Converts a COTSCategory id to a COTSCategory object.
     * 
     * @param id the id of the COTS category
     */
    @Override
    public void setAsText(String id)
    {
        COTSCategory fc = new COTSCategory();
        fc.setId(Long.valueOf(id));

        this.setValue(fc);
    }

    /**
     * Converts a COTSCategory object to an the id.
     * 
     * @return id of the COTS Category
     */
    @Override
    public String getAsText()
    {
        COTSCategory fc = (COTSCategory) this.getValue();
        String parsedId = String.valueOf(fc.getId());
        return parsedId;
    }
}