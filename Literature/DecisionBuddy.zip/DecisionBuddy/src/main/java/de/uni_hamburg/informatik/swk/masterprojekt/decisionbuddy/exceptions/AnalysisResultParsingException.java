package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * Exception for parsing DecisionBuddy-conform Analysis Results.
 * 
 * @author 1fechner
 *
 */
public class AnalysisResultParsingException extends AnalysisResultException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public AnalysisResultParsingException()
    {
        setExceptionType("analysisresultparsing");
    }

    @Override
    public String getViewMode()
    {
        return "result.error.parsing";
    }
}
