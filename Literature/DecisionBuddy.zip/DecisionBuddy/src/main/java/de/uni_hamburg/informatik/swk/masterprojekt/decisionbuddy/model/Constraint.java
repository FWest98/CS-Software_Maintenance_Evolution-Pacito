package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

/**
 * This Class represents the Constraint table from the database.
 *
 * @author Tim
 *
 */
@Entity
@Table(name = "`Constraint`")
public class Constraint
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue
    private Long id;

    @ManyToOne(targetEntity = TechnicalTerm.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "TechnicalTermID", referencedColumnName = "ID", nullable = false)
    private TechnicalTerm technicalTerm;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "constraint", orphanRemoval = true)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<ConstraintElement> elements;

    /**
     * No-argument constructor.
     */
    public Constraint()
    {
        elements = new ArrayList<ConstraintElement>();
    }

    public Long getId()
    {
        return this.id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public TechnicalTerm getTechnicalTerm()
    {
        return technicalTerm;
    }

    public void setTechnicalTerm(TechnicalTerm technicalTerm)
    {
        this.technicalTerm = technicalTerm;
    }

    public List<ConstraintElement> getElements()
    {
        return elements;
    }

    public void setElements(List<ConstraintElement> elements)
    {
        this.elements = elements;
    }

    /**
     * Add a new element to this constraint.
     *
     * @param constraintElement This constraintElement is added to the list.
     */
    public void addElement(ConstraintElement constraintElement)
    {
        if (elements == null)
        {
            elements = new ArrayList<ConstraintElement>();
        }
        constraintElement.setConstraint(this);
        elements.add(constraintElement);
    }

    /**
     * Removes an element from this constraint.
     *
     * @param constraintElement This constraintElement is removed from the list.
     */
    public void removeElement(ConstraintElement constraintElement)
    {
        if (elements != null)
        {
            constraintElement.setConstraint(null);
            elements.remove(constraintElement);
        }
    }

    @Override
    public String toString()
    {
        return id + "," + technicalTerm + "," + elements;
    }

    @Override
    public int hashCode()
    {
        int result = ((getId() == null) ? 0 : getId().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Constraint other = (Constraint) obj;
        return other.getId().equals(this.getId());
    }
}