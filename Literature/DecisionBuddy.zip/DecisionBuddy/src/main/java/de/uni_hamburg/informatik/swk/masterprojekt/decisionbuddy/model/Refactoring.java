package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the Refactoring table from the database.
 *
 * @author Tim
 *
 */
/**
 * @author Tim
 *
 */
@Entity
@Table(name = "Refactoring")
@PrimaryKeyJoinColumn(name = "SolutionID")
public class Refactoring extends Solution
{
    @ManyToOne(targetEntity = RefactoringCategory.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "RefactoringCategoryID", referencedColumnName = "ID", nullable = false)
    private RefactoringCategory refactoringCategory;

    @Column(name = "BadSmell", nullable = true, length = ColumnLength.SHORT)
    private String badSmell;

    @Column(name = "Summary", nullable = true, columnDefinition = "text")
    private String summary;

    @Column(name = "Mechanics", nullable = true, columnDefinition = "text")
    private String mechanics;

    @Column(name = "Examples", nullable = true, columnDefinition = "text")
    private String examples;

    /**
     * Constructor.
     */
    public Refactoring()
    {
        this.setType("Refactoring");
        RefactoringCategory refactoringCategory = new RefactoringCategory();
        refactoringCategory.setId(Long.valueOf("1"));
        this.setRefactoringCategory(refactoringCategory);
    }

    public String getBadSmell()
    {
        return badSmell;
    }

    public void setBadSmell(String badSmell)
    {
        this.badSmell = badSmell;
    }

    public RefactoringCategory getRefactoringCategory()
    {
        return refactoringCategory;
    }

    public void setRefactoringCategory(RefactoringCategory refactoringCategory)
    {
        this.refactoringCategory = refactoringCategory;
    }

    public String getSummary()
    {
        return summary;
    }

    public void setSummary(String summary)
    {
        this.summary = summary;
    }

    public String getMechanics()
    {
        return mechanics;
    }

    public void setMechanics(String mechanics)
    {
        this.mechanics = mechanics;
    }

    public String getExamples()
    {
        return examples;
    }

    public void setExamples(String examples)
    {
        this.examples = examples;
    }
}
