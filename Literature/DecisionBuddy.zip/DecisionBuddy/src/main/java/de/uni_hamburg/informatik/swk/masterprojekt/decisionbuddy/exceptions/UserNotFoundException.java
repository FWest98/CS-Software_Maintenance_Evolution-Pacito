package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a user is not found / does not exist
 * (anymore).
 * 
 * @author Vlad
 *
 */
public class UserNotFoundException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public UserNotFoundException()
    {
        setExceptionType("usernotfound");
    }
}