package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.Comparator;
import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * Overview of interfaces of class ProjectService.
 * 
 * @see architectural specification
 *
 * @author Lucas
 *
 */
public interface ProjectService
{
    /**
     * Adds a given project to the database.
     * 
     * @param project the project to be persisted
     * 
     * @return the saved project object
     * 
     * @throws ProjectPersistenceException Exception if Project could not be
     *             persisted
     */
    Project saveProject(Project project) throws ProjectPersistenceException;

    /**
     * Delete a project by given id.
     * 
     * @param id the id of the project that should be deleted
     * 
     * @throws ProjectNotFoundException Exception if Project is not found
     */
    void deleteProject(long id) throws ProjectNotFoundException;

    /**
     * Find a project by given id.
     * 
     * @param id the id of desired project
     * 
     * @return the matching project
     * 
     * @throws ProjectNotFoundException Exception if Project is not found
     */
    Project getProjectById(long id) throws ProjectNotFoundException;

    /**
     * Get a list of all current projects.
     * 
     * @return List of all projects
     */
    List<Project> getAllProjects();

    /**
     * Get a list of projects, given a Filter and a Sorter.
     * 
     * @see Filter
     * @see Comparator
     * 
     * @param filter a Filter object to reduce the result set
     * @param sorter a Sorter object to arrange the result items by criteria
     * @return List of projects
     */
    List<Project> getProjectsByCriteria(Filter<Project> filter, Comparator<Project> sorter);
}
