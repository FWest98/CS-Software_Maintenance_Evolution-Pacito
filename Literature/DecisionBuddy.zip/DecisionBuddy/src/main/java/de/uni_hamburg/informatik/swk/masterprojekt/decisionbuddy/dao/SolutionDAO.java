package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * A DAO class for Solution.
 * 
 * @author Vlad
 *
 */
public interface SolutionDAO extends JpaRepository<Solution, Long>
{
    List<Solution> findByType(String type);

    Solution findByName(String name);
}
