package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a solution could not be written to the
 * database.
 * 
 * @author schaak
 *
 */
public class SolutionPersistenceException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public SolutionPersistenceException()
    {
        setExceptionType("solutionpersistence");
    }
}
