package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.UsersDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;

/**
 * Our own implementation of the UserDetailService.
 * 
 * @author Vlad
 *
 */
@Service
@Transactional(readOnly = true)
public class UserDetailServiceImpl implements UserDetailsService
{
    @Autowired
    private UsersDAO userDAO;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
    {
        User user = userDAO.findOne(username);
        return user;
    }
}
