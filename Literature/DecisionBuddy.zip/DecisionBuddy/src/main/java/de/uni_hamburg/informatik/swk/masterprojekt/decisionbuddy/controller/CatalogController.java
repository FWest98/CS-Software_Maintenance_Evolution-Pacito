package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxFailure;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxFailureItem;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxResponse;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxSuccess;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.CategorizedSolution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.RatingPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SolutionPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Constraint;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DynamicEntities;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Framework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Property;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.QualityGoal;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Rating;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StaticEntities;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.RatingService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.SolutionService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.TechnicalTermService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ArchitecturalPatternCategoryEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorizationConstants;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.COTSCategoryEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ComparatorFactory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ConstraintEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ConstraintProposer;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.DateEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.DesignPatternCategoryEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.FrameworkCategoryEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.HelperFunctions;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.IntegerEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Paginator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.PropertyEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.QualityGoalEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.RefactoringCategoryEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.SolutionFilterFactory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.StringValueEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.TechnicalTermEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.ArchitecturalPatternValidator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.COTSValidator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.DesignPatternValidator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.FrameworkValidator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.RatingValidator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.RefactoringValidator;

/**
 * This controller is responsible for managing the catalog view.
 * 
 * @author schaak
 *
 */
@Controller
@RequestMapping(value = "/catalog")
public class CatalogController
{
    @Autowired
    private Paginator<Solution> paginationHelper;

    @Autowired
    private SolutionService solutionService;

    @Autowired
    private TechnicalTermService technicalTermService;

    @Autowired
    private RatingService ratingService;

    @Autowired
    private HelperFunctions helperFunctions;

    @Autowired
    private StaticEntities staticEntities;

    @Autowired
    private DynamicEntities dynamicEntities;

    @Autowired
    private FrameworkValidator frameworkValidator;

    @Autowired
    private COTSValidator cotsValidator;

    @Autowired
    private ArchitecturalPatternValidator architecturalPatternValidator;

    @Autowired
    private DesignPatternValidator designPatternValidator;

    @Autowired
    private RefactoringValidator refactoringValidator;

    @Autowired
    private RatingValidator ratingValidator;

    @Autowired
    private ConstraintProposer constraintProposer;

    @Autowired
    private MessageSource messageSource;

    /**
     * Called before binding between input and model fields.
     * 
     * @param binder the binder instance
     */
    @InitBinder
    private void initBinder(WebDataBinder binder)
    {
        // Integer <-> String
        binder.registerCustomEditor(Integer.class, new IntegerEditor());

        // FrameworkCategory <-> String
        binder.registerCustomEditor(FrameworkCategory.class, new FrameworkCategoryEditor());

        // COTSCategory <-> String
        binder.registerCustomEditor(COTSCategory.class, new COTSCategoryEditor());

        // ArchitecturalPatternCategory <-> String
        binder.registerCustomEditor(ArchitecturalPatternCategory.class, new ArchitecturalPatternCategoryEditor());

        // DesignPatternCategory <-> String
        binder.registerCustomEditor(DesignPatternCategory.class, new DesignPatternCategoryEditor());

        // RefactoringCategory <-> String
        binder.registerCustomEditor(RefactoringCategory.class, new RefactoringCategoryEditor());

        // Date <-> String
        binder.registerCustomEditor(Date.class, new DateEditor());

        // StringValue <-> String
        binder.registerCustomEditor(StringValue.class, new StringValueEditor());

        // Constraint <-> String
        binder.registerCustomEditor(Constraint.class, new ConstraintEditor());

        // Property <-> String
        binder.registerCustomEditor(Property.class, new PropertyEditor());

        // QualityGoal <-> String
        binder.registerCustomEditor(QualityGoal.class, new QualityGoalEditor());

        // TechnicalTerm <-> String
        binder.registerCustomEditor(TechnicalTerm.class, new TechnicalTermEditor());
    }

    /******************************************************************
     * 
     * SHOW SOLUTIONS
     * 
     *****************************************************************/

    /**
     * Shows a list of current solutions.
     * 
     * @param page which page in solution list should be returned (optional)
     * @param pageSize how many solutions should be shown (optional)
     * @param filter specifies if the solutions should be filtered (optional)
     * @param sorter specifies how the solutions should be sorted (optional)
     * 
     * @return view for listing solutions.
     * @throws SorterFieldNotFoundException sorting field is not found
     * @throws SorterInvalidTypeException sorting field type is invalid
     */
    @RequestMapping(value = { "", "/", "/list" })
    public ModelAndView listOfSolutions(@RequestParam(value = "page", required = false) String page,
            @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "filter", required = false) String filter,
            @RequestParam(value = "sorter", required = false) String sorter) throws SorterFieldNotFoundException,
            SorterInvalidTypeException
    {
        ModelAndView catalogView = new ModelAndView("index");

        // show solutions.jsp
        catalogView.addObject("jsp", "solutions");

        // get solutions by sorting criteria
        // filtering is applied last, because quicksearch needs unfiltered
        // results
        Comparator<Solution> solutionComparator = new ComparatorFactory<Solution>(Solution.class)
                .generateComparator(sorter);

        List<Solution> processedSolutions = solutionService.getSolutionsByCriteria(null, solutionComparator);

        // convert to categorized solution for quicksearch
        List<CategorizedSolution> categorizedSolutions = new ArrayList<CategorizedSolution>();

        for (Solution solution : processedSolutions)
        {
            categorizedSolutions.add(new CategorizedSolution(solution));
        }

        // for quicksearch, solutions have to be type sorted and unfiltered
        Comparator<CategorizedSolution> typeSorter = new ComparatorFactory<CategorizedSolution>(
                CategorizedSolution.class).generateComparator("solutionType");

        Collections.sort(categorizedSolutions, typeSorter);

        // for normal listing of solutions, the filtering has to be applied at
        // this point
        Filter<Solution> solutionFilter = SolutionFilterFactory.generateSolutionFilter("type", filter);

        List<Solution> solutionList = new ArrayList<Solution>();

        if (solutionFilter != null)
        {
            for (Solution element : processedSolutions)
            {
                if (solutionFilter.isInResult(element))
                {
                    solutionList.add(element);
                }
            }
        }

        // Configure pagination
        paginationHelper.configure(solutionList, pageSize, page);

        // model entries
        catalogView.addObject("pagedListHolder", paginationHelper.getPagedListHolder());

        // get breadcrumbs and menu for action
        catalogView = helperFunctions.getBreadcrumbs("showsolutions", catalogView);
        catalogView = helperFunctions.getMenu("showsolutions", catalogView);

        catalogView.addObject("categorizedSolutions", categorizedSolutions);
        catalogView.addObject("solutionlist", paginationHelper.getPageList());

        return catalogView;
    }

    /******************************************************************
     * 
     * SHOW SOLUTION PROFILE
     * 
     *****************************************************************/

    /**
     * Shows a specific solution in profile view.
     * 
     * @param id ID of solution to be displayed.
     * 
     * @return detailview of solution
     * 
     * @throws SolutionNotFoundException exception if solution is not found
     */
    @RequestMapping(value = "/solution/{id}")
    public ModelAndView solutionProfile(@PathVariable Integer id) throws SolutionNotFoundException
    {
        ModelAndView catalogView = new ModelAndView("index");

        // get solution from service
        Solution solution = solutionService.getSolutionById(id);

        // get ratings for solution
        List<Rating> ratings = ratingService.getRatingsBySolutionID(solution.getId());
        Collections.sort(ratings, Rating.getDateComprator());
        catalogView.addObject("ratinglist", ratings);
        // fill model
        catalogView.addObject("jsp", "addsolution");
        catalogView.addObject("viewmode", "view");
        catalogView.addObject("solution", solution);
        catalogView.addObject("tabindex", 1);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        catalogView = helperFunctions.getBreadcrumbs("solutionprofile", list, catalogView);

        // get menu for action
        catalogView = helperFunctions.getMenu("solutionprofile", list, catalogView);

        return catalogView;
    }

    /******************************************************************
     * 
     * ADD SOLUTION
     * 
     *****************************************************************/
    /**
     * Shows the mask for adding a new solution. Generic method.
     * 
     * @param solution the backing solution for form
     * 
     * @return view/mask for adding a solution
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    public ModelAndView addSolutionPage(Solution solution, ModelAndView catalogView)
    {
        // fill model
        catalogView.addObject("jsp", "addsolution");
        catalogView.addObject("viewmode", "add");
        catalogView.addObject("solution", solution);

        // get breadcrumbs for action
        catalogView = helperFunctions.getBreadcrumbs("addsolution", catalogView);

        // get menu for action
        catalogView = helperFunctions.getMenu("addsolution", catalogView);

        return catalogView;
    }

    /**
     * Shows the mask for adding a new framework. Note: Framework is the default
     * solution type, do not specify type=Framework in params!
     * 
     * @param previousModel needed to conserve bindingResult and validation of
     *            former solution
     * 
     * @return view/mask for adding a framework.
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public ModelAndView addFrameworkPage(Model previousModel)
    {
        Framework framework;

        ModelAndView catalogView = new ModelAndView("index");

        // check if solution object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("solution"))
        {
            framework = (Framework) previousModel.asMap().get("solution");
        }
        else
        {
            // default: no previous solution is available
            framework = new Framework();
        }

        return addSolutionPage(framework, catalogView);
    }

    /**
     * Shows the mask for adding a new cots. Note: COTS is the default solution
     * type, do not specify type=COTS in params!
     * 
     * @param previousModel needed to conserve bindingResult and validation of
     *            former solution
     * 
     * @return view/mask for adding a cots.
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.GET, params = "type=COTS")
    public ModelAndView addCotsPage(Model previousModel)
    {
        COTS cots;

        ModelAndView catalogView = new ModelAndView("index");

        // check if solution object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("solution"))
        {
            cots = (COTS) previousModel.asMap().get("solution");
        }
        else
        {
            // default: no previous solution is available
            cots = new COTS();
        }

        return addSolutionPage(cots, catalogView);
    }

    /**
     * Shows the mask for adding a new architectural pattern.
     * 
     * @param previousModel needed to conserve bindingResult and validation of
     *            former solution
     * 
     * @return view/mask for adding a architectural pattern.
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.GET, params = "type=ArchitecturalPattern")
    public ModelAndView addArchitecturalPatternPage(Model previousModel)
    {
        ArchitecturalPattern architecturalPattern;

        ModelAndView catalogView = new ModelAndView("index");

        // check if solution object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("solution"))
        {
            architecturalPattern = (ArchitecturalPattern) previousModel.asMap().get("solution");
        }
        else
        {
            // default: no previous solution is available
            architecturalPattern = new ArchitecturalPattern();
        }

        return addSolutionPage(architecturalPattern, catalogView);
    }

    /**
     * Shows the mask for adding a new design pattern.
     * 
     * @param previousModel needed to conserve bindingResult and validation of
     *            former solution
     * 
     * @return view/mask for adding a design pattern.
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.GET, params = "type=DesignPattern")
    public ModelAndView addDesignPatternPage(Model previousModel)
    {
        DesignPattern designPattern;

        ModelAndView catalogView = new ModelAndView("index");

        // check if solution object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("solution"))
        {
            designPattern = (DesignPattern) previousModel.asMap().get("solution");
        }
        else
        {
            // default: no previous solution is available
            designPattern = new DesignPattern();
        }

        return addSolutionPage(designPattern, catalogView);
    }

    /**
     * Shows the mask for adding a new refactoring.
     * 
     * @param previousModel needed to conserve bindingResult and validation of
     *            former solution
     * 
     * @return view/mask for adding a refactoring.
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.GET, params = "type=Refactoring")
    public ModelAndView addRefactoringPage(Model previousModel)
    {
        Refactoring refactoring;

        ModelAndView catalogView = new ModelAndView("index");

        // check if solution object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("solution"))
        {
            refactoring = (Refactoring) previousModel.asMap().get("solution");
        }
        else
        {
            // default: no previous solution is available
            refactoring = new Refactoring();
        }

        return addSolutionPage(refactoring, catalogView);
    }

    /**
     * General method for adding a Solution. Should be delegated to from
     * addingFramework, addingRefactoring etc.
     * 
     * @param solution the solution object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex index of desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to add a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * 
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    public String addingSolution(Solution solution, BindingResult bindingResult, String tabindex,
            RedirectAttributes redirectAttrs) throws SolutionPersistenceException
    {
        // finalize
        helperFunctions.finalizeUserEditable(solution);

        // determine if the solution is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("solution", solution);
            redirectAttrs.addFlashAttribute("org.springframework.validation.BindingResult.solution", bindingResult);

            redirectAttrs.addFlashAttribute("tabindex", tabindex);
        }
        else
        {
            Solution savedSolution;

            // persist solution
            savedSolution = solutionService.saveSolution(solution);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "addsolution.success");

            List<String> params = new ArrayList<String>();
            params.add(savedSolution.getName());
            params.add(String.valueOf(savedSolution.getId()));
            redirectAttrs.addFlashAttribute("messageparams", params);
        }

        return "redirect:/catalog/add";
    }

    /**
     * Process of adding a Framework Triggers when Framework details were
     * entered into mask and 'save'-button has been clicked.
     * 
     * @param framework the framework object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex index of desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to add a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if tt could not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.POST, params = "type=Framework")
    public String addingFramework(@ModelAttribute("solution") Framework framework, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex, RedirectAttributes redirectAttrs)
            throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(framework, frameworkValidator, bindingResult);

        // correct add solution page has to be displayed
        redirectAttrs.addAttribute("type", "Framework");

        return addingSolution(framework, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of adding a COTS Triggers when COTS details were entered into
     * mask and 'save'-button has been clicked.
     * 
     * @param cots the cots object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex index of desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to add a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.POST, params = "type=COTS")
    public String addingCOTS(@ModelAttribute("solution") COTS cots, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex, RedirectAttributes redirectAttrs)
            throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(cots, cotsValidator, bindingResult);

        // correct add solution page has to be displayed
        redirectAttrs.addAttribute("type", "COTS");

        return addingSolution(cots, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of adding an ArchitecturalPattern Triggers when
     * ArchitecturalPattern details were entered into mask and 'save'-button has
     * been clicked.
     * 
     * @param architecturalPattern the architecturalpattern object parsed from
     *            input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex index of desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to add a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.POST, params = "type=ArchitecturalPattern")
    public String addingArchitecturalPattern(@ModelAttribute("solution") ArchitecturalPattern architecturalPattern,
            BindingResult bindingResult, @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(architecturalPattern, architecturalPatternValidator, bindingResult);

        // correct add solution page has to be displayed
        redirectAttrs.addAttribute("type", "ArchitecturalPattern");

        return addingSolution(architecturalPattern, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of adding an DesignPattern Triggers when DesignPattern details
     * were entered into mask and 'save'-button has been clicked.
     * 
     * @param designPattern the designpattern object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex index of desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to add a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.POST, params = "type=DesignPattern")
    public String addingDesignPattern(@ModelAttribute("solution") DesignPattern designPattern,
            BindingResult bindingResult, @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(designPattern, designPatternValidator, bindingResult);

        // correct add solution page has to be displayed
        redirectAttrs.addAttribute("type", "DesignPattern");

        return addingSolution(designPattern, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of adding an Refactoring. Triggers when Refactoring details were
     * entered into mask and 'save'-button has been clicked.
     * 
     * @param refactoring the refactoring object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex index of desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to add a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.POST, params = "type=Refactoring")
    public String addingRefactoring(@ModelAttribute("solution") Refactoring refactoring, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex, RedirectAttributes redirectAttrs)
            throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(refactoring, refactoringValidator, bindingResult);

        // correct add solution page has to be displayed
        redirectAttrs.addAttribute("type", "Refactoring");

        return addingSolution(refactoring, bindingResult, tabindex, redirectAttrs);
    }

    /******************************************************************
     * 
     * EDIT SOLUTION
     * 
     *****************************************************************/

    /**
     * Shows the mask for editing a solution. Generic method.
     * 
     * @param id the id of the solution to be edited
     * @param previousModel needed to conserve bindingResult and validation of
     *            former solution
     * 
     * @return view/mask for editing a solution
     * 
     * @throws SolutionNotFoundException exception if solution is not found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
    public ModelAndView editSolutionPage(@PathVariable Integer id, Model previousModel)
            throws SolutionNotFoundException
    {
        ModelAndView catalogView = new ModelAndView("index");

        // check if solution object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (!previousModel.containsAttribute("solution"))
        {
            Solution solution = solutionService.getSolutionById(id);
            catalogView.addObject("solution", solution);
        }

        // fill model
        catalogView.addObject("jsp", "addsolution");
        catalogView.addObject("viewmode", "edit");

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        catalogView = helperFunctions.getBreadcrumbs("editsolution", list, catalogView);

        // get menu for action
        catalogView = helperFunctions.getMenu("editsolution", list, catalogView);

        return catalogView;
    }

    /**
     * Shows the mask for editing a solution WITH proposed constraints.
     * 
     * @param id the id of the solution to be edited
     * 
     * @return view/mask for editing a solution
     * @throws SolutionNotFoundException exception if solution is not found
     * 
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/edit/proposeconstraints/{id}", method = RequestMethod.GET)
    public ModelAndView editSolutionPageProposedConstraints(@PathVariable Integer id) throws SolutionNotFoundException

    {
        ModelAndView catalogView = new ModelAndView("index");

        // load solution
        Solution solution = solutionService.getSolutionById(id);

        // add proposed constraints
        List<Constraint> proposedConstraints = constraintProposer.proposeConstraintsFromModel(solution);
        solution.setConstraints(proposedConstraints);

        catalogView.addObject("solution", solution);

        // fill model
        catalogView.addObject("jsp", "addsolution");
        catalogView.addObject("viewmode", "edit");

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        catalogView = helperFunctions.getBreadcrumbs("editsolution", list, catalogView);

        // get menu for action
        catalogView = helperFunctions.getMenu("editsolution", list, catalogView);

        return catalogView;

    }

    /**
     * General method for editing a Solution. Should be delegated to from
     * editingFramework, editingRefactoring etc.
     * 
     * @param solution the solution object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex the desired tab index
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to edit a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * 
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    public String editingSolution(Solution solution, BindingResult bindingResult, String tabindex,
            RedirectAttributes redirectAttrs) throws SolutionPersistenceException
    {

        // determine if the edited solution is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("org.springframework.validation.BindingResult.solution", bindingResult);
        }
        else
        {
            // finalize object
            helperFunctions.finalizeUserEditable(solution);

            // save solution
            solutionService.saveSolution(solution);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "editsolution.success");
        }

        // fill redirect model
        List<String> params = new ArrayList<String>();
        params.add(solution.getName());
        params.add(String.valueOf(solution.getId()));
        redirectAttrs.addFlashAttribute("messageparams", params);

        redirectAttrs.addFlashAttribute("solution", solution);
        redirectAttrs.addFlashAttribute("tabindex", tabindex);

        redirectAttrs.addAttribute("id", solution.getId());
        return "redirect:/catalog/edit/{id}";
    }

    /**
     * Process of editing a Framework Triggers when Framework details were
     * entered into mask and 'save'-button has been clicked.
     * 
     * @param framework the framework object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex the desired tab index
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to edit a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/edit", method = RequestMethod.POST, params = "type=Framework")
    public String editingFramework(@ModelAttribute("solution") Framework framework, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex, RedirectAttributes redirectAttrs)
            throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(framework, frameworkValidator, bindingResult);
        return editingSolution(framework, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of editing a COTS Triggers when COTS details were entered into
     * mask and 'save'-button has been clicked.
     * 
     * @param cots the cots object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex the desired tab index
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to edit a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/edit", method = RequestMethod.POST, params = "type=COTS")
    public String editingCOTS(@ModelAttribute("solution") COTS cots, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex, RedirectAttributes redirectAttrs)
            throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(cots, cotsValidator, bindingResult);
        return editingSolution(cots, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of editing an ArchitecturalPattern Triggers when
     * ArchitecturalPattern details were entered into mask and 'save'-button has
     * been clicked.
     * 
     * @param architecturalPattern the architecturalpattern object parsed from
     *            input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex the desired tab index
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to edit a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/edit", method = RequestMethod.POST, params = "type=ArchitecturalPattern")
    public String editingArchitecturalPattern(@ModelAttribute("solution") ArchitecturalPattern architecturalPattern,
            BindingResult bindingResult, @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(architecturalPattern, architecturalPatternValidator, bindingResult);
        return editingSolution(architecturalPattern, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of editing an DesignPattern Triggers when DesignPattern details
     * were entered into mask and 'save'-button has been clicked.
     * 
     * @param designPattern the designpattern object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex the desired tab index
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to edit a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/edit", method = RequestMethod.POST, params = "type=DesignPattern")
    public String editingDesignPattern(@ModelAttribute("solution") DesignPattern designPattern,
            BindingResult bindingResult, @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(designPattern, designPatternValidator, bindingResult);
        return editingSolution(designPattern, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of editing an Refactoring Triggers when Refactoring details were
     * entered into mask and 'save'-button has been clicked.
     * 
     * @param refactoring the Refactoring object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex the desired tab index
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to edit a solution and shows a success/failure
     *         message.
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/edit", method = RequestMethod.POST, params = "type=Refactoring")
    public String editingRefactoring(@ModelAttribute("solution") Refactoring refactoring, BindingResult bindingResult,
            @RequestParam(value = "tabindex", required = false) String tabindex, RedirectAttributes redirectAttrs)
            throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(refactoring, refactoringValidator, bindingResult);
        return editingSolution(refactoring, bindingResult, tabindex, redirectAttrs);
    }

    /**
     * Process of editing a Framework inline. Triggers when Framework is edited
     * inline.
     * 
     * @param framework the framework object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/editinline", method = RequestMethod.POST, params = "type=Framework", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingFrameworkInline(@ModelAttribute("solution") Framework framework,
            BindingResult bindingResult) throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(framework, frameworkValidator, bindingResult);
        return editingSolutionInline(framework, bindingResult);
    }

    /**
     * Process of editing a COTS inline. Triggers when COTS is edited inline.
     * 
     * @param cots the cots object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/editinline", method = RequestMethod.POST, params = "type=COTS", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingCOTSInline(@ModelAttribute("solution") COTS cots,
            BindingResult bindingResult) throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(cots, cotsValidator, bindingResult);
        return editingSolutionInline(cots, bindingResult);
    }

    /**
     * Process of editing an ArchitecturalPattern inline. Triggers when
     * ArchitecturalPattern is edited inline.
     * 
     * @param architecturalPattern the architectural pattern object parsed from
     *            input fields
     * @param bindingResult contains information about parsing success
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/editinline", method = RequestMethod.POST, params = "type=ArchitecturalPattern", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingArchitecturalPatternInline(
            @ModelAttribute("solution") ArchitecturalPattern architecturalPattern, BindingResult bindingResult)
            throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(architecturalPattern, architecturalPatternValidator, bindingResult);
        return editingSolutionInline(architecturalPattern, bindingResult);
    }

    /**
     * Process of editing an DesignPattern inline. Triggers when DesignPattern
     * is edited inline.
     * 
     * @param designPattern the design pattern object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/editinline", method = RequestMethod.POST, params = "type=DesignPattern", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingDesignPatternInline(
            @ModelAttribute("solution") DesignPattern designPattern, BindingResult bindingResult)
            throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(designPattern, designPatternValidator, bindingResult);
        return editingSolutionInline(designPattern, bindingResult);
    }

    /**
     * Process of editing an Refactoring inline. Triggers when Refactoring is
     * edited inline.
     * 
     * @param refactoring the design pattern object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * @throws TechnicalTermNotFoundException exception if technicalterm could
     *             not be found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/editinline", method = RequestMethod.POST, params = "type=Refactoring", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingRefactoringInline(@ModelAttribute("solution") Refactoring refactoring,
            BindingResult bindingResult) throws SolutionPersistenceException, TechnicalTermNotFoundException
    {
        validateSolution(refactoring, refactoringValidator, bindingResult);
        return editingSolutionInline(refactoring, bindingResult);
    }

    /**
     * General method for editing a Solution inline. Should be delegated to from
     * editingFrameworkInline, editingRefactoringInline etc.
     * 
     * @param solution the solution object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws SolutionPersistenceException exception if solution could not be
     *             saved
     * 
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    public AjaxResponse editingSolutionInline(Solution solution, BindingResult bindingResult)
            throws SolutionPersistenceException
    {
        // determine if success or failure
        if (bindingResult.hasErrors())
        {
            Locale locale = LocaleContextHolder.getLocale();
            AjaxFailure ajaxFailure = new AjaxFailure();

            // parse every occured error into AjaxFailure object
            for (ObjectError error : bindingResult.getAllErrors())
            {
                AjaxFailureItem ajaxFailureItem = new AjaxFailureItem();
                ajaxFailureItem.setErrorCode(helperFunctions.skipIndexedCodes(error.getCodes()));
                ajaxFailureItem.setErrorArguments(error.getArguments());

                String message = "";
                try
                {
                    message = messageSource.getMessage(helperFunctions.skipIndexedCodes(error.getCodes()),
                            error.getArguments(), locale);
                }
                catch (NoSuchMessageException e)
                {
                }
                ajaxFailureItem.setErrorMessage(message);

                FieldError fieldError = (FieldError) error;

                ajaxFailureItem.setErrorFieldName(fieldError.getField());
                ajaxFailure.addAjaxFailureItem(ajaxFailureItem);
            }

            return ajaxFailure;
        }
        else
        {
            // finalize
            helperFunctions.finalizeUserEditable(solution);

            // save solution
            solutionService.saveSolution(solution);

            // return ajax success object
            AjaxSuccess ajaxSuccess = new AjaxSuccess();
            ajaxSuccess.setLastModifier(solution.getLastModifier());
            Format format = new SimpleDateFormat("yyyy-MM-dd, HH:mm:ss");
            ajaxSuccess.setModificationDate(format.format((Date) solution.getModificationDate()));

            return ajaxSuccess;
        }
    }

    /******************************************************************
     * 
     * DELETE SOLUTION
     * 
     *****************************************************************/

    /**
     * Shows a solution which is about to be deleted.
     * 
     * @param id ID of solution to be deleted
     * 
     * @return detailview of solution to be deleted
     * 
     * @throws SolutionNotFoundException exception if solution is not found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public ModelAndView deleteSolutionPage(@PathVariable Integer id) throws SolutionNotFoundException
    {
        ModelAndView catalogView = new ModelAndView("index");

        // get solution from service
        Solution solution = solutionService.getSolutionById(id);

        // // get constraints for solution
        // List<Constraint> constraintList = solution.getConstraints();

        // fill model
        catalogView.addObject("jsp", "addsolution");
        catalogView.addObject("viewmode", "delete");
        catalogView.addObject("solution", solution);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        catalogView = helperFunctions.getBreadcrumbs("deletesolution", list, catalogView);

        // get menu for action
        catalogView = helperFunctions.getMenu("deletesolution", list, catalogView);

        return catalogView;
    }

    /**
     * Deletes a solution.
     * 
     * @param id ID of solution to be deleted
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return show solutions view
     * 
     * @throws SolutionNotFoundException exception if solution is not found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    public String deletingSolution(@PathVariable Integer id, RedirectAttributes redirectAttrs)
            throws SolutionNotFoundException
    {
        // delete solution
        solutionService.deleteSolution(id);

        // fill redirect model
        redirectAttrs.addFlashAttribute("messagestatus", "success");
        redirectAttrs.addFlashAttribute("messagecode", "deletesolution.success");

        List<String> params = new ArrayList<String>();
        params.add(String.valueOf(id));
        redirectAttrs.addFlashAttribute("messageparams", params);

        return "redirect:/catalog/list";
    }

    /******************************************************************
     * 
     * ADD RATING
     * 
     *****************************************************************
     * 
     * /** Shows the mask for adding a new rating.
     * 
     * @param previousModel needed to conserve bindingResult and validation of
     *            former rating
     * 
     * @return view/mask for adding a rating.
     * @throws SolutionNotFoundException exception if solution is not found
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "solution/{solutionId}/rating/add", method = RequestMethod.GET)
    public ModelAndView addRatingPage(@PathVariable Integer solutionId, Model previousModel)
            throws SolutionNotFoundException
    {
        Rating rating;

        ModelAndView catalogView = new ModelAndView("index");

        // check if rating object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("rating"))
        {
            rating = (Rating) previousModel.asMap().get("rating");
        }
        else
        {
            Solution solution = solutionService.getSolutionById(Long.valueOf(solutionId));

            // default: no previous rating is available
            rating = new Rating();
            rating.setSolution(solution);
        }

        // fill model
        catalogView.addObject("jsp", "addrating");
        catalogView.addObject("viewmode", "add");
        catalogView.addObject("rating", rating);

        ArrayList<String> list = new ArrayList<String>();
        list.add(solutionId.toString());

        // get breadcrumbs for action
        catalogView = helperFunctions.getBreadcrumbs("addrating", list, catalogView);

        // get menu for action
        catalogView = helperFunctions.getMenu("addrating", catalogView);

        return catalogView;
    }

    /**
     * Process of adding a Rating.
     * 
     * @param rating the rating object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex index of desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to add a rating and shows a success/failure
     *         message.
     * 
     * @throws RatingPersistenceException exception if rating could not be saved
     */
    @PreAuthorize(AuthorizationConstants.CATALOG_WRITE)
    @RequestMapping(value = "solution/{solutionId}/rating/add", method = RequestMethod.POST)
    public String addingRating(@PathVariable Integer solutionId, @ModelAttribute("rating") Rating rating,
            BindingResult bindingResult, @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws RatingPersistenceException
    {
        // validate rating
        ratingValidator.validate(rating, bindingResult);

        // finalize
        rating.setCreationDate(new Date());
        rating.setCreator(helperFunctions.createUsername());

        // determine if the rating is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("rating", rating);
            redirectAttrs.addFlashAttribute("org.springframework.validation.BindingResult.rating", bindingResult);

            redirectAttrs.addFlashAttribute("tabindex", tabindex);
        }
        else
        {
            // persist rating
            ratingService.saveRating(rating);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "addrating.success");

            List<String> params = new ArrayList<String>();
            redirectAttrs.addFlashAttribute("messageparams", params);
            redirectAttrs.addFlashAttribute("solutionId", solutionId);
        }

        return "redirect:/catalog/solution/{solutionId}/rating/add";
    }

    /**
     * Validating of solution. If required, set connection to technicalterm.
     * 
     * @param solution the solution to be validated
     * @param validator the specific validator for each solution type
     * @param bindingResult the bindingresult object
     * 
     * @throws TechnicalTermNotFoundException exception if tt is not found
     */
    public void validateSolution(Solution solution, Validator validator, BindingResult bindingResult)
            throws TechnicalTermNotFoundException
    {
        // set connections if not available
        for (Constraint constraint : solution.getConstraints())
        {
            if (constraint.getTechnicalTerm() == null || constraint.getTechnicalTerm().getType() == null)
            {
                TechnicalTerm technicalTerm = technicalTermService.getTechnicalTermById(constraint.getTechnicalTerm()
                        .getId());
                constraint.setTechnicalTerm(technicalTerm);
            }
        }

        // validate solution
        validator.validate(solution, bindingResult);
    }

    /******************************************************************
     * 
     * MODEL POPULATING METHODS
     * 
     *****************************************************************/

    /**
     * Assigns different framework categories to model for populating drop down
     * menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'frameworkcategories' containing List of
     *         FrameworkCategories.
     */
    @ModelAttribute("frameworkcategories")
    public List<FrameworkCategory> dropdownFrameworkCategories()
    {
        return solutionService.getFrameworkCategories();
    }

    /**
     * Assigns different cots categories to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'cotscategories' containing List of
     *         COTSCategories.
     */
    @ModelAttribute("cotscategories")
    public List<COTSCategory> dropdownCOTSCategories()
    {
        return solutionService.getCOTSCategories();
    }

    /**
     * Assigns different architectural pattern categories to model for
     * populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'architecturalpatterncategories' containing List
     *         of ArchitecturalPatternCategories.
     */
    @ModelAttribute("architecturalpatterncategories")
    public List<ArchitecturalPatternCategory> dropdownArchitecturalPatternCategories()
    {
        return solutionService.getArchitecturalPatternCategories();
    }

    /**
     * Assigns different design pattern categories to model for populating drop
     * down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'designpatterncategories' containing List of
     *         DesignPatternCategories.
     */
    @ModelAttribute("designpatterncategories")
    public List<DesignPatternCategory> dropdownDesignPatternCategories()
    {
        return solutionService.getDesignPatternCategories();
    }

    /**
     * Assigns different design pattern categories to model for populating drop
     * down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'refactoringcategories' containing List of
     *         RefactoringCategories.
     */
    @ModelAttribute("refactoringcategories")
    public List<RefactoringCategory> dropdownRefactoringCategories()
    {
        return solutionService.getRefactoringCategories();
    }

    /**
     * Assigns different solution types to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'solutiontypes' containing List of Solution
     *         types.
     */
    @ModelAttribute("solutiontypes")
    public Map<String, String> dropdownSolutionTypes()
    {
        return staticEntities.getSolutionTypes();
    }

    /**
     * Assigns different development stati to model for populating drop down
     * menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'stati' containing List of Development stati
     */
    @ModelAttribute("developmentstati")
    public Map<String, String> dropdownDevelopmentStati()
    {
        return staticEntities.getDevelopmentStati();
    }

    /**
     * Assigns different bad smells to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'badsmells' containing List of bad smells
     */
    @ModelAttribute("badsmells")
    public Map<String, String> dropdownBadSmells()
    {
        return staticEntities.getBadSmells();
    }

    /**
     * Assigns different community sizes to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'communitysizes' containing List of community
     *         sizes
     */
    @ModelAttribute("communitysizes")
    public Map<String, String> dropdownCommunitySizes()
    {
        return staticEntities.getCommunitySizes();
    }

    /**
     * Assigns different licenses to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'licenses' containing List of licenses
     */
    @ModelAttribute("licenses")
    public Map<String, String> dropdownLicenses()
    {
        return staticEntities.getLicenses();
    }

    /**
     * Assigns different programming languages to model for populating drop down
     * menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'programminglanguages' containing List of
     *         programming languages
     */
    @ModelAttribute("programminglanguages")
    public Map<String, String> dropdownProgrammingLanguages()
    {
        return staticEntities.getProgrammingLanguages();
    }

    /**
     * Assigns different operating systems to model for populating drop down
     * menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'frameworkoperatingsystems' containing List of
     *         operating systems
     */
    @ModelAttribute("operatingsystems")
    public Map<String, String> dropdownFrameworkOperatingSystems()
    {
        return staticEntities.getOperatingSystems();
    }

    /**
     * Assigns technical terms to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'technicalTerms' containing List of technical
     *         terms
     * 
     * @throws SorterInvalidTypeException exception if type is invalid
     * @throws SorterFieldNotFoundException exception if field is not found
     */
    @ModelAttribute("technicalterms")
    public Map<String, String> dropdownTechnicalTerms() throws SorterInvalidTypeException, SorterFieldNotFoundException
    {
        return dynamicEntities.getTechnicalTerms();
    }

    /**
     * Assigns constraint comparators to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'constraintcomparators' containing List of
     *         comparators
     */
    @ModelAttribute("constraintcomparators")
    public Map<String, String> dropdownConstraintComparators()
    {
        return staticEntities.getConstraintComparators();
    }

    /**
     * Assigns quality goals to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'qualitygoals' containing List of quality goals
     */
    @ModelAttribute("qualitygoals")
    public Map<String, String> dropdownQualityGoals()
    {
        return dynamicEntities.getQualityGoals();
    }

    /**
     * Assigns properties to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'properties' containing List of properties
     */
    @ModelAttribute("properties")
    public Map<String, String> dropdownProperties()
    {
        return dynamicEntities.getProperties();
    }

    /******************************************************************
     * 
     * CONTROLBAR
     * 
     *****************************************************************/

    /**
     * Returns the sorting params to the view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'sortingParams' containing sorting keys & values
     */
    @ModelAttribute("sortingParams")
    public Map<String, String> sortingParams()
    {
        Map<String, String> sortingParams = new LinkedHashMap<String, String>();

        sortingParams.put("id", "id");
        sortingParams.put("name", "name");
        sortingParams.put("type", "type");
        sortingParams.put("shortDescription", "shortDescription");

        return sortingParams;
    }

    /**
     * Returns the filtering params to the view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'filteringParams' containing filtering keys &
     *         values
     */
    @ModelAttribute("filteringParams")
    public Map<String, String> filteringParams()
    {
        Map<String, String> filteringParams = new LinkedHashMap<String, String>();

        filteringParams.put("framework", "framework");
        filteringParams.put("architecturalpattern", "architecturalpattern");
        filteringParams.put("designpattern", "designpattern");
        filteringParams.put("refactoring", "refactoring");
        filteringParams.put("cots", "cots");

        return filteringParams;
    }

    /**
     * Configures the controlbar.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'controlbar' containing config
     */
    @ModelAttribute("controlbar")
    public Map<String, String> controlbarConfig()
    {
        Map<String, String> controlbar = new LinkedHashMap<String, String>();

        controlbar.put("filteringAllowed", "true");
        controlbar.put("sortingAllowed", "true");
        controlbar.put("pageSizeAllowed", "true");
        controlbar.put("paginationAllowed", "true");
        controlbar.put("modelName", "solution");

        return controlbar;
    }

    /******************************************************************
     * 
     * OTHER
     * 
     *****************************************************************/

    /**
     * CSS-Styling: set catalog view as active view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return String 'activeview' containing 'catalog'
     */
    @ModelAttribute("activeview")
    public String cssActiveView()
    {
        return "catalog";
    }
}