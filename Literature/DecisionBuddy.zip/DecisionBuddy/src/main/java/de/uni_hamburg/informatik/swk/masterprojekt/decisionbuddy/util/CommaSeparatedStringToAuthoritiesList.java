package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;

public class CommaSeparatedStringToAuthoritiesList implements Converter<String, List<GrantedAuthority>>
{

    @Override
    public List<GrantedAuthority> convert(String source)
    {
        return AuthorityUtils.commaSeparatedStringToAuthorityList(source);
    }

}
