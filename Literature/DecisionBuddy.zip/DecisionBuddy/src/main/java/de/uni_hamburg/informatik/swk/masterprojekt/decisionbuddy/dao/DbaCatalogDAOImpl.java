package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.hibernate.jdbc.Work;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class DbaCatalogDAOImpl implements DbaCatalogDAO
{
    @PersistenceContext
    private EntityManager entityManager;

    public static final String CATALOG = "frameworks.csv";

    public static final String QUERY = "SELECT SolutionID, mvngroupid, mvnartefactid FROM Framework "
            + "WHERE mvngroupid<>'' and mvnartefactid<>''";

    @Override
    public void generateFrameworkCatalog()
    {
        deleteOldCatalog();
        Session session = (Session) entityManager.getDelegate();
        session.doWork(new Work()
        {

            @Override
            public void execute(Connection connection) throws SQLException
            {
                PreparedStatement pStmt = null;
                StringBuffer result = new StringBuffer(100);
                try
                {
                    pStmt = connection.prepareStatement(QUERY);
                    pStmt.execute();
                    ResultSet rs = pStmt.getResultSet();
                    rs.beforeFirst();
                    while (rs.next())
                    {
                        result.append(rs.getString(1));
                        result.append(";");
                        result.append(rs.getString(2));
                        result.append(";");
                        result.append(rs.getString(3));
                        result.append("\n");
                    }
                }
                finally
                {
                    if (pStmt != null)
                    {
                        pStmt.close();
                    }
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(catalogFilePath())))
                {
                    writer.write(result.toString());
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        });
    }

    private void deleteOldCatalog()
    {
        File catalog = new File(catalogFilePath());
        if (catalog.exists())
        {
            catalog.delete();
        }
    }

    public static String catalogFilePath()
    {
        String tmpdir = System.getProperty("java.io.tmpdir");
        String result = "";

        if (!(tmpdir.endsWith("/") || tmpdir.endsWith("\\")))
        {
            result = tmpdir + System.getProperty("file.separator") + CATALOG;
        }
        else
        {
            result = tmpdir + CATALOG;
        }

        return result;
    }

}
