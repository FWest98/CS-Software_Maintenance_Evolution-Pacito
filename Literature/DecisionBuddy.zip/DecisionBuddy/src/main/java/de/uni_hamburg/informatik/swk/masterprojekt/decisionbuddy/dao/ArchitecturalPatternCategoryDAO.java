package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;

/**
 * A DAO class for ArchitecturalPatternCategory.
 * 
 * @author Tim
 *
 */
public interface ArchitecturalPatternCategoryDAO extends JpaRepository<ArchitecturalPatternCategory, Long>
{

}
