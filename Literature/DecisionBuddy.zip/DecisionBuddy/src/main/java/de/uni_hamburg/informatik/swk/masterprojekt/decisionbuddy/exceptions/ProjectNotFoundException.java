package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a project is not found / does not exist
 * (anymore).
 * 
 * @author schaak
 *
 */
public class ProjectNotFoundException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public ProjectNotFoundException()
    {
        setExceptionType("projectnotfound");
    }
}