package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Component;

/**
 * Property editor to convert a Date to a String and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class DateEditor extends PropertyEditorSupport
{
    /**
     * Converts a String containing a date to an actual Date object.
     * 
     * @param dateString the String containing the Date
     */
    @Override
    public void setAsText(String dateString)
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd, HH:mm:ss");
        Date date = null;
        try
        {
            date = dateFormat.parse(dateString);
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }

        this.setValue(date);
    }

    /**
     * Converts a Date object to a String containing the date.
     * 
     * @return String containing date
     */
    @Override
    public String getAsText()
    {
        Format format = new SimpleDateFormat("yyyy-MM-dd, HH:mm:ss");
        String dateString = format.format((Date) this.getValue());

        return dateString;
    }
}