package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.designpattern;

import java.util.List;

import javassist.NotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementDesignPatternDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

@Service
@Transactional
public class DesignPatternComponentServiceImpl implements DesignPatternComponentService
{

    @Autowired
    private ElementDesignPatternDAO elementDesignPatternDAO;

    @Override
    public List<ElementDesignPattern> getDesignPatternsForElement(Long projectId, String classPath)
            throws NotFoundException
    {
        return elementDesignPatternDAO.findByProjectIdAndClassPath(projectId, classPath);
        // return new ArrayList<ElementDesignPattern>();
    }

    @Override
    public List<ElementDesignPattern> getDesignPatternsForProject(Long projectId, ElementType type)
            throws NotFoundException
    {
        return elementDesignPatternDAO.findByProjectIdAndType(projectId, type);
    }

}
