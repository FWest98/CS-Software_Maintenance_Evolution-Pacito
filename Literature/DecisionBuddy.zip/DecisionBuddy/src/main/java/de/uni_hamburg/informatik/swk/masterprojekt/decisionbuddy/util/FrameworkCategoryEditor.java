package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.FrameworkCategory;

/**
 * Property editor to convert an Id for a Framework category given as String to
 * an actual FrameworkCategory object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class FrameworkCategoryEditor extends PropertyEditorSupport
{
    /**
     * Converts a FrameworkCategory id to a FrameworkCategory object.
     * 
     * @param id the id of the Framework category
     */
    @Override
    public void setAsText(String id)
    {
        FrameworkCategory fc = new FrameworkCategory();
        fc.setId(Long.valueOf(id));

        this.setValue(fc);
    }

    /**
     * Converts a FrameworkCategory object to an the id.
     * 
     * @return id of the Framework Category
     */
    @Override
    public String getAsText()
    {
        FrameworkCategory fc = (FrameworkCategory) this.getValue();
        String parsedId = String.valueOf(fc.getId());
        return parsedId;
    }
}