package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTSCategory;

/**
 * A DAO class for COTSCategory.
 * 
 * @author Tim
 *
 */
public interface COTSCategoryDAO extends JpaRepository<COTSCategory, Long>
{

}
