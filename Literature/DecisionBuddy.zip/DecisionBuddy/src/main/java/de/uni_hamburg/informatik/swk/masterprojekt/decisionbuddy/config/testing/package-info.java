/**
 * This package contains the testing configuration.
 * 
 * @author Vlad
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.testing;