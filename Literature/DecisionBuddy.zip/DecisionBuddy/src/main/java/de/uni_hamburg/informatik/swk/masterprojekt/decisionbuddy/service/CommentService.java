package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.CommentPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.IssueNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Comment;

/**
 * Overview of interfaces of class CommentService.
 * 
 * @see architectural specification
 *
 * @author schaak
 *
 */
public interface CommentService
{
    /**
     * Adds an comment to the database.
     * 
     * @param comment the comment to be added
     * 
     * @return the saved comment object
     * 
     * @throws CommentPersistenceException Exception if Comment could not be
     *             persisted
     */
    Comment saveComment(Comment comment) throws CommentPersistenceException;

    /**
     * Finds an comment by given id.
     * 
     * @param id id of desired comment
     * 
     * @return desired comment
     * 
     * @throws CommentNotFoundException Exception if Comment is not found
     */
    Comment getCommentById(long id) throws CommentNotFoundException;

    /**
     * Finds all Comments that belong to the project with the specified ID.
     * 
     * @param id ID of the Solution
     * 
     * @return List of Comments that belong to the solution with id. List may be
     *         empty if no Comments were found.
     * 
     * @throws IssueNotFoundException if Issue is not found
     */
    List<Comment> getCommentsByIssueID(long id) throws IssueNotFoundException;
}