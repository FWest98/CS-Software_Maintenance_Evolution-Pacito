package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a project could not be written to the
 * database.
 * 
 * @author schaak
 *
 */
public class ProjectPersistenceException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public ProjectPersistenceException()
    {
        setExceptionType("projectpersistence");
    }
}
