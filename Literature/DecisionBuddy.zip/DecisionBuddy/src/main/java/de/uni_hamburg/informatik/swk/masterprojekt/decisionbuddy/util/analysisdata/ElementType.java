package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

public enum ElementType
{
    Package, File, Dummy, Undefined
}
