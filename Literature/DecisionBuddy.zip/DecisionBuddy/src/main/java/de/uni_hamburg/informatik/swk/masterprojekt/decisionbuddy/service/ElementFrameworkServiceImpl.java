package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.ElementFrameworkDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementFrameworkNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementFrameworkPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;

/**
 * Service class for managing projects.
 *
 * @author Oliver
 *
 */
@Service
@Transactional
public class ElementFrameworkServiceImpl implements ElementFrameworkService
{

    @Autowired
    private ElementFrameworkDAO elementFrameworkDAO;

    /**
     * Adds a new ElementFramework to the database.
     * 
     * @param elementFramework the ElementFramework to save
     * 
     * @return the saved ElementFramework object
     * 
     * @throws ElementFrameworkPersistenceException Exception if
     *             ElementFramework could not be persisted
     */
    @Override
    public ElementFramework saveElementFramework(ElementFramework elementFramework)
            throws ElementFrameworkPersistenceException
    {
        ElementFramework savedElementFramework;
        savedElementFramework = elementFrameworkDAO.saveAndFlush(elementFramework);

        if (savedElementFramework == null)
        {
            throw new ElementFrameworkPersistenceException();
        }

        return savedElementFramework;
    }

    /**
     * Deletes all ElementFrameworks which belong to the specified project.
     * 
     * @param id the id of the project which ElementFrameworks should be deleted
     * 
     * @throws ElementFrameworkNotFoundException Exception if ElementFramework
     *             is not found
     */
    @Override
    public void deleteElementFrameworksByProjectId(long projectId) throws ElementFrameworkNotFoundException
    {
        try
        {
            elementFrameworkDAO.deleteByProjectId(projectId);
        }
        catch (DataAccessException e)
        {
            throw new ElementFrameworkNotFoundException();
        }
    }
}