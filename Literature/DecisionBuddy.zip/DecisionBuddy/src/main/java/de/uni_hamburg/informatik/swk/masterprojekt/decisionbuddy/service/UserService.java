package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.Comparator;
import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Filter;

/**
 * User service delivers a CRUD interface for authorities.
 * 
 * @author Vlad
 *
 */
public interface UserService
{
    /**
     * Adds a given user to the database. User with given username must not be
     * already in the database.
     * 
     * @param user
     * @return
     * @throws UserPersistenceException
     */
    User saveUser(User user) throws UserPersistenceException;

    /**
     * Update an existing user.
     * 
     * @param user
     * @return
     * @throws UserPersistenceException
     */
    User editUser(User user) throws UserPersistenceException;

    /**
     * Find a user by given username.
     * 
     * @param userName
     * @return
     * @throws UserNotFoundException
     */
    User getUser(String userName) throws UserNotFoundException;

    /**
     * Get all users form DB.
     * 
     * @return
     */
    List<User> getUsers();

    /**
     * Delete a user by given username.
     * 
     * @param userName
     * @throws UserNotFoundException
     */
    void deleteUser(String userName) throws UserNotFoundException;

    /**
     * @param filter
     * @param sorter
     * @return
     */
    List<User> getUsersByCriteria(Filter<User> filter, Comparator<User> sorter);

}
