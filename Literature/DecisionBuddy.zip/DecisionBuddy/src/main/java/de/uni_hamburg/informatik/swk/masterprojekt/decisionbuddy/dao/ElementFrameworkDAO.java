package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * A DAO class for Framework.
 * 
 * @author Vlad
 *
 */
public interface ElementFrameworkDAO extends JpaRepository<ElementFramework, Long>
{
	@Query("SELECT ef FROM ElementFramework ef WHERE ef.project.id = ?1 AND ef.classPath = ?2 GROUP BY ef.solution, ef.classPath")
    List<ElementFramework> findByProjectIdAndClassPath(Long projectId, String classPath);

	@Query("SELECT ef FROM ElementFramework ef WHERE ef.project.id = ?1 AND ef.type = ?2 GROUP BY ef.solution, ef.classPath")
    List<ElementFramework> findByProjectIdAndType(Long projectId, ElementType type);

    void deleteByProjectId(Long projectId);
}
