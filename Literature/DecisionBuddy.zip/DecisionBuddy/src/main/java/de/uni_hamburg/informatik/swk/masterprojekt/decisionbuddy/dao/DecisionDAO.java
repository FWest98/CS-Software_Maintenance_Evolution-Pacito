package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;

/**
 * A DAO class for Decision.
 * 
 * @author Tim
 *
 */
public interface DecisionDAO extends JpaRepository<Decision, Long> {
}