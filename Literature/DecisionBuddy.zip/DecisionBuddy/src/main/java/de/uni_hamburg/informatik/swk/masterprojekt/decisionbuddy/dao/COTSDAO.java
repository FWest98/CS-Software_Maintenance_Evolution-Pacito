package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.COTS;

/**
 * A DAO class for COTS.
 * 
 * @author Tim
 *
 */
public interface COTSDAO extends JpaRepository<COTS, Long>
{

}
