package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

/**
 * A simple converter to convert input format. String input from view is
 * converted to an Integer value.
 * 
 * @author Vlad
 *
 */
public class IntegerEditor extends PropertyEditorSupport
{
    /**
     * Converts a string input to an Integer.
     * 
     * @param the integer value
     */
    @Override
    public void setAsText(String string)
    {
        if (string == null || string.isEmpty())
        {
            setValue(null);
        }
        else
        {
            Integer parsedString;

            try
            {
                parsedString = Integer.parseInt(string);
            }
            catch (NumberFormatException nfe)
            {
                parsedString = null;
            }
            setValue(parsedString);
        }
    }

    /**
     * Converts an Integer to a String output.
     * 
     * @return string value of integer
     */
    @Override
    public String getAsText()
    {
        if (getValue() == null)
        {
            return "";
        }
        else
        {
            try
            {
                Integer integer = (Integer) getValue();
                return integer.toString();
            }
            catch (NumberFormatException nfe)
            {
                return "";
            }
        }
    }
}
