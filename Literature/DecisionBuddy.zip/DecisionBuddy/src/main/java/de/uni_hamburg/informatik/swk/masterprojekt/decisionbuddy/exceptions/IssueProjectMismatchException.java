package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if Issue is not assigned to provided
 * Project.
 * 
 * @author schaak
 *
 */
public class IssueProjectMismatchException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public IssueProjectMismatchException()
    {
        setExceptionType("issueprojectmismatch");
    }
}