package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class validates a technical term.
 *
 * @author schaak
 *
 */
@Component
public class TechnicalTermValidator extends ExtendedValidator implements Validator
{
    /**
     * Tests if the validator can validate the given object.
     * 
     * @param object an object to be validated
     * @return boolean if the object can be validated as a technicalterm
     */
    @Override
    public boolean supports(Class<?> object)
    {
        return (TechnicalTerm.class).isAssignableFrom(object);
    }

    /**
     * Checks if a given technicalterm object is considered valid.
     * 
     * @param object the given object
     * @param errors collects encountered field errors
     */
    @Override
    public void validate(Object object, Errors errors)
    {
        checkMandatoryFields(errors);
        checkMaxLength(errors);

        // if type is string or stringint, then at least one string value has to
        // be present
        TechnicalTerm technicalTerm = (TechnicalTerm) object;
        if (technicalTerm.getType() != null && !technicalTerm.getType().equalsIgnoreCase("int"))
        {
            if (technicalTerm.getStringValues() == null || technicalTerm.getStringValues().isEmpty())
            {
                errors.rejectValue("type", "required.stringvalues", "No message definied.");
            }
        }
    }

    /**
     * Validates that fields don't exceed max length.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMaxLength(Errors errors)
    {
        rejectIfStringTooLong(errors, "identifier", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "unit", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
    }

    /**
     * Validates that mandatory fields are not empty.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMandatoryFields(Errors errors)
    {
        // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", REQUIRED_EC);
        ValidationUtils.rejectIfEmpty(errors, "identifier", ErrorCodes.REQUIRED);

    }
}