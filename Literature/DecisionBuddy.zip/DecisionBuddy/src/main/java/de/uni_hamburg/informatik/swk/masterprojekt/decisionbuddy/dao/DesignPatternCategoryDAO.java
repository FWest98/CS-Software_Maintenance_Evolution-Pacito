package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.DesignPatternCategory;

/**
 * A DAO class for DesignPattern.
 * 
 * @author Tim
 *
 */
public interface DesignPatternCategoryDAO extends
		JpaRepository<DesignPatternCategory, Long> {

}
