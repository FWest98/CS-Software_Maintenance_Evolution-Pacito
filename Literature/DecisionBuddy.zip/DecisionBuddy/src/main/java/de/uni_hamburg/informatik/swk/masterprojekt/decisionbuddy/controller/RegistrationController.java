package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AuthorityNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.UserPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Authority;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.User;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.AuthorityService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.UserService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.UserValidator;

@Controller
@RequestMapping(value = "/register")
public class RegistrationController
{
    @Autowired
    private UserService userService;

    @Autowired
    private UserValidator userValidator;

    @Autowired
    private AuthorityService authorityService;

    // @Autowired
    // private HelperFunctions helperFunctions;

    /**
     * 
     * @return
     * @throws UserPersistenceException
     */
    @RequestMapping(value = { "", "/" }, method = RequestMethod.GET)
    public ModelAndView showRegisterForm() throws UserPersistenceException
    {
        // User user = new User();
        ModelAndView registerView = new ModelAndView("index");
        registerView.addObject("jsp", "registrationform");
        return registerView;
    }

    /**
     * 
     * @param user
     * @param bindingResult
     * @param redirectAttributes
     * @return
     * @throws UserPersistenceException
     * @throws AuthorityNotFoundException
     */
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String submitRegistration(@ModelAttribute("user") User user, BindingResult bindingResult,
            RedirectAttributes redirectAttributes) throws UserPersistenceException, AuthorityNotFoundException
    {
        // Grant every user that registers the projec member role.
        Authority authority = authorityService.getAuthorityByName("ROLE_PROJECTMEMBER");
        ArrayList<Authority> authorities = new ArrayList<Authority>();
        authorities.add(authority);
        user.setAuthorities(authorities);

        // Validate user input
        userValidator.validate(user, bindingResult);
        if (bindingResult.hasErrors())
        {
            redirectAttributes.addFlashAttribute("user", user);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.user", bindingResult);
        }
        else
        {
            User savedUser;
            savedUser = userService.saveUser(user);

            redirectAttributes.addFlashAttribute("messagestatus", "success");
            redirectAttributes.addFlashAttribute("messagecode", "register.success");

            List<String> params = new ArrayList<String>();
            params.add(savedUser.getUsername());
            redirectAttributes.addFlashAttribute("messageparams", params);
        }

        return "redirect:/register";
    }

}
