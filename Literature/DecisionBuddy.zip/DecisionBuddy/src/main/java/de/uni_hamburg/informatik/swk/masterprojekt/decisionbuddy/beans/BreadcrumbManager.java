package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans;

import java.io.Serializable;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

/**
 * Builds and returns a collection of breadcrumb items for a specific action.
 * 
 * @author schaak
 *
 */
@Component
public class BreadcrumbManager implements Serializable
{
    private static final long serialVersionUID = 1L;
    private ArrayList<Breadcrumb> breadcrumbs;

    /**
     * Constructor to create Manager.
     */
    public BreadcrumbManager()
    {
        breadcrumbs = new ArrayList<Breadcrumb>();
    }

    /**
     * Returns a collection of Breadcrumb items for specific action.
     * 
     * @param action the action you want to generate breadcrumbs for
     * @param idList additional attributes
     * @return breadcrumbs a collection of breadcrumbs according to action
     */
    public ArrayList<Breadcrumb> getBreadcrumbs(String action, ArrayList<String> idList)
    {
        breadcrumbs = new ArrayList<Breadcrumb>();

        // If second argument contains non-numerical values, default to 0.
        // if (!idList.get(0).matches("[0-9]+"))
        // {
        // idList.set(0, "0");
        // }

        switch (action)
        {
            case "home":
                addWelcome();
                break;
            case "login":
                addLogin(); // View: Login
                break;
            case "showsolutions":
                addSolutionOverview();
                break;
            case "solutionprofile":
                addSolutionOverview();
                addSolutionProfile(idList.get(0));
                break;
            case "addsolution":
                addSolutionOverview();
                addAddSolution();
                break;
            case "addrating":
                addSolutionOverview();
                addSolutionProfile(idList.get(0));
                addAddRating(idList.get(0));
                break;
            case "editsolution":
                addSolutionOverview();
                addSolutionProfile(idList.get(0));
                addEditSolution(idList.get(0));
                break;
            case "deletesolution":
                addSolutionOverview();
                addSolutionProfile(idList.get(0));
                addDeleteSolution(idList.get(0));
                break;
            case "showprojects":
                addProjectOverview();
                break;
            case "projectprofile":
                addProjectOverview();
                addProjectProfile(idList.get(0));
                break;
            case "addproject":
                addProjectOverview();
                addAddProject();
                break;
            case "editproject":
                addProjectOverview();
                addProjectProfile(idList.get(0));
                addEditProject(idList.get(0));
                break;
            case "deleteproject":
                addProjectOverview();
                addProjectProfile(idList.get(0));
                addDeleteProject(idList.get(0));
                break;
            case "issueprofile":
                addProjectOverview();
                addProjectProfile(idList.get(1));
                addIssueProfile(idList.get(1), idList.get(0));
                break;
            case "addissue":
                addProjectOverview();
                addProjectProfile(idList.get(0));
                addAddIssue();
                break;
            case "addcomment":
                addProjectOverview();
                addProjectProfile(idList.get(0));
                addIssueProfile(idList.get(0), idList.get(1));
                addAddComment(idList.get(0), idList.get(1));
                break;
            case "editissue":
                addProjectOverview();
                addProjectProfile(idList.get(1));
                addIssueProfile(idList.get(1), idList.get(0));
                addEditIssue(idList.get(1), idList.get(0));
                break;
            case "deleteissue":
                addProjectOverview();
                addProjectProfile(idList.get(1));
                addIssueProfile(idList.get(1), idList.get(0));
                addDeleteIssue(idList.get(1), idList.get(0));
                break;
            case "showtechnicalterms":
                addTechnicalTermOverview();
                break;
            case "technicaltermprofile":
                addTechnicalTermOverview();
                addTechnicalTermProfile(idList.get(0));
                break;
            case "addtechnicalterm":
                addTechnicalTermOverview();
                addAddTechnicalTerm();
                break;
            case "edittechnicalterm":
                addTechnicalTermOverview();
                addTechnicalTermProfile(idList.get(0));
                addEditTechnicalTerm(idList.get(0));
                break;
            case "deletetechnicalterm":
                addTechnicalTermOverview();
                addTechnicalTermProfile(idList.get(0));
                addDeleteTechnicalTerm(idList.get(0));
                break;
            case "showusers":
                addUserOverview();
                break;
            case "userprofile":
                addUserOverview();
                addUserProfile(idList.get(0));
                break;
            case "adduser":
                addUserOverview();
                addAddUser();
                break;
            case "edituser":
                addUserOverview();
                addUserProfile(idList.get(0));
                addEditUser(idList.get(0));
                break;
            case "deleteuser":
                addUserOverview();
                addUserProfile(idList.get(0));
                addUserProfile(idList.get(0));
                break;
            case "addanalysisdata":
                addProjectOverview();
                addProjectProfile(idList.get(0));
                addAnalysisData();
                break;
            default:
                break;
        }
        return breadcrumbs;
    }

    /**
     * Home view. Helper method for adding Breadcrumb 'Welcome' to Breadcrumbs
     */
    public void addWelcome()
    {
        breadcrumbs.add(new Breadcrumb("home.welcome", "/home"));
    }

    /**
     * Login view. Helper method for adding Breadcrumb 'Login' to Breadcrumbs
     */
    private void addLogin()
    {
        breadcrumbs.add(new Breadcrumb("home.login", "/login"));
    }

    /**
     * Catalog view. Helper method for adding Breadcrumb 'Solutions overview' to
     * Breadcrumbs
     */
    public void addSolutionOverview()
    {
        breadcrumbs.add(new Breadcrumb("catalog.solutionoverview", "/catalog/list"));
    }

    /**
     * Catalog view. Helper method for adding Breadcrumb 'Solution xy' to
     * Breadcrumbs
     * 
     * @param id ID of solution to be displayed
     */
    public void addSolutionProfile(String id)
    {
        Breadcrumb breadcrumb = new Breadcrumb("catalog.solutionprofile", "/catalog/solution/" + id);
        breadcrumb.addParam(id);
        breadcrumbs.add(breadcrumb);
    }

    /**
     * Catalog view. Helper method for adding Breadcrumb 'Add solution' to
     * Breadcrumbs
     */
    public void addAddSolution()
    {
        breadcrumbs.add(new Breadcrumb("catalog.addsolution", "/catalog/add"));
    }

    /**
     * Catalog view. Helper method for adding Breadcrumb 'Edit solution' to
     * Breadcrumbs
     * 
     * @param id ID of solution to be edited
     */
    public void addEditSolution(String id)
    {
        breadcrumbs.add(new Breadcrumb("catalog.editsolution", "/catalog/edit/" + id));
    }

    /**
     * Catalog view. Helper method for adding Breadcrumb 'Delete solution' to
     * Breadcrumbs
     * 
     * @param id ID of solution to be deleted
     */
    public void addDeleteSolution(String id)
    {
        breadcrumbs.add(new Breadcrumb("catalog.deletesolution", "/catalog/delete/" + id));
    }

    /**
     * Catalog view. Helper method for adding Breadcrumb 'Add rating' to
     * Breadcrumbs
     */
    public void addAddRating(String id)
    {
        breadcrumbs.add(new Breadcrumb("catalog.addrating", "/catalog/solution/" + id + "/rating/add"));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Projects overview' to
     * Breadcrumbs
     */
    public void addProjectOverview()
    {
        breadcrumbs.add(new Breadcrumb("project.projectoverview", "/project/list"));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Project xy' to
     * Breadcrumbs
     * 
     * @param id ID of project to be displayed
     */
    public void addProjectProfile(String id)
    {
        Breadcrumb breadcrumb = new Breadcrumb("project.projectprofile", "/project/project/" + id);
        breadcrumb.addParam(id);
        breadcrumbs.add(breadcrumb);
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Add project' to
     * Breadcrumbs
     */
    public void addAddProject()
    {
        breadcrumbs.add(new Breadcrumb("project.addproject", "/project/add"));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Edit project' to
     * Breadcrumbs
     * 
     * @param id ID of project to be edited
     */
    public void addEditProject(String id)
    {
        breadcrumbs.add(new Breadcrumb("project.editproject", "/project/edit/" + id));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Delete project' to
     * Breadcrumbs
     * 
     * @param id ID of solution to be deleted
     */
    public void addDeleteProject(String id)
    {
        breadcrumbs.add(new Breadcrumb("project.deleteproject", "/project/delete/" + id));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Issue xy' to
     * Breadcrumbs
     * 
     * @param projectId ID of the corresponding project
     * @param id ID of issue to be displayed
     */
    public void addIssueProfile(String projectId, String id)
    {
        Breadcrumb breadcrumb = new Breadcrumb("project.issueprofile", "/project/project/" + projectId + "/issue/" + id);
        breadcrumb.addParam(id);
        breadcrumbs.add(breadcrumb);
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Add issue' to
     * Breadcrumbs
     */
    public void addAddIssue()
    {
        breadcrumbs.add(new Breadcrumb("project.addissue", "/project/project/issue/add"));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Edit issue' to
     * Breadcrumbs
     * 
     * @param projectId ID of corresponding project
     * @param id ID of issue to be edited
     */
    public void addEditIssue(String projectId, String id)
    {
        breadcrumbs.add(new Breadcrumb("project.editissue", "/project/project/" + projectId + "/issue/edit/" + id));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Delete issue' to
     * Breadcrumbs
     * 
     * @param projectId ID of corresponding project
     * @param id ID of issue to be deleted
     */
    public void addDeleteIssue(String projectId, String id)
    {
        breadcrumbs.add(new Breadcrumb("project.deleteissue", "/project/project/" + projectId + "/issue/delete/" + id));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Add comment' to
     * Breadcrumbs
     */
    public void addAddComment(String projectId, String id)
    {
        breadcrumbs.add(new Breadcrumb("project.addcomment", "/project/project/" + projectId + "/issue/" + id
                + "/comment/add"));
    }

    /**
     * Constraint view. Helper method for adding Breadcrumb 'TechnicalTerms
     * overview' to Breadcrumbs
     */
    public void addTechnicalTermOverview()
    {
        breadcrumbs.add(new Breadcrumb("constraint.technicaltermoverview", "/constraint/list"));
    }

    /**
     * Constraint view. Helper method for adding Breadcrumb 'TechnicalTerm xy'
     * to Breadcrumbs
     * 
     * @param id ID of technicalterm to be displayed
     */
    public void addTechnicalTermProfile(String id)
    {
        Breadcrumb breadcrumb = new Breadcrumb("constraint.technicaltermprofile", "/constraint/technicalterm/" + id);
        breadcrumb.addParam(id);
        breadcrumbs.add(breadcrumb);
    }

    /**
     * Constraint view. Helper method for adding Breadcrumb 'Add technicalterm'
     * to Breadcrumbs
     */
    public void addAddTechnicalTerm()
    {
        breadcrumbs.add(new Breadcrumb("constraint.addtechnicalterm", "/constraint/add"));
    }

    /**
     * Constraint view. Helper method for adding Breadcrumb 'Edit technicalterm'
     * to Breadcrumbs
     * 
     * @param id ID of technicalterm to be edited
     */
    public void addEditTechnicalTerm(String id)
    {
        breadcrumbs.add(new Breadcrumb("constraint.edittechnicalterm", "/constraint/edit/" + id));
    }

    /**
     * Constraint view. Helper method for adding Breadcrumb 'Delete
     * technicalterm' to Breadcrumbs
     * 
     * @param id ID of technicalterm to be deleted
     */
    public void addDeleteTechnicalTerm(String id)
    {
        breadcrumbs.add(new Breadcrumb("constraint.deletetechnicalterm", "/constraint/delete/" + id));
    }

    /**
     * User view. Helper method for adding Breadcrumb 'User overview' to
     * breadcrumbs.
     */
    public void addUserOverview()
    {
        breadcrumbs.add(new Breadcrumb("user.useroverview", "/user/list"));
    }

    /**
     * User view. Helper method for adding Breadcrumb 'User xy' to Breadcrumbs
     * 
     * @param username username of user to be displayer
     */
    public void addUserProfile(String username)
    {
        Breadcrumb breadcrumb = new Breadcrumb("user.userprofile", "/user/user/" + username);
        breadcrumb.addParam(username);
        breadcrumbs.add(breadcrumb);
    }

    /**
     * User view. Helper method for adding Breadcrumb 'User adding' to
     * breadcrumbs.
     */
    public void addAddUser()
    {
        breadcrumbs.add(new Breadcrumb("user.adduser", "/user/add"));
    }

    /**
     * User view. Helper method for editing Breadcrumb 'Edit user'
     * 
     * @param username the username
     */
    public void addEditUser(String username)
    {
        breadcrumbs.add(new Breadcrumb("user.edituser", "/user/edit/" + username));
    }

    /**
     * User view. Helper method for deleting Breadcrumb 'Edit user'
     * 
     * @param username the username
     */
    public void addDeleteUser(String username)
    {
        breadcrumbs.add(new Breadcrumb("user.deleteuser", "/user/delete/" + username));
    }

    /**
     * Project view. Helper method for adding Breadcrumb 'Add Analysis Data' to
     * Breadcrumbs
     */
    public void addAnalysisData()
    {
        breadcrumbs.add(new Breadcrumb("project.addanalysisdata", "/project/analysisdata/add"));
    }

    /**
     * Convenience method for compability.
     * 
     * @param action action
     * @return breadcrumbs List of Breadcrumbs
     * @see getBreadcrumbs(String action, String id)
     */
    public ArrayList<Breadcrumb> getBreadcrumbs(String action)
    {
        ArrayList<String> list = new ArrayList<String>();
        list.add("0");
        return getBreadcrumbs(action, list);
    }
}