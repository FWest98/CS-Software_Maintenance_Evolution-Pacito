package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * Overview of interfaces of class ElementService.
 * 
 * @see architectural specification
 *
 * @author Burak
 *
 */
public interface ElementService
{
    /**
     * Adds a given Element to the database.
     * 
     * @param element the element to be persisted
     * 
     * @return the saved element object
     * 
     * @throws ElementPersistenceException Exception if Element could not be
     *             persisted
     */
    Element saveElement(Element element) throws ElementPersistenceException;

    /**
     * Find an element by given id.
     * 
     * @param id the id of desired element
     * 
     * @return the matching element
     * 
     * @throws ElementNotFoundException Exception if Element is not found
     */
    Element getElementById(long id) throws ElementNotFoundException;

    /**
     * Delete an element by given id.
     * 
     * @param id the id of the element that should be deleted
     * 
     * @throws ElementNotFoundException Exception if Element is not found
     */
    void deleteElement(long id) throws ElementNotFoundException;

    /**
     * Find an element by given element name.
     * 
     * @param elementName
     * @return element corresponding to the name
     * @throws ElementNotFoundException
     */
    Element getElementByName(String elementName) throws ElementNotFoundException;

    /**
     * Find elements by given parent id.
     * 
     * @param parentId
     * @return childNotes all child nodes of a given parent id, returns empty
     *         list if no children exist
     */
    List<Element> getElementsByParentId(Long parentId);

    /**
     * Get a list of all elements that belong to the type.
     * 
     * @param type the type of the elements that should be found
     * 
     * @return List of all elements
     */
    List<Element> getElementsByType(ElementType type);

    /**
     * Get a list of all elements that belong to the project.
     * 
     * @param id the id of desired project
     * 
     * @return List of all matching elements
     */
    List<Element> getElementsByProjectId(long id);

    /**
     * Get the element that belong to the project and parent.
     * 
     * @param id the id of desired project
     * 
     * @param parentString the id of the parent string
     * 
     * @return List of all matching elements
     */
    Element getElementByProjectIdAndName(long projectId, String name) throws ElementNotFoundException,
            ProjectNotFoundException;
}