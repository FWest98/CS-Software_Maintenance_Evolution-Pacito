package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ArchitecturalPatternCategory;

/**
 * Property editor to convert an Id for an Architectural pattern category given
 * as String to an actual ArchitecturalPattern object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class ArchitecturalPatternCategoryEditor extends PropertyEditorSupport
{
    /**
     * Converts an ArchitecturalPattern id to a ArchitecturalPatternCategory
     * object.
     * 
     * @param id the id of the Architectural pattern category
     */
    @Override
    public void setAsText(String id)
    {
        ArchitecturalPatternCategory apc = new ArchitecturalPatternCategory();
        apc.setId(Long.valueOf(id));

        this.setValue(apc);
    }

    /**
     * Converts an ArchitecturalPatternCategory object to an the id.
     * 
     * @return id of the Architectural pattern Category
     */
    @Override
    public String getAsText()
    {
        ArchitecturalPatternCategory apc = (ArchitecturalPatternCategory) this.getValue();
        String parsedId = String.valueOf(apc.getId());
        return parsedId;
    }
}