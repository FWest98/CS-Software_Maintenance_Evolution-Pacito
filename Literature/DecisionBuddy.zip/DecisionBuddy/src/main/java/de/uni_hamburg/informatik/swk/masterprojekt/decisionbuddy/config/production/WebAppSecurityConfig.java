package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthenticationProviderImpl;

/**
 * Config class for Security (Roles, Permissions, Filters etc.).
 * 
 * @author Vlad
 *
 */
@Configuration
@EnableWebMvcSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebAppSecurityConfig extends WebSecurityConfigurerAdapter
{
    // @Autowired
    // private UserDetailsService userDetailService;

    @Autowired
    private AuthenticationProviderImpl authenticationProviderImpl;

    /**
     * Configures in memory users and their login credentials.
     * 
     * @param auth a AuthenticationManagerBuilder that builds users, permissions
     *            etc.
     * @throws Exception throws exception
     */
    @Autowired
    public void configureGlobal(DataSource dataSource, AuthenticationManagerBuilder auth) throws Exception
    {
        // auth.jdbcAuthentication().dataSource(dataSource);
        //
        // .usersByUsernameQuery("SELECT `username`, `password`, `enabled` FROM `users` WHERE username=?");

        // auth.userDetailsService(userDetailService).passwordEncoder(new
        // Md5PasswordEncoder());

        auth.authenticationProvider(authenticationProviderImpl);
    }

    /**
     * Configures which resources are ignored by security-filter. In this case
     * the /resources folder containing CSS, JavaScript and images.
     */
    @Override
    public void configure(WebSecurity webSecurity)
    {
        // Exlude ressources from security filter (necessary for css, js and
        // images to work before logged in)
        webSecurity.ignoring().antMatchers("/resources/**");
    }

    /**
     * Configures the mapping of user permissions to resources.
     */
    @Override
    public void configure(HttpSecurity http) throws Exception
    {
        http
        // disable csfr token. Anything else would require to massively update
        // the views.
        .csrf().disable()
        //
                .formLogin()
                //
                .loginProcessingUrl("/login")
                //
                .loginPage("/login")
                //
                .failureUrl("/login?error")
                //
                .and()
                //
                .exceptionHandling()
                //
                .accessDeniedPage("/error403");
    }
}
