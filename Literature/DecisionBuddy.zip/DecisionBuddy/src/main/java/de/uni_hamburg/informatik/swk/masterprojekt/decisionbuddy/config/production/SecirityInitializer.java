package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.config.production;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecirityInitializer extends AbstractSecurityWebApplicationInitializer
{

}
