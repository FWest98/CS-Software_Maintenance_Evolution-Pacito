package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

import org.springframework.security.core.AuthenticationException;

/**
 * An exception class that is thrown if a user is not found / does not exist
 * (anymore).
 * 
 * @author Vlad
 *
 */
public class CustomAuthenticationException extends AuthenticationException
{
    private static final long serialVersionUID = 1L;

//    private String exceptionType;

    public CustomAuthenticationException(String msg)
    {
        super(msg);
    }
}