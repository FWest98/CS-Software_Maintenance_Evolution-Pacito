package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.MetricValueDAO;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricValuePersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

/**
 * ServiceClass for managing MetricValues.
 * 
 * @author Burak
 *
 */
@Service
@Transactional
public class MetricValueServiceImpl implements MetricValueService
{

    @Autowired
    private MetricValueDAO metricValueDAO;

    @Autowired
    private ElementService elementService;

    @Autowired
    private MetricService metricService;

    @Override
    public MetricValue saveMetricValue(MetricValue metricValue) throws MetricValuePersistenceException
    {
        MetricValue savedMetricValue = metricValueDAO.saveAndFlush(metricValue);

        if (savedMetricValue == null)
        {
            throw new MetricValuePersistenceException();
        }

        return savedMetricValue;
    }

    @Override
    public List<MetricValue> getMetricValuesByElementID(long id) throws ElementNotFoundException
    {
        Element element = elementService.getElementById(id);

        return metricValueDAO.findByElementId(element.getId());
    }

    @Override
    public MetricValue getMetricValueByMetricID(long id) throws MetricNotFoundException
    {
        Metric metric = metricService.getMetricById(id);

        return metricValueDAO.findByMetricId(metric.getId());
    }

    @Override
    public List<MetricValue> getMetricValuesByProjectIDAndTypeAndSubType(long projectid, MetricType type,
            MetricSubType subtype)
    {
        return metricValueDAO.findByMetric_TypeAndMetric_SubTypeAndElement_Project(projectid, type, subtype);
    }

    @Override
    public List<MetricValue> getMetricValuesByElementIDAndType(long elementid, MetricType type)
    {
        return metricValueDAO.findByElementIdAndMetric_Type(elementid, type);
    }
}
