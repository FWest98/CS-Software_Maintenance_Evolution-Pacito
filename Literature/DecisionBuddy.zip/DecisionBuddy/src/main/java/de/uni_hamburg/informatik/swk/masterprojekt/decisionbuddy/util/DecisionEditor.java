package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Decision;

/**
 * Property editor to convert an Id for a Decision given as String to an actual
 * Decision object and vice versa.
 * 
 * @author schaak
 *
 */
@Component
public class DecisionEditor extends PropertyEditorSupport
{
    /**
     * Converts a Decision id to a Decision object.
     * 
     * @param id the id of the Decision
     */
    @Override
    public void setAsText(String id)
    {
        Decision decision = new Decision();

        if (id != null)
        {
            decision.setId(Long.valueOf(id));

        }

        this.setValue(decision);
    }

    /**
     * Converts a Decision object to an the id.
     * 
     * @return id of the Decision
     */
    @Override
    public String getAsText()
    {
        Decision decision = (Decision) this.getValue();
        String parsedId = String.valueOf(decision.getId());
        return parsedId;
    }
}