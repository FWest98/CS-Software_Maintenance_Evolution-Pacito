package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * This Class represents the Issue_QualityGoal table from the database.
 *
 * @author Tim
 *
 */
@Entity
@IdClass(value = WeightedQualityGoalPK.class)
@Table(name = "Issue_QualityGoal")
public class WeightedQualityGoal implements Serializable
{
    private static final long serialVersionUID = 1L;

    @Id
    @ManyToOne(targetEntity = QualityGoal.class, optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "QualityGoalID", referencedColumnName = "ID", nullable = false)
    private QualityGoal       qualityGoal;

    @Id
    @ManyToOne(targetEntity = Issue.class, optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "IssueID", referencedColumnName = "ID", nullable = false)
    private Issue             issue;

    @Column(name = "Weight", nullable = false, columnDefinition = "TINYINT(4)")
    private int               weight;

    public QualityGoal getQualityGoal()
    {
        return qualityGoal;
    }

    public void setQualityGoal(QualityGoal qualityGoal)
    {
        this.qualityGoal = qualityGoal;
    }

    public Issue getIssue()
    {
        return issue;
    }

    public void setIssue(Issue issue)
    {
        this.issue = issue;
    }

    public int getWeight()
    {
        return weight;
    }

    public void setWeight(int weight)
    {
        this.weight = weight;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((issue == null) ? 0 : issue.hashCode());
        result = prime * result + ((qualityGoal == null) ? 0 : qualityGoal.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        WeightedQualityGoal other = (WeightedQualityGoal) obj;
        if (issue == null)
        {
            if (other.issue != null)
            {
                return false;
            }
        }
        else if (!issue.equals(other.issue))
        {
            return false;
        }
        if (qualityGoal == null)
        {
            if (other.qualityGoal != null)
            {
                return false;
            }
        }
        else if (!qualityGoal.equals(other.qualityGoal))
        {
            return false;
        }
        return true;
    }

}
