/**
 * This package contains classes needed for inline editing.
 * 
 * @author schaak
 *
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax;