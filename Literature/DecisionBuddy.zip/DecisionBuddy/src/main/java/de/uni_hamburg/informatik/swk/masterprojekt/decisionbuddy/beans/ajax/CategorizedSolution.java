package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax;

import java.io.Serializable;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Solution;

/**
 * An instance of this class represents a categorized solution object. These
 * objects are shown in quicksearch on solution catalog
 *
 * @author schaak
 * 
 */
public class CategorizedSolution implements Serializable
{
    private static final long serialVersionUID = 1L;

    private Long solutionId;
    private String label;
    private String solutionType;

    /**
     * Constructor to create a CategorizedSolution object.
     * 
     */
    public CategorizedSolution()
    {

    }

    /**
     * Constructor to create an object based on a solution.
     * 
     * @param solution the backing solution object
     */
    public CategorizedSolution(Solution solution)
    {
        setSolutionId(solution.getId());
        setLabel(solution.getName());
        setSolutionType(solution.getType());
    }

    public Long getSolutionId()
    {
        return this.solutionId;
    }

    public void setSolutionId(Long solutionId)
    {
        this.solutionId = solutionId;
    }

    public String getLabel()
    {
        return this.label;
    }

    public void setLabel(String label)
    {
        this.label = label;
    }

    public String getSolutionType()
    {
        return this.solutionType;
    }

    public void setSolutionType(String solutionType)
    {
        this.solutionType = solutionType;
    }
}