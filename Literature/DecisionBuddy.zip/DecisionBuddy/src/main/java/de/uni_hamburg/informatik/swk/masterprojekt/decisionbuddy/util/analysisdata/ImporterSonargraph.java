package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultParsingException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.AnalysisResultPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementMetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementMetricPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.MetricNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ProjectNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Element;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementMetric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Metric;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.MetricValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Project;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementMetricService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ElementService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.MetricService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.ProjectService;

/**
 * Importer for Sonargraph output files.
 * 
 * @author 1vietor
 *
 */
@Component
public class ImporterSonargraph extends Importer
{
    private static final int FLUSH_LIMIT = 20;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private ElementService elementService;

    @Autowired
    private ElementMetricService elementMetricService;

    @Autowired
    private MetricService metricService;

    // @Autowired
    // private MetricValueService metricValueService;

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    protected String[] getValidFileIndicators()
    {
        String[] lineBeginnings = { "<?xml", "<ns2:report xmlns:ns2=\"http://www.hello2morrow.com/sonargraph/" };
        return lineBeginnings;
    }

    private String removeLastDot(String str)
    {
        return str.substring(0, str.lastIndexOf("."));
    }

    /**
     * Ersetzt Slashes durch Punkte. <br>
     * Beispiel-Input: ./de/uni_hamburg/package/KlassenName.java <br>
     * Beispiel-Output: de.uni_hamburg.package.KlassenName
     * 
     * @param path
     * @return path with dots instead of slashes
     */
    private String changePathToPackageStrucutre(String path)
    {
        path = path.substring(2, path.lastIndexOf(".")); // entfernt ./ sowie
                                                         // .java
        return path.replace('/', '.');
    }

    @Override
    public boolean importFile(Integer projectId, String filePath) throws AnalysisResultException
    {
        long start = System.currentTimeMillis();

        removeOldData(projectId);

        try
        {
            File inputFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder;

            dBuilder = dbFactory.newDocumentBuilder();
            Project project = projectService.getProjectById(projectId);
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            XPath xPath = XPathFactory.newInstance().newXPath();

            // JavaLogicalModuleNamespace = packages
            // JavaInternalCompilationUnit = .java Datei
            String elementPackageExpression = "//moduleElements/element[@kind='JavaLogicalModuleNamespace' or @kind='JavaInternalCompilationUnit']";
            NodeList elementPackageNodes = (NodeList) xPath.compile(elementPackageExpression).evaluate(doc,
                    XPathConstants.NODESET);

            // alle Element IDs und Namen zwischenspeichern
            Map<String, String> elementMapPackages = new TreeMap<String, String>();
            Map<String, String> elementMapFiles = new TreeMap<String, String>();

            int minOccurences = Integer.MAX_VALUE;
            String minOccurencesPackage = "";
            for (int i = 0; i < elementPackageNodes.getLength(); i++)
            {
                NamedNodeMap elementPackageAttrs = elementPackageNodes.item(i).getAttributes();

                // ID des Elementes vom Typ Package
                String elementPackageId = elementPackageAttrs.getNamedItem("id").getNodeValue();
                // Name des Elementes vom Typ Package
                String elementPackageName = elementPackageAttrs.getNamedItem("presentationName").getNodeValue();

                if (elementPackageAttrs.getNamedItem("kind").getNodeValue().equals("JavaLogicalModuleNamespace"))
                {
                    // für Packages
                    int occurance = StringUtils.countOccurrencesOf(elementPackageName, ".");
                    if (occurance < minOccurences)
                    {
                        minOccurences = occurance;
                        minOccurencesPackage = elementPackageName;
                    }
                    elementMapPackages.put(elementPackageId, elementPackageName);
                }
                else
                {
                    // für Java-Dateien
                    elementMapFiles.put(elementPackageId, changePathToPackageStrucutre(elementPackageName));
                }
            }

            // root Element erzeugen & speichern
            String rootElementPackage = removeLastDot(minOccurencesPackage);
            Element rootElement = new Element();
            rootElement.setName(rootElementPackage);
            rootElement.setParent(null);
            rootElement.setType(ElementType.Package); // root-package
            rootElement.setProject(project);
            elementService.saveElement(rootElement);

            // ElementMetric-Eintrag erstellen
            ElementMetric elementMetric = new ElementMetric();
            elementMetric.setElement(rootElement);
            elementMetric.setProject(project);
            // FIXME aktuell eingeloggten Username einfügen
            elementMetric.setCreator(AnalysisFileFormat.Sonargraph.toString());

            elementMetricService.saveElementMetric(elementMetric);

            savePackageElements(projectId, project, elementMapPackages);

            saveJavaFileElements(projectId, project, elementMapFiles);

            // gewünschte Metriken (Baum und Details, KEINE Systemmetriken) aus
            // DB laden
            // List<Metric> wantedMetrics = metricService.getMetricCatalog();
            List<Metric> wantedMetrics = metricService.getMetricsByType(MetricType.Structural);
            wantedMetrics.addAll(metricService.getMetricsByType(MetricType.Additional));

            // gewünschte Metrik-Namen in Liste zwischenspeichern
            List<String> wantedMetricNames = new ArrayList<String>();
            for (Metric metric : wantedMetrics)
            {
                wantedMetricNames.add(metric.getNameXml());
            }

            String metricsListExpression = "//metrics/metric";
            NodeList metricsListNodes = (NodeList) xPath.compile(metricsListExpression).evaluate(doc,
                    XPathConstants.NODESET);

            // gewünschte Metrik-IDs aus XML zwischenspeichern
            Map<String, String> wantedMetricsMap = new HashMap<String, String>();
            for (int i = 0; i < metricsListNodes.getLength(); i++)
            {
                Node currNode = metricsListNodes.item(i);
                if (currNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    org.w3c.dom.Element metricElement = (org.w3c.dom.Element) currNode;
                    String metricName = metricElement.getAttribute("presentationName");
                    if (wantedMetricNames.contains(metricName))
                    {
                        wantedMetricsMap.put(metricElement.getAttribute("id"), metricName);
                    }
                }
            }

            HashMap<KeyMetricAggr, MetricAggregation> aggrMap = saveElementsMetricValues(projectId, doc, xPath,
                    elementMapPackages, elementMapFiles, wantedMetricsMap);

            saveAggregatedElementsMetricValues(aggrMap);

            Map<String, String> wantedSystemMetricsMap = saveSystemMetrics(projectId, project, metricsListNodes);
            saveSystemMetricValues(projectId, doc, xPath, wantedSystemMetricsMap);
        }
        catch (ParserConfigurationException | NumberFormatException | SAXException | IOException
                | XPathExpressionException | ElementNotFoundException e)
        {
            e.printStackTrace();
            throw new AnalysisResultParsingException();
        }
        catch (ElementPersistenceException | ElementMetricPersistenceException | ProjectNotFoundException
                | ElementMetricNotFoundException | MetricNotFoundException e)
        {
            e.printStackTrace();
            throw new AnalysisResultPersistenceException();
        }

        long time = System.currentTimeMillis() - start;
        System.out.println("SonargraphImporter: " + time + "ms (" + (time / 1000) + "s)");
        return true;
    }

    /**
     * Deletes all analysis data of the selected project.
     * 
     * @param projectId
     */
    private void removeOldData(Integer projectId)
    {
        try
        {
            ElementMetric elemMetric = elementMetricService.getElementMetricByProjectId(projectId);
            Element elem = elemMetric.getElement();
            // rootElement löschen; cascadierend werden dadurch alle anderen
            // Metrik-Daten dieses Projektes gelöscht
            elementService.deleteElement(elem.getId());
        }
        catch (ElementMetricNotFoundException | ElementNotFoundException e)
        {
        }
    }

    /**
     * Save all Elements on package level.
     * 
     * @param projectId
     * @param project
     * @param elementMapPackages
     * @throws ProjectNotFoundException
     * @throws ElementNotFoundException
     * @throws ElementPersistenceException
     */
    private void savePackageElements(Integer projectId, Project project, Map<String, String> elementMapPackages)
            throws ProjectNotFoundException, ElementNotFoundException, ElementPersistenceException
    {
        // alle Package-Elemente in DB speichern
        List<String> list = new ArrayList<String>(elementMapPackages.values());

        Comparator<String> stringLengthComparator = new Comparator<String>()
        {
            @Override
            public int compare(String o1, String o2)
            {
                if (o1.length() != o2.length())
                {
                    return o1.length() - o2.length();
                }
                return o1.compareTo(o2);
            }
        };
        // Package-Namen der Länge nach sortieren; sonst wird ggf. erst ein
        // Unterpaket gespeichert, für das kein Parent gefunden werden kann
        Collections.sort(list, stringLengthComparator);

        for (String elem : list)
        {
            String elementName = elem;
            Element element = new Element();
            element.setName(elementName);
            element.setProject(project);

            String parentString = removeLastDot(elementName);
            Element parent = null;
            try
            {
                parent = elementService.getElementByProjectIdAndName(projectId, parentString);
            }
            catch (ElementNotFoundException e)
            {
                // grandparent erzeugen
                parent = new Element();
                parent.setName(parentString);
                parent.setProject(project);
                String grandParentString = removeLastDot(parentString);
                Element grandParent = elementService.getElementByProjectIdAndName(projectId, grandParentString);
                parent.setParent(grandParent);
                parent.setType(ElementType.Package);

                elementService.saveElement(parent);
            }
            element.setParent(parent);
            element.setType(ElementType.Package);
            elementService.saveElement(element);
        }
    }

    /**
     * Save all Elements on Java file level.
     * 
     * @param projectId
     * @param project
     * @param elementMapFiles
     * @throws ProjectNotFoundException
     */
    private void saveJavaFileElements(Integer projectId, Project project, Map<String, String> elementMapFiles)
            throws ProjectNotFoundException
    {
        // alle JavaFile-Elemente in DB speichern
        int counterInserts = 0;
        // begin: session Elements (Java-File)
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        for (Map.Entry<String, String> elem : elementMapFiles.entrySet())
        {
            String elementName = elem.getValue();
            Element element = new Element();
            element.setName(elementName);
            element.setProject(project);
            String parentString = removeLastDot(elementName);
            Element parent = null;
            try
            {
                parent = elementService.getElementByProjectIdAndName(projectId, parentString);
            }
            catch (ElementNotFoundException e)
            {
                // TODO ggf. Parsing Exception?
                System.err.println("Element " + elementName + " besitzt kein Parent-Package");
            }
            element.setParent(parent);
            element.setType(ElementType.File); // Java-Datei

            session.save(element);

            if (counterInserts % FLUSH_LIMIT == 0)
            {
                session.flush();
                session.clear();
            }
            ++counterInserts;
        }
        tx.commit();
        session.close();
        // end: session Elements (Java-File)
    }

    /**
     * Save all MetricValues on non-system level.
     * 
     * @param projectId
     * @param doc
     * @param xPath
     * @param elementMapPackages
     * @param elementMapFiles
     * @param wantedMetricsMap
     * @return aggregated values
     * @throws MetricNotFoundException
     * @throws XPathExpressionException
     * @throws ElementNotFoundException
     * @throws ProjectNotFoundException
     */
    private HashMap<KeyMetricAggr, MetricAggregation> saveElementsMetricValues(Integer projectId, Document doc,
            XPath xPath, Map<String, String> elementMapPackages, Map<String, String> elementMapFiles,
            Map<String, String> wantedMetricsMap) throws MetricNotFoundException, XPathExpressionException,
            ElementNotFoundException, ProjectNotFoundException
    {
        // begin: session MetricValues (Elements)
        int counterInserts = 0;
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Set<String> wantedElementIds = new HashSet<String>();
        wantedElementIds.addAll(elementMapPackages.keySet());
        wantedElementIds.addAll(elementMapFiles.keySet());

        Map<String, String> elementMapAll = elementMapPackages;
        elementMapAll.putAll(elementMapFiles);

        HashMap<KeyMetricAggr, MetricAggregation> aggrMap = new HashMap<KeyMetricAggr, MetricAggregation>();

        for (Map.Entry<String, String> metric : wantedMetricsMap.entrySet())
        {
            // Metric currMetric =
            // metricService.getMetricByNameXml(metric.getValue();
            Metric currMetric = null;
            try
            {
                currMetric = metricService.getMetricByNameXmlAndType(metric.getValue(), MetricType.Structural);
            }
            catch (MetricNotFoundException e)
            {
                currMetric = metricService.getMetricByNameXmlAndType(metric.getValue(), MetricType.Additional);
            }

            String wantedMetricValuesExpression = "//moduleMetrics/level//metric[@ref='" + metric.getKey()
                    + "']/*[self::float or self::int]";
            NodeList wantedMetricValuesNodes = (NodeList) xPath.compile(wantedMetricValuesExpression).evaluate(doc,
                    XPathConstants.NODESET);

            for (int i = 0; i < wantedMetricValuesNodes.getLength(); i++)
            {
                Node currNode = wantedMetricValuesNodes.item(i);
                if (currNode.getNodeType() == Node.ELEMENT_NODE)
                {
                    org.w3c.dom.Element currElement = (org.w3c.dom.Element) currNode;
                    String currMetricValueId = currElement.getAttribute("ref");
                    if (wantedElementIds.contains(currMetricValueId))
                    {
                        MetricValue metricValue = new MetricValue();
                        metricValue.setMetric(currMetric);
                        Element currElementDb = elementService.getElementByProjectIdAndName(projectId,
                                elementMapAll.get(currMetricValueId));
                        metricValue.setElement(currElementDb);
                        float currValue = Float.parseFloat(currNode.getFirstChild().getNodeValue());
                        metricValue.setValue(currValue);

                        session.save(metricValue);

                        MetricAggrFunction aggrFunction = currMetric.getAggrFunction();
                        if (aggrFunction != null)
                        {
                            switch (aggrFunction)
                            {
                                case Average:
                                case Sum:
                                case Count:
                                case Minimum:
                                case Maximum:
                                    Element parent = currElementDb.getParent();
                                    KeyMetricAggr currKey = new KeyMetricAggr(currMetric, parent);
                                    MetricAggregation metrAggr = aggrMap.get(currKey);
                                    if (metrAggr == null)
                                    {
                                        metrAggr = new MetricAggregation(aggrFunction);
                                        aggrMap.put(currKey, metrAggr);
                                    }
                                    metrAggr.add(currValue);
                                    break;
                                default:
                                    // median and mode are not implemented
                                    // yet
                                    break;
                            }
                        }

                        if (counterInserts % FLUSH_LIMIT == 0)
                        {
                            session.flush();
                            session.clear();
                        }
                        ++counterInserts;
                    }
                }
            }
        }
        tx.commit();
        session.close();
        // end: session MetricValues (Elements)
        return aggrMap;
    }

    /**
     * Save all aggregated MetricValues on non-system level.
     * 
     * @param aggrMap
     */
    private void saveAggregatedElementsMetricValues(HashMap<KeyMetricAggr, MetricAggregation> aggrMap)
    {
        // begin: session aggregation MetricValues (Elements)
        int counterInserts = 0;
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        for (Entry<KeyMetricAggr, MetricAggregation> currAggr : aggrMap.entrySet())
        {
            KeyMetricAggr keyMetricAggr = currAggr.getKey();
            Element element = keyMetricAggr.getElement();
            Metric metric = keyMetricAggr.getMetric();
            MetricAggregation metricAggr = currAggr.getValue();

            MetricValue metricValue = new MetricValue();
            metricValue.setMetric(metric);
            metricValue.setElement(element);

            metricValue.setValue(metricAggr.getValue());

            session.save(metricValue);

            if (counterInserts % FLUSH_LIMIT == 0)
            {
                session.flush();
                session.clear();
            }
            ++counterInserts;
        }
        tx.commit();
        session.close();
        // end: session aggregation MetricValues (Elements)
    }

    /**
     * Save all Metrics on system level.
     * 
     * @param projectId
     * @param project
     * @param metricsListNodes
     * @return metric IDs that should be processed
     * @throws ElementMetricNotFoundException
     * @throws ElementPersistenceException
     */
    private Map<String, String> saveSystemMetrics(Integer projectId, Project project, NodeList metricsListNodes)
            throws ElementMetricNotFoundException, ElementPersistenceException
    {
        Element rootElement;
        // begin: System-Metriken
        rootElement = elementMetricService.getElementMetricByProjectId(projectId).getElement();

        // Dummy-Systemelement für Systemmetriken
        Element sysMetricElement = new Element();
        sysMetricElement.setName("System_" + projectId);
        sysMetricElement.setProject(project);
        sysMetricElement.setParent(rootElement);
        sysMetricElement.setType(ElementType.Dummy);
        elementService.saveElement(sysMetricElement);

        // gewünschte Metriken (Systemmetriken) aus DB laden
        List<Metric> wantedSystemMetrics = metricService.getMetricsByType(MetricType.Global);

        // gewünschte Metrik-Namen in Liste zwischenspeichern
        List<String> wantedSystemMetricNames = new ArrayList<String>();
        for (Metric metric : wantedSystemMetrics)
        {
            wantedSystemMetricNames.add(metric.getNameXml());
        }

        // gewünschte Metrik-IDs aus XML zwischenspeichern
        Map<String, String> wantedSystemMetricsMap = new HashMap<String, String>();
        for (int i = 0; i < metricsListNodes.getLength(); i++)
        {
            Node currNode = metricsListNodes.item(i);
            if (currNode.getNodeType() == Node.ELEMENT_NODE)
            {
                org.w3c.dom.Element metricElement = (org.w3c.dom.Element) currNode;
                String metricName = metricElement.getAttribute("presentationName");
                if (wantedSystemMetricNames.contains(metricName))
                {
                    wantedSystemMetricsMap.put(metricElement.getAttribute("id"), metricName);
                }
            }
        }
        return wantedSystemMetricsMap;
    }

    /**
     * Extract all MetricValues on system level and save them in the database.
     * 
     * @param projectId
     * @param doc
     * @param xPath
     * @param wantedSystemMetricsMap
     * @throws ElementNotFoundException
     * @throws ProjectNotFoundException
     * @throws MetricNotFoundException
     * @throws XPathExpressionException
     */
    private void saveSystemMetricValues(Integer projectId, Document doc, XPath xPath,
            Map<String, String> wantedSystemMetricsMap) throws ElementNotFoundException, ProjectNotFoundException,
            MetricNotFoundException, XPathExpressionException
    {
        Element systemElement = elementService.getElementByProjectIdAndName(projectId, "System_" + projectId);
        // begin: session MetricValues (System)
        int counterInserts = 0;
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        for (Map.Entry<String, String> metric : wantedSystemMetricsMap.entrySet())
        {
            Metric currMetric = metricService.getMetricByNameXmlAndType(metric.getValue(), MetricType.Global);

            String wantedMetricValuesExpression = "//systemMetrics/level//metric[@ref='" + metric.getKey()
                    + "']/*[self::float or self::int]";
            NodeList wantedMetricValuesNodes = (NodeList) xPath.compile(wantedMetricValuesExpression).evaluate(doc,
                    XPathConstants.NODESET);

            Node currNode = wantedMetricValuesNodes.item(0);
            if (currNode.getNodeType() == Node.ELEMENT_NODE)
            {
                MetricValue metricValue = new MetricValue();
                metricValue.setMetric(currMetric);
                metricValue.setElement(systemElement);
                metricValue.setValue(Float.parseFloat(currNode.getFirstChild().getNodeValue()));

                session.save(metricValue);

                if (counterInserts % FLUSH_LIMIT == 0)
                {
                    session.flush();
                    session.clear();
                }
                ++counterInserts;
            }
        }
        tx.commit();
        session.close();
        // end: session MetricValues (System)
    }

    class MetricAggregation
    {
        // TODO missing implementation of median and mode
        private final MetricAggrFunction aggrFunc;
        private int count = 0;
        private float sum = 0f;
        private float minimum = 0f;
        private float maximum = 0f;

        MetricAggregation(MetricAggrFunction aggrFunction)
        {
            this.aggrFunc = aggrFunction;
        }

        public void add(float value)
        {
            if (value < minimum)
            {
                minimum = value;
            }
            else if (value > maximum)
            {
                maximum = value;
            }
            ++count;
            sum += value;
        }

        public float getValue()
        {
            float value = 0f;
            switch (getAggrFunction())
            {
                case Average:
                    value = getAvg();
                    break;
                case Sum:
                    value = getSum();
                    break;
                case Count:
                    value = getCount();
                    break;
                case Minimum:
                    value = getMinimum();
                    break;
                case Maximum:
                    value = getMaximum();
                    break;
                default:
                    break;
            }
            return value;
        }

        private float getAvg()
        {
            return sum / (float) count;
        }

        private float getSum()
        {
            return sum;
        }

        private int getCount()
        {
            return count;
        }

        private float getMinimum()
        {
            return minimum;
        }

        private float getMaximum()
        {
            return maximum;
        }

        private MetricAggrFunction getAggrFunction()
        {
            return aggrFunc;
        }
    }

    /**
     * Helper class for a combined key in a HashMap.
     * 
     * @author Oliver
     *
     */
    class KeyMetricAggr
    {

        private final Metric metric;
        private final Element element;

        KeyMetricAggr(Metric metric, Element element)
        {
            this.metric = metric;
            this.element = element;
        }

        public Metric getMetric()
        {
            return metric;
        }

        public Element getElement()
        {
            return element;
        }

        @Override
        public int hashCode()
        {
            final int prime = 31;
            int result = 1;
            result = prime * result + getOuterType().hashCode();
            result = prime * result + ((element == null) ? 0 : element.hashCode());
            result = prime * result + ((metric == null) ? 0 : metric.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj)
        {
            if (this == obj)
            {
                return true;
            }
            if (obj == null)
            {
                return false;
            }
            if (getClass() != obj.getClass())
            {
                return false;
            }
            KeyMetricAggr other = (KeyMetricAggr) obj;
            if (!getOuterType().equals(other.getOuterType()))
            {
                return false;
            }
            if (element == null)
            {
                if (other.element != null)
                {
                    return false;
                }
            }
            else if (!element.equals(other.element))
            {
                return false;
            }
            if (metric == null)
            {
                if (other.metric != null)
                {
                    return false;
                }
            }
            else if (!metric.equals(other.metric))
            {
                return false;
            }
            return true;
        }

        private ImporterSonargraph getOuterType()
        {
            return ImporterSonargraph.this;
        }
    }

}
