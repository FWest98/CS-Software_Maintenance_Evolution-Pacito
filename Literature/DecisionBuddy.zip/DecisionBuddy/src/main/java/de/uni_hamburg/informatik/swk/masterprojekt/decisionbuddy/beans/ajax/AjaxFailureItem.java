package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax;

import java.io.Serializable;

/**
 * An instance of this class represents a single Failure in an AjaxFailure
 * object.
 *
 * @author schaak
 * 
 */
public class AjaxFailureItem implements Serializable
{
    private static final long serialVersionUID = 1L;

    private String errorCode;
    private Object[] errorArguments;
    private String errorMessage;
    private String errorFieldName;

    /**
     * Constructor to create an AjaxFailureItem.
     * 
     */
    public AjaxFailureItem()
    {
    }

    public String getErrorCode()
    {
        return errorCode;
    }

    public void setErrorCode(String errorCode)
    {
        this.errorCode = errorCode;
    }

    public Object[] getErrorArguments()
    {
        return errorArguments;
    }

    public void setErrorArguments(Object[] errorArguments)
    {
        this.errorArguments = errorArguments;
    }

    public String getErrorMessage()
    {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage)
    {
        this.errorMessage = errorMessage;
    }

    public String getErrorFieldName()
    {
        return errorFieldName;
    }

    public void setErrorFieldName(String errorFieldName)
    {
        this.errorFieldName = errorFieldName;
    }
}