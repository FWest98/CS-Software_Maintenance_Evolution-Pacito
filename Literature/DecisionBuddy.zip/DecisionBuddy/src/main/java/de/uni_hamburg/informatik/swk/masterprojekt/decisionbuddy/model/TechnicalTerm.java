package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class represents the TechnicalTerm table from the database.
 *
 * @author Tim
 *
 */
@Entity
@Table(name = "TechnicalTerm")
public class TechnicalTerm
{
    @Id
    @Column(name = "ID", nullable = false, unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Identifier", nullable = false, length = ColumnLength.SHORT)
    private String identifier;

    @Column(name = "Type", nullable = false, length = ColumnLength.SHORT)
    private String type;

    @Column(name = "Unit", nullable = true, length = ColumnLength.SHORT)
    private String unit;

    @Column(name = "requiredBy", nullable = false, length = ColumnLength.SHORT)
    private String requiredBy;

    @Column(name = "deliveredBy", nullable = false, length = ColumnLength.SHORT)
    private String deliveredBy;

    @OneToMany(mappedBy = "technicalTerm", cascade = { CascadeType.ALL }, orphanRemoval = true)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<StringValue> stringValues;

    /**
     * No-argument constructor.
     */
    public TechnicalTerm()
    {
        stringValues = new ArrayList<StringValue>();
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public String getIdentifier()
    {
        return identifier;
    }

    public void setIdentifier(String identifier)
    {
        this.identifier = identifier;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getUnit()
    {
        return unit;
    }

    public void setUnit(String unit)
    {
        this.unit = unit;
    }

    public String getRequiredBy()
    {
        return requiredBy;
    }

    public void setRequiredBy(String requiredBy)
    {
        this.requiredBy = requiredBy;
    }

    public String getDeliveredBy()
    {
        return deliveredBy;
    }

    public void setDeliveredBy(String deliveredBy)
    {
        this.deliveredBy = deliveredBy;
    }

    public List<StringValue> getStringValues()
    {
        return stringValues;
    }

    public void setStringValues(List<StringValue> stringValues)
    {
        this.stringValues = stringValues;
    }

    /**
     * Add a new stringvalue to this technicalterm.
     *
     * @param stringValue This stringValue is added to the list.
     */
    public void addStringValue(StringValue stringValue)
    {
        if (stringValues == null)
        {
            stringValues = new ArrayList<StringValue>();
        }
        stringValue.setTechnicalTerm(this);
        stringValues.add(stringValue);
    }

    /**
     * Removes a stringvalue from this technicalterm.
     *
     * @param stringvalue This stringvalue is removed from the list.
     */
    public void removeStringValue(StringValue stringValue)
    {
        if (stringValues != null)
        {
            stringValue.setTechnicalTerm(null);
            stringValues.remove(stringValue);
        }
    }

    @Override
    public int hashCode()
    {
        int result;
        if (getId() == null)
        {
            result = 0;
        }
        else
        {
            result = getId().hashCode();
        }
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        TechnicalTerm other = (TechnicalTerm) obj;
        if (other.getId() == null || this.getId() == null)
        {
            return false;
        }
        return other.getId().equals(this.getId());
    }

    @Override
    public String toString()
    {
        return id + "," + identifier + "," + type + "," + unit + "," + requiredBy + "," + deliveredBy + ","
                + stringValues;
    }
}
