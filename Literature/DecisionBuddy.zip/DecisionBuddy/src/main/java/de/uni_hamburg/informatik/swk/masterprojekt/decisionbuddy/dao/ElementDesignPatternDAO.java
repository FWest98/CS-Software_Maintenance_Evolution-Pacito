package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * A DAO class for DesignPattern.
 * 
 * @author Tim
 *
 */
public interface ElementDesignPatternDAO extends JpaRepository<ElementDesignPattern, Long>
{
	@Query("SELECT edp FROM ElementDesignPattern edp WHERE edp.project.id = ?1 AND edp.classPath = ?2 GROUP BY edp.solution, edp.classPath")
    List<ElementDesignPattern> findByProjectIdAndClassPath(Long projectId, String classPath);

	@Query("SELECT edp FROM ElementDesignPattern edp WHERE edp.project.id = ?1 AND edp.type = ?2 GROUP BY edp.solution, edp.classPath")
    List<ElementDesignPattern> findByProjectIdAndType(Long projectId, ElementType type);

    void deleteByProjectId(Long projectId);
}
