package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.analysisdata.designpattern;

import java.util.List;

import javassist.NotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementDesignPattern;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.ElementType;

/**
 * Service wrapping access to aggregated design patterns imported from PINOT.
 * 
 * @author 1fechner
 */
public interface DesignPatternComponentService
{
    /**
     * Returns all found design patterns associated with the element from the
     * given project and with the given name.
     * 
     * @param projectId The id of the project to be filtered by
     * @param classPath The classpath of the element to be filtered by
     * @return A List of entities from the table 'ElementDesignPattern'
     * @throws NotFoundException If the project does not exist
     */
    List<ElementDesignPattern> getDesignPatternsForElement(Long projectId, String classPath)
            throws NotFoundException;

    /**
     * Returns all design patterns for the given project, filtered by the given
     * type.
     * 
     * @param projectId The id of the project to be filtered by
     * @param type The type to be filtered by
     * @return A List of entities from the table 'ElementDesignPattern'
     * @throws NotFoundException If the project does not exist or the type does
     *             not exist
     */
    List<ElementDesignPattern> getDesignPatternsForProject(Long projectId, ElementType type)
            throws NotFoundException;
}
