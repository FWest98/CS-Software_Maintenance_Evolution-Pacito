package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricAggrFunction;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricSubType;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.analysisdata.MetricType;

/**
 * This Class represents the Metric table from the database.
 * 
 * @author Burak
 *
 */

@Entity
@Table(name = "Metric")
@Inheritance(strategy = InheritanceType.JOINED)
public class Metric
{
    @Id
    @GeneratedValue
    @Column(name = "ID")
    private Long id;

    @Column(name = "NameLangFile", nullable = false, length = ColumnLength.SHORT)
    private String nameLangFile;

    @Column(name = "NameXml", nullable = false, length = ColumnLength.SHORT)
    private String nameXml;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "Type")
    private MetricType type;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "SubType")
    private MetricSubType subType;

    @Column(name = "Order")
    private int order;

    @Column(name = "MinThreshold", nullable = true)
    private Float minThreshold;

    @Column(name = "MaxThreshold", nullable = true)
    private Float maxThreshold;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "AggrFunction", nullable = true)
    private MetricAggrFunction aggrFunction;

    /**
     * No-argument constructor.
     */
    public Metric()
    {

    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public String getNameLangFile()
    {
        return nameLangFile;
    }

    public void setNameLangFile(String nameLangFile)
    {
        this.nameLangFile = nameLangFile;
    }

    public String getNameXml()
    {
        return nameXml;
    }

    public void setNameXml(String nameXml)
    {
        this.nameXml = nameXml;
    }

    public MetricType getType()
    {
        return type;
    }

    public void setType(MetricType type)
    {
        this.type = type;
    }

    public void setSubType(MetricSubType subType)
    {
        this.subType = subType;
    }

    public MetricSubType getSubType()
    {
        return this.subType;
    }

    public int getOrder()
    {
        return order;
    }

    public void setOrder(int order)
    {
        this.order = order;
    }

    public Float getMinThreshold()
    {
        return minThreshold;
    }

    public void setMinThreshold(Float minThreshold)
    {
        this.minThreshold = minThreshold;
    }

    public Float getMaxThreshold()
    {
        return maxThreshold;
    }

    public void setMaxThreshold(Float maxThreshold)
    {
        this.maxThreshold = maxThreshold;
    }

    public MetricAggrFunction getAggrFunction()
    {
        return aggrFunction;
    }

    public void setAggrFunction(MetricAggrFunction aggrFunction)
    {
        this.aggrFunction = aggrFunction;
    }

    @Override
    public String toString()
    {
        return "ID:" + id + "," + "NameLangFile:" + nameLangFile + "," + "NameXml:" + nameXml + "," + "Type:" + type
                + "," + "SubType:" + subType + "," + "Order:" + order + "," + "MinThreshold:" + minThreshold + ","
                + "MaxThreshold:" + maxThreshold + "," + "AggrFunction:" + aggrFunction;
    }

    @Override
    public int hashCode()
    {
        int result = ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Metric other = (Metric) obj;
        return other.getId().equals(this.getId());
    }

}
