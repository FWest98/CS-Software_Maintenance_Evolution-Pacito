package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import java.beans.PropertyEditorSupport;

import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.RefactoringCategory;

/**
 * Property editor to convert an Id for a Refactoring category given as String
 * to an actual RefactoringCategory object and vice versa.
 * 
 * @author Tim
 *
 */
@Component
public class RefactoringCategoryEditor extends PropertyEditorSupport
{
    /**
     * Converts a RefactoringCategory id to a RefactoringCategory object.
     * 
     * @param id the id of the Refactoring category
     */
    @Override
    public void setAsText(String id)
    {
        RefactoringCategory fc = new RefactoringCategory();
        fc.setId(Long.valueOf(id));

        this.setValue(fc);
    }

    /**
     * Converts a RefactoringCategory object to an the id.
     * 
     * @return id of the Refactoring Category
     */
    @Override
    public String getAsText()
    {
        RefactoringCategory fc = (RefactoringCategory) this.getValue();
        String parsedId = String.valueOf(fc.getId());
        return parsedId;
    }
}