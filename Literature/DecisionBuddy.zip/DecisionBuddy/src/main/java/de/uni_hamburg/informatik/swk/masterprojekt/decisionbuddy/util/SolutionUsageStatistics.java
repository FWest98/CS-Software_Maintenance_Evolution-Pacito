package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao.SolutionCandidateDAO;

/**
 * Delivers functionality for calculating usage statistics of Solutions.
 * 
 * @author Vlad
 *
 */
@Component
public class SolutionUsageStatistics
{
    @Autowired
    private SolutionCandidateDAO solutionCandidateDAO;

    /**
     * empty constructor.
     */
    public SolutionUsageStatistics()
    {

    }

    /**
     * Calculates how often a Solution was selected as SolutionCandidate.
     * 
     * @param givenSolution the Solution.
     * @return the frequency.
     */
    public Long getOverallFrequency(Long solutionId)
    {
        return solutionCandidateDAO.countBySolutionId(solutionId);
    }

    /**
     * Calculates how often a Solution was selected as approved
     * SolutionCandidate.
     * 
     * @param givenSolution the Solution.
     * @return the frequency
     */
    public Long getApproved(Long solutionId)
    {
        return solutionCandidateDAO.countApprovedBySolutionId(solutionId);
    }

}
