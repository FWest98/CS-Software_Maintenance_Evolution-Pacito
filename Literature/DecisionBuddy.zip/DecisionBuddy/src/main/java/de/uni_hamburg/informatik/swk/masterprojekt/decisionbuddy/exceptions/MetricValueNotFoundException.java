package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a MetricValue is not found / does not
 * exist (anymore).
 * 
 * @author Burak
 *
 */
public class MetricValueNotFoundException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public MetricValueNotFoundException()
    {
        setExceptionType("metricvaluenotfound");
    }
}
