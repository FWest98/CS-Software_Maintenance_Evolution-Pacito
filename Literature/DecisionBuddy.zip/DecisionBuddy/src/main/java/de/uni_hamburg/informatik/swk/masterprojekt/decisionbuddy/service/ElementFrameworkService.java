package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementFrameworkNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.ElementFrameworkPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.ElementFramework;

/**
 * Overview of interfaces of class ElementFrameworkService.
 * 
 * @see architectural specification
 *
 * @author Burak
 *
 */
public interface ElementFrameworkService
{
    /**
     * Adds a given ElementFramework to the database.
     * 
     * @param ElementFramework the ElementFramework to be persisted
     * 
     * @return the saved ElementFramework object
     * 
     * @throws ElementFrameworkPersistenceException Exception if
     *             ElementFramework could not be persisted
     */
    ElementFramework saveElementFramework(ElementFramework elementFramework)
            throws ElementFrameworkPersistenceException;

    /**
     * Deletes all ElementFrameworks which belong to the specified project.
     * 
     * @param id the id of the project which ElementFrameworks should be deleted
     * 
     * @throws ElementFrameworkNotFoundException Exception if ElementFramework
     *             is not found
     */
    void deleteElementFrameworksByProjectId(long projectId) throws ElementFrameworkNotFoundException;
}
