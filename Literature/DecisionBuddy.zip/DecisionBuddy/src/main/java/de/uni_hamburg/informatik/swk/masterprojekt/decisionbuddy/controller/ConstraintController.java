package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.controller;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxFailure;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxFailureItem;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxResponse;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.beans.ajax.AjaxSuccess;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterFieldNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.SorterInvalidTypeException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermNotFoundException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions.TechnicalTermPersistenceException;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StaticEntities;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.StringValue;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.TechnicalTerm;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.service.TechnicalTermService;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.AuthorizationConstants;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ComparatorFactory;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.DateEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.HelperFunctions;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.IntegerEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.Paginator;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.TechnicalTermEditor;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation.TechnicalTermValidator;

/**
 * This controller is responsible for managing technical terms and string
 * values.
 * 
 * @author schaak
 *
 */
@Controller
@PreAuthorize(AuthorizationConstants.CONSTRAINT_READ)
@RequestMapping(value = "/constraint")
public class ConstraintController
{
    @Autowired
    private Paginator<TechnicalTerm> paginationHelper;

    @Autowired
    private TechnicalTermService technicalTermService;

    @Autowired
    private HelperFunctions helperFunctions;

    @Autowired
    private StaticEntities staticEntities;

    @Autowired
    private TechnicalTermValidator technicalTermValidator;

    @Autowired
    private MessageSource messageSource;

    /**
     * Called before binding between input and model fields.
     * 
     * @param binder the binder instance
     */
    @InitBinder
    private void initBinder(WebDataBinder binder)
    {
        // Integer <-> String
        binder.registerCustomEditor(Integer.class, new IntegerEditor());

        // TechnicalTerm <-> String
        binder.registerCustomEditor(TechnicalTerm.class, new TechnicalTermEditor());

        // Date <-> String
        binder.registerCustomEditor(Date.class, new DateEditor());
    }

    /******************************************************************
     * 
     * SHOW TECHNICAL TERMS
     * 
     *****************************************************************/

    /**
     * Shows a list of current technicalTerms.
     * 
     * @param page which page in technicalTerm list should be returned
     *            (optional)
     * @param pageSize how many technicalTerms should be shown (optional)
     * @param filter specifies if the technicalTerms should be filtered
     *            (optional)
     * @param sorter specifies how the technicalTerms should be sorted
     *            (optional)
     * 
     * @return view for listing technicalTerms.
     * @throws SorterFieldNotFoundException sorting field is not found
     * @throws SorterInvalidTypeException sorting field type is invalid
     */
    @RequestMapping(value = { "", "/", "/list" })
    public ModelAndView listOfTechnicalTerms(@RequestParam(value = "page", required = false) String page,
            @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "filter", required = false) String filter,
            @RequestParam(value = "sorter", required = false) String sorter) throws SorterFieldNotFoundException,
            SorterInvalidTypeException
    {
        ModelAndView constraintView = new ModelAndView("index");

        // show technicalTerms.jsp
        constraintView.addObject("jsp", "technicalterms");

        // get technicalTerms by sorting criteria
        Comparator<TechnicalTerm> technicalTermComparator = new ComparatorFactory<TechnicalTerm>(TechnicalTerm.class)
                .generateComparator(sorter);

        List<TechnicalTerm> processedTechnicalTerms = technicalTermService.getTechnicalTermsByCriteria(null,
                technicalTermComparator);

        // Configure pagination
        paginationHelper.configure(processedTechnicalTerms, pageSize, page);

        // model entries
        constraintView.addObject("technicaltermlist", paginationHelper.getPageList());
        constraintView.addObject("pagedListHolder", paginationHelper.getPagedListHolder());

        // get breadcrumbs and menu for action
        constraintView = helperFunctions.getBreadcrumbs("showtechnicalterms", constraintView);
        constraintView = helperFunctions.getMenu("showtechnicalterms", constraintView);

        return constraintView;
    }

    /******************************************************************
     * 
     * SHOW TECHNICAL TERM PROFILE
     * 
     *****************************************************************/

    /**
     * Shows a specific technicalTerm in profile view.
     * 
     * @param id ID of technicalTerm to be displayed.
     * @param previousModel needed to conserve bindingResult and validation of
     *            former stringValue
     * 
     * @return detailview of technicalTerm
     * 
     * @throws TechnicalTermNotFoundException exception if technicalTerm is not
     *             found
     * @throws SorterFieldNotFoundException sorting field is not found
     * @throws SorterInvalidTypeException sorting field type is invalid
     */
    @RequestMapping(value = "/technicalterm/{id}")
    public ModelAndView technicalTermProfile(@PathVariable Integer id, Model previousModel)
            throws TechnicalTermNotFoundException, SorterFieldNotFoundException, SorterInvalidTypeException
    {
        ModelAndView constraintView = new ModelAndView("index");

        // get technicalTerm from service
        TechnicalTerm technicalTerm = technicalTermService.getTechnicalTermById(id);

        // fill model
        constraintView.addObject("jsp", "addtechnicalterm");
        constraintView.addObject("viewmode", "view");
        constraintView.addObject("technicalterm", technicalTerm);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        constraintView = helperFunctions.getBreadcrumbs("technicaltermprofile", list, constraintView);

        // get menu for action
        constraintView = helperFunctions.getMenu("technicaltermprofile", list, constraintView);

        return constraintView;
    }

    /******************************************************************
     * 
     * ADD TECHNICAL TERM
     * 
     *****************************************************************/

    /**
     * Shows the mask for adding a new technicalTerm.
     * 
     * @param previousModel needed to conserve bindingResult and validation of
     *            former technicalTerm
     * 
     * @return view/mask for adding a technicalTerm
     * 
     * @throws TechnicalTermNotFoundException exception if technicalTerm is not
     *             found
     */
    @PreAuthorize(AuthorizationConstants.CONSTRAINT_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public ModelAndView addTechnicalTermPage(Model previousModel) throws TechnicalTermNotFoundException
    {
        TechnicalTerm technicalTerm;

        ModelAndView constraintView = new ModelAndView("index");

        // check if technicalTerm object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (previousModel.containsAttribute("technicalterm"))
        {
            technicalTerm = (TechnicalTerm) previousModel.asMap().get("technicalterm");
        }
        else
        {
            // default: no previous technicalTerm is available
            technicalTerm = new TechnicalTerm();
        }

        // fill model
        constraintView.addObject("jsp", "addtechnicalterm");
        constraintView.addObject("viewmode", "add");
        constraintView.addObject("technicalterm", technicalTerm);

        // get breadcrumbs for action
        constraintView = helperFunctions.getBreadcrumbs("addtechnicalterm", constraintView);

        // get menu for action
        constraintView = helperFunctions.getMenu("addtechnicalterm", constraintView);

        return constraintView;
    }

    /**
     * General method for adding a TechnicalTerm.
     * 
     * @param technicalTerm the technicalTerm object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex the desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to add a technicalTerm and shows a success/failure
     *         message.
     * 
     * @throws TechnicalTermPersistenceException exception if technicalTerm
     *             could not be saved
     * @throws TechnicalTermNotFoundException exception if technicalTerm could
     *             not be found
     * @throws SorterFieldNotFoundException exception if sorting field could not
     *             be found
     * @throws SorterInvalidTypeException exception if sorter has invalid type
     * 
     */
    @PreAuthorize(AuthorizationConstants.CONSTRAINT_WRITE)
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addingTechnicalTerm(@ModelAttribute("technicalTerm") TechnicalTerm technicalTerm,
            BindingResult bindingResult, @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws TechnicalTermPersistenceException, TechnicalTermNotFoundException,
            SorterFieldNotFoundException, SorterInvalidTypeException
    {
        // add requiredBy
        technicalTerm = addRequiredBy(technicalTerm);

        // validate technicalTerm
        technicalTermValidator.validate(technicalTerm, bindingResult);

        // determine if the technicalTerm is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs.addFlashAttribute("technicalterm", technicalTerm);
            redirectAttrs
                    .addFlashAttribute("org.springframework.validation.BindingResult.technicalterm", bindingResult);

            redirectAttrs.addFlashAttribute("tabindex", tabindex);
        }
        else
        {
            TechnicalTerm savedTechnicalTerm;

            // persist technicalTerm
            savedTechnicalTerm = technicalTermService.saveTechnicalTerm(technicalTerm);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "addtechnicalterm.success");

            List<String> params = new ArrayList<String>();
            params.add(savedTechnicalTerm.getIdentifier());
            params.add(String.valueOf(savedTechnicalTerm.getId()));
            redirectAttrs.addFlashAttribute("messageparams", params);
        }

        return "redirect:/constraint/add";
    }

    /******************************************************************
     * 
     * EDIT TECHNICAL TERM
     * 
     *****************************************************************/

    /**
     * Shows the mask for editing a technicalTerm. Generic method.
     * 
     * @param id the id of the technicalTerm to be edited
     * @param previousModel needed to conserve bindingResult and validation of
     *            former technicalTerm
     * 
     * @return view/mask for editing a technicalTerm
     * 
     * @throws TechnicalTermNotFoundException exception if technicalTerm is not
     *             found
     * @throws SorterFieldNotFoundException sorting field is not found
     * @throws SorterInvalidTypeException sorting field type is invalid
     */
    @PreAuthorize(AuthorizationConstants.CONSTRAINT_WRITE)
    @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
    public ModelAndView editTechnicalTermPage(@PathVariable Integer id, Model previousModel)
            throws TechnicalTermNotFoundException, SorterFieldNotFoundException, SorterInvalidTypeException
    {
        ModelAndView constraintView = new ModelAndView("index");

        // check if technicalTerm object already exists
        // important if redirected to this method after post to keep binding
        // errors
        if (!previousModel.containsAttribute("technicalterm"))
        {
            TechnicalTerm technicalTerm = technicalTermService.getTechnicalTermById(id);
            constraintView.addObject("technicalterm", technicalTerm);
        }

        // fill model
        constraintView.addObject("jsp", "addtechnicalterm");
        constraintView.addObject("viewmode", "edit");

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        constraintView = helperFunctions.getBreadcrumbs("edittechnicalterm", list, constraintView);

        // get menu for action
        constraintView = helperFunctions.getMenu("edittechnicalterm", list, constraintView);

        return constraintView;
    }

    /**
     * General method for editing a TechnicalTerm.
     * 
     * @param technicalTerm the technicalTerm object parsed from input fields
     * @param bindingResult contains information about parsing success
     * @param tabindex the desired tab
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return stays on mask to edit a technicalTerm and shows a success/failure
     *         message.
     * 
     * @throws TechnicalTermPersistenceException exception if technicalTerm
     *             could not be saved
     * @throws TechnicalTermNotFoundException exception if technicalTerm could
     *             not be found
     * @throws SorterFieldNotFoundException exception if sorting field could not
     *             be found
     * @throws SorterInvalidTypeException exception if sorter has invalid type
     * 
     */
    @PreAuthorize(AuthorizationConstants.CONSTRAINT_WRITE)
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public String editingTechnicalTerm(@ModelAttribute("technicalTerm") TechnicalTerm technicalTerm,
            BindingResult bindingResult, @RequestParam(value = "tabindex", required = false) String tabindex,
            RedirectAttributes redirectAttrs) throws TechnicalTermPersistenceException, TechnicalTermNotFoundException,
            SorterFieldNotFoundException, SorterInvalidTypeException
    {
        // add requiredBy
        technicalTerm = addRequiredBy(technicalTerm);

        // validate technicalTerm
        technicalTermValidator.validate(technicalTerm, bindingResult);

        // determine if the edited technicalTerm is valid
        if (bindingResult.hasErrors())
        {
            // fill redirect model
            redirectAttrs
                    .addFlashAttribute("org.springframework.validation.BindingResult.technicalterm", bindingResult);
        }
        else
        {
            // persist technicalTerm
            technicalTermService.saveTechnicalTerm(technicalTerm);

            // fill redirect model
            redirectAttrs.addFlashAttribute("messagestatus", "success");
            redirectAttrs.addFlashAttribute("messagecode", "edittechnicalterm.success");
        }

        // fill redirect model
        List<String> params = new ArrayList<String>();
        params.add(technicalTerm.getIdentifier());
        params.add(String.valueOf(technicalTerm.getId()));
        redirectAttrs.addFlashAttribute("messageparams", params);

        redirectAttrs.addFlashAttribute("technicalterm", technicalTerm);
        redirectAttrs.addFlashAttribute("tabindex", tabindex);

        redirectAttrs.addAttribute("id", technicalTerm.getId());
        return "redirect:/constraint/edit/{id}";
    }

    /**
     * Process of editing a TechnicalTerm inline. Triggers when TechnicalTerm is
     * edited inline.
     * 
     * @param technicalTerm the technicalTerm object parsed from input fields
     * @param bindingResult contains information about parsing success
     * 
     * @return an AjaxResponse object (AjaxSuccess or AjaxFailure)
     * 
     * @throws TechnicalTermPersistenceException exception if technicalTerm
     *             could not be saved
     * @throws TechnicalTermNotFoundException exception if technicalTerm could
     *             not be found
     * @throws SorterFieldNotFoundException exception if sorting field could not
     *             be found
     * @throws SorterInvalidTypeException exception if sorter has invalid type
     */
    @PreAuthorize(AuthorizationConstants.CONSTRAINT_WRITE)
    @RequestMapping(value = "/editinline", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AjaxResponse editingTechnicalTermInline(
            @ModelAttribute("technicalTerm") TechnicalTerm technicalTerm, BindingResult bindingResult)
            throws TechnicalTermPersistenceException, TechnicalTermNotFoundException, SorterFieldNotFoundException,
            SorterInvalidTypeException
    {
        // add requiredBy
        technicalTerm = addRequiredBy(technicalTerm);

        // validate technicalTerm
        technicalTermValidator.validate(technicalTerm, bindingResult);

        // determine if success or failure
        if (bindingResult.hasErrors())
        {
            Locale locale = LocaleContextHolder.getLocale();
            AjaxFailure ajaxFailure = new AjaxFailure();

            // parse every occured error into AjaxFailure object
            for (ObjectError error : bindingResult.getAllErrors())
            {
                AjaxFailureItem ajaxFailureItem = new AjaxFailureItem();

                ajaxFailureItem.setErrorCode(error.getCodes()[0]);
                ajaxFailureItem.setErrorArguments(error.getArguments());

                String message = "";
                try
                {
                    message = messageSource.getMessage(error.getCodes()[0], error.getArguments(), locale);
                }
                catch (NoSuchMessageException e)
                {
                }
                ajaxFailureItem.setErrorMessage(message);

                FieldError fieldError = (FieldError) error;

                ajaxFailureItem.setErrorFieldName(fieldError.getField());
                ajaxFailure.addAjaxFailureItem(ajaxFailureItem);
            }

            return ajaxFailure;
        }
        else
        {
            // change modification date and last modifier
            String modifierName = helperFunctions.createUsername();
            Date modificationDate = new Date();

            // persist technicalTerm
            technicalTermService.saveTechnicalTerm(technicalTerm);

            // return ajax success object
            AjaxSuccess ajaxSuccess = new AjaxSuccess();
            ajaxSuccess.setLastModifier(modifierName);
            Format format = new SimpleDateFormat("yyyy-MM-dd, HH:mm:ss");
            ajaxSuccess.setModificationDate(format.format((Date) modificationDate));

            return ajaxSuccess;
        }
    }

    /******************************************************************
     * 
     * DELETE TECHNICAL TERM
     * 
     *****************************************************************/

    /**
     * Shows a technicalTerm which is about to be deleted.
     * 
     * @param id ID of technicalTerm to be deleted
     * 
     * @return detailview of technicalTerm to be deleted
     * 
     * @throws TechnicalTermNotFoundException exception if technicalTerm is not
     *             found
     * @throws SorterFieldNotFoundException sorting field is not found
     * @throws SorterInvalidTypeException sorting field type is invalid
     */
    @PreAuthorize(AuthorizationConstants.CONSTRAINT_WRITE)
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public ModelAndView deleteTechnicalTermPage(@PathVariable Integer id) throws TechnicalTermNotFoundException,
            SorterFieldNotFoundException, SorterInvalidTypeException
    {
        ModelAndView constraintView = new ModelAndView("index");

        // get technicalTerm from service
        TechnicalTerm technicalTerm = technicalTermService.getTechnicalTermById(id);

        // fill model
        constraintView.addObject("jsp", "addtechnicalterm");
        constraintView.addObject("viewmode", "delete");
        constraintView.addObject("technicalterm", technicalTerm);

        // get breadcrumbs for action
        ArrayList<String> list = new ArrayList<String>();
        list.add(id.toString());
        constraintView = helperFunctions.getBreadcrumbs("deletetechnicalterm", list, constraintView);

        // get menu for action
        constraintView = helperFunctions.getMenu("deletetechnicalterm", list, constraintView);

        return constraintView;
    }

    /**
     * Deletes a technicalTerm.
     * 
     * @param id ID of technicalTerm to be deleted
     * @param redirectAttrs needed to save values during redirects
     * 
     * @return show technicalTerms view
     * 
     * @throws TechnicalTermNotFoundException exception if technicalTerm is not
     *             found
     */
    @PreAuthorize(AuthorizationConstants.CONSTRAINT_WRITE)
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.POST)
    public String deletingTechnicalTerm(@PathVariable Integer id, RedirectAttributes redirectAttrs)
            throws TechnicalTermNotFoundException
    {
        // delete technicalTerm
        technicalTermService.deleteTechnicalTerm(id);

        // fill redirect model
        redirectAttrs.addFlashAttribute("messagestatus", "success");
        redirectAttrs.addFlashAttribute("messagecode", "deletetechnicalterm.success");

        List<String> params = new ArrayList<String>();
        params.add(String.valueOf(id));
        redirectAttrs.addFlashAttribute("messageparams", params);

        return "redirect:/constraint/list";
    }

    /******************************************************************
     * 
     * HELPER METHODS
     * 
     *****************************************************************/

    /**
     * Helper method to ensure the opposite values in requiredBy / deliveredBy.
     * 
     * @param technicalTerm the technical term without requiredBy
     * 
     * @return the technicalTerm with requiredBy
     */
    public TechnicalTerm addRequiredBy(TechnicalTerm technicalTerm)
    {
        String requiredBy;
        String deliveredBy = technicalTerm.getDeliveredBy();

        if (deliveredBy != null && deliveredBy.equalsIgnoreCase("issue"))
        {
            requiredBy = "solution";
        }
        else if (deliveredBy != null && deliveredBy.equalsIgnoreCase("solution"))
        {
            requiredBy = "issue";
        }
        else
        {
            requiredBy = "solution";
            deliveredBy = "issue";
        }
        technicalTerm.setRequiredBy(requiredBy);
        technicalTerm.setDeliveredBy(deliveredBy);

        return technicalTerm;
    }

    /**
     * Assigns technical term types to model for populating drop down menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'technicaltermtypes' containing List of tt types
     */
    @ModelAttribute("technicaltermtypes")
    public Map<String, String> dropdownTechnicalTermTypes()
    {
        return staticEntities.getTechnicalTermTypes();
    }

    /******************************************************************
     * 
     * CONTROLBAR
     * 
     *****************************************************************/

    /**
     * Returns the sorting params to the view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'sortingParams' containing sorting keys & values
     */
    @ModelAttribute("sortingParams")
    public Map<String, String> sortingParams()
    {
        Map<String, String> sortingParams = new LinkedHashMap<String, String>();

        sortingParams.put("id", "id");
        sortingParams.put("identifier", "identifier");
        sortingParams.put("type", "type");
        sortingParams.put("requiredBy", "requiredBy");
        sortingParams.put("deliveredBy", "deliveredBy");

        return sortingParams;
    }

    /**
     * Configures the controlbar.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'controlbar' containing config
     */
    @ModelAttribute("controlbar")
    public Map<String, String> controlbarConfig()
    {
        Map<String, String> controlbar = new LinkedHashMap<String, String>();

        controlbar.put("filteringAllowed", "false");
        controlbar.put("sortingAllowed", "true");
        controlbar.put("pageSizeAllowed", "true");
        controlbar.put("paginationAllowed", "true");
        controlbar.put("modelName", "technicalTerm");

        return controlbar;
    }

    /******************************************************************
     * 
     * OTHER
     * 
     *****************************************************************/

    /**
     * Inline return of a list of string values for technical term id. Called
     * asynchronously.
     * 
     * @param id the id of the technical term
     * 
     * @return json object containing string values
     * 
     * @throws SorterFieldNotFoundException sorting field is not found
     * @throws SorterInvalidTypeException sorting field type is invalid
     * @throws TechnicalTermNotFoundException exception if tt is not found
     */
    @PreAuthorize(AuthorizationConstants.CONSTRAINT_WRITE)
    @RequestMapping(value = "/stringvalues/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody Map<String, String> proposeStringValues(@PathVariable Integer id)
            throws SorterInvalidTypeException, SorterFieldNotFoundException, TechnicalTermNotFoundException
    {
        return getStringValuesForTechnicalTerm(id);
    }

    /**
     * Helper function that returns string values for technical term id.
     * 
     * @param id id of tt
     * 
     * @return list of string values
     * 
     * @throws SorterFieldNotFoundException sorting field is not found
     * @throws SorterInvalidTypeException sorting field type is invalid
     * @throws TechnicalTermNotFoundException exception if tt is not found
     */
    private Map<String, String> getStringValuesForTechnicalTerm(Integer id) throws SorterInvalidTypeException,
            SorterFieldNotFoundException, TechnicalTermNotFoundException
    {
        Map<String, String> map = new LinkedHashMap<String, String>();
        List<StringValue> stringValues = technicalTermService.getTechnicalTermById(id).getStringValues();

        for (StringValue stringValue : stringValues)
        {
            map.put(stringValue.getId().toString(), stringValue.getStringValue());
        }

        return map;
    }

    /**
     * Assigns requiredBy/deliveredBy options to model for populating drop down
     * menu.
     * 
     * Executes before any RequestHandler.
     * 
     * @return Model attribute 'requireddeliveredby' containing list of options
     */
    @ModelAttribute("requireddeliveredby")
    public Map<String, String> dropdownRequiredDeliveredBy()
    {
        return staticEntities.getRequiredDeliveredBy();
    }

    /**
     * CSS-Styling: set constraint view as active view.
     * 
     * Executes before any RequestHandler.
     * 
     * @return String 'activeview' containing 'constraint'
     */
    @ModelAttribute("activeview")
    public String cssActiveView()
    {
        return "constraint";
    }
}