package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.validation;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.model.Refactoring;
import de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.util.ColumnLength;

/**
 * This Class validates a Refactoring.
 *
 * @author Tim
 *
 */
@Component
public class RefactoringValidator extends SolutionValidator implements Validator
{
    private static final String TYPE = "Refactoring";

    /**
     * Tests if the validator can validate the given object.
     * 
     * @param object an object to be validated
     * @return boolean if the object can be validated as a Refactoring
     */
    @Override
    public boolean supports(Class<?> object)
    {
        return (Refactoring.class).isAssignableFrom(object);
    }

    /**
     * Checks if a given refactoring object is considered valid.
     * 
     * @param object the given object
     * @param errors collects encountered field errors
     */
    @Override
    public void validate(Object object, Errors errors)
    {
        checkMandatoryFields(errors);
        checkMaxLength(errors);
        checkFormats(errors);

        validateConstraints(object, errors);
    }

    /**
     * Validates that fields are in the right format.
     * 
     * @param errors collects encountered field errors
     */
    private void checkFormats(Errors errors)
    {
        // Solution fields
        rejectIfStringInvalid(errors, "type", TYPE, ErrorCodes.INVALID);
    }

    /**
     * Validates that fields don't exceed max length.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMaxLength(Errors errors)
    {
        // Solution fields
        rejectIfStringTooLong(errors, "name", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "shortDescription", ColumnLength.DESCRIPTION, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "type", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "creator", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "lastModifier", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        // Specific fields
        rejectIfStringTooLong(errors, "badSmell", ColumnLength.SHORT, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "summary", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "mechanics", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
        rejectIfStringTooLong(errors, "examples", ColumnLength.MEDIUM, ErrorCodes.MAX_LENGTH);
    }

    /**
     * Validates that mandatory fields are not empty.
     * 
     * @param errors collects encountered field errors
     */
    private void checkMandatoryFields(Errors errors)
    {
        // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id",
        // ErrorCodes.REQUIRED_EC);
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", ErrorCodes.REQUIRED);
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "shortDescription", ErrorCodes.REQUIRED);
        // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "creator",
        // ErrorCodes.REQUIRED_EC);
        // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "creationDate",
        // ErrorCodes.REQUIRED_EC);
    }
}