package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.exceptions;

/**
 * An exception class that is thrown if a elementMetric is not found / does not
 * exist (anymore).
 * 
 * @author Burak
 *
 */
public class ElementMetricNotFoundException extends GeneralException
{
    private static final long serialVersionUID = 1L;

    /**
     * Constructor for Exception.
     */
    public ElementMetricNotFoundException()
    {
        setExceptionType("elementmetricnotfound");
    }
}
