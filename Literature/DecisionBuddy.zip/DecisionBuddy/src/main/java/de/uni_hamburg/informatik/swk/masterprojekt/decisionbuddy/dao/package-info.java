/**
 * This package contains the data access layer.
 */
package de.uni_hamburg.informatik.swk.masterprojekt.decisionbuddy.dao;