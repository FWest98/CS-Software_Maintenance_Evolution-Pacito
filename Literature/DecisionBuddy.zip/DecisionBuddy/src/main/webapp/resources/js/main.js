/**
 * Main javascript file for our application.
 * 
 * @author schaak
 */

$(document).ready(function() {

	/**************************************************************************
	* 
	*	GENERAL 
	*
	**************************************************************************/
	
	// toggle visibility of console.log statements
	var debug = true;
	
	// this function basically returns the object which is currently
	// managed in the mask, e. g. 'solution', 'project', 'issue' etc.
	function getObject() {
		var object;
		
		var solution = ($("#solution-tabs").size() > 0) ? 'true' : 'false';
		var project = ($("#project-tabs").size() > 0) ? 'true' : 'false';
		var issue = ($("#issue-tabs").size() > 0) ? 'true' : 'false';
		var technicalterm = ($("#technicalterm-tabs").size() > 0) ? 'true' : 'false';
		var user = ($("#user-tabs").size() > 0) ? 'true' : 'false';
		var rating = ($("#rating-tabs").size() > 0) ? 'true' : 'false';
		
		var result;
		if (solution == 'true') {
			result = 'solution';
		} else if (project == 'true') {
			result = 'project';
		} else if (issue == 'true') {
			result = 'issue';
		} else if (technicalterm == 'true') {
			result = 'technicalterm';
	    } else if(user == 'true'){
			result = 'user';
		} else if(rating == 'true'){
			result = 'rating';
		} else {
			result = 'unknown';
		}
		
		// console log for debugging
		if (debug) {
			console.log("object: " + result);
		}
		
		return result;
	}
	
	// this function returns the subobject which is currently managed
	// in the current tab, e. g. 'stringvalue', 'constraint' etc.
	function getSubObject() {
		var subobject;
		
		var constraint = ($("#tab-constraints").is(":visible")) ? 'true' : 'false';
		var solutioncandidate = ($("#tab-solution-candidates").is(":visible")) ? 'true' : 'false';
		var stringvalue = ($("#tab-stringvalues").is(":visible")) ? 'true' : 'false';
		var authority = ($("#tab-authorities").is(":visible")) ? 'true' : 'false';
		var recommendations = ($("#tab-recommendations").is(":visible")) ? 'true' : 'false';
		
		var result;
		if (constraint == 'true') {
			result = 'constraint';
		} else if (solutioncandidate == 'true') {
			result = 'solutioncandidate';
		} else if (stringvalue == 'true') {
			result = 'stringvalue';
		} else if (authority == 'true'){
			result = 'authority'
		} else if (recommendations == 'true') {
			result = 'recommendations';
		} else {
			result = null;
		}
		
		// console log for debugging
		if (debug) {
			console.log("subobject: " + result);	
		}
		
		return result;
	}	
	
	// selection model on data rows in listing table of objects
	// on click go to object profile page
	var $selectable = $(".object-row").hover(function(){
		$(this).addClass("row-hover");
	}, function(){
		$(this).removeClass("row-hover");
	}).click(function(){
		if ($(this).attr("data-href") != null) {
			window.document.location = $(this).attr("data-href");
		}
	});
		
	// language switcher 
	// advanced select list features for icon display
	 $.widget( "custom.iconselectmenu", $.ui.selectmenu, {
	      _renderItem: function(ul, item) {
	        var li = $("<li>", {
	        	text: item.label 
	        });
	 
	        if (item.disabled) {
	          li.addClass("ui-state-disabled");
	        }
	 
	        $("<span>", {
	          style: "background: url('" + ctx + "/resources/images/countries/" + item.element.attr("value") + ".gif') 0 0 no-repeat",
	          		 "class": "ui-icon"
	        }).appendTo( li );
	 
	        return li.appendTo(ul);
	      }
	 });
	 
	 $("#lang-switcher")
     .iconselectmenu({
    	 "change": function(event, ui) { 
    		 $("#lang-switcher").parents("form").submit(); 
          },
          "width" : "120",
     })
     .iconselectmenu("menuWidget")
     .addClass("countries");
	 
	// Output format switcher 
	// advanced select list features
	 $.widget( "custom.formatselect", $.ui.selectmenu, {
	      _renderItem: function(ul, item) {
	        var li = $("<li>", {
	        	text: item.label 
	        });

	        return li.appendTo(ul);
	      }
	 });
	 
	 $("#outputFormat")
     .formatselect({
          "width" : "120",
     });
	 
	 // every mask has to be shown in appropriate view mode
	 // modes = 'view', 'add', 'edit' or 'delete'
	 // mode variable is often needed throughout this file
	 var $form = $(".addobject-form");
	 var mode = $form.attr("data-viewmode");
	 
	 // star rating fields for documentation and support
	 var $doc_value = $("#documentation");
	 var $sup_value = $("#support"); 
	 
	 // tab mechanism
	 // active tab can be read from markup 
	 // object-tabs
	 var index = 'active-tab'
	 var dataStore = window.sessionStorage;
	 var oldIndex = 0;
	    try {
	        // getter: Fetch previous value
	        oldIndex = dataStore.getItem(index);
	    } catch(e) {}
		
	$(".object-tabs").tabs({
		active: oldIndex,
		activate: function(event,ui) {
			 var newIndex = ui.newTab.parent().children().index(ui.newTab);
	            //  Set future value
	            try {
	                dataStore.setItem( index, newIndex );
	            } catch(e) {}
		}
	});
	
	// subobject-tabs (in Profile of Solution)
	var indexx = 'active-tabx'
	var oldIndexx = 0;
	    try {
	        // getter: Fetch previous value
	        oldIndexx = dataStore.getItem(indexx);
	    } catch(e) {}
	    
	$(".subobject-tabs").tabs({
		active: oldIndexx,
		activate: function(event,ui) {
			 var newIndexx = ui.newTab.parent().children().index(ui.newTab);
	            //  Set future value
	            try {
	                dataStore.setItem( indexx, newIndexx );
	            } catch(e) {}
		}
	});
	
	// trigger submit on change in controlbar (bar for filtering, sorting, pagination)
	$("select", "#object-controlbar").change(function(){
		$("#object-controlbar-form").submit();
	});
	
	// switch theme 
	$("#theme-switcher img").not(".disabled").click(function(){
		window.document.location = "?theme=" + $(this).attr("data-href");
	});  
	
	// prevent submit of form on enter
	$form.on("keypress", "input,select,textarea", function(event) {
		 // 13 = enter key
		 if (event.which == 13) {
			event.preventDefault();
		 }		 
	 });
	
	// prevent " to be entered and break tooltips
	$("div").on("keypress", function(event) {
		 var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
		if (key.indexOf('"') > -1) {
			alert(key);
		   event.preventDefault();
		   return false;
		}
	});
	
	// some inline editing operations where markup is added interfere with spring naming scheme
	// fix field names by calling this function before submit
	$("#object-submit").click(function(){
		fixFieldNames();
	});
	
	// prevent multiple posts
	$("form").submit(function(){
		$(this).find("input[type=submit]").attr("disabled","disabled").css("cursor","default");
	});
	
	// pagination mechanism
	$("a[data-page]", "#pagination").click(function(){
		var page = $(this).attr("data-page");
		$("#objectpage").val(page).change();
	});
		
	// delete confirmation go back button
	$("#delete-goback").click(function(event){
		event.preventDefault();
		window.document.location = $("#delete-goback").attr("href");
	});
	
	 /**************************************************************************
	 * 
	 *	INLINE EDITING
	 *
	 **************************************************************************/	
	
	// enable / disabled inline editing
	var inlineEditingEnabled = true;
	
	// function for creating labels for input fields
	function createLabelsInput($inputFields) {
		
		 $inputFields.not("#documentation,#support,.weight,input[name=score],.star-value")
					 .not(".object-id")
					 .not("#object-submit")
					 .not("#object-controlbar input")
					 .not("input[type='checkbox']")
					 .not(".element-type")
					 .not("#constraint-proposal-click")
					 .not("#table-constraints .boss-row input")
					 .not(".richtext input")
					 .not("#tabindex")
					 .not("#stringValue").each(function(){
		 
			 // should this field be editable
			 var shouldBeEditable = !(
					 $(this).is("#creator,#creationDate,#lastModifier,#modificationDate,.lastModifier,.modificationDate") 
			 );
			 
			 // mark as editable
			 var editableLabel = "";
			 if (shouldBeEditable && inlineEditingEnabled) {
				$(this).addClass("editable-field editable-input"); 				 
				$(this).closest("td").addClass("editable-td editable-input");
				
				editableLabel = "editable-label editable-input";
			 }
			 	 
			 // update gui
			 $(this).hide();
			 var label = $(this).val();
			 $(this).after("<span class='read-only " + editableLabel + "'>" + label + "</span>");
		 }); 
	}
	
	// function for creating labels for textareas
	function createLabelsTextarea($textareaFields) {
		
		 $textareaFields.each(function(){
					 
			 // should this field be editable
			 var shouldBeEditable = !(
						 false
			 );
			 
			 // mark as editable
			var editableLabel = "";
			if (shouldBeEditable && inlineEditingEnabled) {
				$(this).addClass("editable-field editable-textarea");
				$(this).closest("td").addClass("editable-td editable-textarea");
				
				editableLabel = "editable-label editable-textarea";
			}		
			 
			// update gui
			 $(this).hide();
			 var label = $(this).find(".jqte_editor").html();
			 $(this).after("<div class='read-only " + editableLabel + "'>" + label + "</span>");
		 }); 
	}
	
	// function for creating labels for select lists
	function createLabelsSelect($selectLists) {
		
		 $selectLists.not("#object-controlbar select")
		 			 .not("select[name='constraintelement-comparator'].hidden")
		 			 .not("#qualityGoal")
		 			 .not("#technicalTerm").each(function(){
			 
			 // should this field be editable
			 var shouldBeEditable = !(
					 $(this).is("#catalog-solution-type")				
			 );
			 
			 // mark as editable
		 	 var editableLabel = "";
			 if (shouldBeEditable && inlineEditingEnabled) {
				$(this).addClass("editable-field editable-select");
				$(this).closest("td").addClass("editable-td editable-select");
				editableLabel = "editable-label editable-select";
			 }
		 			
			 // update gui
			 $(this).hide();
			 $(this).after("<span class='read-only read-only-selectlist " + editableLabel + "'>" + $("option:selected", $(this)).text() + "</span>");
		});
	}
	
	// this function is the heart of inline editing
	// executes an asynchronous call to controller
	// the $field variable is the input/textarea/select list, which triggered the call
	 function inlineEditingSubmit($field, $row) {
		
		 // some inline editing operations where markup is added interfere with spring naming scheme
		 // fix field names by calling this function before submit
		 fixFieldNames();
			
		 // for reverting the color change
 		 var oldColor = $field.closest("tr").css("backgroundColor");
 		 
		 // jquery ajax call
		 $.ajax({
		        url: $form.attr("action"),
		        data: $form.serialize(),
		        dataType: 'json',
		        type: 'POST',
		        error: function(error) {
		        	
		        	// red highlighting of row in case of error
		        	$field.closest("tr").animate({backgroundColor: '#DC143C'})
		        						.animate({backgroundColor: oldColor});
		        	
		        	// if call was a delete, abort delete action
		        	deleteFailed($row);
		        },
		        success: function(ajaxResponse) {
		        	
		        	// remove all previous error notifications
		        	$(".field-error-errortext").remove();
		        	$(".field-error-label").removeClass("field-error-label");
		        	$(".field-error-field").removeClass("field-error-field");
		        	
		        	if (ajaxResponse.type && ajaxResponse.type == "success"){
		        		
		        		// call has been successfull
		        		// remove previous error markup
			        	$("#error-box").remove();
			        	$(".dirty-png").remove();
			        	
		        		var $modificationDateField = $("#modificationDate");
		        		var $lastModifierField = $("#lastModifier");
		        		
		        		// update modificationDate and lastmodifier fields in mask
		        		// when they dont exist, statements will just be ignored
		        		$modificationDateField.val(ajaxResponse.modificationDate);
		        		$modificationDateField.next(".read-only").text(ajaxResponse.modificationDate);
		        		
		        		$lastModifierField.val(ajaxResponse.lastModifier);
		        		$lastModifierField.next(".read-only").text(ajaxResponse.lastModifier);
		        		
		        		// green highlighting of row indicates success
			        	$field.closest("tr")
			        		  .animate({backgroundColor: '#ADFF2F'})
							  .animate({backgroundColor: oldColor});	
			        	
			        	// if call was a delete, perform delete action
			        	deleteSuccessful($row);	
			        	
		        	} else {
		        		// the controller call was successful, but the controller response was an AjaxFailure
		        		// this happens for example when there was a validation error
		        		
		        		// also highlight the row red to indicate something went wrong
			        	$field.closest("tr").animate({backgroundColor: '#DC143C'})
											.animate({backgroundColor: oldColor});
			        	
			        	// insert a 'dirty flag' to values that could not be saved if not yet existing
			        	if (!$field.prev("span").hasClass("dirty-png")){
				        	$field.before("<span class='dirty-png'><img width='33px' height='33px' src='" + ctx + "/resources/images/dirty2.png" + "' /></span>");	
			        	}
			        	
			        	// prepare the errors that should be displayed
			        	var $errorList;
			        	
			        	if ($("#error-box").size() < 1) {
			        		var div = $("<div id='error-box'></div>");
			        		$form.prepend(div.html("<ul></ul>"));
			        	}
			        	
		        		$errorList = $("#error-box ul");

			        	$.each(ajaxResponse.ajaxFailureItems, function(index, item){
			        		
				        	var li = "<li><span class='field-error-errortext'>" + item.errorMessage + "</span></li>";
				        	
				        	$errorList.append(li);
				        	
				        	 $("label[for=" + item.errorFieldName +"]").addClass("field-error-label");
				        	 $("#" + item.errorFieldName).addClass("field-error-field");
			        	});	
			        	
			        	// if call was a delete, abort delete action
			        	deleteFailed($row);
		        	}
		        }
		   });	 
	 }
	 
	// define which input fields should be displayed as text
	var $inputFields = $("input", $form);
	 /**************************************************************************
	 * 
	 *	RICH TEXT EDITING
	 *
	 **************************************************************************/
	
	 // every textarea in the app should be a rich text editor
	 // note: activate as few options as necessary! Often unstable
	
	 // default config e. g. for displaying the textarea in a mask
	 var defaultConfig = {
			 b: true, 				// font-weight
		     i: true,				// italic
		     u: true,				// underline
			 br: true,				// new lines
			 center: false,			// justify center
			 left: false,			// justifiy left
			 right: false,			// justify right
			 color: true,			// color
			 fsize: false,			// font size
			 funit: "px",			// font size unit (px is default)
		     format: false,			// text format
		     indent: false,			// indent
		     outdent: false,		// outdent
		     link: true,			// hyperlink
		     unlink: false,			// removing hyperlinks
		     ol: true,				// ordered list
		     ul: true,				// unordered list
		     p: false,				// paragraph
		     remove: false,			// cleaner style
		     rule: true,			// horizontal rule
		     source: true,			// source field
		     sub: false,			// subscript
		     sup: false,			// superscript
		     strike: true,			// strike through
		     title: true,			// title   
	 };
	 
	 // restricted config e. g. for displaying the textarea value in a list
	 var restrictedConfig = {
			 b: true, 				// font-weight
		     i: true,				// italic
		     u: true,				// underline
			 br: true,				// new lines
			 center: false,			// justify center
			 left: false,			// justifiy left
			 right: false,			// justify right
			 color: true,			// color
			 fsize: false,			// font size
			 funit: "px",			// font size unit (px is default)
		     format: false,			// text format
		     indent: false,			// indent
		     outdent: false,		// outdent
		     link: false,			// hyperlink
		     unlink: false,			// removing hyperlinks
		     ol: false,				// ordered list
		     ul: false,				// unordered list
		     p: false,				// paragraph
		     remove: false,			// cleaner style
		     rule: false,			// horizontal rule
		     source: true,			// source field
		     sub: false,			// subscript
		     sup: false,			// superscript
		     strike: true,			// strike through
		     title: true,			// title     
	 };
	 
	 // define which text areas should be displayed as text and which should not
	 var $textareaFields = $("textarea", $form);
		
	 // shortDescription gets displayed in list -> restricted config
	 var $restrictedTextAreas = $("#shortDescription");
	 assignEditor($restrictedTextAreas, restrictedConfig);
	 
	 // other textares are displayed in profiles -> default config
	 assignEditor($textareaFields.not($restrictedTextAreas), defaultConfig);
	 
	 // reference to the original textarea
	 var $textareaFields = $textareaFields.closest(".jqte")	 
	 
	 // function to bind editor also to newly inserted elements
	 function assignEditor($textareas, config) {
		 $textareas.jqte(config);
	 }
	 
	 /**
	  * END OF RICH TEST EDITING
	  */
	 
	// define which select lists should be displayed as text and which should not
	var $selectLists = $("select", $form);
		 
	// Create 'readonly' mode, where above defined inputs, textareas and select lists
	// are hidden and their values are displayed like in a profile view
	if (mode == "view" || mode == "delete") {
			 
		// create read only values and insert hidden into DOM
		createLabelsInput($inputFields);
		createLabelsTextarea($textareaFields);
		createLabelsSelect($selectLists);

	 }
		 
	// Create the inline editing functionality only in view mode
	if (mode == 'view') {
		 
		 // hover over td to indicate inline editing possibility
		$form.on("mouseenter", ".editable-td", function(){	
			 $(this).addClass("td-inline-active");
		 }).on("mouseleave", ".editable-td", function(){	
			 $(this).removeClass("td-inline-active");
		});
				  
		 // inline editing for input labels
		 $form.on("click", ".editable-td.editable-input", function(event){	
			 
			 // one value per td or multiple
			 var fieldSize = $(this).find(".read-only").size();
			 var $label, execute = false;
			 
			 if (fieldSize < 2)
			 {
				$label = $(this).find(".read-only"); 
				execute = true;
			 }
			 else if ($(event.target).is(".read-only.editable-input"))
			 {
				 $label = $(event.target);
				 execute = true
			 }
			 else if ($(event.target).is(".unit"))
			 {
				// in case of constraint invalue, also allow click on unit to edit the int value
			 	$field = ($(event.target).is(".version")) ? $(event.target).nextAll("input:first") : $(event.target).prevAll("input:first");
			 	$label = $field.next(".read-only");
			 	execute = true;
			 }
			 
			 if (execute)
			 { 
				 var $field = $label.prev();
				 
				 $label.hide();
				 
				 // if the field loses focus, the action begins
				 $field.show().focus().blur(function(){
						
					 // only do ajax request if values differ
					 if ($label.text() != $field.val()) {
						 $label.text($field.val());
						 inlineEditingSubmit($field);
					 }
					 
					 $field.hide();
					 $label.show();
				 });
				 
				 // if user presses enter, also trigger the above mechanism
				 $field.keypress(function(event) {
					 // 13 = enter key
					 if (event.which == 13) {
						 $field.trigger("blur");
					 }
				 }); 
			 }
		 });		
		 
		 // textarea labels
		$form.on("click", ".editable-td.editable-textarea", function(event){
			
			 // one value per td or multiple
			 var fieldSize = $(this).find(".read-only").size();
			 var $label, execute = false;
			
			 if (fieldSize < 2)
			 {
				$label = $(this).find(".read-only"); 
				execute = true;
			 }
			 else if ($(event.target).is(".read-only.editable-textarea"))
			 {
				 $label = $(event.target);
				 execute = true;
			 }
			 
			 if (execute)
			 { 
				 var $field = $label.prev();
				 
				 // do nothing when user is just entering a link in jqte
				 var $linkbar = $field.find(".jqte_linkform");
				 
				 if ($linkbar.is(":hidden")) {
					 
					 $label.hide(); 
					 
					 // if the textare loses focus, the action begins
					 $field.show().find(".jqte_editor").focus().focus().blur(function(){
						if ($linkbar.is(":hidden")) {
							
							// only do ajax request if values differ
							if ($label.html() != $field.find(".jqte_editor").html()) {
								 var html = $field.find(".jqte_editor").html();
								 $label.html(html);
								 var $textarea = $field.find(".jqte_source textarea"); 
								 $textarea.text(html);
								 inlineEditingSubmit($textarea);
							}
							
							$field.hide();
						    $label.show();
						}
					 });
				 } 
			 }
		 });	
			 
		 // select list labels
		 $form.on("click", ".editable-td.editable-select", function(event){
			 
			 // one value per td or multiple
			 var fieldSize = $(this).find(".read-only").size();
			 var $label, execute = false;
			 
			 if (fieldSize < 2)
			 {
				$label = $(this).find(".read-only"); 
				execute = true;
			 }
			 else if ($(event.target).is(".read-only.editable-select"))
			 {
				 $label = $(event.target);
				 execute = true;
			 }
				 
			 if (execute)
			 { 
				 var $field = $label.prev();
				 
				 $label.hide();
				 
				 // if the select list changes, the action begins
				 $field.show().focus().blur(function(){
					 $field.hide();
					 $label.show();
				 }).change(function(){
						
					 var $selected= $field.find("option:selected");

					 // only do ajax request if values differ
					 if ($label.text() != $selected.text()) {
						 $label.text($selected.text());
						 inlineEditingSubmit($(this));
					 }
				 }); 
			 }
		 });		
	 }
	
	 /**************************************************************************
	 * 
	 *	CATALOG VIEW
	 *
	 **************************************************************************/
	 
	// autocomplete solution search
	$.widget( "custom.catcomplete", $.ui.autocomplete, {
		    _create: function() {
		      this._super();
		      this.widget().menu( "option", "items", "> :not(.ui-autocomplete-category)" );
		    },
		    _renderMenu: function( ul, items ) {
		      var that = this,
		        currentCategory = "";
		      $.each( items, function( index, item ) {
		        var li;
		        if ( item.solutionType != currentCategory ) {
		          ul.append( "<li class='ui-autocomplete-category'>" + item.solutionType + "</li>" );
		          currentCategory = item.solutionType;
		        }
		        li = that._renderItemData( ul, item );
		        if ( item.solutionType ) {
		          li.attr( "aria-label", item.solutionType + " : " + item.label );
		          li.attr("data-id", item.solutionId);
		        }
		     });
		   }
	});
	      
	// build data for quicksearch 
	var categorizedSolutionData = [];
	$("#categorized-solutions").find(".catsolution").each(function(){
		var $catsolution = $(this);
		categorizedSolutionData.push({
			label : $catsolution.find(".catlabel").text(),
			solutionId : $catsolution.find(".catid").text(),
			solutionType : $catsolution.find(".cattype").text()
		});
	});
	
	// suggests solutions that contain the entered string and leads to profile
	$("#searchsolution").catcomplete({
		delay: 0,
		source: categorizedSolutionData,
	    minLength: 1,
	    select: function( event, ui ) {
	    	window.document.location = ctx + "/catalog/solution/" + ui.item.solutionId;	
	    }
	});
   
	if (getObject() == 'solution' || getObject() == 'rating') {
			      
		 // solution type switcher
		 // used in mask for managing a solution to choose concrete subtype
		 // e. g. 'Framework'. Redirect to appropriate subtype page
		 $("#catalog-solution-type").change(function(){
			 var type = $(this).val();
			 
			window.document.location = ctx + "/catalog/add?type=" + type;	 
		 });
		 
		 // disable solution type
		 if (mode == "edit") {
			$("#catalog-solution-type").hide().after($("#catalog-solution-type").val());		
		 }
		  
		 // star plugin for documentation and support ratings:
		 //
		 // case 1: inline editing in profile view
		 // case 2: normal editing in editing view
		 // case 3: no editing 
		 var readOnlyStars, readOnlyRating, clickHandlerDoc, clickHandlerSup, clickHandlerRating;
		 
		 if (mode == "view" && inlineEditingEnabled) {
			 
			// 1. inline editing mode 
			readOnlyStars = false;
			readOnlyRating = true;
			
			clickHandlerDoc = function(score, evt) {
				if ($doc_value.val() != score) {
				    $doc_value.val(score);
				    inlineEditingSubmit($(this));
				} else {
				    $doc_value.val(score);	
				}
			};
			clickHandlerSup = function(score, evt) {
				if ($sup_value.val() != score) {
					$sup_value.val(score);
					 inlineEditingSubmit($(this));
				} else {
					$sup_value.val(score);
				}
			};
			
			// no inline editing for rating
			clickHandlerRating = function(score, evt) {
			}; 
		 } else if (mode == "edit" || mode == "add") {
			 
			// 2. editing mode
			readOnlyStars = readOnlyRating = false;
			
			clickHandlerDoc = function(score, evt) {
			    $doc_value.val(score);
			};
			clickHandlerSup = function(score, evt) {
			    $sup_value.val(score);
			};			
			clickHandlerRating = function(score, evt) {
			    $(this).nextAll(".star-value").val(score);
			};
			
		 } else {
			 
			// 3. non editing mode
			readOnlyStars = readOnlyRating = true;
			
			clickHandlerDoc = function(score, evt) {
			};
			clickHandlerSup = function(score, evt) {
			};
			clickHandlerRating = function(score, evt) {
			};
		 }
		 
		// actual star rating widget
		var ratyImages = ctx + "/resources/js/raty-2.6.0/lib/images/";
			
		var $documentation = $(".stars", "#stars-documentation").raty({
			score: $doc_value.val(),
			number: 5,
			readOnly: readOnlyStars,
			hints: ['not available', 'not helpful', 'average', 'good', 'superb'],
			target: '#stars-documentation .stars-hint',
			starOn: ratyImages + 'star-on.png',
			starOff: ratyImages + 'star-off.png',
			targetKeep: true,
			click: clickHandlerDoc
		});
			
		var support = $(".stars", "#stars-support").raty({
			score: $sup_value.val(),
			number: 5,
			readOnly: readOnlyStars,
			hints: ['not available', 'not helpful', 'average', 'good', 'superb'],
			target: '#stars-support .stars-hint',
			starOn: ratyImages + 'star-on.png',
			starOff: ratyImages + 'star-off.png',
			targetKeep: true,
			click: clickHandlerSup
		});		

		$(".stars", "#table-ratings").add(".stars", ".stars-overall").each(function(index){
			
			var $singleRating = $(this);
			var score, target;
			
			// on ratings listing the real ratings have to be displayed
			// on adding new rating 3 is default
			if ($singleRating.nextAll(".star-value").val() != '') {
				score = $singleRating.nextAll(".star-value").val();
				target = '';
			} else {
				score = 3;
				target = '.stars-overall .stars-hint';
			}
			
			$singleRating.raty({
				score: score,
				number: 5,
				readOnly: readOnlyRating,
				hints: ['not available', 'not helpful', 'average', 'good', 'superb'],
				target: target,
				starOn: ratyImages + 'star-on.png',
				starOff: ratyImages + 'star-off.png',
				targetKeep: true,
				click: clickHandlerRating
			});	
		});
		
		// only allow rating for quality goal OR property
		$("#property-select").click(function(){
			$(this).removeAttr("disabled");
			$("#qualitygoal-select").attr("disabled", "disabled");
		});
		
		$("#qualitygoal-select").click(function(){
			$(this).removeAttr("disabled");
			$("#property-select").attr("disabled", "disabled");
		});
	}
	 
	 /**************************************************************************
	 * 
	 *	CONSTRAINT VIEW
	 *
	 **************************************************************************/
	 
	if (getObject() == 'technicalterm') {
		
		var $typefield = $("#type", "#tab-technicalterm");
		
		// if technical term type is number, then deactivate stringvalues tab
		if ($typefield.val() == "int") {
			$(".object-tabs").tabs("disable", 1);
		}
		$typefield.change(function(event){
			if ($typefield.val() == "int") {
				$(".object-tabs").tabs("disable", 1);
			} else {
				$(".object-tabs").tabs("enable", 1);
			}
		});	
		
		// if technical term type is string, then deactivate unit field
		if ($typefield.val() == "string") {
			$("#unit").attr("disabled", "disabled");
		}
		$typefield.change(function(event){
			if ($typefield.val() == "string") {
				$("#unit").attr("disabled", "disabled");
			} else {
				$("#unit").removeAttr("disabled");
			}
		});		
		
		// button for adding stringvalue should only be active if input length > 0 
		$(".tempadd.stringvalue").attr("disabled","disabled").css("cursor","default");
		
		$("#stringValue").keyup(function(){
			if ($("#stringValue").val().trim().length > 0) {
				$(".tempadd.stringvalue").removeAttr("disabled").css("cursor","pointer");
			} else {
				$(".tempadd.stringvalue").attr("disabled","disabled").css("cursor","default");
			}
		});	
		
		 // if user presses enter on adding stringvalue, add stringvalue and dont send form
		 $("#stringValue").keypress(function(event) {
			 // 13 = enter key
			 if (event.which == 13) {
					$(".tempadd.stringvalue").trigger("click");
			 }
		 });
			
		// ADDING a new string value
		$(".tempadd.stringvalue").click(function(event){	
			
			var button = $(this);
			var originalEvent = event;
			
			// do not send form
			// event.preventDefault();	
			event.preventDefault();
					
			// config for ajax call to get row markup
			var data = { 
				'stringvalue' : $("#stringValue").val(),
				'technicalTermId' : $("#technicalterm-id").val(),
			};
			var url = ctx + "/markup/stringvalue";
			var $table = $("#table-stringvalues");
				
			insertNewRow(data,url,$table);
		}); 
		
		// DELETING an existing string value
		$form.on("click", ".tempdelete.stringvalue", function(event){	
			var button = $(this);
			
			// remove the row 
			var row = button.closest("tr");
			removeRow(row);
		});
	}
	
	 /**************************************************************************
	 * 
	 *	CONSTRAINT TABS
	 *
	 **************************************************************************/
	 
	if (getObject() == 'issue' || getObject() == 'solution') {
	    
		// hide & show int values upon checkbox for stringint constraint elements
		// "more specific" checkbox
	    $(".constraintelement-useint").each(function(){
	    	var $checkbox = $(this);
	    	var $intValue = $(this).nextAll(".intvalues").first();
	    	
	    	if ($checkbox.is(":checked")) {
	    		$intValue.removeClass("hidden");
	    	} else {
	    		$intValue.addClass("hidden");
	    	}
	    });
	    
		$form.on("change", ".constraintelement-useint", function(){	
			$box = $(this);
			$intvalues = $box.nextAll(".intvalues");
			
			if ($box.is(":checked")) {
				$intvalues.removeClass("hidden");
			} else {
				$intvalues.addClass("hidden");
				$intvalues.find("input:first").val("");
				$intvalues.find("input:first").next(".read-only").text("");
				
			}
			
			if (mode == 'view') {
				 inlineEditingSubmit($intvalues.find("input:first"));
			}
		});
		 
		// ADDING a new constraint
		$(".tempadd.constraint").click(function(event){	
			
			var button = $(event.currentTarget);
			
			// do not send form
			// event.preventDefault();	
			event.preventDefault();
							
			// config for ajax call to get row markup
			var data = {
					'technicaltermid' : $("#technicalTerm").val(), 
					'model' : getObject()
			};
			var url = ctx + "/markup/constraint";
			var $table = $("#table-constraints");
					
			insertNewRow(data,url,$table);
		}); 
		
		// ADDING a new constraint element
		$form.on("click", ".tempadd.constraint-element", function(event) {

			var button = $(event.currentTarget);
			console.log(button);
			
			// do not send form
			// event.preventDefault();	
			event.preventDefault();

			// config for ajax call to get row markup
			var data = {
					'technicaltermid' : $("#technicaltermid", button.closest(".sub-row").prev(".boss-row")).val(), 
					'constraintid' : $("#constraint-id", button.closest(".sub-row").prev(".boss-row")).val(),
					'model' : getObject(),
					'constraintindex' : button.closest(".sub-row").prev(".boss-row").attr("data-collection-id")
			};
			var url = ctx + "/markup/constraintelement";
			var $table = $(this).closest(".inner-table");
			
			insertNewRow(data,url,$table);	
		});
		
		// DELETING an existing constraint
		$form.on("click", ".tempdelete.constraint", function(event){	
			
			var button = $(event.currentTarget);
			
			// remove the row and constraint elements rows
			row = button.closest(".boss-row"); 
			row = row.add(row.next(".sub-row"));
			
			removeRow(row);
		});
		
		// DELETING an existing constraint element
		$form.on("click", ".tempdelete.constraint-element", function(event){	
			
			var button = $(event.currentTarget);
			
			// remove the row and constraint elements rows
			row = button.closest("tr");		
			removeRow(row);
		});	
		
		// on click -> edit mode with proposed constraints
		$("#constraint-proposal-click").click(function(event){
			event.preventDefault();
			window.document.location = $(this).closest("div").attr("data-href");
		});
	}

	/**************************************************************************
	 * 
	 *	USER VIEW
	 *
	 **************************************************************************/	
if (getObject() == 'user') {
		
		var $typefield = $("#username", "#tab-user");		
		
		// button for adding authority should only be active if input length > 0 
		$(".tempadd.user").attr("disabled","disabled").css("cursor","default");
		
		$("#authority").keyup(function(){
			if ($("#authority").val().trim().length > 0) {
				$(".tempadd.user").removeAttr("disabled").css("cursor","pointer");
			} else {
				$(".tempadd.user").attr("disabled","disabled").css("cursor","default");
			}
		});	
		
		 // if user presses enter on adding stringvalue, add stringvalue and dont send form
		 $("#stringValue").keypress(function(event) {
			 // 13 = enter key
			 if (event.which == 13) {
					$(".tempadd.user").trigger("click");
			 }
		 });
			
		// ADDING a new user
		$(".tempadd.user").click(function(event){	
			
			var button = $(this);
			var originalEvent = event;
			
			// do not send form
			// event.preventDefault();	
			event.preventDefault();
					
			// config for ajax call to get row markup
			var data = { 
				'authority' : $("#authority").val(),
				'userUsername' : $("#user-username").val(),
			};
			var url = ctx + "/markup/stringvalue";
			var $table = $("#table-authorities");
				
			insertNewRow(data,url,$table);
		}); 
		
		// DELETING an existing string value
		$form.on("click", ".tempdelete.user", function(event){	
			var button = $(this);
			
			// remove the row 
			var row = button.closest("tr");
			removeRow(row);
		});
	}
	
	/**************************************************************************
	 * 
	 *	RECOMMENDATION TAB
	 *
	 **************************************************************************/
	 
	if (getObject() == 'issue') {
		
		 // slider plugin for quality goal weightss:
		 //
		 // case 1: inline editing in profile view
		 // case 2: normal editing in editing view
		 // case 3: no editing 
		 var readOnly, slideHandler;
		 
		 if (mode == "view" && inlineEditingEnabled) {
			 
			// 1. inline editing mode 
			readOnly = false;
			slideHandler = function( event, ui ) {
				var $weight = $(this).next(".weight");
		        
				if ($weight.val() != ui.value) {
			        $(this).find(".ui-slider-handle").attr("title", ui.value);
			        $weight.val(ui.value);
			        inlineEditingSubmit($(this));
				} else {
			        $(this).find(".ui-slider-handle").attr("title", ui.value);
			        $weight.val(ui.value);
				}
			};
			
		 } else if (mode == "edit" || mode == "add") {
			 
			// 2. editing mode
			readOnly = false;
			slideHandler = function( event, ui ) {
		        $(this).find(".ui-slider-handle").attr("title", ui.value);
		        $(this).next(".weight").val(ui.value);
			};	 
		 } else {
			 
			// 3. non editing mode
			readOnly = true;
			slideHandler = function(event, ui) {
			};
		 }
			
		 // the actual slider plugin - also needs to apply to future dom elements
		 function attachSliders() {
			 $(".weight-slider").filter(function(){
				 return ($(this).slider("instance") == undefined) ? true : false;
			 }).slider({
					disabled: readOnly,
					stop: slideHandler,
					min: 0,
					max: 10,
					create: function( event, ui ) {
						var start = $(this).next(".weight").val();
						$(this).slider( "option", "value", start);
				        $(this).find(".ui-slider-handle").attr("title", start);
					}
			});
		 }
		 attachSliders();
		
		// updates the remaining choices for selecting quality goals
		function limitQualityGoals() {
			var $lists = $(".quality-select");
			var $selectedLists = $(".quality-selected");
			
			// enable all
			$("option", $lists).removeAttr("disabled");
			
			// disable the right ones
			$("option:selected", $selectedLists).each(function(){
				var $selected = $(this);
				
				$("option", $lists).not($selected).each(function(){
					var $option = $(this);
					
					if ($option.val() == $selected.val()) {
						$option.attr("disabled", "disabled");
						console.log("removed: selected: " + $option.val() + " because: " + $selected.val());
					} 
				});
			});
		}
		
		limitQualityGoals();
		$(".quality-selected").change(function(){
			limitQualityGoals();
			$("#qualityGoal").val("nochoice");
		});
			
		// ADDING a new quality goal
		$("#qualityGoal").change(function(event){
			
			if ($("option:selected", $(this)).val() != 'nochoice') {
				var select = $(event.currentTarget);
					
					// do not send form
					// event.preventDefault();	
					event.preventDefault();
		
					// config for ajax call to get row markup
					var data = {
							'issueid' : $("#issue-id").val(), 
							'qualitygoalid' : $("#qualityGoal").val(), 
					};
					var url = ctx + "/markup/qualitygoal";
					var $table = $("#table-qualitygoals");
					
					insertNewRow(data,url,$table);		
			}
		});
		
		// DELETING an existing quality goal
		$form.on("click", ".tempdelete.qualitygoal", function(event){	
			
			var button = $(event.currentTarget);
			
			// remove the row and constraint elements rows
			row = button.closest("tr");		
			removeRow(row);
		});	
		
		// ADDING a new solution candidate
		$(".tempadd.candidate").click(function(event){	
			
			var button = $(event.currentTarget);
			
			// do not send form
			// event.preventDefault();	
			event.preventDefault();
							
			// config for ajax call to get row markup
			var data = {
					'solutionid' : button.closest("tr").find(".solution-id").val(), 
					'decisionid' : $("#decision-id").first().val(),
					'solutionname' : button.closest("tr").find(".solution-id").next("span").text(),
					'solutiontype' : button.closest("tr").find(".solution-id").closest("td").next("td").text()
					
			};
			var url = ctx + "/markup/solutioncandidate";
			var $table = $("#table-solutioncandidates");
					
			insertNewRow(data,url,$table);
			
			// change button to 'added' flag
			button.addClass("hidden").next("span").removeClass("hidden");
		}); 

		// DELETING an existing solution candidate
		$form.on("click", ".tempdelete.candidate", function(event){	
			
			var button = $(event.currentTarget);
			
			// remove the row and constraint elements rows
			row = button.closest(".boss-row"); 
			row = row.add(row.next(".child-row"));
			
			removeRow(row);
			
			// change 'added' flag back to button
			var solutionId = button.closest(".boss-row").find(".solution-id").val(); 
			
			$(".solution-id", "#table-recommendations").each(function(){
				if ($(this).val() == solutionId) {
					// found the goal row
					$(this).closest("tr").find(".tempadd.candidate").removeClass("hidden").next("span").addClass("hidden");
				}
			});
		});
		
		// on start, determine which candidates are already added by showing the flag
		$(".solution-id", "#table-solutioncandidates").each(function(){
			var solutionId = $(this).val();
			
			$(".solution-id", "#table-recommendations").each(function(){
				if ($(this).val() == solutionId) {
					// found the goal row
					$(this).closest("tr").find(".tempadd.candidate").addClass("hidden").next("span").removeClass("hidden");
				}
			});

		});
		
		// managing the decision colors
		function updateDecisionColors(){
			$(".cand-status").each(function(){
				var status = $(this).find("option:selected", ".decision-state").first().text();
				$(this).removeClass("cand-status-approved")
					   .removeClass("cand-status-undecided")
					   .removeClass("cand-status-rejected");
				$(this).addClass("cand-status-" + status);
			});
		}
		updateDecisionColors();
		
		$form.on("change", ".cand-status", function(event) {
			updateDecisionColors();
		});
	}
	
	 /**************************************************************************
	 * 
	 *	MANAGING SUBOBJECTS
	 *
	 **************************************************************************/	

	// calls server side method for new markup, then adds it to the DOM
	function insertNewRow(data, url, $table) {
		
		// execute asynchronous call to controller to generate markup for a row
		// markup includes too many dynamic values to be constructed on frontend
		$.ajax({
            type: "GET",
            url: url,
            data: data,
            success: function(markup) {
				appendRow($table, markup);
            },
            failure: function () {
				appendRow("<span>failed</span>");
            }
        });   	
	}
	
	// does the actual appending into DOM
	function appendRow($table, data) {

		var $row;
		
		if ($table.is("#table-stringvalues"))
		{
			$table.append(data);
			$row = $table.find("tr:last");		
		}
		else if ($table.is(".inner-table"))
		{
			$table.find("tr:last").before(data);	
			$row = $table.find("tr[data-subcollection-id]:last");
		}
		else if ($table.is("#table-constraints")) 
		{
			$table.append(data);
			$row = $table.find("tr.boss-row:last");
		}
		else if ($table.is("#table-qualitygoals")) 
		{
			$table.append(data);
			$row = $table.find("tr.single-row:last");
			limitQualityGoals();
			attachSliders();
		}
		else if ($table.is("#table-solutioncandidates")) 
		{
			$table.append(data);
			$row = $table.find("tr.boss-row:last").add($table.find("tr.boss-row:last").next(".child-row"));
		}

		// reestablish jqte on textareas
		assignEditor($row.find("textarea"), defaultConfig);

		// inline editing in viewmode
		if (mode == 'view') {			
			inlineEditingSubmit($row.find("input:first"));			
			
			// create read only values and insert hidden into DOM
			createLabelsInput($row.find("input"));
			createLabelsTextarea($row.find("textarea").closest(".jqte"));
			createLabelsSelect($row.find("select"));
		}

		updateTableVisibility();
	}
	
	// does the removing/deleting of rows
	// sets the status to 'remove' so that it gets deleted by controller method
	// hides row in the gui to avoid further manipulation
	function removeRow($row) {	
		
		if (mode == 'view') {
			
			// mark that delete is in progress
			$row.addClass("deleteinprogress");
			
			// change names and ids , so that values are excluded 
			$row.find("input,select,textarea").andSelf().each(function(){
				$(this).data("savedname", $(this).attr("name"));
				$(this).attr("name", "old-" + $(this).attr("name"));
			});
			
			inlineEditingSubmit($row.find("input:first"), $row);
		} else {
			$row.remove();
			updateTableVisibility();		
		}
		limitQualityGoals();
	}
	
	// this function is called from a successful inline edit
	// waiting delete operations can now be performed
	function deleteSuccessful($row) {
		
		if ($($row).is(".deleteinprogress")) {
			// wait 1 second so that the user gets a green confirmation, before deleting item
			setTimeout(function(){
				$row.fadeOut(100, function() {
					$row.remove();
					updateTableVisibility();
				});
			}, 800);	
		}
	}
	
	// this function is called from a failed inline edit
	// delete operations have to be reverted
	function deleteFailed($row) {
		
		if ($row.is(".deleteinprogress")) {
			
			// include values of row in form request
			$row.find("input,select,textarea").andSelf().each(function(){
				$(this).attr("name", $(this).data("savedname"));
			});
			$row.removeClass("deleteinprogress");
		}
	}
	
	// inserting or deleting rows conflicts with springs naming mechanism
	// this function fixes this 
	function fixFieldNames() {
		
		$("table").each(function(){
			var $table = $(this);
			
			// for main tables
			var $trs = $("tr[data-collection-id]", $table).not(".deleteinprogress");
			
			$trs.each(function(index){
				var $tr = $(this);
				var number = $tr.attr("data-collection-id");
				$tr.attr("data-collection-id", index);
				$("[name*='" + number + "']", $tr).each(function(){
					$(this).attr("name", $(this).attr("name").replace("[" + number + "]", "[" + index + "]"));
				});

				// for childrows (like solution candidates)
				$("[name*='" + number + "']", $tr.next(".child-row")).each(function(){
					$(this).attr("name", $(this).attr("name").replace("[" + number + "]", "[" + index + "]"));
				});

				// for subrows (like constraint elements)
				var $subtrs = $tr.next(".sub-row").find("tr[data-subcollection-id]").not(".deleteinprogress");
				$subtrs.each(function(subindex){
					var $subtr = $(this);
					var subnumber = $subtr.attr("data-subcollection-id");
					$subtr.attr("data-subcollection-id", subindex);
					$("[name*='elements[" + subnumber + "]']", $subtr).each(function(){
						$(this).attr("name", $(this).attr("name").replace("constraints[" + number + "]", "constraints[" + index + "]"));
						$(this).attr("name", $(this).attr("name").replace("elements[" + subnumber + "]", "elements[" + subindex + "]"));
					});
				});				
			});		
		});
	}
	
	// this function determines if tables are shown or 'no elements available'
	// is shown depending on number of data trs
	function updateTableVisibility() {
		
		// for main tables
		$("table.list-table").each(function(){
			var $table = $(this);
			var rowCount = $table.find("tr[data-collection-id]").size();

			if (rowCount <= 0) {
					$table.prev(".notavailable").removeClass("hidden");	
					$table.addClass("hidden");
			} else {
					$table.prev(".notavailable").addClass("hidden");	
					$table.removeClass("hidden");
			}
		});
		
		// for sub tables
		$(".inner-table").each(function(){
			var $table = $(this);
			var rowCount = $table.find("tr[data-subcollection-id]").size();

			if (rowCount <= 0) {
					$table.prev(".elementsnotavailable").removeClass("hidden");	
			} else {
					$table.prev(".elementsnotavailable").addClass("hidden");	
			}
		});
		
	}
	
	
	
	 /**************************************************************************
	 * 
	 *	Upload in AddAnalysisData
	 *
	 **************************************************************************/	
	
	$("#addanalysisdata-form").submit(function() {
		$("#object-submit-div").html("");
		$("#object-submit-div").append("<img id='waitingForUploadGif' src='" + ctx + "/resources/images/waiting.gif' />");
	});
	
});