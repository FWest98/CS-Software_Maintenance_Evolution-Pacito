var _tableName = "metricstree"
var _additionalTableName = "table-metrics"
var _frameworkTableName = "table-frameworks"
var _patternsTableName = "table-patterns"

var _structuralError = "#structural-error";
var _strcuturalLoad = "#structural-load";

var _additionalError = "#additional-error";
var _additionalLoad = "#additional-load";
var _additionalSelection = "#additional-selection";

var _loadAnimationInterval = 800;

var _nodeSelected = -1

$(document).ready( function() {	
	$("#" + _tableName).treetable({ expandable: true });
	
	$(_structuralError).hide();
	$(_strcuturalLoad).hide();
	$(_additionalError).hide();
	$(_additionalLoad).hide();

	// Add on-click handler for each row to select
	$("#" + _tableName + " tbody").on("click", "tr", function() {
		$(".selected").not(this).removeClass("selected");
		$(this).toggleClass("selected");

		loadChildNodes($(this), this);
		loadAdditionalInformation($(this), this);
	});     

	// Load animation
	i = 0;
	setInterval(function() {
  		i = ++i % 4;
  		$(".loading").text(Array(i+1).join("."));
	}, _loadAnimationInterval);
});

/**
  * Load all child nodes for the given node
  * 
  * @param node The to be expanded in the treetable
  * 
  * @param dom The dom of the node to be extended
  */
function loadChildNodes(node, dom) {
	
	var nodeId = node.attr("data-tt-id");
	
	// Only if there was no data previously loaded for this node
	if (!node.is(".loaded"))
	{
		console.log("Getting children for node...");
		$(_strcuturalLoad).show();

		$.ajax({
			url: window.location.pathname + "/metrics/child",
			data: "id=" + nodeId,
			dataType: 'json',
			type: 'GET',
			success: function(data) {		
				// Hide last recent error and loading animation shown before
				$(_structuralError).hide();
				$(_strcuturalLoad).hide();

				$(dom).find("td:first").css('color','#000000');
				
			    // Get node to add children to
			    var node = $("#" + _tableName).treetable("node", nodeId);
			    
				for (var i = 0; i < data.nodes.length; i++) {
					// Get node to append nodes to 			 				    		
			    	var newNode = createNode(data.nodes[i]);
			    	
			    	// Expand branch with new node
			    	$("#" + _tableName).treetable("loadBranch", node, newNode);
				}
			    
			    // Indicate that this node had data loaded, so we don't need to send a second request if expanded again
				$(dom).addClass("loaded");
			},
			error: function(error) {
				console.log(error);
				console.log("Severe error; could not expand node");
				
				$(dom).find("td:first").css('color','#FF0000');

				// Hightlight row with error
				$(_structuralError).show();
				$(_strcuturalLoad).hide();
			}
		});	 
	}
};

/**
  * Create a new dom-string using the given data-object
  *
  * @param data Object containing the nodes data
  */
function createNode(data) {
	// console.log(data);

	var returnText;
	returnText = "<tr " +
					"class='" + data.expandability + "' " +
					"data-tt-id='" + data.id + "' " +
					"data-tt-classpath='" + data.path + "' " +
					"data-tt-parent-id='" + data.parent + "'" +
				">" +
				"<td><span class='" + data.type + "' /> " + 
				data.path.substr(data.path.lastIndexOf(".") + 1) + "</td>";
				
	for (var metricValue in data.metricValues) {
		returnText += "<td class='threshold" 
		+ data.metricValues[metricValue].thresh + "' title='"
		+ data.metricValues[metricValue].threshreason +"'>" 
		+ data.metricValues[metricValue].value  + "</td>";
	}
	returnText +=
      	"</tr>";
	return returnText;
};

/**
  * Load additional information for the given node
  * 
  * @param node The to be expanded in the treetable
  * 
  * @param dom The dom of the node to be extended
  */
function loadAdditionalInformation(node, dom) {
	var nodeId = node.attr("data-tt-id");
	var nodeClassPath = node.attr("data-tt-classpath");
	
	// Only if there was no data previously loaded for this node
	if (nodeId != _nodeSelected)
	{
		console.log("getting additional information for node...");
		$(_additionalLoad).show();

		$.ajax({
			url: window.location.pathname + "/metrics/additional",
			data: "id=" + nodeId + "&classpath=" + nodeClassPath,
			dataType: 'json',
			type: 'GET',
			success: function(data) {
				// if shown before
				$(_additionalError).hide();
				$(_additionalLoad).hide();
				
				// console.log(data);

			    // Change headline of additional panel
				$(_additionalSelection).text("(" + $(dom).find("td:first").text().trim() + ")");
				_nodeSelected = nodeId;
				
				// Set additional metrics
				setAdditionalMetrics(data.metrics);
				setAddtionalPatterns(data.patterns);
				setAdditionalFrameworks(data.frameworks);
							    
			},
			error: function(error) {
				console.log(error);
				console.log("Severe error; could not load additional information");
				
				$("#" + _additionalTableName).empty()
				$(_additionalError).show();
				$(_additionalLoad).hide();
			}
		});
	}
}

/**
  *
  * @param data Object containg the metrics
  */
function setAdditionalMetrics(data) {
	$("#table-metric-section").hide();

	if (data.length > 0) {		
		$("#table-metric-section").show();
		$("#" + _additionalTableName).empty().append(createAdditionalMetricTable(data));
	}
}

/**
  *
  * @param data Object containg the pattern
  */
function setAddtionalPatterns(data) {
	// Hide both pattern-panels first
	$("#table-patterns-file-section").hide();
	$("#table-patterns-package-section").hide();

	// If there is data
	if (data.length > 0 ){
		// Decide whether to display the header for files or for packackages
		if (data[0].type == "file")
		{
			$("#table-patterns-file-section").show();
			$("#" + _patternsTableName + "-element").empty().append(createAdditionalPatternTable(data, true));
		} else {
			$("#table-patterns-package-section").show();
			$("#" + _patternsTableName + "-package").empty().append(createAdditionalPatternTable(data, false));
		}

	}
}

/**
  *
  * @param data Object containg the frameworks
  */
function setAdditionalFrameworks(data) {
	$("#table-frameworks-section").hide();

	if (data.length > 0) {
		$("#table-frameworks-section").show();
		$("#" + _frameworkTableName).empty().append(createAdditionalFrameworkTable(data));
	}
	

}

/**
  * Create a new dom-string for the additional information table
  * using the given data-object
  *
  * @param data Object containing additional data
  */
function createAdditionalMetricTable(data) {
	var table = "";
		
	data.forEach(function(v) {
		table = table + "<tr>" 
		+ "<td>"+ v.name + " <img class='infoicon' alt='" + v.desc + "' title='" + v.desc + "' src='" + getContextPath() + "/resources/images/infoicon.png' /></td>"
		+ "<td class='threshold" + v.thresh 
		+ "'title='" + v.threshreason + "'>" 
		+ v.value 
		+ "</td></tr>";
	});
		
	return table;
}

/**
  * Returns a row for the additional framework table.
  * Data from data is inserted.
  *
  * @param data Object containing frameworks data
  */
function createAdditionalFrameworkTable(data) {
	var table = "";
		
	data.forEach(function(v) {

		table = table + "<tr>"
		+ "<td><a href='"+ getURLforElement(v) + "' target='_blank'>" + v.name + "</a>" 
		+ "</td></tr>";
	});
	
	return table;
}

/**
  * Returns a row for the additional pattern table. Data from data is inserted
  * @param data Object containing patterns data
  * @param setRole Whether the column for design pattern roles should be displayed or not
  */
function createAdditionalPatternTable(data, setRole) {
	var table = "";

	data.forEach(function(v) {
		table = table + "<tr>"
		+ "<td><a href='"+ getURLforElement(v) + "' target='_blank'>" + v.name + "</td>"
		+ (setRole ? "<td>" + v.role + "</td>" : "")
		+ "</tr>"
	});

	return table;
}

/**
  * Returns the URL contained in the current element. If the element is already in the catlog,
  * an referece to its ID is returned. If not, an external URL is returned
  *
  * @param elem The element containing the URL
  */
function getURLforElement(elem) {
	return (elem.inCatalog ? getContextPath() + "/catalog/solution/" + elem.url : elem.url);
}

/**
  * Returns the path of the current context. This is necessary for dynamic adding of pictures.
  */
function getContextPath() {
	return window.location.pathname.substring(0, window.location.pathname.indexOf("/",2));
}