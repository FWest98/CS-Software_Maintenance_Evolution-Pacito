spring data jpa
===============

This example builds uses Spring Data JPA with Java configuration files replaced the standard Spring MVC template XML files created by STS in Eclipse.  In addition, this code shows an end-to-end example of:

MySQL -> Hibernate -> Spring MVC -> JSP

The most interesting part is the StrategyRepository Interface which has no Impl class to it. The implementation is directly injected by Spring Data JPA.

This example has been validated with the following environment on MS Windows 7x64:

1. Eclipse Luna (4.4)
   1.1 Spring Tool Suite (STS) 3.6.0.RELEASE - for Luna
2. Java SDK 1.7.0_51 (separate install)
3. Tomcat 7.0.53 (separate install)
4. Maven 3.0.5 (separate install)
5. MySQL 5.5.37





Don't forget to connect VPN and port forwarding ;)